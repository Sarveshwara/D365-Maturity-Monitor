# Testhouse D365 Quality Assurance Maturity Platform

A comprehensive platform for managing QA maturity assessments, dashboards, artifacts, and intelligence for Microsoft Dynamics 365 projects.

## Quick Start

### Prerequisites
- Node.js 18+ ([Download](https://nodejs.org/))
- npm or pnpm

### Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Fix logo imports (IMPORTANT):**

Before running the app, you need to replace the Figma asset imports with actual logo files:

**Option A - Use Testhouse website logo:**
```tsx
// In src/app/components/Layout.tsx and src/app/components/auth/Login.tsx
// Replace:
import testhouseLogo from "figma:asset/0586510c8391c25311f2496a3dde183ca9bcb462.png";

// With:
const testhouseLogo = "https://www.testhouse.net/wp-content/uploads/2021/03/logo.png";
```

**Option B - Use local logo file:**
1. Download the Testhouse logo and save it to `public/logo.png`
2. Replace the import with:
```tsx
import testhouseLogo from "/logo.png";
```

3. **Start development server:**
```bash
npm run dev
```

4. **Open browser:**
Navigate to `http://localhost:5173/`

## Features

### 25 Comprehensive Screens:

**Dashboards (7 screens):**
- Program Dashboard - Project tracking and resource allocation
- Executive Dashboard - High-level KPIs and trends
- QA Maturity Dashboard - Domain scores and evolution
- DevOps Maturity Dashboard - CI/CD metrics
- Success by Design Dashboard - Implementation health
- Defect Intelligence Dashboard - Defect analytics
- Benchmarking Dashboard - Industry comparisons

**Assessments (5 screens):**
- Assessment Wizard - Guided assessment creation
- Domain Selection - Choose assessment areas
- Questionnaire - Interactive questions
- Assessment Review - Review and submit
- Assessment Results - Scores and insights

**Artifacts (3 screens):**
- Artifact Upload - Document management
- Artifact Integration - External tool connections
- Artifact Processing Status - Upload tracking

**Intelligence (4 screens):**
- Traceability Graph - Requirement linkages
- Test Impact Analysis - Change impact visualization
- Test Intelligence Workspace - AI-powered test generation
- Generated Test Viewer - Review AI tests

**Reports (2 screens):**
- Report Generator - Custom report creation
- Recommendations Center - Actionable insights

**Administration (3 screens):**
- User & Role Management - Access control
- Platform Settings - Configuration
- Notification Center - Alert management

**Auth (1 screen):**
- Login - SSO and standard authentication

## Tech Stack

- **React 18.3** - UI framework
- **TypeScript** - Type safety
- **Material UI 7.3** - Component library
- **React Router 7** - Navigation
- **Recharts** - Data visualization
- **Vite** - Build tool
- **Tailwind CSS 4** - Utility styling

## Project Structure

```
├── src/
│   ├── app/
│   │   ├── components/
│   │   │   ├── dashboards/      # Dashboard screens
│   │   │   ├── assessments/     # Assessment workflow
│   │   │   ├── artifacts/       # Artifact management
│   │   │   ├── intelligence/    # AI/ML features
│   │   │   ├── reports/         # Reporting tools
│   │   │   ├── admin/           # Admin screens
│   │   │   └── auth/            # Authentication
│   │   ├── App.tsx              # Main app component
│   │   └── routes.tsx           # Route configuration
│   └── styles/                  # Global styles
├── package.json
├── vite.config.ts
└── tsconfig.json
```

## Available Scripts

- `npm run dev` - Start development server (port 5173)
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Lint code

## Branding

**Color Scheme:**
- Primary: Navy Blue (#2B3E7E) - Testhouse brand color
- Secondary: Turquoise (#4DD4AC) - Accent color
- Background: Light Gray (#f5f7fa)

**Typography:**
- Font Family: Inter, Roboto, Helvetica Neue
- Headings: 600 weight
- Body: 400 weight

## Development Notes

### Mock Data
All screens use mock data for demonstration. Replace with real API calls:
- Dashboard metrics
- Assessment data
- Artifact uploads
- User management

### Authentication
Current login is mock-based (any credentials work). Integrate with:
- Azure AD
- Google OAuth
- Microsoft SSO

### Routing
Uses React Router 7 Data Mode with `react-router` package (not `react-router-dom`).

### Theme Customization
Edit `src/app/App.tsx` to customize Material UI theme:
```tsx
const theme = createTheme({
  palette: {
    primary: { main: "#2B3E7E" },
    secondary: { main: "#4DD4AC" },
  },
  // ... more customization
});
```

## Troubleshooting

**Issue: Module not found errors**
- Solution: Run `npm install` again
- Delete `node_modules` and `package-lock.json`, then reinstall

**Issue: figma:asset import errors**
- Solution: Replace with actual image files or URLs (see Installation step 2)

**Issue: TypeScript errors**
- Solution: Ensure TypeScript is installed: `npm install -D typescript`

**Issue: Port already in use**
- Solution: Vite will automatically use next available port

## Production Deployment

1. Build the application:
```bash
npm run build
```

2. The `dist/` folder contains production files

3. Deploy to:
   - Azure Static Web Apps
   - Vercel
   - Netlify
   - AWS S3 + CloudFront
   - Any static hosting service

4. Configure environment variables for:
   - API endpoints
   - Authentication providers
   - Feature flags

## License

Proprietary - Testhouse Ltd.

## Support

For issues or questions, refer to `SETUP_GUIDE.md` for detailed setup instructions.

---

**Version:** 1.0.0  
**Last Updated:** March 2026  
**Built with:** Figma Make
