import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";

import {
  apiRequest,
  login as apiLogin,
  register as apiRegister,
  logout as apiLogout,
  forgotPassword as apiForgotPassword,
  resetPassword as apiResetPassword,
  type AuthUser,
} from "../components/services/api";

// ─────────────────────────────────────────────────────────────
// Types
//
// UserRole/UserProfile used to live in supabase-client.ts. They're
// defined here now since this context talks to the Project Orbit
// backend directly, but the shape stays the same so nothing that
// consumes them needs to change.
// ─────────────────────────────────────────────────────────────

export type UserRole =
  | "super_admin"
  | "customer_admin"
  | "assessor"
  | "viewer"
  | "customer";

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  organization_id: string | null;
  role: UserRole;
  active: boolean;
  created_at: string;
}

function toProfile(user: AuthUser): UserProfile {
  return {
    id: user.id,
    email: user.email,
    full_name: user.name,
    organization_id: user.organizationId,
    role: user.role as UserRole,
    active: true,
    created_at: "",
  };
}

interface AuthContextValue {
  profile: UserProfile | null;

  /**
   * Alias for `profile`. Several existing components (DebugPanel,
   * PackageContext) read `user.id` / `user.email` — kept so those
   * didn't need to change during this migration.
   */
  user: UserProfile | null;

  role: UserRole;

  isLoading: boolean;

  isAuthenticated: boolean;

  isSuperAdmin: boolean;

  isCustomerAdmin: boolean;

  signIn: (
    email: string,
    password: string
  ) => Promise<{ error: string | null }>;

  signUp: (
    email: string,
    password: string,
    fullName: string
  ) => Promise<{ error: string | null }>;

  signOut: () => void;

  sendPasswordReset: (
    email: string
  ) => Promise<{ error: string | null }>;

  resetPassword: (
    token: string,
    newPassword: string
  ) => Promise<{ error: string | null }>;

  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  profile: null,
  user: null,
  role: "viewer",
  isLoading: true,
  isAuthenticated: false,
  isSuperAdmin: false,
  isCustomerAdmin: false,
  signIn: async () => ({ error: null }),
  signUp: async () => ({ error: null }),
  signOut: () => {},
  sendPasswordReset: async () => ({ error: null }),
  resetPassword: async () => ({ error: null }),
  refreshProfile: async () => {},
});

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}

export function AuthProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  /**
   * Loads the current user using whatever token is in localStorage
   * (project_orbit_token — see services/api.ts). Called on mount, and
   * again any time something needs a fresh copy (refreshProfile).
   */
  const loadProfile = useCallback(async () => {
    const token = localStorage.getItem("project_orbit_token");

    if (!token) {
      setProfile(null);
      return;
    }

    try {
      const data = await apiRequest<{ user: AuthUser }>("/auth/me");
      setProfile(toProfile(data.user));
    } catch (error) {
      console.error("[AuthContext] Failed to load profile:", error);
      // Token is invalid/expired — clear it so ProtectedRoute sends
      // the person back to /login instead of looping.
      apiLogout();
      setProfile(null);
    }
  }, []);

  useEffect(() => {
    (async () => {
      setIsLoading(true);
      await loadProfile();
      setIsLoading(false);
    })();
  }, [loadProfile]);

  const signIn = async (email: string, password: string) => {
    try {
      const data = await apiLogin(email, password);

      localStorage.setItem("project_orbit_token", data.token);
      localStorage.setItem("project_orbit_user", JSON.stringify(data.user));
      setProfile(toProfile(data.user));

      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Login failed") };
    }
  };

  const signUp = async (
    email: string,
    password: string,
    fullName: string
  ) => {
    try {
      const data = await apiRegister(fullName, email, password);

      localStorage.setItem("project_orbit_token", data.token);
      localStorage.setItem("project_orbit_user", JSON.stringify(data.user));
      setProfile(toProfile(data.user));

      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Sign up failed") };
    }
  };

  const signOut = () => {
    apiLogout();
    setProfile(null);
  };

  const sendPasswordReset = async (email: string) => {
    try {
      await apiForgotPassword(email);
      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Unable to send reset email") };
    }
  };

  const resetPassword = async (token: string, newPassword: string) => {
    try {
      await apiResetPassword(token, newPassword);
      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Unable to reset password") };
    }
  };

  const role: UserRole = profile?.role ?? "viewer";

  return (
    <AuthContext.Provider
      value={{
        profile,
        user: profile,
        role,
        isLoading,
        isAuthenticated: !!profile,
        isSuperAdmin: role === "super_admin",
        isCustomerAdmin:
          role === "customer_admin" || role === "super_admin",
        signIn,
        signUp,
        signOut,
        sendPasswordReset,
        resetPassword,
        refreshProfile: loadProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
