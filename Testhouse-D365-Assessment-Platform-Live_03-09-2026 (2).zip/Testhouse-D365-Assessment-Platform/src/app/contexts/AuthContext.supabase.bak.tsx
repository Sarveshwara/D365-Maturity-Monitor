import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback
} from "react";

import type {
  Session,
  User
} from "@supabase/supabase-js";

import {
  supabase,
  type UserProfile,
  type UserRole
} from "../lib/supabase-client";

interface BackendUser {
  id: string;
  organizationId: string | null;
  name: string;
  email: string;
  role: string;
}


interface AuthContextValue {

  session: Session | null;

  user: User | null;

  profile: UserProfile | null;

  role: UserRole;

  isLoading: boolean;

  isSuperAdmin: boolean;

  isCustomerAdmin: boolean;

  signIn: (
    email: string,
    password: string
  ) => Promise<{
    error: string | null
  }>;

  signInWithGoogle: () => Promise<{
    error: string | null
  }>;

  signOut: () => Promise<void>;

  sendPasswordReset: (
    email: string
  ) => Promise<{
    error: string | null
  }>;

  updatePassword: (
    newPassword: string
  ) => Promise<{
    error: string | null
  }>;

  refreshProfile: () => Promise<void>;
}


const AuthContext =
  createContext<AuthContextValue>({
    session: null,
    user: null,
    profile: null,
    role: "viewer",
    isLoading: true,
    isSuperAdmin: false,
    isCustomerAdmin: false,

    signIn: async () => ({
      error: null
    }),

    signInWithGoogle: async () => ({
      error: null
    }),

    signOut: async () => {},

    sendPasswordReset: async () => ({
      error: null
    }),

    updatePassword: async () => ({
      error: null
    }),

    refreshProfile: async () => {},
  });


export function AuthProvider({
  children
}: {
  children: React.ReactNode
}) {

  const [session, setSession] =
    useState<Session | null>(null);

  const [user, setUser] =
    useState<User | null>(null);

  const [profile, setProfile] =
    useState<UserProfile | null>(null);

  const [backendUser, setBackendUser] =
    useState<BackendUser | null>(null);

  const [isLoading, setIsLoading] =
    useState(true);


  /**
   * Fetch Supabase profile
   */
  const fetchProfile =
    useCallback(
      async (uid: string) => {

        const {
          data,
          error
        } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", uid)
          .maybeSingle();


        if (error) {

          console.error(
            "[AuthContext] Profile fetch failed:",
            error.message
          );

          return;

        }


        if (data) {

          console.log(
            "[AuthContext] Supabase profile loaded:",
            data
          );

          setProfile(
            data as UserProfile
          );

        }

      },
      []
    );


  /**
   * Refresh current Supabase profile
   */
  const refreshProfile =
    useCallback(
      async () => {

        if (user) {

          await fetchProfile(
            user.id
          );

        }

      },
      [
        user,
        fetchProfile
      ]
    );


  /**
   * Initialise authentication
   */
  useEffect(() => {

    const initialiseAuth =
      async () => {

        try {

          /**
           * FIRST:
           * Check Project Orbit backend JWT
           */
          const token =
            localStorage.getItem(
              "project_orbit_token"
            );

          const storedUser =
            localStorage.getItem(
              "project_orbit_user"
            );


          if (
            token &&
            storedUser
          ) {

            const parsedUser =
              JSON.parse(
                storedUser
              ) as BackendUser;


            console.log(
              "[AuthContext] Backend JWT session found:",
              parsedUser
            );


            setBackendUser(
              parsedUser
            );

            setIsLoading(false);

            return;

          }


          /**
           * SECOND:
           * Fall back to Supabase session
           */
          const {
            data: {
              session: supabaseSession
            }
          } =
            await supabase
              .auth
              .getSession();


          setSession(
            supabaseSession
          );

          setUser(
            supabaseSession?.user ??
            null
          );


          if (
            supabaseSession?.user
          ) {

            await fetchProfile(
              supabaseSession.user.id
            );

          }

        } catch (error) {

          console.error(
            "[AuthContext] Authentication initialization failed:",
            error
          );

        } finally {

          setIsLoading(false);

        }

      };


    initialiseAuth();


    /**
     * Listen for Supabase authentication changes
     */
    const {
      data: {
        subscription
      }
    } =
      supabase
        .auth
        .onAuthStateChange(
          async (
            _event,
            supabaseSession
          ) => {

            setSession(
              supabaseSession
            );

            setUser(
              supabaseSession?.user ??
              null
            );


            if (
              supabaseSession?.user
            ) {

              await fetchProfile(
                supabaseSession.user.id
              );

            } else {

              setProfile(null);

            }

          }
        );


    return () => {

      subscription.unsubscribe();

    };

  }, [
    fetchProfile
  ]);


  /**
   * Supabase sign in
   */
  const signIn =
    async (
      email: string,
      password: string
    ) => {

      const {
        error
      } =
        await supabase
          .auth
          .signInWithPassword({
            email,
            password
          });


      return {
        error:
          error?.message ??
          null
      };

    };


  /**
   * Google sign in
   */
  const signInWithGoogle =
    async () => {

      const {
        error
      } =
        await supabase
          .auth
          .signInWithOAuth({
            provider: "google",

            options: {
              redirectTo:
                `${window.location.origin}/`
            }

          });


      return {
        error:
          error?.message ??
          null
      };

    };


  /**
   * Sign out from BOTH systems
   */
  const signOut =
    async () => {

      /**
       * Clear backend JWT
       */
      backendLogout();


      /**
       * Clear local backend user
       */
      setBackendUser(
        null
      );


      /**
       * Sign out Supabase
       */
      await supabase
        .auth
        .signOut();


      setSession(
        null
      );

      setUser(
        null
      );

      setProfile(
        null
      );


      console.log(
        "[AuthContext] User signed out"
      );

    };


  /**
   * Password reset
   */
  const sendPasswordReset =
    async (
      email: string
    ) => {

      const {
        error
      } =
        await supabase
          .auth
          .resetPasswordForEmail(
            email,
            {
              redirectTo:
                `${window.location.origin}/reset-password`
            }
          );


      return {
        error:
          error?.message ??
          null
      };

    };


  /**
   * Update password
   */
  const updatePassword =
    async (
      newPassword: string
    ) => {

      const {
        error
      } =
        await supabase
          .auth
          .updateUser({
            password:
              newPassword
          });


      return {
        error:
          error?.message ??
          null
      };

    };


  /**
   * Determine active role.
   *
   * Backend login takes priority.
   */
  const role: UserRole =
    backendUser
      ? backendUser.role as UserRole
      : (
          profile?.role as UserRole
        ) ??
        "viewer";


  return (

    <AuthContext.Provider
      value={{

        session,

        user,

        profile,

        role,

        isLoading,

        isSuperAdmin:
          role === "super_admin",

        isCustomerAdmin:
          role === "customer_admin" ||
          role === "super_admin",

        signIn,

        signInWithGoogle,

        signOut,

        sendPasswordReset,

        updatePassword,

        refreshProfile,

      }}
    >

      {children}

    </AuthContext.Provider>

  );

}


export const useAuth =
  () => useContext(
    AuthContext
  );