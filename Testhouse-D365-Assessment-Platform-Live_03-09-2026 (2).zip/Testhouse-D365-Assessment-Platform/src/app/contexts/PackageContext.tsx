/**
 * PackageContext — dynamic package-based authorization
 *
 * Supports:
 *
 * Project Orbit Backend JWT
 *        ↓
 * user.organizationId
 *        ↓
 * customer_subscriptions
 *        ↓
 * assessment_packages
 *        ↓
 * accessible routes
 */

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";

import {
  supabase,
} from "../lib/supabase-client";

import {
  useAuth,
} from "./AuthContext";

import type {
  LoginUser,
} from "../services/api";

// ─────────────────────────────────────────────────────────────
// Package → Route Mapping
// ─────────────────────────────────────────────────────────────

export const PACKAGE_ROUTE_MAP:
  Record<
    string,
    string[]
  > = {

  QA_FULL: [
    "/assessment",
    "/qa-maturity",
    "/benchmarking",
  ],

  PERF: [
    "/performance",
    "/benchmarking",
  ],

  SEC: [
    "/security",
  ],

  AUTO: [
    "/assessment",
  ],

  DEVOPS: [
    "/devops-maturity",
    "/benchmarking",
  ],

};

// ─────────────────────────────────────────────────────────────
// All Assessment Routes
// ─────────────────────────────────────────────────────────────

const ALL_ASSESSMENT_ROUTES = [

  "/assessment",

  "/qa-maturity",

  "/performance",

  "/security",

  "/devops-maturity",

  "/benchmarking",

];

// ─────────────────────────────────────────────────────────────
// Always Accessible Routes
// ─────────────────────────────────────────────────────────────

const ALWAYS_ACCESSIBLE = [

  "/executive",

  "/success-by-design",

  "/defect-intelligence",

  "/artifacts",

  "/intelligence",

  "/reports",

  "/admin",

];

// ─────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────

export interface SubscribedPackage {

  package_code: string;

  package_name: string;

  color: string | null;

}

export interface PackageContextValue {

  orgId:
    string | null;

  orgName:
    string | null;

  subscribedPackages:
    SubscribedPackage[];

  accessibleRoutes:
    string[];

  isLoading:
    boolean;

  isSuperAdmin:
    boolean;

  overrideOrgId:
    string | null;

  organizations:
    Array<{
      id: string;
      name: string;
      code: string;
      customer_subscriptions?: any[];
    }>;

  switchOrg: (
    orgId:
      string | null
  ) => void;

  canAccess: (
    routePrefix:
      string
  ) => boolean;

  refresh:
    () => void;

}

// ─────────────────────────────────────────────────────────────
// Default Context
// ─────────────────────────────────────────────────────────────

const PackageContext =
  createContext<PackageContextValue>({

    orgId: null,

    orgName: null,

    subscribedPackages: [],

    accessibleRoutes: [],

    isLoading: true,

    isSuperAdmin: false,

    overrideOrgId: null,

    organizations: [],

    switchOrg: () => {},

    canAccess: () => true,

    refresh: () => {},

  });

// ─────────────────────────────────────────────────────────────
// Storage Key
// ─────────────────────────────────────────────────────────────

const STORAGE_ORG_KEY =
  "th_demo_org_id";

// ─────────────────────────────────────────────────────────────
// Helper
// ─────────────────────────────────────────────────────────────

function isBackendUser(
  user: any
): user is LoginUser {

  return (
    !!user &&
    "organizationId" in user &&
    "role" in user
  );
}

// ─────────────────────────────────────────────────────────────
// Package Provider
// ─────────────────────────────────────────────────────────────

export function PackageProvider({
  children,
}: {
  children:
    React.ReactNode;
}) {

  const {

    profile,

    user,

    isSuperAdmin,

    isAuthenticated,

  } =
    useAuth();

  // ─────────────────────────────────────────────────────────
  // State
  // ─────────────────────────────────────────────────────────

  const [
    subscribedPackages,
    setSubscribedPackages,
  ] =
    useState<
      SubscribedPackage[]
    >([]);

  const [
    accessibleRoutes,
    setAccessibleRoutes,
  ] =
    useState<
      string[]
    >([]);

  const [
    organizations,
    setOrganizations,
  ] =
    useState<any[]>([]);

  const [
    orgName,
    setOrgName,
  ] =
    useState<
      string | null
    >(null);

  const [
    isLoading,
    setIsLoading,
  ] =
    useState(true);

  // ─────────────────────────────────────────────────────────
  // Super Admin Org Override
  // ─────────────────────────────────────────────────────────

  const [
    overrideOrgId,
    setOverrideOrgId,
  ] =
    useState<
      string | null
    >(
      () =>
        localStorage.getItem(
          STORAGE_ORG_KEY
        )
    );

  // ─────────────────────────────────────────────────────────
  // Backend Organization ID
  // ─────────────────────────────────────────────────────────

  const backendOrgId =
    isBackendUser(user)
      ? user.organizationId
      : null;

  // ─────────────────────────────────────────────────────────
  // Effective Organization
  // ─────────────────────────────────────────────────────────

  const effectiveOrgId =
    isSuperAdmin
      ? (
          overrideOrgId ??
          null
        )
      : (
          profile?.organization_id ??
          backendOrgId ??
          null
        );

  // ─────────────────────────────────────────────────────────
  // Fetch Subscriptions
  // ─────────────────────────────────────────────────────────

  const fetchSubscriptions =
    useCallback(
      async (
        orgId:
          string | null
      ) => {

        // Super Admin without an org override
        if (!orgId) {

          setSubscribedPackages(
            []
          );

          setAccessibleRoutes(
            isSuperAdmin
              ? ALL_ASSESSMENT_ROUTES
              : []
          );

          setOrgName(
            null
          );

          return;
        }

        console.log(
          "[PackageContext] Loading subscriptions for:",
          orgId
        );

        const {
          data,
          error,
        } =
          await supabase
            .from(
              "customer_subscriptions"
            )
            .select(`
              assessment_packages (
                package_code,
                package_name,
                color
              )
            `)
            .eq(
              "organization_id",
              orgId
            )
            .eq(
              "active",
              true
            );

        if (
          error ||
          !data
        ) {

          console.error(
            "[PackageContext] Subscription fetch failed:",
            error
          );

          setSubscribedPackages(
            []
          );

          setAccessibleRoutes(
            isSuperAdmin
              ? ALL_ASSESSMENT_ROUTES
              : []
          );

          return;
        }

        // ───────────────────────────────────────────────────
        // Extract Packages
        // ───────────────────────────────────────────────────

        const packages:
          SubscribedPackage[] =
            data
              .map(
                (subscription: any) =>
                  subscription.assessment_packages
              )
              .filter(
                Boolean
              )
              .flat();

        setSubscribedPackages(
          packages
        );

        // ───────────────────────────────────────────────────
        // Build Accessible Routes
        // ───────────────────────────────────────────────────

        const routes =
          new Set<string>();

        for (
          const pkg
          of packages
        ) {

          const mapped =
            PACKAGE_ROUTE_MAP[
              pkg.package_code
            ] ?? [];

          mapped.forEach(
            (
              route
            ) =>
              routes.add(
                route
              )
          );
        }

        setAccessibleRoutes(
          [
            ...routes,
          ]
        );

        // ───────────────────────────────────────────────────
        // Fetch Organization Name
        // ───────────────────────────────────────────────────

        const {
          data: org,
        } =
          await supabase
            .from(
              "organizations"
            )
            .select(
              "name"
            )
            .eq(
              "id",
              orgId
            )
            .single();

        setOrgName(
          org?.name ??
          null
        );

      },
      [
        isSuperAdmin,
      ]
    );

  // ─────────────────────────────────────────────────────────
  // Fetch Organizations
  // Super Admin Only
  // ─────────────────────────────────────────────────────────

  const fetchOrgs =
    useCallback(
      async () => {

        if (
          !isSuperAdmin
        ) {
          return;
        }

        const {
          data,
          error,
        } =
          await supabase
            .from(
              "organizations"
            )
            .select(`
              id,
              name,
              code,

              customer_subscriptions (
                id,
                active,

                assessment_packages (
                  id,
                  package_code,
                  package_name,
                  color
                )
              )
            `)
            .order(
              "name"
            );

        if (error) {

          console.error(
            "[PackageContext] Organization fetch failed:",
            error
          );

          return;
        }

        setOrganizations(
          data ?? []
        );

      },
      [
        isSuperAdmin,
      ]
    );

  // ─────────────────────────────────────────────────────────
  // Refresh
  // ─────────────────────────────────────────────────────────

  const refresh =
    useCallback(
      async () => {

        setIsLoading(
          true
        );

        try {

          await Promise.all([

            fetchSubscriptions(
              effectiveOrgId
            ),

            fetchOrgs(),

          ]);

        } finally {

          setIsLoading(
            false
          );

        }

      },
      [

        fetchSubscriptions,

        fetchOrgs,

        effectiveOrgId,

      ]
    );

  // ─────────────────────────────────────────────────────────
  // Load Packages
  // ─────────────────────────────────────────────────────────

  useEffect(() => {

    // IMPORTANT:
    //
    // Previously this checked:
    //
    // if (!session)
    //
    // That prevented backend JWT users
    // from loading subscriptions.
    //
    // Now we check generic authentication.

    if (
      !isAuthenticated
    ) {

      setIsLoading(
        false
      );

      return;
    }

    refresh();

  }, [

    isAuthenticated,

    profile?.organization_id,

    backendOrgId,

    overrideOrgId,

    isSuperAdmin,

    refresh,

  ]);

  // ─────────────────────────────────────────────────────────
  // Switch Organization
  // ─────────────────────────────────────────────────────────

  const switchOrg =
    (
      orgId:
        string | null
    ) => {

      if (
        !isSuperAdmin
      ) {
        return;
      }

      setOverrideOrgId(
        orgId
      );

      if (orgId) {

        localStorage.setItem(
          STORAGE_ORG_KEY,
          orgId
        );

      } else {

        localStorage.removeItem(
          STORAGE_ORG_KEY
        );

      }

    };

  // ─────────────────────────────────────────────────────────
  // Access Check
  // ─────────────────────────────────────────────────────────

  const canAccess =
    (
      routePrefix:
        string
    ): boolean => {

      // Dashboard root
      if (
        routePrefix === "/"
      ) {
        return true;
      }

      // Always accessible areas
      if (
        ALWAYS_ACCESSIBLE.some(
          (
            route
          ) =>
            routePrefix.startsWith(
              route
            )
        )
      ) {
        return true;
      }

      // Super Admin without organisation override
      if (
        isSuperAdmin &&
        !overrideOrgId
      ) {
        return true;
      }

      // Check subscribed package routes
      return (
        accessibleRoutes.some(
          (
            route
          ) =>
            routePrefix.startsWith(
              route
            )
        )
      );

    };

  // ─────────────────────────────────────────────────────────
  // Current Organization
  // ─────────────────────────────────────────────────────────

  const currentOrg =
    organizations.find(
      (
        organization
      ) =>
        organization.id ===
        effectiveOrgId
    ) ??
    null;

  // ─────────────────────────────────────────────────────────
  // Provider
  // ─────────────────────────────────────────────────────────

  return (

    <PackageContext.Provider
      value={{

        orgId:
          effectiveOrgId,

        orgName:
          currentOrg?.name ??
          orgName,

        subscribedPackages,

        accessibleRoutes,

        isLoading,

        // Only unrestricted if Super Admin
        // and not impersonating another org
        isSuperAdmin:
          isSuperAdmin &&
          !overrideOrgId,

        overrideOrgId,

        organizations,

        switchOrg,

        canAccess,

        refresh,

      }}
    >

      {children}

    </PackageContext.Provider>

  );

}

// ─────────────────────────────────────────────────────────────
// Hook
// ─────────────────────────────────────────────────────────────

export const usePackage =
  () =>
    useContext(
      PackageContext
    );