import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Card, CardContent, Typography, Box, Button, LinearProgress, Chip, TextField, Divider, ToggleButtonGroup, ToggleButton,
} from "@mui/material";
import { ArrowForward, ArrowBack, CheckCircle } from "@mui/icons-material";
import {
  securityModules, scoreSecurityModule, getSecurityRiskTier, getPentestSignal,
  type SecurityResponse,
} from "../../data/securityQuestions";

const MODULE_COLORS: Record<string, string> = {
  APPSHIELD: "#0F6CBD",
  MOBILESHIELD: "#107C10",
  INFRASHIELD: "#8764B8",
  CLOUDSHIELD: "#038387",
};

const CRITICALITY_COLORS: Record<string, string> = {
  Critical: "#D83B01",
  High: "#E65C00",
  Medium: "#FFB900",
};

const RESPONSE_STYLES: Record<string, { color: string; bg: string; border: string }> = {
  Yes: { color: "#107C10", bg: "#E8FBF5", border: "#107C10" },
  Partial: { color: "#B8860B", bg: "#FFFBF0", border: "#FFB900" },
  No: { color: "#D83B01", bg: "#FFF0EE", border: "#D83B01" },
  "N/A": { color: "#666", bg: "#F5F5F5", border: "#BDBDBD" },
};

export default function SecurityQuestionnaire() {
  const navigate = useNavigate();
  const [moduleIdx, setModuleIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, SecurityResponse>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});

  const currentModule = securityModules[moduleIdx];
  const modColor = MODULE_COLORS[currentModule.id] ?? "#2B3E7E";
  const isLast = moduleIdx === securityModules.length - 1;

  const totalChecks = securityModules.reduce((s, m) => s + m.checks.length, 0);
  const answeredCount = Object.keys(answers).length;
  const moduleAnswered = currentModule.checks.filter((c) => answers[c.ref] != null).length;
  const allModuleAnswered = currentModule.checks.every((c) => answers[c.ref] != null);

  // Live score for current module
  const modScore = scoreSecurityModule(currentModule.id, answers);
  const modRisk = getSecurityRiskTier(modScore.score);

  const handleNext = () => {
    if (isLast) {
      navigate("/security/results", { state: { answers, notes } });
    } else {
      setModuleIdx(moduleIdx + 1);
      window.scrollTo(0, 0);
    }
  };

  return (
    <Box sx={{ maxWidth: 1100, mx: "auto" }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
          <Typography variant="h5" fontWeight={700} sx={{ color: modColor }}>
            Security Assessment Toolkit
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {answeredCount} of {totalChecks} checks completed
          </Typography>
        </Box>

        {/* Module tabs */}
        <Box sx={{ display: "flex", gap: 0.5, mb: 1.5, flexWrap: "wrap" }}>
          {securityModules.map((mod, i) => {
            const done = mod.checks.every((c) => answers[c.ref] != null);
            const active = i === moduleIdx;
            const col = MODULE_COLORS[mod.id] ?? "#2B3E7E";
            return (
              <Box key={mod.id} onClick={() => setModuleIdx(i)}
                sx={{
                  px: 1.5, py: 0.5, borderRadius: 2, cursor: "pointer", fontSize: "0.72rem", fontWeight: active ? 700 : 500,
                  border: `1px solid ${active ? col : done ? "#4DD4AC" : "#E0E4EC"}`,
                  bgcolor: active ? col : done ? "#E8FBF5" : "#F7F9FF",
                  color: active ? "white" : done ? "#107C10" : "text.secondary",
                  transition: "all 0.15s", "&:hover": { opacity: 0.85 },
                  display: "flex", alignItems: "center", gap: 0.5,
                }}>
                {done && !active && <CheckCircle sx={{ fontSize: 12 }} />}
                {mod.icon} {mod.name}
              </Box>
            );
          })}
        </Box>

        <LinearProgress variant="determinate" value={(answeredCount / totalChecks) * 100}
          sx={{ height: 4, borderRadius: 2, bgcolor: "#E8ECF4" }} />
        <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: "block" }}>
          Module {moduleIdx + 1} of {securityModules.length} — {currentModule.name} ({currentModule.label})
        </Typography>
      </Box>

      <Box sx={{ display: "flex", gap: 3, alignItems: "flex-start" }}>
        {/* Main checks panel */}
        <Box sx={{ flex: "1 1 0", minWidth: 0 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", borderRadius: 3, mb: 2 }}>
            <CardContent sx={{ p: 3 }}>
              {/* Module header */}
              <Box sx={{
                display: "flex", alignItems: "center", gap: 1.5, mb: 2.5, p: 2, borderRadius: 2,
                bgcolor: `${modColor}0D`, border: `1px solid ${modColor}30`,
              }}>
                <Typography variant="h2" sx={{ lineHeight: 1 }}>{currentModule.icon}</Typography>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="subtitle1" fontWeight={800} sx={{ color: modColor }}>{currentModule.name}</Typography>
                  <Typography variant="caption" color="text.secondary">{currentModule.description}</Typography>
                </Box>
                <Box sx={{ textAlign: "right", flexShrink: 0 }}>
                  <Typography variant="caption" color="text.secondary">Module Progress</Typography>
                  <Typography variant="h6" fontWeight={800} sx={{ color: modColor }}>
                    {moduleAnswered}/{currentModule.checks.length}
                  </Typography>
                </Box>
              </Box>

              {/* Response legend */}
              <Box sx={{ display: "flex", gap: 1, mb: 2.5, flexWrap: "wrap" }}>
                {(["Yes", "Partial", "No", "N/A"] as const).map((r) => {
                  const s = RESPONSE_STYLES[r];
                  return (
                    <Box key={r} sx={{ display: "flex", alignItems: "center", gap: 0.5, px: 1, py: 0.3, borderRadius: 1, bgcolor: s.bg, border: `1px solid ${s.border}` }}>
                      <Typography variant="caption" fontWeight={700} sx={{ color: s.color }}>{r}</Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ fontSize: "0.6rem" }}>
                        {r === "Yes" ? "= 2pts" : r === "Partial" ? "= 1pt" : r === "No" ? "= 0pts" : "= excl."}
                      </Typography>
                    </Box>
                  );
                })}
              </Box>

              {/* Checks */}
              {currentModule.checks.map((check, ci) => {
                const critCol = CRITICALITY_COLORS[check.criticality];
                const answered = answers[check.ref];
                return (
                  <Box key={check.ref} sx={{ mb: 3 }}>
                    <Box sx={{ display: "flex", gap: 1.5, mb: 1.5 }}>
                      <Box sx={{
                        flexShrink: 0, width: 26, height: 26, borderRadius: "50%",
                        bgcolor: answered != null ? modColor : "#E0E4EC",
                        color: answered != null ? "white" : "text.secondary",
                        display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7rem", fontWeight: 700,
                      }}>
                        {ci + 1}
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Box sx={{ display: "flex", gap: 1, mb: 0.8, flexWrap: "wrap" }}>
                          <Chip label={check.ref} size="small"
                            sx={{ bgcolor: `${modColor}18`, color: modColor, fontWeight: 700, fontSize: "0.65rem" }} />
                          <Chip label={check.criticality} size="small"
                            sx={{ bgcolor: `${critCol}18`, color: critCol, fontWeight: 700, fontSize: "0.65rem" }} />
                        </Box>
                        <Typography variant="body2" fontWeight={600} sx={{ mb: 0.8, lineHeight: 1.5 }}>
                          {check.check}
                        </Typography>
                        <Box sx={{ p: 1.5, mb: 1.5, borderRadius: 1.5, bgcolor: "#F7F9FF", border: "1px solid #E8ECF4" }}>
                          <Typography variant="caption" color="text.secondary" sx={{ fontStyle: "italic" }}>
                            <strong>What to look for:</strong> {check.whatToLookFor}
                          </Typography>
                        </Box>

                        {/* Yes / Partial / No / N/A toggle */}
                        <ToggleButtonGroup
                          value={answered ?? null}
                          exclusive
                          onChange={(_, val) => {
                            if (val !== null) setAnswers((prev) => ({ ...prev, [check.ref]: val as SecurityResponse }));
                          }}
                          size="small"
                          sx={{ flexWrap: "wrap", gap: 0.5 }}
                        >
                          {(["Yes", "Partial", "No", "N/A"] as const).map((opt) => {
                            const s = RESPONSE_STYLES[opt];
                            const sel = answered === opt;
                            return (
                              <ToggleButton key={opt} value={opt}
                                sx={{
                                  px: 2, py: 0.6, borderRadius: "8px !important", border: `1.5px solid ${sel ? s.border : "#E0E4EC"} !important`,
                                  bgcolor: sel ? s.bg : "white", color: sel ? s.color : "text.secondary",
                                  fontWeight: sel ? 800 : 500, fontSize: "0.78rem",
                                  "&.Mui-selected": { bgcolor: s.bg, color: s.color },
                                  "&:hover": { bgcolor: s.bg, borderColor: `${s.border} !important` },
                                }}>
                                {opt}
                              </ToggleButton>
                            );
                          })}
                        </ToggleButtonGroup>

                        <TextField fullWidth size="small" multiline rows={1}
                          label="Notes / evidence (optional)"
                          placeholder="Add context or evidence for this response…"
                          value={notes[check.ref] ?? ""}
                          onChange={(e) => setNotes((prev) => ({ ...prev, [check.ref]: e.target.value }))}
                          sx={{ mt: 1.5, "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
                        />
                      </Box>
                    </Box>
                    {ci < currentModule.checks.length - 1 && <Divider sx={{ mt: 2 }} />}
                  </Box>
                );
              })}
            </CardContent>
          </Card>

          {/* Navigation */}
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Button variant="outlined" startIcon={<ArrowBack />}
              onClick={() => { setModuleIdx(Math.max(0, moduleIdx - 1)); window.scrollTo(0, 0); }}
              disabled={moduleIdx === 0}>
              Previous Module
            </Button>
            <Button variant="contained" endIcon={<ArrowForward />}
              onClick={handleNext}
              sx={{ bgcolor: modColor, "&:hover": { bgcolor: `${modColor}CC` }, minWidth: 160 }}>
              {isLast ? "View Results" : "Next Module"}
            </Button>
          </Box>
        </Box>

        {/* Right panel — live scoring */}
        <Box sx={{ flexShrink: 0, width: 260 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", borderRadius: 3, position: "sticky", top: 80 }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>Live Module Score</Typography>

              {/* Score ring */}
              <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
                <Box sx={{ position: "relative", width: 90, height: 90 }}>
                  <svg width="90" height="90" style={{ transform: "rotate(-90deg)" }}>
                    <circle cx="45" cy="45" r="38" fill="none" stroke="#E8ECF4" strokeWidth="8" />
                    <circle cx="45" cy="45" r="38" fill="none"
                      stroke={modRisk.color} strokeWidth="8"
                      strokeDasharray={`${2 * Math.PI * 38}`}
                      strokeDashoffset={`${2 * Math.PI * 38 * (1 - modScore.score / 100)}`}
                      strokeLinecap="round"
                      style={{ transition: "stroke-dashoffset 0.4s ease" }}
                    />
                  </svg>
                  <Box sx={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
                    <Typography variant="h5" fontWeight={900} sx={{ color: modRisk.color }}>{modScore.score.toFixed(0)}</Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1 }}>/100</Typography>
                  </Box>
                </Box>
              </Box>

              {/* Risk badge */}
              <Box sx={{ textAlign: "center", mb: 2, px: 1.5, py: 1, borderRadius: 2, bgcolor: `${modRisk.color}15`, border: `1px solid ${modRisk.color}40` }}>
                <Typography variant="caption" fontWeight={800} sx={{ color: modRisk.color }}>{modScore.score === 0 && modScore.answered === 0 ? "NOT STARTED" : `${modRisk.tier} — ${modRisk.label}`}</Typography>
              </Box>

              {/* Module stats */}
              <Box sx={{ mb: 2 }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.5 }}>
                  <Typography variant="caption" color="text.secondary">Answered</Typography>
                  <Typography variant="caption" fontWeight={700}>{modScore.answered}</Typography>
                </Box>
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.5 }}>
                  <Typography variant="caption" color="text.secondary">Skipped (N/A)</Typography>
                  <Typography variant="caption" fontWeight={700}>{modScore.skipped}</Typography>
                </Box>
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.5 }}>
                  <Typography variant="caption" color="text.secondary">Critical Gaps</Typography>
                  <Typography variant="caption" fontWeight={700} sx={{ color: modScore.criticalGaps > 0 ? "#D83B01" : "text.primary" }}>{modScore.criticalGaps}</Typography>
                </Box>
                <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                  <Typography variant="caption" color="text.secondary">Pentest Signal</Typography>
                  <Typography variant="caption" fontWeight={700} sx={{ color: modRisk.color }}>{modScore.answered > 0 ? getPentestSignal(modScore.score) : "—"}</Typography>
                </Box>
              </Box>

              <Divider sx={{ mb: 2 }} />

              {/* All modules progress */}
              <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ display: "block", mb: 1 }}>
                All Modules
              </Typography>
              {securityModules.map((mod, i) => {
                const ms = scoreSecurityModule(mod.id, answers);
                const col = MODULE_COLORS[mod.id] ?? "#2B3E7E";
                const pct = Math.round((mod.checks.filter((c) => answers[c.ref] != null).length / mod.checks.length) * 100);
                return (
                  <Box key={mod.id} sx={{ mb: 1 }}>
                    <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.2 }}>
                      <Typography variant="caption" sx={{ color: col, fontWeight: i === moduleIdx ? 700 : 400 }}>
                        {mod.icon} {mod.name}
                      </Typography>
                      <Typography variant="caption" fontWeight={700} color="text.secondary">{pct}%</Typography>
                    </Box>
                    <LinearProgress variant="determinate" value={pct}
                      sx={{ height: 4, borderRadius: 2, bgcolor: "#E8ECF4", "& .MuiLinearProgress-bar": { bgcolor: col } }} />
                  </Box>
                );
              })}
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Box>
  );
}
