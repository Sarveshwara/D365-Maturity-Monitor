import { useNavigate } from "react-router";
import { Card, CardContent, Typography, Box, Button, Grid, Chip } from "@mui/material";
import { Shield, Lock, CloudQueue, PhoneAndroid, Computer, PlayArrow, Assignment, Schedule, BarChart, Warning, CheckCircle, TrendingUp } from "@mui/icons-material";
import { securityModules } from "../../data/securityQuestions";

const MODULE_COLORS: Record<string, string> = {
  APPSHIELD: "#0F6CBD",
  MOBILESHIELD: "#107C10",
  INFRASHIELD: "#8764B8",
  CLOUDSHIELD: "#038387",
};

const MODULE_ICONS: Record<string, React.ReactNode> = {
  APPSHIELD: <Computer sx={{ fontSize: 22 }} />,
  MOBILESHIELD: <PhoneAndroid sx={{ fontSize: 22 }} />,
  INFRASHIELD: <Lock sx={{ fontSize: 22 }} />,
  CLOUDSHIELD: <CloudQueue sx={{ fontSize: 22 }} />,
};

const RISK_STATS = [
  { icon: <Warning sx={{ color: "#D83B01", fontSize: 22 }} />, label: "43%", sublabel: "of breaches exploit known unpatched vulnerabilities" },
  { icon: <TrendingUp sx={{ color: "#D83B01", fontSize: 22 }} />, label: "$4.45M", sublabel: "Average cost of a data breach (IBM 2023)" },
  { icon: <CheckCircle sx={{ color: "#107C10", fontSize: 22 }} />, label: "277 days", sublabel: "Average time to identify + contain a breach" },
  { icon: <Shield sx={{ color: "#FFB900", fontSize: 22 }} />, label: "82%", sublabel: "Breaches involve human element or misconfiguration" },
];

const RISK_TIERS = [
  { tier: "CRITICAL", range: "0–39%", color: "#D83B01", bg: "#FFF0EE", desc: "Severe gaps. Pentest strongly recommended. Immediate action." },
  { tier: "HIGH", range: "40–59%", color: "#E65C00", bg: "#FFF5F0", desc: "Significant weaknesses. Pentest recommended urgently." },
  { tier: "MEDIUM", range: "60–74%", color: "#FFB900", bg: "#FFFBF0", desc: "Moderate risk. Pentest advisable before next release." },
  { tier: "LOW", range: "75–89%", color: "#4CAF50", bg: "#F0FBF2", desc: "Good posture with minor gaps. Targeted pentest suggested." },
  { tier: "SECURE", range: "90–100%", color: "#107C10", bg: "#E8FBF5", desc: "Strong controls. Pentest for validation / compliance." },
];

export default function SecurityAssessment() {
  const navigate = useNavigate();
  const totalChecks = securityModules.reduce((s, m) => s + m.checks.length, 0);

  return (
    <Box sx={{ maxWidth: 1000, mx: "auto" }}>
      {/* Hero */}
      <Box sx={{
        background: "linear-gradient(135deg, #1A0A2E 0%, #2D1B5E 55%, #6B3FBE 100%)",
        borderRadius: 3, p: { xs: 3, md: 5 }, mb: 4, color: "white", position: "relative", overflow: "hidden",
      }}>
        <Box sx={{ position: "absolute", top: -30, right: -30, width: 200, height: 200, borderRadius: "50%", bgcolor: "rgba(107,63,190,0.2)" }} />
        <Box sx={{ position: "absolute", bottom: -50, right: 120, width: 130, height: 130, borderRadius: "50%", bgcolor: "rgba(107,63,190,0.12)" }} />

        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2 }}>
          <Shield sx={{ fontSize: 32, color: "#A78BFA" }} />
          <Chip label="Security Assessment Toolkit" size="small"
            sx={{ bgcolor: "rgba(167,139,250,0.2)", color: "#A78BFA", fontWeight: 700, border: "1px solid rgba(167,139,250,0.4)" }} />
        </Box>

        <Typography variant="h3" fontWeight={800} sx={{ mb: 1.5, lineHeight: 1.2 }}>
          Security Testing<br />Need Assessment
        </Typography>
        <Typography variant="body1" sx={{ opacity: 0.85, maxWidth: 580, mb: 4, lineHeight: 1.7 }}>
          A structured checklist-based security readiness review across four modules — AppShield, MobileShield, InfraShield, and CloudShield. Generates a scored risk posture report and pentest recommendation.
        </Typography>

        <Box sx={{ display: "flex", gap: 4, flexWrap: "wrap", mb: 4 }}>
          {[
            { icon: <Assignment sx={{ fontSize: 18 }} />, label: `${totalChecks} Security Checks` },
            { icon: <Schedule sx={{ fontSize: 18 }} />, label: "~25 Minutes" },
            { icon: <BarChart sx={{ fontSize: 18 }} />, label: "4 Shield Modules" },
            { icon: <Shield sx={{ fontSize: 18 }} />, label: "Risk Posture Report" },
          ].map((s) => (
            <Box key={s.label} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Box sx={{ color: "#A78BFA" }}>{s.icon}</Box>
              <Typography variant="body2" fontWeight={600}>{s.label}</Typography>
            </Box>
          ))}
        </Box>

        <Button variant="contained" size="large" endIcon={<PlayArrow />}
          onClick={() => navigate("/security/questionnaire")}
          sx={{ bgcolor: "#A78BFA", color: "#1A0A2E", fontWeight: 800, fontSize: "1rem", px: 4, py: 1.5, "&:hover": { bgcolor: "#9061F9" }, boxShadow: "0 4px 20px rgba(167,139,250,0.4)" }}>
          Start Assessment
        </Button>
      </Box>

      {/* Why this matters */}
      <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Why Security Assessment Matters</Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {RISK_STATS.map((s) => (
          <Grid size={{ xs: 12, sm: 6, md: 3 }} key={s.label}>
            <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%", textAlign: "center" }}>
              <CardContent sx={{ py: 2.5 }}>
                <Box sx={{ mb: 1 }}>{s.icon}</Box>
                <Typography variant="h5" fontWeight={900} sx={{ lineHeight: 1.1 }}>{s.label}</Typography>
                <Typography variant="caption" color="text.secondary">{s.sublabel}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Shield Modules */}
      <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Assessment Modules</Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {securityModules.map((mod) => {
          const col = MODULE_COLORS[mod.id] ?? "#2B3E7E";
          return (
            <Grid size={{ xs: 12, sm: 6 }} key={mod.id}>
              <Card elevation={0} sx={{ border: `1px solid ${col}30`, height: "100%", bgcolor: `${col}05` }}>
                <CardContent sx={{ py: 2, px: 2.5 }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 1 }}>
                    <Box sx={{ color: col }}>{MODULE_ICONS[mod.id]}</Box>
                    <Box>
                      <Typography variant="subtitle2" fontWeight={800} sx={{ color: col }}>{mod.name}</Typography>
                      <Typography variant="caption" color="text.secondary" fontWeight={600}>{mod.label}</Typography>
                    </Box>
                    <Chip label={`${mod.checks.length} checks`} size="small"
                      sx={{ ml: "auto", bgcolor: `${col}18`, color: col, fontSize: "0.65rem", fontWeight: 700 }} />
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1.5 }}>{mod.description}</Typography>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      {/* Scoring & Risk Tiers */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, md: 5 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>Scoring System</Typography>
              {[
                { label: "Yes", pts: "2 pts", color: "#107C10", bg: "#E8FBF5", desc: "Control fully implemented and evidenced" },
                { label: "Partial", pts: "1 pt", color: "#FFB900", bg: "#FFFBF0", desc: "Control partially implemented or in progress" },
                { label: "No", pts: "0 pts", color: "#D83B01", bg: "#FFF0EE", desc: "Control not implemented — risk is present" },
                { label: "N/A", pts: "Excl.", color: "#666", bg: "#F5F5F5", desc: "Not applicable — excluded from score" },
              ].map((s) => (
                <Box key={s.label} sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 1, p: 1, borderRadius: 1.5, bgcolor: s.bg }}>
                  <Box sx={{ minWidth: 56, px: 1, py: 0.3, borderRadius: 1, bgcolor: s.color, textAlign: "center" }}>
                    <Typography variant="caption" fontWeight={800} sx={{ color: "white" }}>{s.label}</Typography>
                  </Box>
                  <Typography variant="caption" fontWeight={700} sx={{ color: s.color, minWidth: 36 }}>{s.pts}</Typography>
                  <Typography variant="caption" color="text.secondary">{s.desc}</Typography>
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 7 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>Risk Tiers</Typography>
              {RISK_TIERS.map((t) => (
                <Box key={t.tier} sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 1, p: 1, borderRadius: 1.5, bgcolor: t.bg }}>
                  <Box sx={{ minWidth: 72, px: 1, py: 0.3, borderRadius: 1, bgcolor: t.color, textAlign: "center" }}>
                    <Typography variant="caption" fontWeight={800} sx={{ color: "white", fontSize: "0.6rem" }}>{t.tier}</Typography>
                  </Box>
                  <Typography variant="caption" fontWeight={700} sx={{ color: t.color, minWidth: 52 }}>{t.range}</Typography>
                  <Typography variant="caption" color="text.secondary">{t.desc}</Typography>
                </Box>
              ))}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* CTA */}
      <Card sx={{ bgcolor: "#F5F0FF", border: "1px solid #D4BFFF" }}>
        <CardContent sx={{ p: 3, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 2 }}>
          <Box>
            <Typography variant="subtitle1" fontWeight={700} sx={{ color: "#6B3FBE" }}>Ready to assess your security posture?</Typography>
            <Typography variant="caption" color="text.secondary">Complete all four modules to receive your full risk posture report and pentest recommendation.</Typography>
          </Box>
          <Button variant="contained" endIcon={<PlayArrow />}
            onClick={() => navigate("/security/questionnaire")} size="large"
            sx={{ bgcolor: "#6B3FBE", "&:hover": { bgcolor: "#5A2FA8" } }}>
            Begin Security Assessment
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
}
