import { useState } from "react";
import { useLocation, useNavigate } from "react-router";
import {
  Card, CardContent, Typography, Box, Button, Grid, Chip, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, Divider, TextField, LinearProgress,
} from "@mui/material";
import {
  Shield, Download, ArrowBack, Warning, CheckCircle, Computer, PhoneAndroid, Lock, CloudQueue,
} from "@mui/icons-material";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from "recharts";
import {
  securityModules, scoreOverall, scoreSecurityModule, getSecurityRiskTier, getPentestSignal,
  type SecurityResponse,
} from "../../data/securityQuestions";

const MODULE_COLORS: Record<string, string> = {
  APPSHIELD: "#0F6CBD",
  MOBILESHIELD: "#107C10",
  INFRASHIELD: "#8764B8",
  CLOUDSHIELD: "#038387",
};

const MODULE_ICONS: Record<string, React.ReactNode> = {
  APPSHIELD: <Computer sx={{ fontSize: 16 }} />,
  MOBILESHIELD: <PhoneAndroid sx={{ fontSize: 16 }} />,
  INFRASHIELD: <Lock sx={{ fontSize: 16 }} />,
  CLOUDSHIELD: <CloudQueue sx={{ fontSize: 16 }} />,
};

const PENTEST_SIGNAL_COLORS: Record<string, string> = {
  "Immediate": "#D83B01",
  "Recommended": "#E65C00",
  "Advisable": "#FFB900",
  "Targeted Pentest": "#4CAF50",
  "Validation Only": "#107C10",
};

const PENTEST_RECOMMENDATION: Record<string, string> = {
  CRITICAL: "An immediate full-scope penetration test is strongly recommended. The number of Critical and High gaps indicates a significant probability of exploitable vulnerabilities. Testhouse recommends an emergency pentest alongside a parallel remediation programme.",
  HIGH: "A full-scope penetration test is urgently recommended. Significant weaknesses have been identified across one or more modules. Testhouse recommends scheduling a pentest in the current sprint/cycle alongside priority remediation actions.",
  MEDIUM: "A targeted penetration test is advisable before the next release. Moderate risk has been identified. Testhouse recommends scoping a pentest focused on the highest-risk areas and addressing medium-priority findings.",
  LOW: "Good security posture with minor gaps identified. A targeted pentest is suggested for assurance and compliance. Testhouse recommends addressing minor gaps and scheduling a pentest for validation within the next quarter.",
  SECURE: "Strong security controls evidenced. A pentest for validation and compliance assurance is recommended. Testhouse recommends a scheduled annual pentest to verify posture and meet regulatory requirements.",
};

export default function SecurityResults() {
  const { state } = useLocation() as { state: { answers: Record<string, SecurityResponse>; notes: Record<string, string> } };
  const navigate = useNavigate();
  const [exporting, setExporting] = useState<"pdf" | "excel" | null>(null);

  const answers: Record<string, SecurityResponse> = state?.answers ?? {};
  const notes: Record<string, string> = state?.notes ?? {};

  const { overallScore, modules, riskTier } = scoreOverall(answers);

  // Chart data
  const barData = securityModules.map((mod) => {
    const ms = modules[mod.id];
    return { name: mod.name, score: ms.score, color: MODULE_COLORS[mod.id] };
  });

  const riskCounts = { Critical: 0, High: 0, Secure: 0 };
  for (const mod of securityModules) {
    const ms = modules[mod.id];
    const t = getSecurityRiskTier(ms.score).tier;
    if (t === "CRITICAL") riskCounts.Critical++;
    else if (t === "HIGH" || t === "MEDIUM") riskCounts.High++;
    else riskCounts.Secure++;
  }
  const pieData = [
    { name: "Critical / High", value: riskCounts.Critical + riskCounts.High, color: "#D83B01" },
    { name: "Medium", value: 0, color: "#FFB900" },
    { name: "Low / Secure", value: riskCounts.Secure, color: "#107C10" },
  ].filter((d) => d.value > 0);

  // Critical gaps across all modules
  const criticalGapChecks: Array<{ ref: string; check: string; module: string; modColor: string }> = [];
  for (const mod of securityModules) {
    for (const check of mod.checks) {
      if (answers[check.ref] === "No" && check.criticality === "Critical") {
        criticalGapChecks.push({ ref: check.ref, check: check.check, module: mod.name, modColor: MODULE_COLORS[mod.id] });
      }
    }
  }

  const today = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });

  const buildExportData = () => ({
    overallScore,
    riskTier: riskTier.tier,
    pentestSignal: getPentestSignal(riskTier.tier),
    answers,
    modules: securityModules.map((mod) => {
      const ms = modules[mod.id];
      const tier = getSecurityRiskTier(ms.score);
      const criticalGaps = mod.checks
        .filter((c) => answers[c.ref] === "No" && c.criticality === "Critical")
        .map((c) => c.check);
      return { id: mod.id, name: mod.name, score: ms.score, maxPossible: ms.maxPossible, risk: tier.tier, criticalGaps };
    }),
  });

  const handleExportPDF = async () => {
    setExporting("pdf");
    const { exportSecurityPDF } = await import("../../lib/export-service");
    exportSecurityPDF(buildExportData());
    setExporting(null);
  };

  const handleExportExcel = async () => {
    setExporting("excel");
    const { exportSecurityExcel } = await import("../../lib/export-service");
    exportSecurityExcel(buildExportData());
    setExporting(null);
  };

  return (
    <Box sx={{ maxWidth: 1100, mx: "auto" }}>
      {/* Header bar */}
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Shield sx={{ color: "#6B3FBE", fontSize: 28 }} />
          <Box>
            <Typography variant="h5" fontWeight={800}>Security Assessment Report</Typography>
            <Typography variant="caption" color="text.secondary">AppShield · MobileShield · InfraShield · CloudShield | Risk Posture & Pentest Recommendation</Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 1.5 }}>
          <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => navigate("/security/questionnaire")} size="small">Back</Button>
          <Button variant="outlined" startIcon={<Download />} size="small"
            onClick={handleExportExcel} disabled={!!exporting}>
            {exporting === "excel" ? "Exporting…" : "Excel"}
          </Button>
          <Button variant="contained" startIcon={<Download />} size="small"
            onClick={handleExportPDF} disabled={!!exporting}
            sx={{ bgcolor: "#6B3FBE", "&:hover": { bgcolor: "#5A2FA8" } }}>
            {exporting === "pdf" ? "Exporting…" : "Export PDF"}
          </Button>
        </Box>
      </Box>

      {/* Engagement */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ bgcolor: "#1A0A2E", px: 2, py: 1 }}>
            <Typography variant="caption" fontWeight={700} sx={{ color: "white" }}>ENGAGEMENT</Typography>
          </Box>
          <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 0 }}>
            {[
              { label: "Client", val: "—" },
              { label: "Asset", val: "—" },
              { label: "Assessor", val: "—" },
              { label: "Date", val: today },
            ].map((f) => (
              <Box key={f.label} sx={{ px: 2, py: 1, borderRight: "1px solid #E0E4EC", "&:last-child": { borderRight: "none" } }}>
                <Typography variant="caption" color="text.secondary">{f.label}</Typography>
                <Typography variant="body2" fontWeight={600}>{f.val}</Typography>
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>

      {/* Module Scores Table */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ bgcolor: "#1A0A2E", px: 2, py: 1 }}>
            <Typography variant="caption" fontWeight={700} sx={{ color: "white" }}>MODULE SCORES</Typography>
          </Box>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: "#2D1B5E" }}>
                  {["Module", "Earned", "Max Possible", "Score", "Risk Tier", "Critical Gaps", "Pentest Signal"].map((h) => (
                    <TableCell key={h} sx={{ color: "white", fontWeight: 700, fontSize: "0.75rem", py: 1 }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {securityModules.map((mod) => {
                  const ms = modules[mod.id];
                  const rt = getSecurityRiskTier(ms.score);
                  const signal = getPentestSignal(ms.score);
                  const col = MODULE_COLORS[mod.id];
                  return (
                    <TableRow key={mod.id} sx={{ "&:nth-of-type(even)": { bgcolor: "#FAFBFF" } }}>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <Box sx={{ color: col }}>{MODULE_ICONS[mod.id]}</Box>
                          <Typography variant="body2" fontWeight={700} sx={{ color: col }}>{mod.name}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell><Typography variant="body2" fontWeight={700}>{ms.earned}</Typography></TableCell>
                      <TableCell><Typography variant="body2" color="text.secondary">{ms.maxPossible}</Typography></TableCell>
                      <TableCell><Typography variant="body2" fontWeight={800}>{ms.score.toFixed(1)}%</Typography></TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                          <Box sx={{ width: 10, height: 10, borderRadius: "50%", bgcolor: rt.color, flexShrink: 0 }} />
                          <Typography variant="caption" fontWeight={700} sx={{ color: rt.color }}>{rt.label}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight={700} sx={{ color: ms.criticalGaps > 0 ? "#D83B01" : "text.secondary" }}>{ms.criticalGaps}</Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                          <Warning sx={{ fontSize: 14, color: PENTEST_SIGNAL_COLORS[signal] ?? "#666" }} />
                          <Typography variant="caption" fontWeight={700} sx={{ color: PENTEST_SIGNAL_COLORS[signal] ?? "#666" }}>{signal}</Typography>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}
                <TableRow sx={{ bgcolor: "#1A0A2E" }}>
                  <TableCell colSpan={3}><Typography variant="body2" fontWeight={800} sx={{ color: "white" }}>OVERALL</Typography></TableCell>
                  <TableCell colSpan={4}><Typography variant="body1" fontWeight={900} sx={{ color: riskTier.color }}>{overallScore.toFixed(1)}%</Typography></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Risk Posture & Recommendation */}
      <Card elevation={0} sx={{ border: `2px solid ${riskTier.color}40`, mb: 3, bgcolor: `${riskTier.color}05` }}>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ bgcolor: "#1A0A2E", px: 2, py: 1 }}>
            <Typography variant="caption" fontWeight={700} sx={{ color: "white" }}>RISK POSTURE & PENTEST RECOMMENDATION</Typography>
          </Box>
          <Box sx={{ p: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
              <Typography variant="body2" color="text.secondary" sx={{ minWidth: 140, fontWeight: 600 }}>Overall Risk Tier</Typography>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Box sx={{ width: 14, height: 14, borderRadius: "50%", bgcolor: riskTier.color }} />
                <Typography variant="body1" fontWeight={800} sx={{ color: riskTier.color }}>
                  {riskTier.tier} RISK — {riskTier.description}
                </Typography>
              </Box>
            </Box>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ display: "flex", gap: 2 }}>
              <Typography variant="body2" color="text.secondary" sx={{ minWidth: 140, fontWeight: 600 }}>Recommendation</Typography>
              <Typography variant="body2" sx={{ lineHeight: 1.7 }}>{PENTEST_RECOMMENDATION[riskTier.tier] ?? PENTEST_RECOMMENDATION.HIGH}</Typography>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>Module Score Overview</Typography>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={barData} barSize={40}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F0F0F0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: number) => [`${v.toFixed(1)}%`, "Score"]} />
                  <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                    {barData.map((entry, i) => <Cell key={`sec-bar-cell-${entry.name}-${i}`} fill={entry.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>Risk Distribution</Typography>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value">
                    {pieData.map((entry, i) => <Cell key={`sec-pie-cell-${entry.name}-${i}`} fill={entry.color} />)}
                  </Pie>
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Critical Gaps */}
      {criticalGapChecks.length > 0 && (
        <Card elevation={0} sx={{ border: "2px solid #D83B0140", mb: 3, bgcolor: "#FFF8F7" }}>
          <CardContent sx={{ p: 0 }}>
            <Box sx={{ bgcolor: "#D83B01", px: 2, py: 1, display: "flex", alignItems: "center", gap: 1 }}>
              <Warning sx={{ color: "white", fontSize: 16 }} />
              <Typography variant="caption" fontWeight={700} sx={{ color: "white" }}>CRITICAL GAPS — CONTROLS NOT IMPLEMENTED ({criticalGapChecks.length})</Typography>
            </Box>
            <Box sx={{ p: 2 }}>
              {criticalGapChecks.map((g, i) => (
                <Box key={g.ref} sx={{ display: "flex", gap: 1.5, mb: 1, p: 1, borderRadius: 1.5, bgcolor: "white", border: "1px solid #FFCBC0" }}>
                  <Chip label={g.ref} size="small" sx={{ bgcolor: `${g.modColor}18`, color: g.modColor, fontWeight: 700, fontSize: "0.6rem" }} />
                  <Typography variant="caption" sx={{ lineHeight: 1.5 }}>{g.check}</Typography>
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Completion Tracker */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ bgcolor: "#1A0A2E", px: 2, py: 1 }}>
            <Typography variant="caption" fontWeight={700} sx={{ color: "white" }}>COMPLETION TRACKER</Typography>
          </Box>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: "#2D1B5E" }}>
                  {["Module", "Total Checks", "Answered", "Skipped (N/A)", "Not Yet Answered", "% Complete"].map((h) => (
                    <TableCell key={h} sx={{ color: "white", fontWeight: 700, fontSize: "0.72rem", py: 1 }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {securityModules.map((mod) => {
                  const ms = modules[mod.id];
                  const total = mod.checks.length;
                  const pct = Math.round(((ms.answered + ms.skipped) / total) * 100);
                  const col = MODULE_COLORS[mod.id];
                  return (
                    <TableRow key={mod.id} sx={{ "&:nth-of-type(even)": { bgcolor: "#FAFBFF" } }}>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <CheckCircle sx={{ fontSize: 14, color: pct === 100 ? "#107C10" : "#E0E4EC" }} />
                          <Typography variant="body2" fontWeight={600} sx={{ color: col }}>{mod.icon} {mod.name}</Typography>
                        </Box>
                      </TableCell>
                      <TableCell><Typography variant="body2">{total}</Typography></TableCell>
                      <TableCell><Typography variant="body2" fontWeight={700}>{ms.answered}</Typography></TableCell>
                      <TableCell><Typography variant="body2" color="text.secondary">{ms.skipped}</Typography></TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ color: ms.notAnswered > 0 ? "#E65C00" : "text.secondary" }}>{ms.notAnswered}</Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                          <LinearProgress variant="determinate" value={pct}
                            sx={{ flex: 1, height: 6, borderRadius: 3, bgcolor: "#E8ECF4", "& .MuiLinearProgress-bar": { bgcolor: pct === 100 ? "#107C10" : col } }} />
                          <Typography variant="caption" fontWeight={700} sx={{ color: pct < 100 ? "#E65C00" : "#107C10", minWidth: 30 }}>{pct}%</Typography>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
          <Box sx={{ p: 2, bgcolor: "#F7F9FF", borderTop: "1px solid #E0E4EC" }}>
            <Typography variant="caption" color="text.secondary" sx={{ fontStyle: "italic" }}>
              This assessment is a preliminary checklist-based readiness review. It does not replace a formal penetration test or security audit.
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Sign-off */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent sx={{ p: 0 }}>
          <Box sx={{ bgcolor: "#1A0A2E", px: 2, py: 1 }}>
            <Typography variant="caption" fontWeight={700} sx={{ color: "white" }}>ASSESSMENT SIGN-OFF & NEXT STEPS</Typography>
          </Box>
          <Box sx={{ p: 3 }}>
            <Grid container spacing={2}>
              {[
                { label: "Assessment Reviewed By", placeholder: "Name / Role" },
                { label: "Review Date", placeholder: today },
                { label: "Approved By / Authority", placeholder: "Name / Role" },
                { label: "Next Review Date", placeholder: "DD MMM YYYY" },
                { label: "Pentest Tool / Vendor", placeholder: "e.g. Testhouse Security Practice" },
                { label: "Pentest Environment", placeholder: "Staging / Production" },
                { label: "Estimated Pentest Effort", placeholder: "e.g. 5 days" },
                { label: "Priority", placeholder: `${riskTier.tier}` },
              ].map((f) => (
                <Grid size={{ xs: 12, sm: 6 }} key={f.label}>
                  <TextField fullWidth size="small" label={f.label} placeholder={f.placeholder}
                    sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }} />
                </Grid>
              ))}
              <Grid size={{ xs: 12 }}>
                <TextField fullWidth size="small" multiline rows={2}
                  label="Additional Comments / Notes"
                  sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }} />
              </Grid>
            </Grid>
          </Box>
        </CardContent>
      </Card>

      <Box sx={{ p: 2, textAlign: "center", borderRadius: 2, bgcolor: `${riskTier.color}10`, border: `1px solid ${riskTier.color}30` }}>
        <Typography variant="body2" fontWeight={800} sx={{ color: riskTier.color }}>
          ⚠️ VERDICT: {riskTier.tier} RISK — {riskTier.description}
        </Typography>
      </Box>
    </Box>
  );
}
