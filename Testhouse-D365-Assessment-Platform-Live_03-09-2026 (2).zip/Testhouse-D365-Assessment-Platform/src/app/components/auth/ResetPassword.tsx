import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import {
  Box, Card, CardContent, TextField, Button, Typography,
  Container, Alert, CircularProgress, LinearProgress,
} from "@mui/material";
import { LockReset, CheckCircle } from "@mui/icons-material";
import { useAuth } from "../../contexts/AuthContext";
import TesthouseLogo from "../shared/TesthouseLogo";

function passwordStrength(pwd: string): { score: number; label: string; color: string } {
  let score = 0;
  if (pwd.length >= 8)  score++;
  if (pwd.length >= 12) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  const labels = ["Very Weak", "Weak", "Fair", "Good", "Strong", "Very Strong"];
  const colors  = ["#D83B01", "#E65C00", "#FFB900", "#4DD4AC", "#107C10", "#107C10"];
  return { score, label: labels[score], color: colors[score] };
}

export default function ResetPassword() {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  const { resetPassword } = useAuth();
  const strength = passwordStrength(password);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) { setError("Passwords do not match."); return; }
    if (password.length < 8)  { setError("Password must be at least 8 characters."); return; }
    if (!token) { setError("This reset link is invalid or has expired."); return; }
    setError(null);
    setLoading(true);
    const { error: err } = await resetPassword(token, password);
    setLoading(false);
    if (err) setError(err);
    else setDone(true);
  };

  if (!token) {
    return (
      <Box sx={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "primary.main" }}>
        <Container maxWidth="sm">
          <Card elevation={8} sx={{ borderRadius: 3 }}>
            <CardContent sx={{ p: 5, textAlign: "center" }}>
              <Alert severity="warning" sx={{ mb: 2 }}>
                This password reset link is invalid or has expired.
              </Alert>
              <Button variant="contained" onClick={() => navigate("/forgot-password")}>
                Request a new link
              </Button>
            </CardContent>
          </Card>
        </Container>
      </Box>
    );
  }

  return (
    <Box sx={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", bgcolor: "primary.main" }}>
      <Container maxWidth="sm">
        <Card elevation={8} sx={{ borderRadius: 3 }}>
          <CardContent sx={{ p: 5 }}>
            <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
              <TesthouseLogo variant="login" />
            </Box>

            {done ? (
              <Box sx={{ textAlign: "center" }}>
                <CheckCircle sx={{ fontSize: 56, color: "#107C10", mb: 2 }} />
                <Typography variant="h6" fontWeight={700} gutterBottom>Password updated</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Your password has been changed successfully.
                </Typography>
                <Button variant="contained" onClick={() => navigate("/")}>
                  Go to Dashboard
                </Button>
              </Box>
            ) : (
              <>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 1, mb: 1 }}>
                  <LockReset sx={{ color: "primary.main" }} />
                  <Typography variant="h5" fontWeight={600}>Set new password</Typography>
                </Box>
                <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 3 }}>
                  Choose a strong password for your account.
                </Typography>

                {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

                <form onSubmit={handleSubmit}>
                  <TextField
                    fullWidth label="New password" type="password" value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    margin="normal" required autoFocus
                  />
                  {password && (
                    <Box sx={{ mt: 0.5, mb: 1 }}>
                      <LinearProgress variant="determinate" value={(strength.score / 5) * 100}
                        sx={{ height: 5, borderRadius: 2, bgcolor: "#E0E4EC", "& .MuiLinearProgress-bar": { bgcolor: strength.color } }} />
                      <Typography variant="caption" sx={{ color: strength.color, fontWeight: 600 }}>
                        {strength.label}
                      </Typography>
                    </Box>
                  )}
                  <TextField
                    fullWidth label="Confirm new password" type="password" value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    margin="normal" required
                    error={!!confirm && confirm !== password}
                    helperText={confirm && confirm !== password ? "Passwords do not match" : ""}
                  />
                  <Button
                    fullWidth type="submit" variant="contained" size="large"
                    disabled={loading || !password || !confirm} sx={{ mt: 2, py: 1.5 }}
                  >
                    {loading ? <CircularProgress size={22} color="inherit" /> : "Update Password"}
                  </Button>
                </form>
              </>
            )}
          </CardContent>
        </Card>
      </Container>
    </Box>
  );
}
