import { useState } from "react";
import { useNavigate, Link } from "react-router";

import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Container,
  Alert,
  CircularProgress,
} from "@mui/material";

import { useAuth } from "../../contexts/AuthContext";
import TesthouseLogo from "../shared/TesthouseLogo";

export default function Signup() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { signUp } = useAuth();

  const handleSignup = async (event: React.FormEvent) => {
    event.preventDefault();

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setLoading(true);
    setError(null);

    const { error: signUpError } = await signUp(email, password, fullName);

    setLoading(false);

    if (signUpError) {
      setError(signUpError);
      return;
    }

    // New accounts land straight in the app; they can start a D365
    // assessment right away and it'll show up under "My Assessments".
    navigate("/");
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        bgcolor: "primary.main",
      }}
    >
      <Container maxWidth="sm">
        <Card elevation={8} sx={{ borderRadius: 3 }}>
          <CardContent sx={{ p: 5 }}>
            <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
              <TesthouseLogo variant="login" />
            </Box>

            <Typography
              variant="h6"
              align="center"
              gutterBottom
              sx={{ fontWeight: 700, color: "#1B2F6E" }}
            >
              Create your account
            </Typography>

            <Typography
              variant="body2"
              align="center"
              color="text.secondary"
              sx={{ mb: 3 }}
            >
              Take the D365 QA Maturity Assessment and keep your results in
              one place.
            </Typography>

            {error && (
              <Alert
                severity="error"
                sx={{ mb: 2 }}
                onClose={() => setError(null)}
              >
                {error}
              </Alert>
            )}

            <form onSubmit={handleSignup}>
              <TextField
                fullWidth
                label="Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                margin="normal"
                required
                autoComplete="name"
                autoFocus
              />

              <TextField
                fullWidth
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                margin="normal"
                required
                autoComplete="email"
              />

              <TextField
                fullWidth
                label="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                margin="normal"
                required
                autoComplete="new-password"
                helperText="At least 8 characters"
              />

              <TextField
                fullWidth
                label="Confirm Password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                margin="normal"
                required
                autoComplete="new-password"
                error={!!confirmPassword && confirmPassword !== password}
                helperText={
                  confirmPassword && confirmPassword !== password
                    ? "Passwords do not match"
                    : " "
                }
              />

              <Button
                fullWidth
                type="submit"
                variant="contained"
                size="large"
                disabled={loading}
                sx={{ mt: 1, mb: 2, py: 1.5 }}
              >
                {loading ? (
                  <CircularProgress size={22} color="inherit" />
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>

            <Box sx={{ textAlign: "center" }}>
              <Typography variant="body2" color="text.secondary" component="span">
                Already have an account?{" "}
              </Typography>
              <Link
                to="/login"
                style={{ fontSize: "0.875rem", color: "#2B3E7E", fontWeight: 600 }}
              >
                Sign in
              </Link>
            </Box>
          </CardContent>
        </Card>
      </Container>
    </Box>
  );
}
