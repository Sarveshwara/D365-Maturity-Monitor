import { useState } from "react";
import { useNavigate, Link } from "react-router";

import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Divider,
  Container,
  Alert,
  CircularProgress,
} from "@mui/material";

import { Google } from "@mui/icons-material";

import { useAuth } from "../../contexts/AuthContext";
import TesthouseLogo from "../shared/TesthouseLogo";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { signIn } = useAuth();

  const handleLogin = async (event: React.FormEvent) => {
    event.preventDefault();

    setLoading(true);
    setError(null);

    const { error: signInError } = await signIn(email, password);

    setLoading(false);

    if (signInError) {
      setError(signInError);
      return;
    }

    navigate("/");
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        bgcolor: "primary.main",
      }}
    >
      <Container maxWidth="sm">
        <Card elevation={8} sx={{ borderRadius: 3 }}>
          <CardContent sx={{ p: 5 }}>
            {/* Logo */}

            <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
              <TesthouseLogo variant="login" />
            </Box>

            {/* Heading */}

            <Typography
              variant="h6"
              align="center"
              gutterBottom
              sx={{ fontWeight: 700, color: "#1B2F6E" }}
            >
              Quality Engineering Intelligence Platform
            </Typography>

            <Typography
              variant="body2"
              align="center"
              color="text.secondary"
              sx={{ mb: 3 }}
            >
              Welcome — sign in to your account
            </Typography>

            {/* Error */}

            {error && (
              <Alert
                severity="error"
                sx={{ mb: 2 }}
                onClose={() => setError(null)}
              >
                {error}
              </Alert>
            )}

            {/* Login Form */}

            <form onSubmit={handleLogin}>
              <TextField
                fullWidth
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                margin="normal"
                required
                autoComplete="email"
                autoFocus
              />

              <TextField
                fullWidth
                label="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                margin="normal"
                required
                autoComplete="current-password"
              />

              {/* Forgot Password */}

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  mt: 0.5,
                  mb: 1,
                }}
              >
                <Link
                  to="/forgot-password"
                  style={{ fontSize: "0.85rem", color: "#2B3E7E" }}
                >
                  Forgot password?
                </Link>
              </Box>

              {/* Sign In */}

              <Button
                fullWidth
                type="submit"
                variant="contained"
                size="large"
                disabled={loading}
                sx={{ mt: 1, mb: 2, py: 1.5 }}
              >
                {loading ? (
                  <CircularProgress size={22} color="inherit" />
                ) : (
                  "Sign In"
                )}
              </Button>
            </form>

            {/* Create account */}

            <Box sx={{ textAlign: "center", mb: 1 }}>
              <Typography variant="body2" color="text.secondary" component="span">
                New here?{" "}
              </Typography>
              <Link
                to="/signup"
                style={{ fontSize: "0.875rem", color: "#2B3E7E", fontWeight: 600 }}
              >
                Create an account
              </Link>
            </Box>

            <Divider sx={{ my: 2 }} />

            {/* Google button temporarily kept as UI only */}

            <Button
              fullWidth
              variant="outlined"
              startIcon={<Google />}
              disabled
              sx={{ mb: 2 }}
            >
              Sign in with Google
            </Button>

            {/* Footer Links */}

            <Box
              sx={{ display: "flex", justifyContent: "center", gap: 2, mt: 1 }}
            >
              <Link
                to="/privacy"
                style={{ fontSize: "0.75rem", color: "#999", textDecoration: "none" }}
              >
                Privacy Policy
              </Link>

              <Link
                to="/terms"
                style={{ fontSize: "0.75rem", color: "#999", textDecoration: "none" }}
              >
                Terms & Conditions
              </Link>

              <Link
                to="/landing"
                style={{ fontSize: "0.75rem", color: "#999", textDecoration: "none" }}
              >
                About
              </Link>
            </Box>
          </CardContent>
        </Card>
      </Container>
    </Box>
  );
}
