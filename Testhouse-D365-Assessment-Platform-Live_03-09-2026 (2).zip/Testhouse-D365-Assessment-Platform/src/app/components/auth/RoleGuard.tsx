import { Box, Typography, Button, CircularProgress } from "@mui/material";
import { LockOutlined } from "@mui/icons-material";
import { useNavigate } from "react-router";
import { useAuth } from "../../contexts/AuthContext";
import type { UserRole } from "../../contexts/AuthContext";

interface RoleGuardProps {
  children: React.ReactNode;
  allowedRoles: UserRole[];
}

export default function RoleGuard({ children, allowedRoles }: RoleGuardProps) {
  const { role, isLoading } = useAuth();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!allowedRoles.includes(role)) {
    return (
      <Box sx={{
        display: "flex", flexDirection: "column", alignItems: "center",
        justifyContent: "center", minHeight: 400, textAlign: "center", gap: 2,
      }}>
        <Box sx={{
          width: 72, height: 72, borderRadius: "50%", bgcolor: "#FFF0EE",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <LockOutlined sx={{ fontSize: 36, color: "#D83B01" }} />
        </Box>
        <Typography variant="h5" fontWeight={700} color="text.primary">
          Access Denied
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 360 }}>
          You do not have permission to view this page. Contact your administrator
          if you believe this is an error.
        </Typography>
        <Typography variant="caption" color="text.disabled" sx={{
          px: 1.5, py: 0.5, bgcolor: "#F5F5F5", borderRadius: 1, fontFamily: "monospace",
        }}>
          Required: {allowedRoles.join(" or ")} · Your role: {role}
        </Typography>
        <Button variant="outlined" onClick={() => navigate("/")}>
          Back to Dashboard
        </Button>
      </Box>
    );
  }

  return <>{children}</>;
}
