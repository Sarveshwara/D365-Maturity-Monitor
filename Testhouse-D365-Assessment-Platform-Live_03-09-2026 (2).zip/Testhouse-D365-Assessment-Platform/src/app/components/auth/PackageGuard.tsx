import { Box, Typography, Button, CircularProgress, Card, CardContent, Chip } from "@mui/material";
import { LockOutlined, Storefront } from "@mui/icons-material";
import { useNavigate } from "react-router";
import { usePackage } from "../../contexts/PackageContext";

interface PackageGuardProps {
  children: React.ReactNode;
  /** The route prefix this guard protects, e.g. "/performance" */
  routePrefix: string;
  /** Human-readable name shown in the denial message, e.g. "Performance Assessment" */
  label?: string;
}

export default function PackageGuard({ children, routePrefix, label }: PackageGuardProps) {
  const { canAccess, isLoading, subscribedPackages, isSuperAdmin } = usePackage();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!canAccess(routePrefix)) {
    return (
      <Box sx={{
        display: "flex", flexDirection: "column", alignItems: "center",
        justifyContent: "center", minHeight: 400, textAlign: "center", gap: 2, p: 4,
      }}>
        <Box sx={{
          width: 72, height: 72, borderRadius: "50%", bgcolor: "#FFF0EE",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <LockOutlined sx={{ fontSize: 36, color: "#D83B01" }} />
        </Box>

        <Typography variant="h5" fontWeight={700}>
          {label ? `${label} Not Available` : "Assessment Not Available"}
        </Typography>

        <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 400 }}>
          Your organisation does not have an active subscription to this assessment.
          Contact your Testhouse account manager to add this package.
        </Typography>

        {subscribedPackages.length > 0 && (
          <Box>
            <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 1 }}>
              Your active packages:
            </Typography>
            <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", justifyContent: "center" }}>
              {subscribedPackages.map((pkg) => (
                <Chip
                  key={pkg.package_code}
                  label={pkg.package_name}
                  size="small"
                  sx={{
                    bgcolor: `${pkg.color ?? "#2B3E7E"}18`,
                    color: pkg.color ?? "#2B3E7E",
                    fontWeight: 700, fontSize: "0.7rem",
                  }}
                />
              ))}
            </Box>
          </Box>
        )}

        {subscribedPackages.length === 0 && (
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", maxWidth: 360 }}>
            <CardContent sx={{ py: 2 }}>
              <Typography variant="caption" color="text.secondary">
                No assessment packages are assigned to your organisation yet.
                Please contact your administrator.
              </Typography>
            </CardContent>
          </Card>
        )}

        <Box sx={{ display: "flex", gap: 2, mt: 1 }}>
          <Button variant="outlined" onClick={() => navigate(-1 as any)}>Go Back</Button>
          <Button variant="contained" onClick={() => navigate("/")}>Dashboard</Button>
        </Box>
      </Box>
    );
  }

  return <>{children}</>;
}
