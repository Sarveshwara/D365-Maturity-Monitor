import { useState } from "react";
import { Link } from "react-router";
import {
  Box, Card, CardContent, TextField, Button, Typography,
  Container, Alert, CircularProgress,
} from "@mui/material";
import { ArrowBack, MarkEmailRead } from "@mui/icons-material";
import { useAuth } from "../../contexts/AuthContext";
import TesthouseLogo from "../shared/TesthouseLogo";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { sendPasswordReset } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error: err } = await sendPasswordReset(email);
    setLoading(false);
    if (err) setError(err);
    else setSent(true);
  };

  return (
    <Box sx={{
      minHeight: "100vh", display: "flex", alignItems: "center",
      justifyContent: "center", bgcolor: "primary.main",
    }}>
      <Container maxWidth="sm">
        <Card elevation={8} sx={{ borderRadius: 3 }}>
          <CardContent sx={{ p: 5 }}>
            <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
              <TesthouseLogo variant="login" />
            </Box>

            {sent ? (
              <Box sx={{ textAlign: "center" }}>
                <MarkEmailRead sx={{ fontSize: 56, color: "#107C10", mb: 2 }} />
                <Typography variant="h6" fontWeight={700} gutterBottom>
                  Check your email
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  We sent a password reset link to <strong>{email}</strong>.
                  The link expires in 1 hour.
                </Typography>
                <Link to="/login" style={{ textDecoration: "none" }}>
                  <Button variant="outlined" startIcon={<ArrowBack />}>
                    Back to Sign In
                  </Button>
                </Link>
              </Box>
            ) : (
              <>
                <Typography variant="h5" align="center" fontWeight={600} gutterBottom>
                  Reset your password
                </Typography>
                <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 3 }}>
                  Enter your account email and we'll send you a reset link.
                </Typography>

                {error && (
                  <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
                    {error}
                  </Alert>
                )}

                <form onSubmit={handleSubmit}>
                  <TextField
                    fullWidth label="Email address" type="email" value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    margin="normal" required autoFocus
                  />
                  <Button
                    fullWidth type="submit" variant="contained" size="large"
                    disabled={loading} sx={{ mt: 2, mb: 2, py: 1.5 }}
                  >
                    {loading ? <CircularProgress size={22} color="inherit" /> : "Send Reset Link"}
                  </Button>
                </form>

                <Box sx={{ textAlign: "center" }}>
                  <Link to="/login" style={{ fontSize: "0.85rem", color: "#2B3E7E" }}>
                    ← Back to Sign In
                  </Link>
                </Box>
              </>
            )}
          </CardContent>
        </Card>
      </Container>
    </Box>
  );
}
