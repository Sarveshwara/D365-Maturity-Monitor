import { Box, Container, Typography, Divider, Chip } from "@mui/material";
import { Link } from "react-router";
import TesthouseLogo from "../shared/TesthouseLogo";

const SECTIONS = [
  {
    title: "1. Definitions",
    body: `In these Terms and Conditions:

**"Testhouse"** means Testhouse Ltd, registered in England and Wales.
**"Platform"** means the Testhouse Quality Engineering Intelligence Platform and all associated services.
**"Customer"** means the organisation that has entered into a subscription agreement with Testhouse.
**"User"** means any individual authorised by the Customer to access the Platform.
**"Assessment Data"** means questionnaire responses, scores, notes, and reports generated through the Platform.
**"Subscription"** means the agreement granting the Customer access to one or more assessment packages.`,
  },
  {
    title: "2. Acceptance of Terms",
    body: `By accessing or using the Platform, you agree to be bound by these Terms and Conditions and our Privacy Policy. If you do not agree, you must not use the Platform.

These Terms constitute the entire agreement between you and Testhouse in relation to your use of the Platform, superseding any prior agreements.

If you are accessing the Platform on behalf of an organisation, you represent that you have authority to bind that organisation to these Terms.`,
  },
  {
    title: "3. Access and Accounts",
    body: `Access to the Platform is granted on a per-subscription basis. The Customer is responsible for:

• Ensuring only authorised Users access the Platform
• Maintaining the security of all account credentials
• All activities that occur under their account
• Notifying Testhouse immediately of any unauthorised use or security breach

Users must not share login credentials. Each User must have a unique account. Testhouse reserves the right to suspend or terminate accounts that breach these Terms.`,
  },
  {
    title: "4. Permitted Use",
    body: `The Platform is licensed for the Customer's internal business use only. Users may:

• Complete assessments within their assigned assessment packages
• Generate and download reports for internal use
• Share reports with the Customer's management and stakeholders

Users must not:

• Use the Platform for any unlawful purpose
• Attempt to reverse engineer, decompile or extract source code
• Resell, sublicense or distribute access to the Platform
• Upload malicious code, scripts or harmful content
• Attempt to access data belonging to other customers
• Circumvent any security, authentication or access control measure`,
  },
  {
    title: "5. Assessment Packages and Entitlements",
    body: `The Customer is granted access to specific assessment packages as defined in the Subscription agreement. Access is limited to the domains and questionnaires included in those packages.

Testhouse reserves the right to update, modify or discontinue assessment packages. Where material changes are made, Customers will be given at least 30 days notice.

Assessment results and recommendations are provided for informational purposes. Testhouse does not guarantee specific outcomes from implementing recommendations.`,
  },
  {
    title: "6. Intellectual Property",
    body: `**Testhouse IP:** The Platform, including all software, questionnaire content, scoring models, maturity frameworks, report templates, and branding, is the exclusive intellectual property of Testhouse Ltd and is protected by copyright and other intellectual property laws.

**Customer Data:** Assessment responses and data entered by the Customer remain the Customer's property. Testhouse does not claim ownership of Customer Assessment Data.

**Reports:** Generated PDF and Excel reports may be used by the Customer internally. Reports may not be resold, republished or distributed commercially without Testhouse's written consent.

You must not remove any copyright notices or proprietary labels from the Platform.`,
  },
  {
    title: "7. Data Protection",
    body: `Both parties will comply with applicable data protection legislation including UK GDPR and the Data Protection Act 2018.

Testhouse acts as a Data Processor for Customer Assessment Data. The Customer acts as the Data Controller.

Testhouse will:
• Process Customer data only as instructed by the Customer
• Implement appropriate technical and organisational security measures
• Notify the Customer of any personal data breach without undue delay
• Delete or return Customer data upon termination of the Subscription

Please refer to our Privacy Policy for full details of how personal data is handled.`,
  },
  {
    title: "8. Availability and Uptime",
    body: `Testhouse will use commercially reasonable efforts to make the Platform available. However, we do not guarantee uninterrupted, error-free access.

The Platform may be unavailable during:
• Scheduled maintenance (with advance notice where possible)
• Emergency maintenance required for security or stability
• Events beyond Testhouse's reasonable control

Testhouse will provide status updates for any extended outages through the Platform or by email.`,
  },
  {
    title: "9. Limitation of Liability",
    body: `To the maximum extent permitted by law:

• Testhouse's total liability for any claim arising from use of the Platform shall not exceed the subscription fees paid by the Customer in the 12 months preceding the claim.

• Testhouse shall not be liable for indirect, incidental, special or consequential damages, including loss of profits, data, business or goodwill.

• Assessment scores and recommendations are provided in good faith based on information provided by the Customer. Testhouse is not liable for decisions made based on assessment outputs.

Nothing in these Terms limits liability for death, personal injury caused by negligence, fraud or any other liability that cannot be excluded by law.`,
  },
  {
    title: "10. Termination",
    body: `Either party may terminate the Subscription:

• At the end of the subscription period by providing 30 days written notice
• Immediately by Testhouse if the Customer materially breaches these Terms and fails to remedy the breach within 14 days of written notice
• Immediately by either party if the other becomes insolvent or enters administration

Upon termination, the Customer's access to the Platform will cease. Assessment data will be retained for 24 months and then permanently deleted unless earlier deletion is requested.`,
  },
  {
    title: "11. Governing Law",
    body: `These Terms are governed by the laws of England and Wales. Any disputes will be subject to the exclusive jurisdiction of the courts of England and Wales.

If any provision of these Terms is found to be unenforceable, the remaining provisions will continue in full force and effect.`,
  },
  {
    title: "12. Changes to These Terms",
    body: `Testhouse may update these Terms from time to time. Material changes will be notified to Customers by email or prominent notice within the Platform at least 30 days before taking effect.

Your continued use of the Platform after changes take effect constitutes acceptance of the revised Terms.`,
  },
  {
    title: "13. Contact",
    body: `For any questions about these Terms:

**Email:** legal@testhouse.net
**Post:** Testhouse Ltd, Legal Department, United Kingdom
**General:** contact@testhouse.net
**Website:** www.testhouse.net`,
  },
];

export default function TermsAndConditions() {
  return (
    <Box sx={{ bgcolor: "white", minHeight: "100vh" }}>
      {/* Nav */}
      <Box sx={{ borderBottom: "1px solid #E0E4EC", py: 1.5 }}>
        <Container maxWidth="lg">
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <Link to="/landing">
              <TesthouseLogo variant="nav" />
            </Link>
            <Box sx={{ display: "flex", gap: 3 }}>
              <Link to="/landing" style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>Home</Link>
              <Link to="/privacy" style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>Privacy</Link>
              <Link to="/login"   style={{ color: "#2B3E7E", fontSize: "0.85rem", fontWeight: 700, textDecoration: "none" }}>Sign In</Link>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* Header */}
      <Box sx={{ bgcolor: "#F7F9FF", borderBottom: "1px solid #E0E4EC", py: 6 }}>
        <Container maxWidth="md">
          <Chip label="Legal" size="small" sx={{ bgcolor: "#2B3E7E18", color: "#2B3E7E", fontWeight: 700, mb: 2 }} />
          <Typography variant="h3" fontWeight={800} sx={{ color: "#0D1B3E", mb: 1 }}>
            Terms &amp; Conditions
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Last updated: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5, maxWidth: 560 }}>
            These Terms govern your use of the Testhouse Quality Engineering Intelligence Platform. Please read them carefully before using the Platform.
          </Typography>
        </Container>
      </Box>

      {/* Content */}
      <Container maxWidth="md" sx={{ py: 8 }}>
        {SECTIONS.map((section, i) => (
          <Box key={i} sx={{ mb: 5 }}>
            <Typography variant="h6" fontWeight={700} sx={{ color: "#0D1B3E", mb: 2 }}>
              {section.title}
            </Typography>
            {section.body.split("\n\n").map((para, j) => (
              <Typography key={j} variant="body2" color="text.secondary"
                sx={{ mb: 1.5, lineHeight: 1.8, whiteSpace: "pre-line" }}>
                {para.replace(/\*\*(.*?)\*\*/g, "$1")}
              </Typography>
            ))}
            {i < SECTIONS.length - 1 && <Divider sx={{ mt: 3 }} />}
          </Box>
        ))}
      </Container>

      {/* Footer */}
      <Box sx={{ bgcolor: "#0D1B3E", py: 3, textAlign: "center" }}>
        <Typography variant="caption" sx={{ color: "rgba(255,255,255,0.5)" }}>
          © {new Date().getFullYear()} Testhouse Ltd ·{" "}
          <Link to="/privacy" style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Privacy</Link>
          {" · "}
          <Link to="/terms"   style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Terms</Link>
          {" · "}
          <Link to="/landing" style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Home</Link>
        </Typography>
      </Box>
    </Box>
  );
}
