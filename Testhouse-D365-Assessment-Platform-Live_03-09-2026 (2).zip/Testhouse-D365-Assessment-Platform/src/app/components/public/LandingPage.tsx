import { useNavigate, Link } from "react-router";
import {
  Box, Typography, Button, Container, Grid, Card, CardContent,
  Chip, Divider, Avatar,
} from "@mui/material";
import {
  Assessment, Speed, Shield, SmartToy, Cloud, CheckCircle,
  ArrowForward, BarChart, People, Business, TrendingUp,
  Security, Analytics, PlayArrow,
} from "@mui/icons-material";
import TesthouseLogo from "../shared/TesthouseLogo";

const PACKAGES = [
  {
    code: "QA_FULL", name: "QA Maturity Assessment", color: "#2B3E7E",
    icon: <Assessment sx={{ fontSize: 28 }} />,
    desc: "Complete quality engineering maturity across strategy, automation, tools, process, skills and metrics.",
    domains: ["Strategy & Governance", "Test Automation", "Tools & Infrastructure", "Process Maturity", "Skills & Competency", "Metrics & Reporting"],
  },
  {
    code: "PERF", name: "Performance Assessment", color: "#0F6CBD",
    icon: <Speed sx={{ fontSize: 28 }} />,
    desc: "Performance engineering readiness — architecture, environment, load testing and SLA compliance.",
    domains: ["Traffic & Scalability", "SLA Compliance", "Architecture Review", "Data Volume", "Incident Readiness"],
  },
  {
    code: "SEC", name: "Security Assessment", color: "#6B3FBE",
    icon: <Shield sx={{ fontSize: 28 }} />,
    desc: "Security posture and pentest readiness across web, mobile, infrastructure and cloud.",
    domains: ["AppShield", "MobileShield", "InfraShield", "CloudShield"],
  },
  {
    code: "AUTO", name: "Test Automation Assessment", color: "#107C10",
    icon: <SmartToy sx={{ fontSize: 28 }} />,
    desc: "Test automation strategy, framework maturity, CI/CD integration and toolchain selection.",
    domains: ["Automation Strategy", "Framework Maturity", "CI/CD Integration", "Coverage Analysis"],
  },
  {
    code: "DEVOPS", name: "DevOps Assessment", color: "#038387",
    icon: <Cloud sx={{ fontSize: 28 }} />,
    desc: "DevOps maturity covering CI/CD pipelines, infrastructure as code and release engineering.",
    domains: ["CI/CD Pipelines", "Infrastructure as Code", "Release Engineering", "Quality Gates"],
  },
];

const FEATURES = [
  { icon: <BarChart sx={{ fontSize: 24 }} />, title: "Evidence-Based Scoring", desc: "Structured 5-level maturity model with weighted scoring across 15+ enterprise dimensions per assessment." },
  { icon: <People sx={{ fontSize: 24 }} />, title: "Multi-Tenant by Design", desc: "Each customer sees only their assigned assessment packages. Full data isolation enforced at the database level." },
  { icon: <Analytics sx={{ fontSize: 24 }} />, title: "Executive Reports", desc: "Auto-generated PDF and Excel reports with domain scores, risk heatmaps, recommendations and roadmaps." },
  { icon: <Security sx={{ fontSize: 24 }} />, title: "Enterprise Security", desc: "Row Level Security on all data. Supabase Auth with SSO support. Role-based access control across all screens." },
  { icon: <TrendingUp sx={{ fontSize: 24 }} />, title: "Improvement Roadmap", desc: "Actionable recommendations prioritised by risk level with a phased 12-month transformation roadmap." },
  { icon: <Business sx={{ fontSize: 24 }} />, title: "Package Entitlements", desc: "Sell individual assessments — Performance only, Security only, or the full QA Maturity suite. Per-customer control." },
];

const STATS = [
  { value: "5", label: "Assessment Packages" },
  { value: "88+", label: "Security Checks" },
  { value: "15", label: "QA Dimensions" },
  { value: "5", label: "Maturity Levels" },
];

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <Box sx={{ bgcolor: "white", minHeight: "100vh" }}>
      {/* ── Nav bar ────────────────────────────────────────────── */}
      <Box sx={{
        position: "sticky", top: 0, zIndex: 100,
        bgcolor: "white", borderBottom: "1px solid #E0E4EC",
        boxShadow: "0 1px 8px rgba(0,0,0,0.06)",
      }}>
        <Container maxWidth="lg">
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", py: 1.5 }}>
            <TesthouseLogo variant="nav" />
            <Box sx={{ display: "flex", alignItems: "center", gap: 3 }}>
              <Link to="/about" style={{ textDecoration: "none", color: "#555", fontSize: "0.9rem" }}>About</Link>
              <Link to="/contact" style={{ textDecoration: "none", color: "#555", fontSize: "0.9rem" }}>Contact</Link>
              <Button variant="outlined" size="small" onClick={() => navigate("/login")}
                sx={{ borderColor: "#2B3E7E", color: "#2B3E7E" }}>Sign In</Button>
              <Button variant="contained" size="small" onClick={() => navigate("/login")}
                sx={{ bgcolor: "#4DD4AC", color: "#1B2F6E", fontWeight: 700, "&:hover": { bgcolor: "#3ab892" } }}>
                Get Started
              </Button>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* ── Hero ───────────────────────────────────────────────── */}
      <Box sx={{
        background: "linear-gradient(135deg, #0D1B3E 0%, #1B2F6E 50%, #2B3E7E 100%)",
        color: "white", py: { xs: 8, md: 12 }, position: "relative", overflow: "hidden",
      }}>
        {/* Decorative circles */}
        {[
          { size: 400, top: -100, right: -80, opacity: 0.06 },
          { size: 250, top: 60, right: 200, opacity: 0.05 },
          { size: 180, bottom: -60, left: 120, opacity: 0.07 },
        ].map((c, i) => (
          <Box key={i} sx={{
            position: "absolute", width: c.size, height: c.size, borderRadius: "50%",
            bgcolor: "#4DD4AC", opacity: c.opacity,
            top: c.top, right: (c as any).right, bottom: (c as any).bottom, left: (c as any).left,
          }} />
        ))}

        <Container maxWidth="lg" sx={{ position: "relative" }}>
          <Box sx={{ maxWidth: 720 }}>
            <Chip label="Quality Engineering Intelligence Platform"
              sx={{ bgcolor: "rgba(77,212,172,0.2)", color: "#4DD4AC", fontWeight: 700, mb: 3,
                border: "1px solid rgba(77,212,172,0.4)", fontSize: "0.8rem" }} />
            <Typography variant="h2" fontWeight={800} sx={{ lineHeight: 1.15, mb: 3, fontSize: { xs: "2.2rem", md: "3rem" } }}>
              Measure. Report. Transform.
              <Box component="span" sx={{ color: "#4DD4AC", display: "block" }}>
                Your QA Maturity.
              </Box>
            </Typography>
            <Typography variant="h6" sx={{ opacity: 0.85, mb: 4, lineHeight: 1.7, fontWeight: 400, maxWidth: 580 }}>
              Testhouse's AI-powered assessment platform gives organisations a structured, evidence-based view of their Quality Engineering maturity — with actionable recommendations and executive-ready reports.
            </Typography>
            <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
              <Button variant="contained" size="large" endIcon={<PlayArrow />}
                onClick={() => navigate("/login")}
                sx={{ bgcolor: "#4DD4AC", color: "#0D1B3E", fontWeight: 800, px: 4, py: 1.5,
                  "&:hover": { bgcolor: "#3ab892" }, boxShadow: "0 4px 24px rgba(77,212,172,0.4)" }}>
                Start Free Assessment
              </Button>
              <Button variant="outlined" size="large"
                onClick={() => navigate("/about")}
                sx={{ borderColor: "rgba(255,255,255,0.4)", color: "white", px: 4, py: 1.5,
                  "&:hover": { bgcolor: "rgba(255,255,255,0.08)" } }}>
                Learn More
              </Button>
            </Box>

            {/* Stats row */}
            <Box sx={{ display: "flex", gap: 4, mt: 6, flexWrap: "wrap" }}>
              {STATS.map((s) => (
                <Box key={s.label}>
                  <Typography variant="h4" fontWeight={800} sx={{ color: "#4DD4AC", lineHeight: 1 }}>
                    {s.value}
                  </Typography>
                  <Typography variant="caption" sx={{ opacity: 0.7 }}>{s.label}</Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </Container>
      </Box>

      {/* ── Assessment Packages ────────────────────────────────── */}
      <Box sx={{ py: 10, bgcolor: "#F7F9FF" }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: "center", mb: 6 }}>
            <Chip label="Assessment Packages" size="small"
              sx={{ bgcolor: "#2B3E7E18", color: "#2B3E7E", fontWeight: 700, mb: 2 }} />
            <Typography variant="h3" fontWeight={800} sx={{ color: "#0D1B3E", mb: 2 }}>
              Choose Your Assessment
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 560, mx: "auto" }}>
              Purchase individual assessment packages or the full QA Maturity suite. Each customer sees only what they have subscribed to.
            </Typography>
          </Box>

          <Grid container spacing={3}>
            {PACKAGES.map((pkg) => (
              <Grid size={{ xs: 12, sm: 6, md: 4 }} key={pkg.code}>
                <Card elevation={0} sx={{
                  border: `1.5px solid ${pkg.color}30`,
                  height: "100%", display: "flex", flexDirection: "column",
                  transition: "all 0.2s",
                  "&:hover": { transform: "translateY(-4px)", boxShadow: `0 12px 32px ${pkg.color}20` },
                }}>
                  <Box sx={{ p: 2.5, background: `linear-gradient(135deg, ${pkg.color}12 0%, ${pkg.color}06 100%)`, borderBottom: `1px solid ${pkg.color}20` }}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 1 }}>
                      <Box sx={{ p: 1, borderRadius: 2, bgcolor: pkg.color, color: "white", display: "flex" }}>
                        {pkg.icon}
                      </Box>
                      <Box>
                        <Typography variant="subtitle1" fontWeight={800} sx={{ color: pkg.color, lineHeight: 1.2 }}>
                          {pkg.name}
                        </Typography>
                        <Chip label={pkg.code} size="small"
                          sx={{ bgcolor: `${pkg.color}18`, color: pkg.color, fontWeight: 700, fontSize: "0.6rem", height: 18 }} />
                      </Box>
                    </Box>
                  </Box>
                  <CardContent sx={{ flex: 1, p: 2.5 }}>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2, lineHeight: 1.6 }}>
                      {pkg.desc}
                    </Typography>
                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                      {pkg.domains.map((d) => (
                        <Chip key={d} label={d} size="small" variant="outlined"
                          sx={{ fontSize: "0.65rem", borderColor: `${pkg.color}40`, color: pkg.color }} />
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* ── Features ───────────────────────────────────────────── */}
      <Box sx={{ py: 10 }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: "center", mb: 6 }}>
            <Chip label="Platform Features" size="small"
              sx={{ bgcolor: "#4DD4AC18", color: "#038387", fontWeight: 700, mb: 2 }} />
            <Typography variant="h3" fontWeight={800} sx={{ color: "#0D1B3E", mb: 2 }}>
              Built for Enterprise QA Teams
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 520, mx: "auto" }}>
              Everything your team needs to assess, benchmark, and improve quality engineering maturity at scale.
            </Typography>
          </Box>

          <Grid container spacing={3}>
            {FEATURES.map((f) => (
              <Grid size={{ xs: 12, sm: 6, md: 4 }} key={f.title}>
                <Box sx={{ p: 3, border: "1px solid #E8ECF4", borderRadius: 3, height: "100%",
                  transition: "all 0.2s", "&:hover": { borderColor: "#4DD4AC", bgcolor: "#F7FFFE" } }}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 1.5 }}>
                    <Box sx={{ p: 1, borderRadius: 1.5, bgcolor: "#2B3E7E18", color: "#2B3E7E" }}>
                      {f.icon}
                    </Box>
                    <Typography variant="subtitle2" fontWeight={700}>{f.title}</Typography>
                  </Box>
                  <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.6 }}>
                    {f.desc}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* ── How it works ───────────────────────────────────────── */}
      <Box sx={{ py: 10, bgcolor: "#F7F9FF" }}>
        <Container maxWidth="md">
          <Box sx={{ textAlign: "center", mb: 6 }}>
            <Typography variant="h3" fontWeight={800} sx={{ color: "#0D1B3E", mb: 2 }}>
              How It Works
            </Typography>
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {[
              { step: "01", title: "Select Your Package", desc: "Your organisation is assigned one or more assessment packages by your Testhouse account manager." },
              { step: "02", title: "Complete the Questionnaire", desc: "Work through structured, guided questions. Auto-saves progress so you can complete at your own pace." },
              { step: "03", title: "Review Your Score", desc: "See your maturity score across all domains with a risk heatmap and gap analysis." },
              { step: "04", title: "Download Your Report", desc: "Export a branded PDF or Excel report with scores, recommendations, and a 12-month transformation roadmap." },
            ].map((item, i) => (
              <Box key={i} sx={{ display: "flex", gap: 3, p: 3, bgcolor: "white",
                borderRadius: 3, border: "1px solid #E8ECF4", alignItems: "flex-start" }}>
                <Box sx={{ width: 48, height: 48, borderRadius: 2, bgcolor: "#2B3E7E",
                  display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <Typography variant="caption" fontWeight={800} sx={{ color: "#4DD4AC", fontSize: "0.85rem" }}>
                    {item.step}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 0.5 }}>{item.title}</Typography>
                  <Typography variant="body2" color="text.secondary">{item.desc}</Typography>
                </Box>
              </Box>
            ))}
          </Box>
        </Container>
      </Box>

      {/* ── CTA ────────────────────────────────────────────────── */}
      <Box sx={{
        background: "linear-gradient(135deg, #0D1B3E 0%, #2B3E7E 100%)",
        py: 10, color: "white", textAlign: "center",
      }}>
        <Container maxWidth="md">
          <Typography variant="h3" fontWeight={800} sx={{ mb: 2 }}>
            Ready to assess your QA maturity?
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.8, mb: 4, maxWidth: 480, mx: "auto" }}>
            Get your organisation's quality engineering score in under 25 minutes with a free assessment.
          </Typography>
          <Button variant="contained" size="large" endIcon={<ArrowForward />}
            onClick={() => navigate("/login")}
            sx={{ bgcolor: "#4DD4AC", color: "#0D1B3E", fontWeight: 800, px: 5, py: 1.8,
              "&:hover": { bgcolor: "#3ab892" }, boxShadow: "0 4px 24px rgba(77,212,172,0.4)" }}>
            Start Your Free Assessment
          </Button>
        </Container>
      </Box>

      {/* ── Footer ─────────────────────────────────────────────── */}
      <Box sx={{ bgcolor: "#0D1B3E", color: "rgba(255,255,255,0.7)", py: 4 }}>
        <Container maxWidth="lg">
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 2 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <TesthouseLogo height={28} />
              <Typography variant="caption">© {new Date().getFullYear()} Testhouse Ltd. All rights reserved.</Typography>
            </Box>
            <Box sx={{ display: "flex", gap: 3 }}>
              {[
                { label: "About", to: "/about" },
                { label: "Contact", to: "/contact" },
                { label: "Privacy Policy", to: "/privacy" },
                { label: "Terms & Conditions", to: "/terms" },
              ].map((l) => (
                <Link key={l.to} to={l.to}
                  style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none", fontSize: "0.8rem" }}>
                  {l.label}
                </Link>
              ))}
            </Box>
          </Box>
        </Container>
      </Box>
    </Box>
  );
}
