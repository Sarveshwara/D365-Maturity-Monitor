import { Box, Container, Typography, Grid, Card, CardContent, Chip, Button } from "@mui/material";
import { Link, useNavigate } from "react-router";
import { Assessment, Speed, Shield, People, TrendingUp, EmojiObjects } from "@mui/icons-material";
import TesthouseLogo from "../shared/TesthouseLogo";

const VALUES = [
  { icon: <Assessment sx={{ fontSize: 24 }} />, title: "Evidence-Based", desc: "Every score is grounded in structured questionnaire responses, not opinions. We give organisations hard data to drive quality decisions." },
  { icon: <EmojiObjects sx={{ fontSize: 24 }} />, title: "Actionable Insights", desc: "We don't just score — we prioritise. Every assessment generates a ranked list of improvements and a phased roadmap." },
  { icon: <People sx={{ fontSize: 24 }} />, title: "Customer-Centric", desc: "Each customer sees only the assessments relevant to them. Package-based entitlements mean the platform adapts to every engagement." },
  { icon: <Shield sx={{ fontSize: 24 }} />, title: "Enterprise Security", desc: "Data isolation enforced at database level. Role-based access. Full audit trail. Built for enterprise compliance from day one." },
  { icon: <Speed sx={{ fontSize: 24 }} />, title: "Speed to Insight", desc: "A full QA maturity assessment takes under 25 minutes. Reports generate instantly. No waiting for consultants to compile spreadsheets." },
  { icon: <TrendingUp sx={{ fontSize: 24 }} />, title: "Continuous Improvement", desc: "Track maturity over time. Run repeat assessments and measure progress against your previous scores and industry benchmarks." },
];

export default function AboutPage() {
  const navigate = useNavigate();
  return (
    <Box sx={{ bgcolor: "white", minHeight: "100vh" }}>
      {/* Nav */}
      <Box sx={{ borderBottom: "1px solid #E0E4EC", py: 1.5 }}>
        <Container maxWidth="lg">
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <Link to="/landing">
              <TesthouseLogo variant="nav" />
            </Link>
            <Box sx={{ display: "flex", gap: 3, alignItems: "center" }}>
              <Link to="/contact" style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>Contact</Link>
              <Button variant="contained" size="small" onClick={() => navigate("/login")}
                sx={{ bgcolor: "#4DD4AC", color: "#1B2F6E", fontWeight: 700, "&:hover": { bgcolor: "#3ab892" } }}>
                Get Started
              </Button>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* Hero */}
      <Box sx={{ background: "linear-gradient(135deg, #0D1B3E 0%, #2B3E7E 100%)", color: "white", py: 10 }}>
        <Container maxWidth="md" sx={{ textAlign: "center" }}>
          <Chip label="About Testhouse" sx={{ bgcolor: "rgba(77,212,172,0.2)", color: "#4DD4AC", fontWeight: 700, mb: 3, border: "1px solid rgba(77,212,172,0.3)" }} />
          <Typography variant="h2" fontWeight={800} sx={{ mb: 3, lineHeight: 1.2 }}>
            We help organisations build
            <Box component="span" sx={{ color: "#4DD4AC" }}> better software, faster.</Box>
          </Typography>
          <Typography variant="h6" sx={{ opacity: 0.8, lineHeight: 1.7, fontWeight: 400, maxWidth: 600, mx: "auto" }}>
            Testhouse is a global quality engineering and software testing company. We have been helping organisations deliver high-quality software since 2000. The QA Intelligence Platform is our tool for making quality maturity visible, measurable and improvable.
          </Typography>
        </Container>
      </Box>

      {/* Mission */}
      <Box sx={{ py: 10 }}>
        <Container maxWidth="md">
          <Grid container spacing={6} alignItems="center">
            <Grid size={{ xs: 12, md: 6 }}>
              <Chip label="Our Mission" size="small" sx={{ bgcolor: "#2B3E7E18", color: "#2B3E7E", fontWeight: 700, mb: 2 }} />
              <Typography variant="h4" fontWeight={800} sx={{ color: "#0D1B3E", mb: 2 }}>
                Making quality maturity measurable for every organisation
              </Typography>
              <Typography variant="body1" color="text.secondary" sx={{ lineHeight: 1.8, mb: 2 }}>
                For too long, quality engineering maturity has been assessed through expensive, time-consuming manual consultancy engagements — producing reports that quickly become outdated.
              </Typography>
              <Typography variant="body1" color="text.secondary" sx={{ lineHeight: 1.8 }}>
                The QA Intelligence Platform changes that. It gives every organisation — from a startup to a global enterprise — the ability to assess their quality maturity in minutes, track improvement over time, and generate executive-ready reports without waiting weeks for a consultant's spreadsheet.
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Box sx={{ bgcolor: "#F7F9FF", borderRadius: 3, p: 4, border: "1px solid #E0E4EC" }}>
                {[
                  { value: "25+", label: "Years of QA expertise" },
                  { value: "500+", label: "Enterprise clients served" },
                  { value: "5", label: "Assessment packages" },
                  { value: "88+", label: "Security checks" },
                ].map((s) => (
                  <Box key={s.label} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", py: 2, borderBottom: "1px solid #E8ECF4", "&:last-child": { borderBottom: "none" } }}>
                    <Typography variant="body2" color="text.secondary">{s.label}</Typography>
                    <Typography variant="h5" fontWeight={800} color="primary.main">{s.value}</Typography>
                  </Box>
                ))}
              </Box>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* Values */}
      <Box sx={{ py: 10, bgcolor: "#F7F9FF" }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: "center", mb: 6 }}>
            <Typography variant="h3" fontWeight={800} sx={{ color: "#0D1B3E", mb: 2 }}>
              Our Principles
            </Typography>
          </Box>
          <Grid container spacing={3}>
            {VALUES.map((v) => (
              <Grid size={{ xs: 12, sm: 6, md: 4 }} key={v.title}>
                <Card elevation={0} sx={{ height: "100%", border: "1px solid #E8ECF4" }}>
                  <CardContent sx={{ p: 3 }}>
                    <Box sx={{ p: 1, borderRadius: 1.5, bgcolor: "#2B3E7E18", color: "#2B3E7E", display: "inline-flex", mb: 2 }}>
                      {v.icon}
                    </Box>
                    <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>{v.title}</Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.7 }}>{v.desc}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* CTA */}
      <Box sx={{ py: 8, textAlign: "center" }}>
        <Container maxWidth="sm">
          <Typography variant="h4" fontWeight={800} sx={{ color: "#0D1B3E", mb: 2 }}>
            Ready to get started?
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
            Contact us to set up your organisation's assessment package.
          </Typography>
          <Box sx={{ display: "flex", gap: 2, justifyContent: "center" }}>
            <Button variant="contained" onClick={() => navigate("/contact")}
              sx={{ bgcolor: "#2B3E7E", px: 3 }}>Contact Us</Button>
            <Button variant="outlined" onClick={() => navigate("/login")}
              sx={{ borderColor: "#2B3E7E", color: "#2B3E7E", px: 3 }}>Sign In</Button>
          </Box>
        </Container>
      </Box>

      {/* Footer */}
      <Box sx={{ bgcolor: "#0D1B3E", py: 3, textAlign: "center" }}>
        <Typography variant="caption" sx={{ color: "rgba(255,255,255,0.5)" }}>
          © {new Date().getFullYear()} Testhouse Ltd ·{" "}
          {[{ l: "Privacy", to: "/privacy" }, { l: "Terms", to: "/terms" }, { l: "Home", to: "/landing" }].map((x) => (
            <span key={x.to}>
              <Link to={x.to} style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>{x.l}</Link>
              {" · "}
            </span>
          ))}
        </Typography>
      </Box>
    </Box>
  );
}
