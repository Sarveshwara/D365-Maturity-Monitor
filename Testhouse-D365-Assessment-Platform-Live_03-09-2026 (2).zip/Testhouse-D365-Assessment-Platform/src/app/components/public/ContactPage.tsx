import { useState } from "react";
import { Box, Container, Typography, Grid, Card, CardContent, TextField, Button, Chip, Alert, CircularProgress } from "@mui/material";
import { Link } from "react-router";
import { Email, Phone, LocationOn, CheckCircle } from "@mui/icons-material";
import TesthouseLogo from "../shared/TesthouseLogo";

const ENQUIRY_TYPES = [
  "New Assessment Package", "Existing Subscription", "Technical Support",
  "Partnership / Reseller", "General Enquiry",
];

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", company: "", type: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Simulate submission — wire to a real form service (e.g. Formspree) in production
    await new Promise((r) => setTimeout(r, 1200));
    setSubmitting(false);
    setSubmitted(true);
  };

  const set = (field: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((p) => ({ ...p, [field]: e.target.value }));

  return (
    <Box sx={{ bgcolor: "white", minHeight: "100vh" }}>
      {/* Nav */}
      <Box sx={{ borderBottom: "1px solid #E0E4EC", py: 1.5 }}>
        <Container maxWidth="lg">
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <Link to="/landing">
              <TesthouseLogo variant="nav" />
            </Link>
            <Box sx={{ display: "flex", gap: 3 }}>
              <Link to="/about"   style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>About</Link>
              <Link to="/landing" style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>Home</Link>
              <Link to="/login"   style={{ color: "#2B3E7E", fontSize: "0.85rem", fontWeight: 700, textDecoration: "none" }}>Sign In</Link>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* Header */}
      <Box sx={{ background: "linear-gradient(135deg, #0D1B3E 0%, #2B3E7E 100%)", color: "white", py: 8 }}>
        <Container maxWidth="md" sx={{ textAlign: "center" }}>
          <Chip label="Get in Touch" sx={{ bgcolor: "rgba(77,212,172,0.2)", color: "#4DD4AC", fontWeight: 700, mb: 3, border: "1px solid rgba(77,212,172,0.3)" }} />
          <Typography variant="h3" fontWeight={800} sx={{ mb: 2 }}>
            Contact Testhouse
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.8, maxWidth: 480, mx: "auto", lineHeight: 1.7 }}>
            Interested in an assessment package for your organisation? Our team will get back to you within one business day.
          </Typography>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Grid container spacing={6}>
          {/* Contact form */}
          <Grid size={{ xs: 12, md: 7 }}>
            <Typography variant="h5" fontWeight={700} sx={{ mb: 3, color: "#0D1B3E" }}>
              Send us a message
            </Typography>

            {submitted ? (
              <Box sx={{ textAlign: "center", py: 6 }}>
                <CheckCircle sx={{ fontSize: 56, color: "#107C10", mb: 2 }} />
                <Typography variant="h6" fontWeight={700} sx={{ mb: 1 }}>Message received!</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Thank you for contacting Testhouse. We will respond to {form.email} within one business day.
                </Typography>
                <Button variant="outlined" onClick={() => { setSubmitted(false); setForm({ name: "", email: "", company: "", type: "", message: "" }); }}>
                  Send another message
                </Button>
              </Box>
            ) : (
              <form onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField fullWidth label="Full Name" value={form.name}
                      onChange={set("name")} required size="small" />
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField fullWidth label="Work Email" type="email" value={form.email}
                      onChange={set("email")} required size="small" />
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <TextField fullWidth label="Company / Organisation" value={form.company}
                      onChange={set("company")} size="small" />
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <TextField fullWidth label="Enquiry Type" value={form.type}
                      onChange={set("type")} size="small" select
                      SelectProps={{ native: true }}>
                      <option value="">Select…</option>
                      {ENQUIRY_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </TextField>
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <TextField fullWidth label="Message" value={form.message}
                      onChange={set("message")} required multiline rows={5} size="small"
                      placeholder="Tell us about your organisation and what you're looking for…" />
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <Alert severity="info" sx={{ mb: 2, fontSize: "0.78rem" }}>
                      By submitting this form you agree to our{" "}
                      <Link to="/privacy" style={{ color: "#0F6CBD" }}>Privacy Policy</Link>.
                      We will only use your details to respond to your enquiry.
                    </Alert>
                    <Button type="submit" variant="contained" size="large" fullWidth
                      disabled={submitting || !form.name || !form.email || !form.message}
                      sx={{ bgcolor: "#2B3E7E", py: 1.5 }}>
                      {submitting ? <CircularProgress size={22} color="inherit" /> : "Send Message"}
                    </Button>
                  </Grid>
                </Grid>
              </form>
            )}
          </Grid>

          {/* Contact info */}
          <Grid size={{ xs: 12, md: 5 }}>
            <Typography variant="h5" fontWeight={700} sx={{ mb: 3, color: "#0D1B3E" }}>
              Get in touch directly
            </Typography>

            {[
              { icon: <Email sx={{ fontSize: 20 }} />, label: "General Enquiries", value: "contact@testhouse.net" },
              { icon: <Email sx={{ fontSize: 20 }} />, label: "Platform Support", value: "support@testhouse.net" },
              { icon: <Email sx={{ fontSize: 20 }} />, label: "Privacy & Legal", value: "privacy@testhouse.net" },
              { icon: <LocationOn sx={{ fontSize: 20 }} />, label: "Headquarters", value: "United Kingdom" },
            ].map((c) => (
              <Box key={c.label} sx={{ display: "flex", gap: 2, mb: 3, alignItems: "flex-start" }}>
                <Box sx={{ p: 1, borderRadius: 1.5, bgcolor: "#2B3E7E18", color: "#2B3E7E", flexShrink: 0 }}>
                  {c.icon}
                </Box>
                <Box>
                  <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ textTransform: "uppercase", letterSpacing: 0.5 }}>
                    {c.label}
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>{c.value}</Typography>
                </Box>
              </Box>
            ))}

            <Card elevation={0} sx={{ bgcolor: "#F7F9FF", border: "1px solid #E8ECF4", mt: 4 }}>
              <CardContent sx={{ p: 2.5 }}>
                <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>Response times</Typography>
                {[
                  { type: "General enquiries", time: "1 business day" },
                  { type: "Platform support", time: "4 business hours" },
                  { type: "Security issues", time: "2 business hours" },
                ].map((r) => (
                  <Box key={r.type} sx={{ display: "flex", justifyContent: "space-between", py: 1, borderBottom: "1px solid #E8ECF4", "&:last-child": { borderBottom: "none" } }}>
                    <Typography variant="caption" color="text.secondary">{r.type}</Typography>
                    <Typography variant="caption" fontWeight={700} color="#107C10">{r.time}</Typography>
                  </Box>
                ))}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Container>

      {/* Footer */}
      <Box sx={{ bgcolor: "#0D1B3E", py: 3, textAlign: "center" }}>
        <Typography variant="caption" sx={{ color: "rgba(255,255,255,0.5)" }}>
          © {new Date().getFullYear()} Testhouse Ltd ·{" "}
          {[{ l: "Privacy", to: "/privacy" }, { l: "Terms", to: "/terms" }, { l: "Home", to: "/landing" }].map((x) => (
            <span key={x.to}>
              <Link to={x.to} style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>{x.l}</Link>
              {" · "}
            </span>
          ))}
        </Typography>
      </Box>
    </Box>
  );
}
