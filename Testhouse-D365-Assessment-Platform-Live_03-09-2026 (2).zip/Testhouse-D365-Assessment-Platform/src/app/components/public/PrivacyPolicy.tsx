import { Box, Container, Typography, Divider, Chip } from "@mui/material";
import { Link } from "react-router";
import TesthouseLogo from "../shared/TesthouseLogo";

const SECTIONS = [
  {
    title: "1. Who We Are",
    body: `Testhouse Ltd ("Testhouse", "we", "us", "our") is a quality engineering and software testing services company. This Privacy Policy applies to the Testhouse Quality Engineering Intelligence Platform (the "Platform"), accessible to authorised users under a subscription agreement.

Testhouse Ltd is registered in England and Wales. Our registered office is in the United Kingdom.`,
  },
  {
    title: "2. Information We Collect",
    body: `We collect the following categories of personal data:

**Account Data:** Name, email address, job title and organisation name provided when your account is created or when you are invited by an administrator.

**Assessment Data:** Responses to questionnaire items, scores, notes and comments you enter during assessments. This data belongs to your organisation.

**Usage Data:** Pages visited, features used, timestamps of actions, and assessment progress. Collected automatically via our platform.

**Audit Logs:** Records of login events, assessment completions, report exports, user management actions, and other platform activities.

**Technical Data:** IP address, browser type, device type and operating system. Collected automatically by our infrastructure.`,
  },
  {
    title: "3. How We Use Your Information",
    body: `We use your personal data to:

• Provide, operate and maintain the Platform
• Authenticate your identity and manage your session
• Deliver assessment results, scores and reports
• Send invitation and password reset emails
• Enforce role-based access control and data isolation between customers
• Maintain audit logs for compliance and security purposes
• Improve platform features and fix technical issues
• Communicate important platform notices and updates

We do not use your personal data for advertising or sell it to third parties.`,
  },
  {
    title: "4. Legal Basis for Processing (UK/EEA)",
    body: `We process your personal data under the following legal bases:

**Contractual necessity:** Processing required to deliver the Platform services under your organisation's subscription agreement.

**Legitimate interests:** Platform security, fraud prevention, audit logging, and service improvement — where these interests are not overridden by your rights.

**Legal obligation:** Retention of certain records for compliance with applicable law.

**Consent:** Where you have provided explicit consent (e.g. optional communications).`,
  },
  {
    title: "5. Data Storage and Security",
    body: `Your data is stored on Supabase infrastructure, hosted on AWS in the European Union region. We implement the following security measures:

• Row Level Security (RLS) ensuring your organisation's data is isolated from other customers
• TLS 1.3 encryption in transit for all data
• AES-256 encryption at rest
• Role-based access control enforced at both application and database levels
• Supabase Auth for identity management with multi-factor authentication support
• Audit logging of all access and modification events

We do not store payment card information. Subscription billing is handled by our commercial team.`,
  },
  {
    title: "6. Data Retention",
    body: `We retain your data for the following periods:

• **Account data:** For the duration of your subscription plus 12 months after termination
• **Assessment data:** For the duration of your subscription plus 24 months after termination (to support historical reporting)
• **Audit logs:** 12 months from the date of the event
• **Backup data:** Deleted within 30 days of the primary data deletion date

You may request deletion of your personal data at any time (subject to legal retention obligations) by contacting privacy@testhouse.net.`,
  },
  {
    title: "7. Data Sharing",
    body: `We share your data only in the following circumstances:

**Within your organisation:** Administrators and authorised users within your organisation can access assessment data according to their assigned roles.

**Service providers:** We use Supabase (database and authentication infrastructure). Supabase processes data on our behalf under a Data Processing Agreement.

**Legal requirements:** We may disclose data if required by law, court order or regulatory authority.

We do not share, sell or rent your personal data to any third party for their own marketing purposes.`,
  },
  {
    title: "8. Your Rights",
    body: `Under UK GDPR and applicable data protection law, you have the right to:

• **Access** — Request a copy of the personal data we hold about you
• **Rectification** — Request correction of inaccurate or incomplete data
• **Erasure** — Request deletion of your personal data (subject to legal retention obligations)
• **Restriction** — Request that we restrict processing of your data
• **Portability** — Receive your data in a structured, machine-readable format
• **Object** — Object to processing based on legitimate interests

To exercise any of these rights, contact us at privacy@testhouse.net. We will respond within 30 days.

If you are unhappy with how we handle your data, you have the right to lodge a complaint with the Information Commissioner's Office (ICO) at ico.org.uk.`,
  },
  {
    title: "9. Cookies",
    body: `The Platform uses session cookies strictly necessary for authentication and maintaining your logged-in state. We do not use advertising, tracking or analytics cookies.

Your session cookie is deleted when you log out or when your session expires.`,
  },
  {
    title: "10. Changes to This Policy",
    body: `We may update this Privacy Policy from time to time. When we make material changes, we will notify you by email or by a prominent notice within the Platform. The date of the latest revision is shown at the top of this page.

Your continued use of the Platform after changes take effect constitutes acceptance of the revised policy.`,
  },
  {
    title: "11. Contact Us",
    body: `For any questions about this Privacy Policy or how we handle your personal data:

**Email:** privacy@testhouse.net
**Post:** Testhouse Ltd, Data Protection Officer, United Kingdom

For general enquiries: contact@testhouse.net
Website: www.testhouse.net`,
  },
];

export default function PrivacyPolicy() {
  return (
    <Box sx={{ bgcolor: "white", minHeight: "100vh" }}>
      {/* Nav */}
      <Box sx={{ borderBottom: "1px solid #E0E4EC", py: 1.5 }}>
        <Container maxWidth="lg">
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <Link to="/landing">
              <TesthouseLogo variant="nav" />
            </Link>
            <Box sx={{ display: "flex", gap: 3 }}>
              <Link to="/landing" style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>Home</Link>
              <Link to="/terms"   style={{ color: "#555", fontSize: "0.85rem", textDecoration: "none" }}>Terms</Link>
              <Link to="/login"   style={{ color: "#2B3E7E", fontSize: "0.85rem", fontWeight: 700, textDecoration: "none" }}>Sign In</Link>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* Header */}
      <Box sx={{ bgcolor: "#F7F9FF", borderBottom: "1px solid #E0E4EC", py: 6 }}>
        <Container maxWidth="md">
          <Chip label="Legal" size="small" sx={{ bgcolor: "#2B3E7E18", color: "#2B3E7E", fontWeight: 700, mb: 2 }} />
          <Typography variant="h3" fontWeight={800} sx={{ color: "#0D1B3E", mb: 1 }}>
            Privacy Policy
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Last updated: {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1.5, maxWidth: 560 }}>
            This policy explains how Testhouse Ltd collects, uses and protects your personal data when you use the Quality Engineering Intelligence Platform.
          </Typography>
        </Container>
      </Box>

      {/* Content */}
      <Container maxWidth="md" sx={{ py: 8 }}>
        {SECTIONS.map((section, i) => (
          <Box key={i} sx={{ mb: 5 }}>
            <Typography variant="h6" fontWeight={700} sx={{ color: "#0D1B3E", mb: 2 }}>
              {section.title}
            </Typography>
            {section.body.split("\n\n").map((para, j) => (
              <Typography key={j} variant="body2" color="text.secondary"
                sx={{ mb: 1.5, lineHeight: 1.8, whiteSpace: "pre-line" }}>
                {para.replace(/\*\*(.*?)\*\*/g, "$1")}
              </Typography>
            ))}
            {i < SECTIONS.length - 1 && <Divider sx={{ mt: 3 }} />}
          </Box>
        ))}
      </Container>

      {/* Footer */}
      <Box sx={{ bgcolor: "#0D1B3E", py: 3, textAlign: "center" }}>
        <Typography variant="caption" sx={{ color: "rgba(255,255,255,0.5)" }}>
          © {new Date().getFullYear()} Testhouse Ltd ·{" "}
          <Link to="/terms" style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Terms</Link>
          {" · "}
          <Link to="/privacy" style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Privacy</Link>
          {" · "}
          <Link to="/landing" style={{ color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Home</Link>
        </Typography>
      </Box>
    </Box>
  );
}
