import { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid, Box, Chip, CircularProgress, Alert, LinearProgress } from "@mui/material";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, Radar, PieChart, Pie, Cell,
} from "recharts";
import { TrendingUp, Speed, Assessment, CheckCircle, Refresh } from "@mui/icons-material";
import { getDashboardStats } from "../../lib/api";

const TYPE_COLORS: Record<string, string> = {
  QA_MATURITY: "#2B3E7E",
  PERFORMANCE: "#0F6CBD",
  SECURITY:    "#6B3FBE",
};

const TYPE_LABELS: Record<string, string> = {
  QA_MATURITY: "QA Maturity",
  PERFORMANCE: "Performance",
  SECURITY:    "Security",
};

const STATUS_COLORS: Record<string, string> = {
  Completed:   "#107C10",
  "In Progress": "#0F6CBD",
  Draft:       "#E0E4EC",
};

function KPICard({ title, value, sub, icon, color = "#2B3E7E" }: {
  title: string; value: string | number; sub?: string; icon: React.ReactNode; color?: string;
}) {
  return (
    <Card sx={{ height: "100%" }}>
      <CardContent>
        <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
          <Typography color="text.secondary" variant="body2" fontWeight={600}>{title}</Typography>
          <Box sx={{ color }}>{icon}</Box>
        </Box>
        <Typography variant="h4" fontWeight={800} sx={{ color, mb: 0.5 }}>{value}</Typography>
        {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
      </CardContent>
    </Card>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: 260, flexDirection: "column", gap: 1 }}>
      <Assessment sx={{ fontSize: 36, color: "text.disabled" }} />
      <Typography variant="body2" color="text.secondary">{label}</Typography>
      <Typography variant="caption" color="text.disabled">Complete assessments to see data here</Typography>
    </Box>
  );
}

export default function ExecutiveDashboard() {
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const stats = await getDashboardStats();
      setData(stats);
    } catch (e: any) {
      setError(e.message + " — deploy the edge function to load live data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const kpis = data?.kpis ?? {};
  const byType = data?.byType ?? {};
  const monthly: any[] = data?.monthlyTrend ?? [];
  const recent: any[]  = data?.recentRuns ?? [];
  const statusDist: any[] = data?.statusDist ?? [];

  // Bar chart data — assessments by type
  const typeBarData = Object.entries(byType)
    .filter(([, v]) => (v as number) > 0)
    .map(([key, count]) => ({ name: TYPE_LABELS[key] ?? key, count: count as number, color: TYPE_COLORS[key] ?? "#2B3E7E" }));

  // Score summary
  const scoreItems = [
    { label: "Avg QA Maturity Score", value: kpis.avgScoreQA, max: 5, fmt: (v: number) => `${v.toFixed(2)} / 5.0` },
    { label: "Avg Performance Score", value: kpis.avgScorePerf, max: 100, fmt: (v: number) => `${v.toFixed(0)}%` },
    { label: "Avg Security Score",    value: kpis.avgScoreSec,  max: 100, fmt: (v: number) => `${v.toFixed(0)}%` },
  ].filter((s) => s.value != null);

  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
        <Typography variant="h4" fontWeight={700}>Executive Dashboard</Typography>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          {!loading && (
            <Chip label="Live Data" size="small"
              sx={{ bgcolor: "#E8FBF5", color: "#107C10", fontWeight: 700, fontSize: "0.65rem" }} />
          )}
          <Refresh sx={{ cursor: "pointer", color: "text.secondary", fontSize: 20 }} onClick={load} />
        </Box>
      </Box>

      {error && (
        <Alert severity="warning" sx={{ mb: 3 }} onClose={() => setError(null)}>{error}</Alert>
      )}

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 10 }}><CircularProgress /></Box>
      ) : (
        <>
          {/* KPI Cards */}
          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
              <KPICard title="Total Assessments" value={kpis.totalRuns ?? 0}
                sub={`${kpis.completedRuns ?? 0} completed`} color="#2B3E7E"
                icon={<Assessment />} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
              <KPICard title="Completion Rate" value={`${kpis.completionRate ?? 0}%`}
                sub="Of all started assessments" color="#107C10"
                icon={<CheckCircle />} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
              <KPICard
                title="Avg QA Score"
                value={kpis.avgScoreQA != null ? `${(kpis.avgScoreQA as number).toFixed(1)} / 5` : "—"}
                sub="Across completed QA runs" color="#0F6CBD"
                icon={<Speed />} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 3 }}>
              <KPICard
                title="In Progress"
                value={kpis.inProgressRuns ?? 0}
                sub={`${kpis.draftRuns ?? 0} drafts`} color="#E65C00"
                icon={<TrendingUp />} />
            </Grid>
          </Grid>

          {/* Score summary bars */}
          {scoreItems.length > 0 && (
            <Card sx={{ mb: 3 }}>
              <CardContent>
                <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Average Scores by Assessment Type</Typography>
                <Grid container spacing={3}>
                  {scoreItems.map((s) => (
                    <Grid size={{ xs: 12, md: 4 }} key={s.label}>
                      <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>{s.label}</Typography>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                        <LinearProgress variant="determinate"
                          value={((s.value as number) / s.max) * 100}
                          sx={{ flex: 1, height: 10, borderRadius: 5, bgcolor: "#E8ECF4",
                            "& .MuiLinearProgress-bar": { bgcolor: "#2B3E7E", borderRadius: 5 } }} />
                        <Typography variant="body2" fontWeight={800} color="primary.main" sx={{ minWidth: 60 }}>
                          {s.fmt(s.value as number)}
                        </Typography>
                      </Box>
                    </Grid>
                  ))}
                </Grid>
              </CardContent>
            </Card>
          )}

          {/* Charts row */}
          <Grid container spacing={3} sx={{ mb: 3 }}>
            {/* Monthly trend */}
            <Grid size={{ xs: 12, md: 8 }}>
              <Card>
                <CardContent>
                  <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Assessment Activity — Last 6 Months</Typography>
                  {monthly.some((m) => m.total > 0) ? (
                    <ResponsiveContainer width="100%" height={260}>
                      <LineChart data={monthly}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                        <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                        <Tooltip />
                        <Legend key="exec-line-legend" />
                        <Line key="exec-line-qa"   type="monotone" dataKey="qa"   name="QA Maturity"  stroke="#2B3E7E" strokeWidth={2} dot={{ r: 4 }} />
                        <Line key="exec-line-perf" type="monotone" dataKey="perf" name="Performance"  stroke="#0F6CBD" strokeWidth={2} dot={{ r: 4 }} />
                        <Line key="exec-line-sec"  type="monotone" dataKey="sec"  name="Security"     stroke="#6B3FBE" strokeWidth={2} dot={{ r: 4 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : <EmptyState label="No completed assessments in the last 6 months" />}
                </CardContent>
              </Card>
            </Grid>

            {/* Status distribution */}
            <Grid size={{ xs: 12, md: 4 }}>
              <Card>
                <CardContent>
                  <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Status Distribution</Typography>
                  {statusDist.length > 0 ? (
                    <ResponsiveContainer width="100%" height={260}>
                      <PieChart>
                        <Pie key="exec-pie-status" data={statusDist}
                          cx="50%" cy="45%" innerRadius={55} outerRadius={85}
                          paddingAngle={3} dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}>
                          {statusDist.map((entry: any, i: number) => (
                            <Cell key={`exec-status-cell-${i}`}
                              fill={STATUS_COLORS[entry.name] ?? "#E0E4EC"} />
                          ))}
                        </Pie>
                        <Tooltip key="exec-pie-tooltip" />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : <EmptyState label="No assessment data yet" />}
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Assessments by type bar */}
          {typeBarData.length > 0 && (
            <Grid container spacing={3} sx={{ mb: 3 }}>
              <Grid size={{ xs: 12, md: 6 }}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>
                      Completed Assessments by Type
                    </Typography>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={typeBarData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                        <Tooltip />
                        <Bar key="exec-bar-type" dataKey="count" name="Completed" radius={[4, 4, 0, 0]}>
                          {typeBarData.map((entry: any, i: number) => (
                            <Cell key={`exec-type-cell-${i}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </Grid>

              {/* Recent runs */}
              <Grid size={{ xs: 12, md: 6 }}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Recent Assessments</Typography>
                    {recent.length === 0 ? (
                      <EmptyState label="No assessments started yet" />
                    ) : (
                      recent.slice(0, 6).map((run: any) => (
                        <Box key={run.id} sx={{
                          display: "flex", alignItems: "center", justifyContent: "space-between",
                          py: 1.2, borderBottom: "1px solid #F0F0F0", "&:last-child": { borderBottom: "none" },
                        }}>
                          <Box>
                            <Typography variant="body2" fontWeight={600} noWrap sx={{ maxWidth: 200 }}>
                              {run.name}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {new Date(run.run_date).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}
                            </Typography>
                          </Box>
                          <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
                            {run.score != null && (
                              <Typography variant="caption" fontWeight={700} color="primary.main">
                                {run.type === "QA_MATURITY"
                                  ? `${(run.score as number).toFixed(1)}/5`
                                  : `${Math.round(run.score as number)}%`}
                              </Typography>
                            )}
                            <Chip label={run.status} size="small" sx={{
                              bgcolor: run.status === "completed" ? "#E8FBF5"
                                : run.status === "in_progress" ? "#E8F4FF" : "#F5F5F5",
                              color: run.status === "completed" ? "#107C10"
                                : run.status === "in_progress" ? "#0F6CBD" : "#999",
                              fontWeight: 700, fontSize: "0.6rem",
                              textTransform: "capitalize",
                            }} />
                          </Box>
                        </Box>
                      ))
                    )}
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          )}

          {/* Empty state when no data at all */}
          {kpis.totalRuns === 0 && (
            <Card sx={{ bgcolor: "#F7F9FF", border: "1px solid #E0E4EC" }}>
              <CardContent sx={{ textAlign: "center", py: 6 }}>
                <Assessment sx={{ fontSize: 56, color: "text.disabled", mb: 2 }} />
                <Typography variant="h6" fontWeight={700} sx={{ mb: 1 }}>No assessment data yet</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 420, mx: "auto" }}>
                  Once your team starts completing assessments, live scores, trends, and insights will appear here automatically.
                </Typography>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </Box>
  );
}
