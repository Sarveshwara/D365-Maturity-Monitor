import { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid, Box, LinearProgress, Chip, Alert } from "@mui/material";
import { assessmentService } from "../../lib/assessment-service";
import { getMaturityLevel } from "../../data/assessmentQuestions";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";

const maturityLevels = [
  { domain: "Test Strategy & Planning", current: 4, target: 5, level: "Optimizing" },
  { domain: "Test Automation", current: 3, target: 4, level: "Defined" },
  { domain: "Test Data Management", current: 3, target: 5, level: "Defined" },
  { domain: "CI/CD Integration", current: 4, target: 5, level: "Managed" },
  { domain: "Defect Management", current: 4, target: 5, level: "Managed" },
  { domain: "Test Metrics & Analytics", current: 5, target: 5, level: "Optimizing" },
];

const radarData = [
  { capability: "Strategy", current: 85, target: 100 },
  { capability: "Automation", current: 72, target: 95 },
  { capability: "Data Mgmt", current: 68, target: 90 },
  { capability: "CI/CD", current: 80, target: 95 },
  { capability: "Defects", current: 88, target: 100 },
  { capability: "Metrics", current: 92, target: 100 },
  { capability: "Tools", current: 75, target: 90 },
  { capability: "Skills", current: 70, target: 85 },
];

const progressData = [
  { period: "6mo ago", score: 62 },
  { period: "5mo ago", score: 68 },
  { period: "4mo ago", score: 72 },
  { period: "3mo ago", score: 76 },
  { period: "2mo ago", score: 78 },
  { period: "1mo ago", score: 82 },
  { period: "Current", score: 85 },
];

const recommendations = [
  {
    priority: "High",
    area: "Test Automation",
    recommendation: "Increase API test automation coverage to 90%",
    impact: "High",
  },
  {
    priority: "High",
    area: "Test Data Management",
    recommendation: "Implement synthetic test data generation",
    impact: "Medium",
  },
  {
    priority: "Medium",
    area: "Skills Development",
    recommendation: "Conduct advanced automation training for team",
    impact: "High",
  },
  {
    priority: "Medium",
    area: "CI/CD Integration",
    recommendation: "Add performance testing to pipeline",
    impact: "Medium",
  },
  {
    priority: "Low",
    area: "Documentation",
    recommendation: "Standardize test case documentation format",
    impact: "Low",
  },
];

const calculateMaturityScore = (responses: Record<string, unknown>) => {
  const scores = Object.values(responses)
    .map((response) => {
      if (typeof response === "number") return response;
      if (typeof response === "string" && response.trim() !== "") return Number(response);
      if (response && typeof response === "object" && "score" in response) {
        return Number((response as { score: unknown }).score);
      }
      return NaN;
    })
    .filter((score) => Number.isFinite(score));

  const overall = scores.length
    ? scores.reduce((sum, score) => sum + score, 0) / scores.length
    : 0;

  return { overall, totalAnswered: scores.length };
};

const getLevelColor = (level: number) => {
  if (level >= 4) return "success";
  if (level === 3) return "primary";
  if (level === 2) return "warning";
  return "error";
};

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "High":
      return "error";
    case "Medium":
      return "warning";
    default:
      return "info";
  }
};

export default function QAMaturityDashboard() {
  const [latestRun, setLatestRun] = useState<any | null>(null);

  useEffect(() => {
    assessmentService.list("QA_MATURITY").then(({ runs }) => {
      const completed = runs.filter((r) => r.status === "completed");
      if (completed.length > 0) setLatestRun(completed[0]);
    });
  }, []);

  const liveScore = latestRun
    ? calculateMaturityScore(latestRun.responses_data ?? {})
    : null;

  return (
    <Box>
      {/* Live latest assessment banner */}
      {latestRun && liveScore && (
        <Card sx={{
          mb: 3, background: "linear-gradient(135deg, #1B2F6E 0%, #2B3E7E 100%)", color: "white",
        }}>
          <CardContent sx={{ p: 2.5 }}>
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 2 }}>
              <Box>
                <Chip label="Latest Completed Assessment" size="small"
                  sx={{ bgcolor: "rgba(77,212,172,0.2)", color: "#4DD4AC", fontWeight: 700,
                    border: "1px solid rgba(77,212,172,0.4)", mb: 1 }} />
                <Typography variant="h5" fontWeight={800}>{latestRun.assessment_name}</Typography>
                <Typography variant="caption" sx={{ opacity: 0.7 }}>
                  Completed {new Date(latestRun.completed_at).toLocaleDateString("en-GB",
                    { day: "numeric", month: "long", year: "numeric" })}
                </Typography>
              </Box>
              <Box sx={{ display: "flex", gap: 4 }}>
                <Box sx={{ textAlign: "center" }}>
                  <Typography variant="h3" fontWeight={800} sx={{ color: "#4DD4AC" }}>
                    {liveScore.overall.toFixed(1)}
                  </Typography>
                  <Typography variant="caption" sx={{ opacity: 0.7 }}>Score / 5.0</Typography>
                </Box>
                <Box sx={{ textAlign: "center" }}>
                  <Typography variant="h5" fontWeight={700}>
                    {getMaturityLevel(liveScore.overall)}
                  </Typography>
                  <Typography variant="caption" sx={{ opacity: 0.7 }}>Maturity Level</Typography>
                </Box>
                <Box sx={{ textAlign: "center" }}>
                  <Typography variant="h5" fontWeight={700}>
                    {liveScore.totalAnswered} / 15
                  </Typography>
                  <Typography variant="caption" sx={{ opacity: 0.7 }}>Questions</Typography>
                </Box>
              </Box>
            </Box>
          </CardContent>
        </Card>
      )}

      <Typography variant="h4" sx={{ mb: 3 }}>
        QA Maturity Dashboard
      </Typography>

      {/* Overall Score */}
      <Card sx={{ mb: 3, bgcolor: "primary.main", color: "white" }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 1 }}>
            Overall QA Maturity Score
          </Typography>
          <Box sx={{ display: "flex", alignItems: "baseline", gap: 2 }}>
            <Typography variant="h2">85</Typography>
            <Typography variant="h5">/100</Typography>
            <Chip label="+3 from last month" sx={{ bgcolor: "white", color: "primary.main" }} />
          </Box>
          <Typography variant="body2" sx={{ mt: 1, opacity: 0.9 }}>
            Level 4: Managed - On track to reach Optimizing level
          </Typography>
        </CardContent>
      </Card>

      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Maturity by Capability
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="capability" />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  <Radar
                    name="Current"
                    dataKey="current"
                    stroke="#2196f3"
                    fill="#2196f3"
                    fillOpacity={0.6}
                  />
                  <Radar
                    name="Target"
                    dataKey="target"
                    stroke="#4caf50"
                    fill="#4caf50"
                    fillOpacity={0.3}
                  />
                  <Legend />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>
                Maturity Progress
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="score" fill="#2196f3" name="Maturity Score" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Domain Maturity Levels */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            Maturity by Domain
          </Typography>
          <Grid container spacing={2}>
            {maturityLevels.map((domain, index) => (
              <Grid size={{ xs: 12, md: 6 }} key={index}>
                <Box sx={{ p: 2, border: "1px solid", borderColor: "divider", borderRadius: 1 }}>
                  <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1 }}>
                    <Typography variant="body1">{domain.domain}</Typography>
                    <Chip
                      label={domain.level}
                      color={getLevelColor(domain.current) as any}
                      size="small"
                    />
                  </Box>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                    <Typography variant="body2" color="text.secondary" sx={{ minWidth: 80 }}>
                      Level {domain.current}/5
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={(domain.current / 5) * 100}
                      sx={{ flex: 1, height: 8, borderRadius: 4 }}
                    />
                    <Typography variant="body2" color="text.secondary">
                      Target: {domain.target}
                    </Typography>
                  </Box>
                </Box>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            Improvement Recommendations
          </Typography>
          <Box sx={{ overflow: "auto" }}>
            {recommendations.map((rec, index) => (
              <Box
                key={index}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  p: 2,
                  borderBottom: "1px solid",
                  borderColor: "divider",
                  "&:last-child": { borderBottom: "none" },
                }}
              >
                <Box sx={{ flex: 1 }}>
                  <Box sx={{ display: "flex", gap: 1, mb: 1 }}>
                    <Chip
                      label={rec.priority}
                      color={getPriorityColor(rec.priority) as any}
                      size="small"
                    />
                    <Chip label={rec.area} variant="outlined" size="small" />
                  </Box>
                  <Typography variant="body1">{rec.recommendation}</Typography>
                </Box>
                <Chip label={`${rec.impact} Impact`} variant="outlined" size="small" />
              </Box>
            ))}
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}