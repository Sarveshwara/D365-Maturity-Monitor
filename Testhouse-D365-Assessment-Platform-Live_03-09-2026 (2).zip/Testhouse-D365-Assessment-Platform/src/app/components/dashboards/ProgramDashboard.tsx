import { useEffect, useState } from "react";
import { Card, CardContent, Typography, Grid, Box, LinearProgress, Chip, CircularProgress, Alert } from "@mui/material";
import { TrendingUp, TrendingDown, CheckCircle, Warning, Error as ErrorIcon, Refresh } from "@mui/icons-material";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { getDashboardStats } from "../../lib/api";

// Static KPIs (business metrics — not yet in DB)
const STATIC_KPIS = [
  { title: "Test Coverage",   value: "87%",   change: "+5%",  trend: "up",   color: "success.main" },
  { title: "Defect Density",  value: "0.45",  change: "-12%", trend: "up",   color: "success.main" },
  { title: "Automation Rate", value: "72%",   change: "+8%",  trend: "up",   color: "primary.main" },
  { title: "Critical Defects",value: "23",    change: "+3",   trend: "down", color: "error.main" },
];

const STATUS_COLORS: Record<string, string> = {
  completed:   "#107C10",
  in_progress: "#0F6CBD",
  draft:       "#E0E4EC",
};

const TYPE_COLORS: Record<string, string> = {
  QA_MATURITY: "#2B3E7E",
  PERFORMANCE: "#0F6CBD",
  SECURITY:    "#6B3FBE",
};

const TYPE_LABELS: Record<string, string> = {
  QA_MATURITY: "QA Maturity",
  PERFORMANCE: "Performance",
  SECURITY:    "Security",
};

function statusIcon(status: string) {
  if (status === "completed")   return <CheckCircle color="success" />;
  if (status === "in_progress") return <Warning color="warning" />;
  return <ErrorIcon color="disabled" />;
}

export default function ProgramDashboard() {
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await getDashboardStats());
    } catch (e: any) {
      setError(e.message + " — deploy the edge function to load live data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const monthly: any[]    = data?.monthlyTrend ?? [];
  const recent: any[]     = data?.recentRuns ?? [];
  const statusDist: any[] = data?.statusDist ?? [];
  const kpis              = data?.kpis ?? {};

  // Status pie data
  const pieData = statusDist.map((s: any) => ({
    ...s,
    fill: STATUS_COLORS[s.name?.toLowerCase().replace(" ", "_")] ?? "#E0E4EC",
  }));

  // Monthly bar data
  const barData = monthly.map((m: any) => ({
    month: m.month,
    "QA Maturity":  m.qa,
    "Performance":  m.perf,
    "Security":     m.sec,
  }));

  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
        <Typography variant="h4" fontWeight={700}>Program Dashboard</Typography>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          {!loading && data && (
            <Chip label="Live Data" size="small"
              sx={{ bgcolor: "#E8FBF5", color: "#107C10", fontWeight: 700, fontSize: "0.65rem" }} />
          )}
          <Refresh sx={{ cursor: "pointer", color: "text.secondary", fontSize: 20 }} onClick={load} />
        </Box>
      </Box>

      {error && <Alert severity="warning" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      {/* Static KPI Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        {STATIC_KPIS.map((kpi) => (
          <Grid size={{ xs: 12, sm: 6, md: 3 }} key={kpi.title}>
            <Card>
              <CardContent>
                <Typography color="text.secondary" gutterBottom variant="body2">{kpi.title}</Typography>
                <Typography variant="h4" sx={{ mb: 1 }}>{kpi.value}</Typography>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  {kpi.trend === "up"
                    ? <TrendingUp sx={{ color: kpi.color }} />
                    : <TrendingDown sx={{ color: kpi.color }} />}
                  <Typography variant="body2" sx={{ color: kpi.color }}>{kpi.change} from last month</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Live assessment summary */}
      {!loading && data && (
        <Grid container spacing={3} sx={{ mb: 3 }}>
          {[
            { label: "Total Runs",   value: kpis.totalRuns   ?? 0, color: "#2B3E7E" },
            { label: "Completed",    value: kpis.completedRuns ?? 0, color: "#107C10" },
            { label: "In Progress",  value: kpis.inProgressRuns ?? 0, color: "#0F6CBD" },
            { label: "Completion %", value: `${kpis.completionRate ?? 0}%`, color: "#6B3FBE" },
          ].map((s) => (
            <Grid size={{ xs: 6, sm: 3 }} key={s.label}>
              <Card elevation={0} sx={{ border: "1px solid #E0E4EC", textAlign: "center" }}>
                <CardContent sx={{ py: 2 }}>
                  <Typography variant="h4" fontWeight={800} sx={{ color: s.color }}>{s.value}</Typography>
                  <Typography variant="caption" color="text.secondary">{s.label}</Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Charts */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 8 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>
                {loading ? "Assessment Trends" : "Completed Assessments by Month"}
              </Typography>
              {loading ? (
                <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}><CircularProgress /></Box>
              ) : monthly.some((m: any) => m.total > 0) ? (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                    <Tooltip key="prog-bar-tooltip" />
                    <Legend key="prog-bar-legend" />
                    <Bar key="prog-bar-qa"   dataKey="QA Maturity" fill="#2B3E7E" radius={[3, 3, 0, 0]} />
                    <Bar key="prog-bar-perf" dataKey="Performance" fill="#0F6CBD" radius={[3, 3, 0, 0]} />
                    <Bar key="prog-bar-sec"  dataKey="Security"    fill="#6B3FBE" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: 280, flexDirection: "column", gap: 1 }}>
                  <Typography variant="body2" color="text.secondary">No completed assessments in the last 6 months</Typography>
                  <Typography variant="caption" color="text.disabled">Complete assessments to see trends here</Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Status Distribution</Typography>
              {loading ? (
                <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}><CircularProgress /></Box>
              ) : pieData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie key="prog-pie-status"
                      data={pieData} cx="50%" cy="45%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={90} dataKey="value">
                      {pieData.map((entry: any, i: number) => (
                        <Cell key={`prog-status-cell-${i}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip key="prog-pie-tooltip" />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: 280 }}>
                  <Typography variant="body2" color="text.secondary">No assessments started yet</Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Recent Assessment Runs */}
      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Recent Assessment Runs</Typography>
          {loading ? (
            <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}><CircularProgress /></Box>
          ) : recent.length === 0 ? (
            <Box sx={{ textAlign: "center", py: 4 }}>
              <Typography variant="body2" color="text.secondary">No assessments started yet.</Typography>
            </Box>
          ) : (
            recent.map((run: any) => (
              <Box key={run.id} sx={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                p: 2, borderBottom: "1px solid", borderColor: "divider",
                "&:last-child": { borderBottom: "none" },
              }}>
                <Box sx={{ display: "flex", alignItems: "center", gap: 2, flex: 1 }}>
                  {statusIcon(run.status)}
                  <Box>
                    <Typography variant="body1" fontWeight={600}>{run.name ?? run.type}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {new Date(run.run_date).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                      {" · "}
                      <Chip label={TYPE_LABELS[run.type] ?? run.type} size="small"
                        sx={{ bgcolor: `${TYPE_COLORS[run.type] ?? "#2B3E7E"}18`,
                          color: TYPE_COLORS[run.type] ?? "#2B3E7E", fontWeight: 700, fontSize: "0.6rem", height: 18 }} />
                    </Typography>
                  </Box>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                  {run.score != null && (
                    <Box sx={{ width: 120 }}>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                        Score:{" "}
                        {run.type === "QA_MATURITY"
                          ? `${(run.score as number).toFixed(1)} / 5`
                          : `${Math.round(run.score as number)}%`}
                      </Typography>
                      <LinearProgress variant="determinate"
                        value={run.type === "QA_MATURITY"
                          ? ((run.score as number) / 5) * 100
                          : run.score as number}
                        sx={{ height: 6, borderRadius: 3 }} />
                    </Box>
                  )}
                  <Chip label={run.status?.replace("_", " ")} size="small"
                    sx={{
                      minWidth: 90, textTransform: "capitalize",
                      bgcolor: run.status === "completed" ? "#E8FBF5"
                        : run.status === "in_progress" ? "#E8F4FF" : "#F5F5F5",
                      color: run.status === "completed" ? "#107C10"
                        : run.status === "in_progress" ? "#0F6CBD" : "#999",
                      fontWeight: 700,
                    }}
                  />
                </Box>
              </Box>
            ))
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
