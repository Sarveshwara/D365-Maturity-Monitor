import { useEffect, useRef, useState } from "react";
import { useNavigate, useLocation } from "react-router";

import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  TextField,
  MenuItem,
  Divider,
  CircularProgress,
  Chip,
} from "@mui/material";

import {
  ArrowBack,
  ArrowForward,
  Business,
  CheckCircle,
  CloudOff,
} from "@mui/icons-material";

import { useAuth } from "../../contexts/AuthContext";
import { assessmentService } from "../../lib/assessment-service";

export interface AssessmentCustomerInfoData {
  firstName: string;
  lastName: string;
  email: string;
  countryCode: string;
  phone: string;
  companyName: string;
  jobTitle: string;
  industry: string;
  country: string;
  organizationSize: string;
}

// A representative set, not exhaustive — "Other" covers anyone not
// listed rather than forcing an incorrect selection.
const COUNTRY_CODES = [
  { code: "+91", label: "+91 (India)" },
  { code: "+1", label: "+1 (US/Canada)" },
  { code: "+44", label: "+44 (UK)" },
  { code: "+61", label: "+61 (Australia)" },
  { code: "+971", label: "+971 (UAE)" },
  { code: "+65", label: "+65 (Singapore)" },
  { code: "+49", label: "+49 (Germany)" },
  { code: "+33", label: "+33 (France)" },
  { code: "+31", label: "+31 (Netherlands)" },
  { code: "+34", label: "+34 (Spain)" },
  { code: "+39", label: "+39 (Italy)" },
  { code: "+81", label: "+81 (Japan)" },
  { code: "+86", label: "+86 (China)" },
  { code: "+27", label: "+27 (South Africa)" },
  { code: "+55", label: "+55 (Brazil)" },
];

/** Splits a signup full name into first/last for the two locked fields. */
function splitName(fullName: string | null | undefined): {
  firstName: string;
  lastName: string;
} {
  const trimmed = (fullName ?? "").trim();
  if (!trimmed) return { firstName: "", lastName: "" };

  const parts = trimmed.split(/\s+/);
  return {
    firstName: parts[0],
    lastName: parts.slice(1).join(" "),
  };
}

const AUTOSAVE_DELAY_MS = 800;

export default function AssessmentCustomerInfo() {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile } = useAuth();

  const state = (location.state as any) || {};

  const [customerInfo, setCustomerInfo] =
    useState<AssessmentCustomerInfoData>(() => {
      if (state.customerInfo) {
        // Resuming a draft — name/email are still re-derived fresh
        // from the account below, never trusted from the old draft.
        return { ...state.customerInfo };
      }

      const { firstName, lastName } = splitName(profile?.full_name);

      return {
        firstName,
        lastName,
        email: profile?.email ?? "",
        countryCode: "",
        phone: "",
        companyName: "",
        jobTitle: "",
        industry: "",
        country: "",
        organizationSize: "",
      };
    });

  // Name/email always reflect the signed-in account, even if a
  // resumed draft or a slow-loading profile briefly disagrees.
  useEffect(() => {
    if (!profile) return;
    const { firstName, lastName } = splitName(profile.full_name);
    setCustomerInfo((previous) => ({
      ...previous,
      firstName,
      lastName,
      email: profile.email ?? previous.email,
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.full_name, profile?.email]);

  // ───────────────────────────────────────────────────────────
  // AUTO-SAVE
  //
  // A run is only created once Company Name has something in it —
  // not on the very first keystroke into any field. Company Name is
  // the one piece of information an admin actually needs to follow
  // up with someone who didn't finish, so it's treated as the
  // trigger, not an afterthought. This also fixes a real bug: the
  // run's name used to get fixed permanently at creation time,
  // falling back to the literal word "Draft" when company name
  // was still empty at that moment — which then sat there forever
  // even after the real company name was filled in and the
  // assessment was completed, reading confusingly as "Draft —
  // Completed" in My Assessments. Now the name is re-sent on every
  // save, so it stays in sync if the company name is corrected or
  // changed partway through.
  const runIdRef = useRef<string | null>(state.runId ?? null);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [saveStatus, setSaveStatus] = useState<
    "idle" | "saving" | "saved" | "error"
  >("idle");

  const persist = async (info: AssessmentCustomerInfoData) => {
    const trimmedCompany = info.companyName.trim();

    if (!runIdRef.current && !trimmedCompany) {
      // Nothing to anchor a record to yet — hold everything in local
      // state only until Company Name has something in it.
      setSaveStatus("idle");
      return;
    }

    const displayName = trimmedCompany
      ? `D365 QA Maturity Assessment — ${trimmedCompany}`
      : undefined;

    try {
      if (!runIdRef.current) {
        const { runId, error } = await assessmentService.start(
          "QA_MATURITY",
          displayName as string, // trimmedCompany is guaranteed non-empty here
          { customerInfo: info }
        );

        if (error || !runId) {
          setSaveStatus("error");
          return;
        }

        runIdRef.current = runId;
      } else {
        const { error } = await assessmentService.updateContext(
          runIdRef.current,
          { customerInfo: info },
          displayName
        );

        if (error) {
          setSaveStatus("error");
          return;
        }
      }

      setSaveStatus("saved");
    } catch {
      setSaveStatus("error");
    }
  };

  const scheduleAutoSave = (info: AssessmentCustomerInfoData) => {
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);

    setSaveStatus("saving");

    saveTimeoutRef.current = setTimeout(() => {
      persist(info);
    }, AUTOSAVE_DELAY_MS);
  };

  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, []);

  const handleChange =
    (field: keyof AssessmentCustomerInfoData) =>
    (
      event: React.ChangeEvent<
        HTMLInputElement | HTMLTextAreaElement
      >
    ) => {
      const updated = { ...customerInfo, [field]: event.target.value };
      setCustomerInfo(updated);
      scheduleAutoSave(updated);
    };

  const [continuing, setContinuing] = useState(false);

  const handleContinue = async () => {
    setContinuing(true);

    // Flush immediately rather than waiting for the debounce, so the
    // very last keystrokes aren't lost and a runId definitely exists
    // before Domain Selection needs it.
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    await persist(customerInfo);

    setContinuing(false);

    navigate("/assessment/domain-selection", {
      state: {
        ...location.state,
        customerInfo,
        runId: runIdRef.current,
      },
    });
  };

  const handleBack = () => {
    navigate("/assessment");
  };

  return (
    <Box
      sx={{
        maxWidth: 900,
        mx: "auto",
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          mb: 3,
          gap: 2,
        }}
      >
        <Box>
          <Typography
            variant="h4"
            fontWeight={700}
            color="primary.main"
          >
            Assessment Information
          </Typography>

          <Typography
            variant="body1"
            color="text.secondary"
            sx={{ mt: 1 }}
          >
            Tell us a little about the organisation completing this
            assessment. This information will be included in the
            assessment report.
          </Typography>
        </Box>

        {saveStatus !== "idle" && (
          <Chip
            size="small"
            icon={
              saveStatus === "saving" ? (
                <CircularProgress size={14} />
              ) : saveStatus === "error" ? (
                <CloudOff fontSize="small" />
              ) : (
                <CheckCircle fontSize="small" />
              )
            }
            label={
              saveStatus === "saving"
                ? "Saving..."
                : saveStatus === "error"
                ? "Save failed"
                : "Saved"
            }
            color={
              saveStatus === "error"
                ? "error"
                : saveStatus === "saved"
                ? "success"
                : "default"
            }
            variant="outlined"
            sx={{ mt: 1, flexShrink: 0 }}
          />
        )}
      </Box>

      <Card
        elevation={0}
        sx={{
          border: "1px solid #E0E4EC",
          borderRadius: 3,
        }}
      >
        <CardContent sx={{ p: 4 }}>
          {/* CONTACT INFORMATION */}

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              mb: 1,
            }}
          >
            <Business color="primary" />

            <Typography
              variant="h6"
              fontWeight={700}
            >
              Contact Information
            </Typography>
          </Box>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ mb: 3 }}
          >
            Name and email are from your account — job title and
            phone are the only details we still need from you here.
          </Typography>

          <Grid container spacing={2.5}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                disabled
                label="First Name"
                value={customerInfo.firstName}
                helperText="From your account"
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                disabled
                label="Last Name"
                value={customerInfo.lastName}
                helperText="From your account"
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                disabled
                type="email"
                label="Business Email"
                value={customerInfo.email}
                helperText="From your account"
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Job Title / Role"
                value={customerInfo.jobTitle}
                onChange={handleChange("jobTitle")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                select
                fullWidth
                label="Country Code"
                value={customerInfo.countryCode}
                onChange={handleChange("countryCode")}
              >
                <MenuItem value="">Select</MenuItem>
                {COUNTRY_CODES.map((c) => (
                  <MenuItem key={c.code} value={c.code}>
                    {c.label}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            <Grid size={{ xs: 12, sm: 8 }}>
              <TextField
                fullWidth
                label="Contact Number"
                placeholder="9876543210"
                value={customerInfo.phone}
                onChange={handleChange("phone")}
              />
            </Grid>
          </Grid>

          <Divider sx={{ my: 4 }} />

          {/* ORGANISATION INFORMATION */}

          <Typography
            variant="h6"
            fontWeight={700}
            sx={{ mb: 1 }}
          >
            Organisation Information
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ mb: 3 }}
          >
            This helps provide context for your maturity assessment.
          </Typography>

          <Grid container spacing={2.5}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                required
                label="Company Name"
                value={customerInfo.companyName}
                onChange={handleChange("companyName")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Industry"
                value={customerInfo.industry}
                onChange={handleChange("industry")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                select
                fullWidth
                label="Organisation Size"
                value={customerInfo.organizationSize}
                onChange={handleChange("organizationSize")}
              >
                <MenuItem value="">
                  Select organisation size
                </MenuItem>

                <MenuItem value="1-50">
                  1–50 employees
                </MenuItem>

                <MenuItem value="51-250">
                  51–250 employees
                </MenuItem>

                <MenuItem value="251-1000">
                  251–1,000 employees
                </MenuItem>

                <MenuItem value="1001-5000">
                  1,001–5,000 employees
                </MenuItem>

                <MenuItem value="5000+">
                  5,000+ employees
                </MenuItem>
              </TextField>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Country / Region"
                value={customerInfo.country}
                onChange={handleChange("country")}
              />
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* NAVIGATION */}

      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          mt: 3,
        }}
      >
        <Button
          variant="outlined"
          startIcon={<ArrowBack />}
          onClick={handleBack}
        >
          Back
        </Button>

        <Button
          variant="contained"
          endIcon={continuing ? undefined : <ArrowForward />}
          onClick={handleContinue}
          disabled={!customerInfo.companyName || continuing}
        >
          {continuing ? (
            <CircularProgress size={22} color="inherit" />
          ) : (
            "Continue to Assessment Setup"
          )}
        </Button>
      </Box>
    </Box>
  );
}
