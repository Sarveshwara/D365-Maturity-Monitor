import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router";

import { assessmentService } from "../../lib/assessment-service";
import { useAuth } from "../../contexts/AuthContext";

import {
  Card,
  CardContent,
  Typography,
  Box,
  Grid,
  Chip,
  Button,
  LinearProgress,
  CircularProgress,
  Alert,
} from "@mui/material";

import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
} from "recharts";

import {
  Download,
  CheckCircle,
  Warning,
  Error as ErrorIcon,
  Assessment,
  ArrowForward,
} from "@mui/icons-material";

import {
  getAssessmentQuestions,
  getMaturityLevel,
  type AssessmentDomain,
  type ImplementationType,
} from "../../data/assessmentQuestions";

// ============================================================================
// TYPES
// ============================================================================

type AnswerMap = Record<string, number>;

type RecommendationPriority =
  | "Critical"
  | "High"
  | "Medium";

interface Recommendation {
  questionId: string;

  priority: RecommendationPriority;

  category: string;

  area: string;

  question: string;

  businessImpact: string;

  observation: string;

  action: string;

  timeline: string;

  level: number;
}

// ============================================================================
// HELPERS
// ============================================================================

function getMaturityLabel(score: number): string {
  return getMaturityLevel(score);
}

function getRiskColor(score: number): string {
  if (score < 2.5) {
    return "#D83B01";
  }

  if (score < 3.5) {
    return "#FFB900";
  }

  return "#107C10";
}

function getRiskLabel(score: number): string {
  if (score < 2.5) {
    return "High Risk";
  }

  if (score < 3.5) {
    return "Moderate Risk";
  }

  return "Low Risk";
}

// ============================================================================
// CONSTANTS
// ============================================================================

const ROADMAP = [
  {
    phase: "Phase 1 — Stabilise",
    months: "0–3 months",
    color: "#D83B01",
    items: [
      "Define quality gates",
      "Establish KPI baselines",
      "Standardise environments",
    ],
  },
  {
    phase: "Phase 2 — Optimise",
    months: "3–6 months",
    color: "#FFB900",
    items: [
      "Expand automation coverage",
      "Continuous monitoring",
      "Executive dashboards",
    ],
  },
  {
    phase: "Phase 3 — Transform",
    months: "6–12 months",
    color: "#107C10",
    items: [
      "AI-driven quality engineering",
      "Predictive analytics",
      "Intelligent governance",
    ],
  },
];

const PRIORITY_COLORS: Record<
  RecommendationPriority,
  string
> = {
  Critical: "#D83B01",
  High: "#FFB900",
  Medium: "#0F6CBD",
};

const PRIORITY_BG: Record<
  RecommendationPriority,
  string
> = {
  Critical: "#FFF5F2",
  High: "#FFFBF0",
  Medium: "#F0F6FF",
};

// ============================================================================
// RISK ICON
// ============================================================================

function RiskIcon({
  score,
}: {
  score: number;
}) {
  if (score < 2.5) {
    return (
      <ErrorIcon
        sx={{
          color: "#D83B01",
          fontSize: 28,
        }}
      />
    );
  }

  if (score < 3.5) {
    return (
      <Warning
        sx={{
          color: "#FFB900",
          fontSize: 28,
        }}
      />
    );
  }

  return (
    <CheckCircle
      sx={{
        color: "#107C10",
        fontSize: 28,
      }}
    />
  );
}

// ============================================================================
// COMPONENT
// ============================================================================

export default function AssessmentResults() {
  const location = useLocation();
  const routeParams = useParams<{ runId?: string }>();

  const navigate = useNavigate();

  const { role } = useAuth();
  const isCustomer = role === "customer";

  const state =
    (location.state as {
      runId?: string;
      answers?: AnswerMap;
      notes?: Record<string, string>;
      selectedDomains?: AssessmentDomain[];
      implementationType?: ImplementationType;
      customerInfo?: Record<string, string>;
    } | null) ?? {};

  // Fresh completion (Questionnaire.tsx) passes runId via router
  // state. Opening a specific submission (My Assessments, the admin
  // submissions list, or a bookmarked/shared link) passes it as a
  // route param instead — this previously only checked state, so
  // those links silently showed a blank report.
  const runId = state.runId ?? routeParams.runId;

  const initialAnswers: AnswerMap =
    state.answers ?? {};

  const [selectedDomains, setSelectedDomains] =
    useState<AssessmentDomain[] | undefined>(
      state.selectedDomains
    );

  const [implementationType, setImplementationType] =
    useState<ImplementationType>(
      state.implementationType ?? "Greenfield"
    );

  const hasInitialAnswers =
    Object.keys(initialAnswers).length > 0;

  // ───────────────────────────────────────────────────────────
  // ENTRY GUARD
  //
  // No runId at all (neither state nor route param) means someone
  // landed here directly — the sidebar link, a bookmarked URL — with
  // nothing to actually show. Previously this rendered a report full
  // of zeros instead of saying so.
  //
  // IMPORTANT: this only schedules the redirect — it must NOT
  // early-return here. Every hook below (useMemo for scoring,
  // charts, etc.) still needs to run on every render regardless of
  // runId, or React throws "Rendered fewer hooks than expected" the
  // moment this component re-renders in place with a different
  // runId than the previous render had (e.g. clicking "Results" in
  // the sidebar while already on this page — same route, so React
  // reuses the existing instance instead of remounting it). The
  // actual "don't render the report" decision happens once, right
  // before the final JSX return, after all hooks have run.
  useEffect(() => {
    if (!runId) {
      navigate("/profile/my-assessments", { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runId]);

  // ==========================================================================
  // QUESTIONS
  //
  // IMPORTANT:
  // This replaces the missing `allQuestions` variable.
  // ==========================================================================

  const allQuestions = useMemo(() => {
    const questions =
      getAssessmentQuestions(
        selectedDomains,
        implementationType
      );

    return questions;
  }, [
    selectedDomains,
    implementationType,
  ]);

  // ==========================================================================
  // STATE
  // ==========================================================================

  const [answers, setAnswers] =
    useState<AnswerMap>(
      initialAnswers
    );

  // Falls back to what was saved on the run itself (assessment_context)
  // when this page is opened without router state — e.g. an admin
  // opening a submission from /admin/assessment-submissions, or a
  // reloaded results page.
  const [customerInfo, setCustomerInfo] =
    useState<Record<string, string> | undefined>(
      state.customerInfo
    );

  const [loadingRun, setLoadingRun] =
    useState(
      !!runId &&
        !hasInitialAnswers
    );

  const [loadError, setLoadError] =
    useState<string | null>(
      null
    );

  const [exporting, setExporting] =
    useState<
      "pdf" | "excel" | null
    >(null);

  // ==========================================================================
  // LOAD SAVED ASSESSMENT
  // ==========================================================================

  useEffect(() => {
    let cancelled = false;

    const loadAssessment =
      async () => {
        if (
          !runId ||
          hasInitialAnswers
        ) {
          setLoadingRun(false);

          return;
        }

        try {
          setLoadingRun(true);

          setLoadError(null);

          const { run } =
            await assessmentService.get(
              runId
            );

          if (cancelled) {
            return;
          }

          if (
            run?.responses_data
          ) {
            setAnswers(
              run.responses_data as AnswerMap
            );

            if (run.assessment_context?.customerInfo) {
              setCustomerInfo(
                run.assessment_context.customerInfo as Record<string, string>
              );
            }

            if (run.assessment_context?.selectedDomains) {
              setSelectedDomains(
                run.assessment_context.selectedDomains as AssessmentDomain[]
              );
            }

            if (run.assessment_context?.implementationType) {
              setImplementationType(
                run.assessment_context.implementationType as ImplementationType
              );
            }
          } else {
            setLoadError(
              "No assessment responses were found for this assessment."
            );
          }
        } catch (error) {
          console.error(
            "Failed to load assessment results:",
            error
          );

          if (!cancelled) {
            setLoadError(
              "Unable to load the saved assessment."
            );
          }
        } finally {
          if (!cancelled) {
            setLoadingRun(false);
          }
        }
      };

    loadAssessment();

    return () => {
      cancelled = true;
    };
  }, [
    runId,
    hasInitialAnswers,
  ]);

  // ───────────────────────────────────────────────────────────
  // BACKFILL CONTEXT ON A FRESH COMPLETION
  //
  // The block above intentionally skips fetching anything when we
  // already have answers via router state (fast path right after
  // finishing the questionnaire — no need to re-fetch what we just
  // saved). But if this session was ever paused and resumed along
  // the way (sidebar link, "Start Assessment" resuming a draft, or
  // "Continue" from My Assessments), those resume points only ever
  // pass {runId} forward — customerInfo/selectedDomains/
  // implementationType silently drop out of state from that point
  // on, even though they're still sitting in the database untouched.
  // This runs quietly in the background (no loading spinner, no
  // effect on the answers already shown) purely to backfill those
  // three fields whenever they're missing.
  useEffect(() => {
    if (!runId || !hasInitialAnswers) return;
    if (customerInfo) return;

    let cancelled = false;

    (async () => {
      const { run } = await assessmentService.get(runId);
      if (cancelled || !run) return;

      if (run.assessment_context?.customerInfo) {
        setCustomerInfo(
          run.assessment_context.customerInfo as Record<string, string>
        );
      }
      if (run.assessment_context?.selectedDomains) {
        setSelectedDomains(
          run.assessment_context.selectedDomains as AssessmentDomain[]
        );
      }
      if (run.assessment_context?.implementationType) {
        setImplementationType(
          run.assessment_context.implementationType as ImplementationType
        );
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runId, hasInitialAnswers]);

  // ==========================================================================
  // SCORE CALCULATION
  // ==========================================================================

  const {
    overall,
    byCategory,
    totalAnswered,
  } = useMemo(() => {
    const domainTotals: Record<
      string,
      {
        total: number;
        count: number;
      }
    > = {};

    let total = 0;

    let answered = 0;

    allQuestions.forEach(
      (question) => {
        const score =
          answers[question.id];

        if (
          typeof score !== "number" ||
          !Number.isFinite(score)
        ) {
          return;
        }

        total += score;

        answered += 1;

        const domain =
          question.domain ??
          "Unclassified";

        if (!domainTotals[domain]) {
          domainTotals[domain] = {
            total: 0,
            count: 0,
          };
        }

        domainTotals[domain].total +=
          score;

        domainTotals[domain].count +=
          1;
      }
    );

    const byCategory =
      Object.fromEntries(
        Object.entries(
          domainTotals
        ).map(
          ([
            domain,
            value,
          ]) => [
            domain,

            value.count > 0
              ? value.total /
                value.count
              : 0,
          ]
        )
      );

    return {
      overall:
        answered > 0
          ? total / answered
          : 0,

      byCategory,

      totalAnswered: answered,
    };
  }, [
    answers,
    allQuestions,
  ]);

  const maturityLabel =
    getMaturityLabel(
      overall
    );

  const riskColor =
    getRiskColor(
      overall
    );

  const riskLabel =
    getRiskLabel(
      overall
    );

  // ==========================================================================
  // COMPLETION
  // ==========================================================================

  const totalQuestions =
    allQuestions.length;

  const completionPercentage =
    totalQuestions > 0
      ? Math.min(
          100,
          (
            totalAnswered /
            totalQuestions
          ) * 100
        )
      : 0;

  // ==========================================================================
  // BUILD RECOMMENDATIONS
  // ==========================================================================

  const recommendations:
    Recommendation[] =
    useMemo(() => {
      return allQuestions
        .filter(
          (question) => {
            const level =
              answers[question.id];

            return (
              typeof level ===
                "number" &&
              Number.isFinite(
                level
              ) &&
              level >= 1 &&
              level < 4
            );
          }
        )
        .map(
          (question) => {
            const level =
              answers[question.id];

            const option =
              Array.isArray(
                question.options
              )
                ? question.options.find(
                    (item) =>
                      item.level ===
                      level
                  )
                : undefined;

            if (!option) {
              console.warn(
                "Recommendation skipped - option data not found:",
                {
                  questionId:
                    question.id,

                  selectedLevel:
                    level,

                  availableOptions:
                    question.options?.map(
                      (item) =>
                        item.level
                    ) ?? [],
                }
              );

              return null;
            }

            const priority:
              RecommendationPriority =
              level === 1
                ? "Critical"
                : level === 2
                ? "High"
                : "Medium";

            const timeline =
              level === 1
                ? "0–3 months"
                : level === 2
                ? "3–6 months"
                : "6–12 months";

            const category =
              question.domain ??
              "Unclassified";

            return {
              questionId:
                question.id,

              priority,

              category,

              area:
                category,

              question:
                question.question ??
                "Assessment question not available",

              businessImpact:
                option.businessImpact ??
                "No business impact available.",

              observation:
                option.businessImpact ??
                "No business impact available.",

              action:
                option.recommendation ??
                "No recommendation available.",

              timeline,

              level,
            };
          }
        )
        .filter(
          (
            recommendation
          ): recommendation is Recommendation =>
            recommendation !== null
        )
        .sort(
          (a, b) => {
            const priorityOrder:
              Record<
                RecommendationPriority,
                number
              > = {
              Critical: 0,
              High: 1,
              Medium: 2,
            };

            return (
              priorityOrder[
                a.priority
              ] -
              priorityOrder[
                b.priority
              ]
            );
          }
        );
    }, [
      answers,
      allQuestions,
    ]);

  const criticalAndHighCount =
    recommendations.filter(
      (recommendation) =>
        recommendation.priority ===
          "Critical" ||
        recommendation.priority ===
          "High"
    ).length;

  // ==========================================================================
  // EXPORT DATA
  //
  // Matches QAExportData in export-service.ts
  // ==========================================================================

  const exportData = {
    answers,

    overall,

    maturityLabel,

    riskLabel,

    byCategory,

    customerInfo,

    recommendations:
      recommendations.map(
        (
          recommendation
        ) => ({
          questionId:
            recommendation.questionId,

          priority:
            recommendation.priority,

          category:
            recommendation.category,

          area:
            recommendation.area,

          question:
            recommendation.question,

          businessImpact:
            recommendation.businessImpact,

          action:
            recommendation.action,

          timeline:
            recommendation.timeline,

          level:
            recommendation.level,
        })
      ),

    totalAnswered,

    totalQuestions,
  };

  // ==========================================================================
  // EXPORT PDF
  // ==========================================================================

  const handleExportPDF =
    async () => {
      try {
        setExporting("pdf");

        const {
          exportQAPDF,
        } = await import(
          "../../lib/export-service"
        );

        await exportQAPDF(
          exportData,
          { restrictedView: isCustomer }
        );
      } catch (error) {
        console.error(
          "Failed to export PDF:",
          error
        );
      } finally {
        setExporting(null);
      }
    };

  // ==========================================================================
  // EXPORT EXCEL
  // ==========================================================================

  const handleExportExcel =
    async () => {
      try {
        setExporting("excel");

        const {
          exportQAExcel,
        } = await import(
          "../../lib/export-service"
        );

        exportQAExcel(
          exportData
        );
      } catch (error) {
        console.error(
          "Failed to export Excel:",
          error
        );
      } finally {
        setExporting(null);
      }
    };

  // ==========================================================================
  // RADAR DATA
  // ==========================================================================

  const radarData =
    Object.entries(
      byCategory
    ).map(
      ([
        domain,
        score,
      ]) => ({
        domain,

        score: Number(
          Number(
            score
          ).toFixed(1)
        ),

        fullMark: 5,
      })
    );

  // ==========================================================================
  // RISK DISTRIBUTION
  // ==========================================================================

  const answeredQuestions =
    allQuestions.filter(
      (question) =>
        answers[
          question.id
        ] != null
    );

  const pieData = [
    {
      name: "High Risk (L1)",

      value:
        answeredQuestions.filter(
          (question) =>
            answers[
              question.id
            ] === 1
        ).length,

      color: "#D83B01",
    },
    {
      name: "Medium Risk (L2–3)",

      value:
        answeredQuestions.filter(
          (question) => {
            const level =
              answers[
                question.id
              ] ?? 0;

            return (
              level >= 2 &&
              level <= 3
            );
          }
        ).length,

      color: "#FFB900",
    },
    {
      name: "Low Risk (L4–5)",

      value:
        answeredQuestions.filter(
          (question) => {
            const level =
              answers[
                question.id
              ] ?? 0;

            return level >= 4;
          }
        ).length,

      color: "#107C10",
    },
  ].filter(
    (item) =>
      item.value > 0
  );

  // ==========================================================================
  // LOADING STATE
  // ==========================================================================

  if (loadingRun) {
    return (
      <Box
        sx={{
          minHeight: 400,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 2,
        }}
      >
        <CircularProgress />

        <Typography
          variant="body2"
          color="text.secondary"
        >
          Loading assessment results...
        </Typography>
      </Box>
    );
  }

  // No runId at all — the redirect effect above is already sending
  // the person to My Assessments. Render nothing while that happens,
  // rather than a report full of zeros. (Deliberately placed here,
  // after every hook above has already run unconditionally — see
  // the ENTRY GUARD comment near the top of this component for why.)
  if (!runId) {
    return null;
  }

  // ==========================================================================
  // RENDER
  // ==========================================================================

  return (
    <Box
      sx={{
        maxWidth: 1100,
        mx: "auto",
      }}
    >
      {loadError && (
        <Alert
          severity="warning"
          sx={{
            mb: 3,
          }}
        >
          {loadError}
        </Alert>
      )}

      {/* HEADER */}

      <Box
        sx={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems:
            "flex-start",
          mb: 3,
          gap: 2,
          flexWrap: "wrap",
        }}
      >
        <Box>
          <Typography
            variant="h4"
            fontWeight={800}
            color="primary.main"
          >
            D365 QA Maturity Report
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              mt: 0.5,
            }}
          >
            {totalAnswered} of{" "}
            {totalQuestions} dimensions
            assessed · Generated{" "}
            {new Date().toLocaleString(
              "en-GB",
              {
                day: "numeric",
                month: "long",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              }
            )}
          </Typography>
        </Box>

        <Box
          sx={{
            display: "flex",
            gap: 1.5,
            flexWrap: "wrap",
          }}
        >
          {!isCustomer && (
            <Button
              variant="outlined"
              startIcon={
                <Download />
              }
              size="small"
              onClick={
                handleExportExcel
              }
              disabled={
                !!exporting
              }
            >
              {exporting ===
              "excel"
                ? "Exporting…"
                : "Export Excel"}
            </Button>
          )}

          <Button
            variant="contained"
            startIcon={
              <Download />
            }
            size="small"
            onClick={
              handleExportPDF
            }
            disabled={
              !!exporting
            }
          >
            {exporting === "pdf"
              ? "Exporting…"
              : "Export PDF"}
          </Button>
        </Box>
      </Box>

      {/* KPI CARDS */}

      <Grid
        container
        spacing={2}
        sx={{
          mb: 3,
        }}
      >
        <Grid
          size={{
            xs: 12,
            sm: 6,
            md: 3,
          }}
        >
          <Card
            sx={{
              bgcolor:
                "primary.main",
              color: "white",
              height: "100%",
            }}
          >
            <CardContent>
              <Typography
                variant="overline"
                sx={{
                  opacity: 0.75,
                  fontSize:
                    "0.65rem",
                }}
              >
                Overall Maturity
              </Typography>

              <Typography
                variant="h2"
                fontWeight={900}
                sx={{
                  lineHeight: 1,
                  my: 0.5,
                }}
              >
                {overall.toFixed(1)}
              </Typography>

              <Typography
                variant="caption"
                sx={{
                  opacity: 0.8,
                }}
              >
                Score 1 (Initial)
                to 5 (Optimised)
              </Typography>

              <Box
                sx={{
                  mt: 1,
                  px: 1.2,
                  py: 0.4,
                  bgcolor:
                    "rgba(255,255,255,0.18)",
                  borderRadius: 1,
                  display:
                    "inline-block",
                }}
              >
                <Typography
                  variant="caption"
                  fontWeight={800}
                >
                  {maturityLabel}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid
          size={{
            xs: 12,
            sm: 6,
            md: 3,
          }}
        >
          <Card
            sx={{
              height: "100%",
              border:
                `2px solid ${riskColor}`,
            }}
          >
            <CardContent>
              <Typography
                variant="overline"
                color="text.secondary"
                sx={{
                  fontSize:
                    "0.65rem",
                }}
              >
                Operational Risk
              </Typography>

              <Box
                sx={{
                  display: "flex",
                  alignItems:
                    "center",
                  gap: 1,
                  mt: 0.5,
                }}
              >
                <RiskIcon
                  score={overall}
                />

                <Typography
                  variant="h5"
                  fontWeight={800}
                  sx={{
                    color:
                      riskColor,
                  }}
                >
                  {riskLabel}
                </Typography>
              </Box>

              <Typography
                variant="caption"
                color="text.secondary"
              >
                Across{" "}
                {totalAnswered}{" "}
                assessed dimensions
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid
          size={{
            xs: 12,
            sm: 6,
            md: 3,
          }}
        >
          <Card
            sx={{
              height: "100%",
              bgcolor:
                "#F7F9FF",
            }}
          >
            <CardContent>
              <Typography
                variant="overline"
                color="text.secondary"
                sx={{
                  fontSize:
                    "0.65rem",
                }}
              >
                Questions Completed
              </Typography>

              <Typography
                variant="h2"
                fontWeight={900}
                color="primary.main"
                sx={{
                  lineHeight: 1,
                  my: 0.5,
                }}
              >
                {totalAnswered}

                <Typography
                  component="span"
                  variant="h5"
                  fontWeight={400}
                  color="text.secondary"
                >
                  {" "}
                  /{totalQuestions}
                </Typography>
              </Typography>

              <LinearProgress
                variant="determinate"
                value={
                  completionPercentage
                }
                sx={{
                  height: 5,
                  borderRadius: 3,
                  mt: 1,
                }}
              />
            </CardContent>
          </Card>
        </Grid>

        <Grid
          size={{
            xs: 12,
            sm: 6,
            md: 3,
          }}
        >
          <Card
            sx={{
              height: "100%",
              bgcolor:
                "#FFF8F7",
              border:
                "1px solid #FFD5C8",
            }}
          >
            <CardContent>
              <Typography
                variant="overline"
                color="text.secondary"
                sx={{
                  fontSize:
                    "0.65rem",
                }}
              >
                Priority Actions
              </Typography>

              <Typography
                variant="h2"
                fontWeight={900}
                sx={{
                  color:
                    "#D83B01",
                  lineHeight: 1,
                  my: 0.5,
                }}
              >
                {criticalAndHighCount}
              </Typography>

              <Typography
                variant="caption"
                color="text.secondary"
              >
                Critical & high
                priority items
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* CHARTS */}

      <Grid
        container
        spacing={3}
        sx={{
          mb: 3,
        }}
      >
        <Grid
          size={{
            xs: 12,
            md: 7,
          }}
        >
          <Card
            elevation={0}
            sx={{
              border:
                "1px solid #E0E4EC",
              height: "100%",
            }}
          >
            <CardContent>
              <Typography
                variant="h6"
                fontWeight={700}
                sx={{
                  mb: 2,
                }}
              >
                {isCustomer
                  ? "Maturity by Assessments"
                  : "Maturity by Domain"}
              </Typography>

              {radarData.length >
              1 ? (
                <ResponsiveContainer
                  width="100%"
                  height={280}
                >
                  <RadarChart
                    data={radarData}
                  >
                    <PolarGrid
                      stroke="#E8ECF4"
                    />

                    <PolarAngleAxis
                      dataKey="domain"
                      tick={{
                        fontSize: 11,
                        fill: "#555",
                      }}
                    />

                    <PolarRadiusAxis
                      angle={90}
                      domain={[
                        0,
                        5,
                      ]}
                      tick={{
                        fontSize: 9,
                      }}
                    />

                    <Radar
                      name="Score"
                      dataKey="score"
                      stroke="#2B3E7E"
                      fill="#2B3E7E"
                      fillOpacity={0.45}
                    />

                    <Tooltip
                      formatter={(
                        value: number
                      ) => [
                        Number(
                          value
                        ).toFixed(1),
                        "Score",
                      ]}
                    />

                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              ) : (
                <Box
                  sx={{
                    height: 280,
                    display: "flex",
                    alignItems:
                      "center",
                    justifyContent:
                      "center",
                    color:
                      "text.secondary",
                  }}
                >
                  Answer more questions
                  to see the domain chart.
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid
          size={{
            xs: 12,
            md: 5,
          }}
        >
          <Card
            elevation={0}
            sx={{
              border:
                "1px solid #E0E4EC",
              height: "100%",
            }}
          >
            <CardContent>
              <Typography
                variant="h6"
                fontWeight={700}
                sx={{
                  mb: 2,
                }}
              >
                Risk Distribution
              </Typography>

              {pieData.length >
              0 ? (
                <>
                  <ResponsiveContainer
                    width="100%"
                    height={200}
                  >
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={52}
                        outerRadius={82}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieData.map(
                          (
                            entry,
                            index
                          ) => (
                            <Cell
                              key={`risk-cell-${index}`}
                              fill={
                                entry.color
                              }
                            />
                          )
                        )}
                      </Pie>

                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>

                  <Box
                    sx={{
                      mt: 1,
                    }}
                  >
                    {pieData.map(
                      (entry) => (
                        <Box
                          key={
                            entry.name
                          }
                          sx={{
                            display:
                              "flex",
                            justifyContent:
                              "space-between",
                            py: 0.4,
                          }}
                        >
                          <Box
                            sx={{
                              display:
                                "flex",
                              alignItems:
                                "center",
                              gap: 1,
                            }}
                          >
                            <Box
                              sx={{
                                width: 10,
                                height: 10,
                                borderRadius:
                                  "50%",
                                bgcolor:
                                  entry.color,
                              }}
                            />

                            <Typography
                              variant="caption"
                            >
                              {entry.name}
                            </Typography>
                          </Box>

                          <Typography
                            variant="caption"
                            fontWeight={700}
                          >
                            {entry.value}{" "}
                            questions
                          </Typography>
                        </Box>
                      )
                    )}
                  </Box>
                </>
              ) : (
                <Box
                  sx={{
                    height: 200,
                    display: "flex",
                    alignItems:
                      "center",
                    justifyContent:
                      "center",
                    color:
                      "text.secondary",
                  }}
                >
                  No data yet.
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* SCORES BY DOMAIN */}

      {Object.keys(
        byCategory
      ).length > 0 && (
        <Card
          elevation={0}
          sx={{
            border:
              "1px solid #E0E4EC",
            mb: 3,
          }}
        >
          <CardContent>
            <Typography
              variant="h6"
              fontWeight={700}
              sx={{
                mb: 2,
              }}
            >
              {isCustomer
                ? "Scores by Assessments"
                : "Scores by Domain"}
            </Typography>

            <Grid
              container
              spacing={2}
            >
              {Object.entries(
                byCategory
              ).map(
                ([
                  category,
                  score,
                ]) => (
                  <Grid
                    size={{
                      xs: 12,
                      sm: 6,
                      md: 4,
                    }}
                    key={category}
                  >
                    <Box
                      sx={{
                        p: 2,
                        borderRadius: 2,
                        border:
                          "1px solid",
                        borderColor:
                          "divider",
                      }}
                    >
                      <Box
                        sx={{
                          display:
                            "flex",
                          justifyContent:
                            "space-between",
                          mb: 1,
                        }}
                      >
                        <Typography
                          variant="body2"
                          fontWeight={700}
                        >
                          {category}
                        </Typography>

                        <Typography
                          variant="body2"
                          fontWeight={800}
                          sx={{
                            color:
                              getRiskColor(
                                score
                              ),
                          }}
                        >
                          {Number(
                            score
                          ).toFixed(1)}{" "}
                          / 5
                        </Typography>
                      </Box>

                      <LinearProgress
                        variant="determinate"
                        value={Math.min(
                          100,
                          (
                            Number(
                              score
                            ) /
                            5
                          ) * 100
                        )}
                        sx={{
                          height: 6,
                          borderRadius: 3,
                          bgcolor:
                            "#F0F0F0",

                          "& .MuiLinearProgress-bar":
                            {
                              bgcolor:
                                getRiskColor(
                                  score
                                ),
                            },
                        }}
                      />

                      <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{
                          mt: 0.5,
                          display:
                            "block",
                        }}
                      >
                        {getMaturityLabel(
                          score
                        )}
                      </Typography>
                    </Box>
                  </Grid>
                )
              )}
            </Grid>
          </CardContent>
        </Card>
      )}

      {/* RECOMMENDATIONS */}

      {!isCustomer && (
      <>
      <Card
        elevation={0}
        sx={{
          border:
            "1px solid #E0E4EC",
          mb: 3,
        }}
      >
        <CardContent>
          <Box
            sx={{
              display: "flex",
              justifyContent:
                "space-between",
              alignItems:
                "center",
              mb: 2,
              gap: 2,
              flexWrap: "wrap",
            }}
          >
            <Typography
              variant="h6"
              fontWeight={700}
            >
              Prioritised
              Recommendations
            </Typography>

            <Chip
              label={`${recommendations.length} total`}
              size="small"
              color="primary"
            />
          </Box>

          {recommendations.length ===
          0 ? (
            <Box
              sx={{
                textAlign:
                  "center",
                py: 4,
                bgcolor:
                  "#F0FBF2",
                borderRadius: 2,
              }}
            >
              <CheckCircle
                sx={{
                  fontSize: 48,
                  color:
                    "#107C10",
                  mb: 1,
                }}
              />

              <Typography
                variant="h6"
                color="#107C10"
              >
                Excellent maturity
                level
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
              >
                No critical gaps
                identified. Focus on
                sustaining current
                practices.
              </Typography>
            </Box>
          ) : (
            recommendations.map(
              (
                recommendation,
                index
              ) => {
                const priorityColor =
                  PRIORITY_COLORS[
                    recommendation
                      .priority
                  ];

                const priorityBackground =
                  PRIORITY_BG[
                    recommendation
                      .priority
                  ];

                return (
                  <Box
                    key={`${recommendation.questionId}-${index}`}
                    sx={{
                      p: 2,
                      mb: 1.5,
                      borderRadius: 2,

                      bgcolor:
                        priorityBackground,

                      border:
                        `1px solid ${priorityColor}30`,

                      borderLeft:
                        `4px solid ${priorityColor}`,
                    }}
                  >
                    <Box
                      sx={{
                        display:
                          "flex",
                        gap: 1,
                        mb: 1,
                        flexWrap:
                          "wrap",
                      }}
                    >
                      <Chip
                        label={
                          recommendation
                            .priority
                        }
                        size="small"
                        sx={{
                          bgcolor:
                            priorityColor,
                          color:
                            "white",
                          fontWeight: 700,
                        }}
                      />

                      <Chip
                        label={
                          recommendation
                            .category
                        }
                        variant="outlined"
                        size="small"
                      />

                      <Chip
                        label={
                          recommendation
                            .timeline
                        }
                        variant="outlined"
                        size="small"
                      />
                    </Box>

                    <Typography
                      variant="body2"
                      fontWeight={700}
                      sx={{
                        mb: 0.75,
                      }}
                    >
                      {
                        recommendation
                          .question
                      }
                    </Typography>

                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{
                        mb: 0.5,
                      }}
                    >
                      <strong>
                        Business impact:
                      </strong>{" "}
                      {
                        recommendation
                          .businessImpact
                      }
                    </Typography>

                    <Typography
                      variant="body2"
                      sx={{
                        color:
                          priorityColor,
                        fontWeight: 500,
                      }}
                    >
                      <strong>
                        Recommended action:
                      </strong>{" "}
                      {
                        recommendation
                          .action
                      }
                    </Typography>
                  </Box>
                );
              }
            )
          )}
        </CardContent>
      </Card>

      {/* TRANSFORMATION ROADMAP */}

      <Card
        elevation={0}
        sx={{
          border:
            "1px solid #E0E4EC",
          mb: 3,
        }}
      >
        <CardContent>
          <Typography
            variant="h6"
            fontWeight={700}
            sx={{
              mb: 3,
            }}
          >
            Suggested QA Transformation
            Roadmap
          </Typography>

          <Box
            sx={{
              display: "flex",
              gap: 2,
              flexWrap:
                "wrap",
            }}
          >
            {ROADMAP.map(
              (phase) => (
                <Box
                  key={
                    phase.phase
                  }
                  sx={{
                    flex:
                      "1 1 180px",
                    minWidth: 160,
                  }}
                >
                  <Box
                    sx={{
                      p: 2.5,
                      border:
                        `2px solid ${phase.color}`,
                      borderRadius: 2,
                      bgcolor:
                        `${phase.color}0D`,
                      height:
                        "100%",
                    }}
                  >
                    <Typography
                      variant="subtitle2"
                      fontWeight={800}
                      sx={{
                        color:
                          phase.color,
                        mb: 0.3,
                      }}
                    >
                      {phase.phase}
                    </Typography>

                    <Typography
                      variant="caption"
                      color="text.secondary"
                      sx={{
                        display:
                          "block",
                        mb: 1.5,
                      }}
                    >
                      {phase.months}
                    </Typography>

                    {phase.items.map(
                      (item) => (
                        <Box
                          key={item}
                          sx={{
                            display:
                              "flex",
                            alignItems:
                              "flex-start",
                            gap: 0.8,
                            mb: 0.6,
                          }}
                        >
                          <ArrowForward
                            sx={{
                              fontSize: 12,
                              color:
                                phase.color,
                              mt: 0.2,
                              flexShrink: 0,
                            }}
                          />

                          <Typography
                            variant="caption"
                            sx={{
                              lineHeight:
                                1.4,
                            }}
                          >
                            {item}
                          </Typography>
                        </Box>
                      )
                    )}
                  </Box>
                </Box>
              )
            )}
          </Box>
        </CardContent>
      </Card>
      </>
      )}

      {/* FOOTER ACTIONS */}

      <Box
        sx={{
          display: "flex",
          gap: 2,
          justifyContent:
            "flex-end",
          flexWrap: "wrap",
        }}
      >
        <Button
          variant="outlined"
          startIcon={
            <Assessment />
          }
          onClick={() =>
            navigate(
              "/assessment"
            )
          }
        >
          New Assessment
        </Button>

        {!isCustomer && (
          <Button
            variant="outlined"
            startIcon={
              <Download />
            }
            onClick={
              handleExportExcel
            }
            disabled={
              !!exporting
            }
          >
            {exporting ===
            "excel"
              ? "Exporting…"
              : "Export Excel"}
          </Button>
        )}

        <Button
          variant="contained"
          startIcon={
            <Download />
          }
          onClick={
            handleExportPDF
          }
          disabled={
            !!exporting
          }
        >
          {exporting ===
          "pdf"
            ? "Exporting…"
            : "Export PDF Report"}
        </Button>
      </Box>
    </Box>
  );
}