import { useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router";

import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Grid,
  Chip,
  Divider,
  Alert,
  CircularProgress,
} from "@mui/material";

import {
  CheckCircle,
  ArrowForward,
  Assignment,
} from "@mui/icons-material";

import type { AssessmentDomain } from "../../data/assessmentQuestions";
import { assessmentService } from "../../lib/assessment-service";
import { useAuth } from "../../contexts/AuthContext";


// ─────────────────────────────────────────────────────────────
// ASSESSMENT DOMAINS
// ─────────────────────────────────────────────────────────────

const assessmentDomains: {
  id: AssessmentDomain;
  name: string;
  description: string;
}[] = [

  {
    id: "Architecture",
    name: "Architecture",
    description:
      "Assess solution architecture, integrations, environments, technical dependencies, and architectural governance.",
  },

  {
    id: "Implementation",
    name: "Implementation",
    description:
      "Assess D365 delivery practices, implementation approach, testing readiness, deployment planning, and delivery risks.",
  },

  {
    id: "Product",
    name: "Product",
    description:
      "Assess product configuration, customisation, extensibility, and governance of the Dynamics 365 solution.",
  },

  {
    id: "Fit for Purpose",
    name: "Fit for Purpose",
    description:
      "Assess how effectively the Dynamics 365 solution supports business requirements and operational needs.",
  },

  {
    id: "Project Governance",
    name: "Project Governance",
    description:
      "Assess governance, accountability, stakeholder engagement, risks, dependencies, scope, timelines, and quality management.",
  },

  {
    id: "Competency",
    name: "Competency",
    description:
      "Assess organisational skills, knowledge, capability development, and Dynamics 365 competency.",
  },

  {
    id: "Support",
    name: "Support",
    description:
      "Assess support maturity, incident management, operational processes, and continuous improvement.",
  },

  {
    id: "Release Management",
    name: "Release Management",
    description:
      "Assess release planning, change control, deployment governance, and readiness for Dynamics 365 updates.",
  },

  {
    id: "Quality Engineering",
    name: "Quality Engineering",
    description:
      "Assess test strategy, quality processes, automation capability, defect management, and quality governance.",
  },

  {
    id: "Data Quality",
    name: "Data Quality",
    description:
      "Assess data migration readiness, data validation, data quality controls, ownership, and governance.",
  },

  {
    id: "Security & Access Governance",
    name: "Security & Access Governance",
    description:
      "Assess role-based access control, security role testing, access governance, and periodic access review practices.",
  },

  {
    id: "Integration Testing",
    name: "Integration Testing",
    description:
      "Assess integration test coverage, validation of interfaces, error handling, dependencies, and end-to-end testing practices.",
  },

];


// ─────────────────────────────────────────────────────────────
// COMPONENT
// ─────────────────────────────────────────────────────────────

export default function DomainSelection() {

  const navigate = useNavigate();

  const location = useLocation();

  const { role } = useAuth();
  const isCustomer = role === "customer";

  const state = (location.state as any) || {};


  // ───────────────────────────────────────────────────────────
  // ALL DOMAINS ARE MANDATORY
  //
  // The assessment is now fixed at 20 questions.
  // Users can review the assessment scope but cannot
  // select or deselect domains.
  // ───────────────────────────────────────────────────────────

  const selectedDomains =
    useMemo<AssessmentDomain[]>(
      () =>
        assessmentDomains.map(
          (domain) => domain.id
        ),
      []
    );


  // ───────────────────────────────────────────────────────────
  // START THE RUN + CONTINUE
  // ───────────────────────────────────────────────────────────

  const [starting, setStarting] = useState(false);
  const [startError, setStartError] = useState<string | null>(null);

  const handleContinue = async () => {
    setStarting(true);
    setStartError(null);

    const customerInfo = state.customerInfo;
    const implementationType = state.implementationType ?? "Greenfield";

    // Customer Info now creates (and auto-saves into) the run the
    // moment the customer starts typing — this step should update
    // that same run, not start a second one. Only fall back to
    // creating a fresh run if that somehow never happened (e.g. this
    // page was reached without going through Customer Info at all).
    const existingRunId: string | undefined = state.runId;

    const companyName: string =
      customerInfo?.companyName?.trim() || "Unnamed Organisation";

    const { runId, error } = existingRunId
      ? await assessmentService
          .updateContext(existingRunId, {
            selectedDomains,
            implementationType,
            customerInfo,
          })
          .then((result) => ({
            runId: result.error ? null : existingRunId,
            error: result.error,
          }))
      : await assessmentService.start(
          "QA_MATURITY",
          `D365 QA Maturity Assessment — ${companyName}`,
          {
            selectedDomains,
            implementationType,
            customerInfo,
          }
        );

    setStarting(false);

    if (error || !runId) {
      setStartError(
        error ??
          "Unable to start the assessment. Please check your connection and try again."
      );
      return;
    }

    navigate(
      "/assessment/questionnaire",
      {
        state: {
          ...state,

          runId,

          selectedDomains,

          assessmentQuestionCount: 20,
        },
      }
    );

  };


  // ───────────────────────────────────────────────────────────
  // BACK
  // ───────────────────────────────────────────────────────────

  const handleBack = () => {

    navigate(
      "/assessment"
    );

  };


  // ───────────────────────────────────────────────────────────
  // RENDER
  // ───────────────────────────────────────────────────────────

  return (

    <Box
      sx={{
        maxWidth: 1100,
        mx: "auto",
        pb: 4,
      }}
    >


      {/* ─────────────────────────────────────────────────────── */}
      {/* PAGE HEADER */}
      {/* ─────────────────────────────────────────────────────── */}

      <Box
        sx={{
          mb: 3,
        }}
      >

        <Typography
          variant="h4"
          fontWeight={700}
          color="primary.main"
          sx={{
            mb: 1,
          }}
        >
          D365 QA Maturity Assessment
        </Typography>


        <Typography
          variant="body1"
          color="text.secondary"
        >
          The assessment covers all key dimensions of Dynamics 365
          quality, delivery, governance, security, data, testing,
          releases, and operational maturity.
        </Typography>

      </Box>


      {/* ─────────────────────────────────────────────────────── */}
      {/* ASSESSMENT OVERVIEW */}
      {/* ─────────────────────────────────────────────────────── */}

      <Card
        elevation={0}
        sx={{
          mb: 3,

          border:
            "1px solid #E0E4EC",

          borderRadius: 3,

          bgcolor:
            "#F8FAFD",
        }}
      >

        <CardContent
          sx={{
            p: 3,
          }}
        >

          <Box
            sx={{
              display: "flex",

              justifyContent:
                "space-between",

              alignItems:
                {
                  xs: "flex-start",
                  sm: "center",
                },

              flexDirection:
                {
                  xs: "column",
                  sm: "row",
                },

              gap: 2,
            }}
          >

            <Box
              sx={{
                display: "flex",

                alignItems:
                  "flex-start",

                gap: 1.5,
              }}
            >

              <Assignment
                sx={{
                  color:
                    "primary.main",

                  mt: 0.2,
                }}
              />


              <Box>

                <Typography
                  variant="h6"
                  fontWeight={700}
                >
                  Assessment Scope
                </Typography>


                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{
                    mt: 0.5,
                  }}
                >
                  All assessment areas are included to provide a
                  complete and consistent maturity evaluation.
                </Typography>

              </Box>

            </Box>


            <Box
              sx={{
                display: "flex",

                gap: 1,

                flexWrap:
                  "wrap",
              }}
            >

              <Chip
                label="20 Questions"
                color="primary"
                variant="outlined"
                sx={{
                  fontWeight: 700,
                }}
              />


              <Chip
                label={`${assessmentDomains.length} Assessment Domains`}
                sx={{
                  fontWeight: 700,

                  bgcolor:
                    "#EAF2FF",

                  color:
                    "#0F6CBD",
                }}
              />

            </Box>

          </Box>

        </CardContent>

      </Card>


      {/* ─────────────────────────────────────────────────────── */}
      {/* SECTION HEADER */}
      {/* ─────────────────────────────────────────────────────── */}

      <Box
        sx={{
          display: "flex",

          justifyContent:
            "space-between",

          alignItems:
            "center",

          mb: 2,
        }}
      >

        <Box>

          <Typography
            variant="h5"
            fontWeight={700}
          >
            Assessment Areas
          </Typography>


          <Typography
            variant="body2"
            color="text.secondary"
            sx={{
              mt: 0.5,
            }}
          >
            The following domains are included in this assessment.
          </Typography>

        </Box>


        <Chip
          icon={
            <CheckCircle />
          }
          label="All Included"
          size="small"
          sx={{
            fontWeight: 700,

            bgcolor:
              "#EAF7EE",

            color:
              "#107C10",

            "& .MuiChip-icon": {
              color:
                "#107C10",
            },
          }}
        />

      </Box>


      {/* ─────────────────────────────────────────────────────── */}
      {/* DOMAIN CARDS */}
      {/* ─────────────────────────────────────────────────────── */}

      <Grid
        container
        spacing={2}
      >

        {assessmentDomains.map(
          (domain, index) => (

            <Grid
              key={domain.id}
              size={{
                xs: 12,
                md: 6,
              }}
            >

              <Card
                elevation={0}
                sx={{
                  height:
                    "100%",

                  border:
                    "1px solid #E0E4EC",

                  borderRadius: 3,

                  transition:
                    "box-shadow 0.2s ease, border-color 0.2s ease",

                  "&:hover": {

                    borderColor:
                      "primary.light",

                    boxShadow:
                      "0 4px 14px rgba(0,0,0,0.08)",

                  },
                }}
              >

                <CardContent
                  sx={{
                    p: 2.5,
                  }}
                >

                  {/* TOP ROW */}

                  <Box
                    sx={{
                      display:
                        "flex",

                      justifyContent:
                        "space-between",

                      alignItems:
                        "flex-start",

                      gap: 2,
                    }}
                  >

                    <Box
                      sx={{
                        display:
                          "flex",

                        alignItems:
                          "center",

                        gap: 1.5,

                        minWidth: 0,
                      }}
                    >

                      {/* DOMAIN NUMBER */}

                      <Box
                        sx={{
                          width: 34,

                          height: 34,

                          flexShrink: 0,

                          borderRadius:
                            "50%",

                          bgcolor:
                            "#EAF2FF",

                          color:
                            "primary.main",

                          display:
                            "flex",

                          alignItems:
                            "center",

                          justifyContent:
                            "center",

                          fontWeight: 800,

                          fontSize: 14,
                        }}
                      >
                        {index + 1}
                      </Box>


                      {/* DOMAIN NAME */}

                      <Typography
                        variant="h6"
                        fontWeight={700}
                        sx={{
                          lineHeight: 1.3,
                        }}
                      >
                        {domain.name}
                      </Typography>

                    </Box>


                    {/* INCLUDED INDICATOR */}

                    <CheckCircle
                      sx={{
                        color:
                          "#107C10",

                        fontSize:
                          22,

                        flexShrink: 0,
                      }}
                    />

                  </Box>


                  <Divider
                    sx={{
                      my: 1.5,
                    }}
                  />


                  {/* DESCRIPTION */}

                  <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{
                      lineHeight:
                        1.6,

                      minHeight:
                        {
                          md: 66,
                        },
                    }}
                  >
                    {domain.description}
                  </Typography>


                  {/* INCLUDED CHIP */}

                  <Box
                    sx={{
                      mt: 2,
                    }}
                  >

                    <Chip
                      label="Included in assessment"
                      size="small"
                      sx={{
                        fontSize:
                          11,

                        fontWeight:
                          600,

                        bgcolor:
                          "#F0F8F1",

                        color:
                          "#107C10",

                        border:
                          "1px solid #D4EDDA",
                      }}
                    />

                  </Box>

                </CardContent>

              </Card>

            </Grid>

          )
        )}

      </Grid>


      {/* ─────────────────────────────────────────────────────── */}
      {/* FOOTER */}
      {/* ─────────────────────────────────────────────────────── */}

      {startError && (
        <Alert severity="error" sx={{ mt: 3 }} onClose={() => setStartError(null)}>
          {startError}
        </Alert>
      )}

      <Box
        sx={{
          display:
            "flex",

          justifyContent:
            "space-between",

          alignItems:
            "center",

          mt: 4,

          pt: 3,

          borderTop:
            "1px solid",

          borderColor:
            "divider",
        }}
      >

        <Button
          variant="outlined"
          onClick={
            handleBack
          }
        >
          Back
        </Button>


        <Box
          sx={{
            display:
              "flex",

            alignItems:
              "center",

            gap: 2,
          }}
        >

          {!isCustomer && (
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                display:
                  {
                    xs: "none",
                    sm: "block",
                  },
              }}
            >
              20 questions across all assessment areas
            </Typography>
          )}


          <Button
            variant="contained"
            size="large"

            endIcon={
              starting ? undefined : <ArrowForward />
            }

            onClick={
              handleContinue
            }

            disabled={starting}

            sx={{
              minWidth:
                230,
            }}
          >
            {starting ? (
              <CircularProgress size={22} color="inherit" />
            ) : (
              "Start Assessment"
            )}
          </Button>

        </Box>

      </Box>

    </Box>

  );

}