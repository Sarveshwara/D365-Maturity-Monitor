import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  CircularProgress,
} from "@mui/material";
import { Assignment, ArrowForward } from "@mui/icons-material";
import { assessmentService } from "../../lib/assessment-service";

export default function AssessmentWizard() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(false);

  const handleStart = async () => {
    setChecking(true);

    // Same gap that the sidebar "Questionnaire" link had: always
    // starting fresh, even when the person already has a draft,
    // silently orphaned the old run as a permanent "In Progress"
    // entry in My Assessments every time someone re-entered here.
    const { run } = await assessmentService.getLatestResumable("QA_MATURITY");

    setChecking(false);

    if (run) {
      // A draft that never made it past Customer Info (no domains
      // chosen yet) needs to resume there, pre-filled — not jump
      // straight to the questionnaire with domains/implementation
      // type it never actually set.
      if (run.assessment_context?.selectedDomains) {
        navigate("/assessment/questionnaire", {
          state: { runId: run.id },
        });
      } else {
        navigate("/assessment/customer-info", {
          state: {
            runId: run.id,
            customerInfo: run.assessment_context?.customerInfo,
            assessmentType: "D365",
            implementationType: "Greenfield",
          },
        });
      }
      return;
    }

    navigate("/assessment/customer-info", {
      state: {
        assessmentType: "D365",
        implementationType: "Greenfield",
      },
    });
  };

  return (
    <Box sx={{ maxWidth: 1000, mx: "auto" }}>
      <Typography variant="h4" fontWeight={700} sx={{ mb: 1 }}>
        D365 Assessment
      </Typography>

      <Typography
        variant="body1"
        color="text.secondary"
        sx={{ mb: 4 }}
      >
        Assess the maturity of your Microsoft Dynamics 365 testing
        and quality engineering practices.
      </Typography>

      <Card
        sx={{
          borderRadius: 3,
          border: "1px solid",
          borderColor: "divider",
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Grid container spacing={3} alignItems="center">
            <Grid size={{ xs: 12, md: 2 }}>
              <Box
                sx={{
                  width: 72,
                  height: 72,
                  borderRadius: 3,
                  bgcolor: "primary.light",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Assignment
                  sx={{
                    fontSize: 40,
                    color: "primary.main",
                  }}
                />
              </Box>
            </Grid>

            <Grid size={{ xs: 12, md: 7 }}>
              <Typography variant="h5" fontWeight={700}>
                Dynamics 365 QA Maturity Assessment
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
                sx={{ mt: 1 }}
              >
                Evaluate your current testing maturity across
                strategy, planning, test management, automation,
                quality engineering, DevOps and other relevant
                assessment domains.
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, md: 3 }}>
              <Button
                fullWidth
                variant="contained"
                size="large"
                endIcon={checking ? undefined : <ArrowForward />}
                onClick={handleStart}
                disabled={checking}
              >
                {checking ? (
                  <CircularProgress size={22} color="inherit" />
                ) : (
                  "Start Assessment"
                )}
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
}