import { useState, useEffect, useRef, useMemo } from "react";
import { useNavigate, useLocation } from "react-router";

import {
  Card,
  CardContent,
  Typography,
  Box,
  Button,
  LinearProgress,
  CircularProgress,
  Chip,
  TextField,
  Dialog,
  DialogContent,
  DialogActions,
} from "@mui/material";

import {
  ArrowForward,
  ArrowBack,
  Save,
  CheckCircle,
  CloudDone,
} from "@mui/icons-material";

import {
  getAssessmentQuestions,
  type AssessmentQuestion,
  type AnswerOption,
  type AssessmentDomain,
  type ImplementationType,
} from "../../data/assessmentQuestions";

import { assessmentService } from "../../lib/assessment-service";
import { auditService } from "../../lib/audit-service";
import { useAuth } from "../../contexts/AuthContext";

// ─────────────────────────────────────────────────────────────
// LEVEL STYLE
// ─────────────────────────────────────────────────────────────

const LEVEL_STYLE: Record<
  number,
  {
    border: string;
    bg: string;
    text: string;
    badge: string;
  }
> = {
  1: {
    border: "#D83B01",
    bg: "#FFF5F2",
    text: "#D83B01",
    badge: "#FFE8E0",
  },

  2: {
    border: "#B8860B",
    bg: "#FFFBF0",
    text: "#B8860B",
    badge: "#FFF3CC",
  },

  3: {
    border: "#0F6CBD",
    bg: "#F0F6FF",
    text: "#0F6CBD",
    badge: "#D6E9FB",
  },

  4: {
    border: "#107C10",
    bg: "#F0FBF2",
    text: "#107C10",
    badge: "#D4EDDA",
  },

  5: {
    border: "#5C2D91",
    bg: "#F8F0FF",
    text: "#5C2D91",
    badge: "#E8D8F8",
  },
};

// ─────────────────────────────────────────────────────────────
// DOMAIN COLOURS
// ─────────────────────────────────────────────────────────────

const DOMAIN_COLORS: Record<AssessmentDomain, string> = {
  Architecture: "#0F6CBD",

  Implementation: "#107C10",

  Product: "#8764B8",

  "Fit for Purpose": "#038387",

  "Project Governance": "#C43501",

  Competency: "#E65C00",

  Support: "#004E8C",

  "Release Management": "#5C2D91",

  "Quality Engineering": "#008272",

  "Data Quality": "#8E562E",

  "Security & Access Governance": "#D13438",

  "Integration Testing": "#6B69D6",
};

// ─────────────────────────────────────────────────────────────
// LEVEL CARD
// ─────────────────────────────────────────────────────────────

function LevelCard({
  option,
  selected,
  onSelect,
  hideLevelBadge,
}: {
  option: AnswerOption;
  selected: boolean;
  onSelect: () => void;
  hideLevelBadge?: boolean;
}) {
  const style =
    LEVEL_STYLE[option.level] ??
    LEVEL_STYLE[3];

  return (
    <Box
      onClick={onSelect}
      role="radio"
      aria-checked={selected}
      tabIndex={0}
      onKeyDown={(event) => {
        if (
          event.key === "Enter" ||
          event.key === " "
        ) {
          event.preventDefault();
          onSelect();
        }
      }}
      sx={{
        display: "flex",
        alignItems: "flex-start",
        gap: 2,
        p: 2,
        mb: 1.5,
        border: `2px solid ${
          selected
            ? style.border
            : "#E0E4EC"
        }`,
        borderRadius: 2,
        bgcolor: selected
          ? style.bg
          : "background.paper",
        cursor: "pointer",
        transition:
          "border-color 0.15s, background-color 0.15s",

        "&:hover": {
          borderColor: style.border,
          bgcolor: style.bg,
        },
      }}
    >
      {/* RADIO */}

      <Box
        sx={{
          flexShrink: 0,
          width: 22,
          height: 22,
          borderRadius: "50%",
          border: `2px solid ${
            selected
              ? style.border
              : "#BDBDBD"
          }`,
          bgcolor: selected
            ? style.border
            : "transparent",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          mt: 0.15,
        }}
      >
        {selected && (
          <Box
            sx={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              bgcolor: "white",
            }}
          />
        )}
      </Box>

      {/* CONTENT */}

      <Box sx={{ flex: 1 }}>
        {!hideLevelBadge && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              mb: 1,
            }}
          >
            <Box
              sx={{
                px: 1,
                py: 0.2,
                borderRadius: 1,
                bgcolor: style.badge,
                display: "inline-flex",
                alignItems: "center",
              }}
            >
              <Typography
                variant="caption"
                fontWeight={800}
                sx={{
                  color: style.text,
                  letterSpacing: 0.3,
                }}
              >
                Level {option.level}
              </Typography>
            </Box>
          </Box>
        )}

        <Typography
          variant="body2"
          color="text.primary"
          sx={{
            lineHeight: 1.55,
          }}
        >
          {option.response}
        </Typography>
      </Box>

      {selected && (
        <CheckCircle
          sx={{
            color: style.border,
            fontSize: 20,
            flexShrink: 0,
            mt: 0.1,
          }}
        />
      )}
    </Box>
  );
}

// ─────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────

export default function Questionnaire() {
  const navigate = useNavigate();
  const location = useLocation();

  const { role } = useAuth();
  const isCustomer = role === "customer";

  const state =
    (location.state as any) || {};

  const runId: string | undefined =
    state.runId;

  // ───────────────────────────────────────────────────────────
  // ENTRY GUARD
  //
  // runId is only ever set by DomainSelection.tsx (fresh start,
  // after customer info + domains are captured) or by
  // MyAssessments.tsx (resuming an existing run). Any other way of
  // landing here — the sidebar link, a bookmarked URL, a page
  // refresh that lost router state — has no runId, and used to just
  // render a blank 20-question form with nothing ever saved.
  //
  // Instead: if there's a draft/in-progress run already, resume it;
  // otherwise send them to the proper starting point so customer
  // info gets captured first.
  const [checkingEntry, setCheckingEntry] = useState<boolean>(!runId);

  useEffect(() => {
    if (runId) return;

    let cancelled = false;

    (async () => {
      const { run } = await assessmentService.getLatestResumable(
        "QA_MATURITY"
      );

      if (cancelled) return;

      if (run) {
        // Same as the "Start Assessment" resume check — a draft
        // that never got past Customer Info (no domains chosen yet)
        // needs to resume there, not jump straight into questions.
        if (run.assessment_context?.selectedDomains) {
          navigate("/assessment/questionnaire", {
            state: { runId: run.id },
            replace: true,
          });
          // Navigating to the same route doesn't guarantee a remount,
          // so explicitly clear this rather than relying on one —
          // `runId` itself will pick up the new value on next render
          // since it's derived fresh from location.state each time.
          setCheckingEntry(false);
        } else {
          navigate("/assessment/customer-info", {
            state: {
              runId: run.id,
              customerInfo: run.assessment_context?.customerInfo,
              assessmentType: "D365",
              implementationType: "Greenfield",
            },
            replace: true,
          });
        }
      } else {
        navigate("/assessment", { replace: true });
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ───────────────────────────────────────────────────────────
  // IMPLEMENTATION TYPE
  // ───────────────────────────────────────────────────────────

  const implementationType: ImplementationType =
    state.implementationType ||
    "Greenfield";

  // ───────────────────────────────────────────────────────────
  // SELECTED DOMAINS
  // ───────────────────────────────────────────────────────────

  const selectedDomains = useMemo(() => {
    if (
      Array.isArray(
        state.selectedDomains
      ) &&
      state.selectedDomains.length > 0
    ) {
      return state.selectedDomains
        .map((domain: any) => {
          if (
            typeof domain ===
            "string"
          ) {
            return domain;
          }

          return (
            domain?.name ??
            domain?.id
          );
        })
        .filter(
          Boolean
        ) as AssessmentDomain[];
    }

    return [
      "Architecture",
      "Implementation",
      "Product",
      "Fit for Purpose",
      "Project Governance",
      "Competency",
      "Support",
      "Release Management",
      "Quality Engineering",
      "Data Quality",
      "Security & Access Governance",
      "Integration Testing",
    ] as AssessmentDomain[];
  }, [
    state.selectedDomains,
  ]);

  // ───────────────────────────────────────────────────────────
  // FILTERED QUESTIONS
  // ───────────────────────────────────────────────────────────

 const questions: AssessmentQuestion[] =
  useMemo(() => {
    const result =
      getAssessmentQuestions();

    return Array.isArray(result)
      ? result
      : [];
  }, []);

  // ───────────────────────────────────────────────────────────
  // STATE
  // ───────────────────────────────────────────────────────────

  const [
    currentIdx,
    setCurrentIdx,
  ] = useState(0);

  const [
    answers,
    setAnswers,
  ] = useState<
    Record<string, number>
  >({});

  const [
    notes,
    setNotes,
  ] = useState<
    Record<string, string>
  >({});

  const [
    saving,
    setSaving,
  ] = useState(false);

  const [
    loading,
    setLoading,
  ] = useState(Boolean(runId));

  const [
    lastSaved,
    setLastSaved,
  ] = useState<Date | null>(
    null
  );

  const [
    errorMessage,
    setErrorMessage,
  ] = useState<
    string | null
  >(null);

  // Customers see a confirmation popup on submit instead of jumping
  // straight to results — navigation is deferred until they dismiss
  // it. Other roles keep the immediate-navigate behavior unchanged.
  const [
    pendingResultsNav,
    setPendingResultsNav,
  ] = useState<{
    path: string;
    state: Record<string, any>;
  } | null>(null);

  const saveTimer =
    useRef<
      ReturnType<typeof setTimeout> | null
    >(null);

  // ───────────────────────────────────────────────────────────
  // QUESTION IDS
  // ───────────────────────────────────────────────────────────

  const applicableQuestionIds =
    useMemo(
      () =>
        new Set(
          questions.map(
            (question) =>
              question.id
          )
        ),
      [questions]
    );

  // ───────────────────────────────────────────────────────────
  // KEEP INDEX VALID
  // ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (
      questions.length === 0
    ) {
      setCurrentIdx(0);
      return;
    }

    setCurrentIdx(
      (previous) =>
        Math.min(
          previous,
          questions.length - 1
        )
    );
  }, [
    questions.length,
  ]);

  // ───────────────────────────────────────────────────────────
  // REMOVE STALE ANSWERS
  // ───────────────────────────────────────────────────────────

  useEffect(() => {
    setAnswers(
      (previous) => {
        const filtered =
          Object.fromEntries(
            Object.entries(
              previous
            ).filter(
              ([questionId]) =>
                applicableQuestionIds.has(
                  questionId
                )
            )
          );

        return filtered;
      }
    );

    setNotes(
      (previous) => {
        const filtered =
          Object.fromEntries(
            Object.entries(
              previous
            ).filter(
              ([questionId]) =>
                applicableQuestionIds.has(
                  questionId
                )
            )
          );

        return filtered;
      }
    );
  }, [
    applicableQuestionIds,
  ]);

  // ───────────────────────────────────────────────────────────
  // LOAD DRAFT / RESUME
  // ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (
      !runId ||
      questions.length === 0
    ) {
      setLoading(false);
      return;
    }

    let mounted = true;

    async function loadRun() {
      try {
        setLoading(true);

        const {
          run,
          error,
        } =
          await assessmentService.get(
            runId
          );

        if (
          !mounted
        ) {
          return;
        }

        if (
          error
        ) {
          setErrorMessage(
            error
          );
          return;
        }

        if (
          !run
        ) {
          setErrorMessage(
            "Assessment could not be found."
          );
          return;
        }

        const validAnswers:
          Record<string, number> =
          {};

        if (
          run.responses_data &&
          typeof run.responses_data ===
            "object"
        ) {
          Object.entries(
            run.responses_data
          ).forEach(
            ([
              questionId,
              value,
            ]) => {
              const numericValue =
                Number(value);

              if (
                applicableQuestionIds.has(
                  questionId
                ) &&
                !Number.isNaN(
                  numericValue
                ) &&
                numericValue >= 1 &&
                numericValue <= 5
              ) {
                validAnswers[
                  questionId
                ] =
                  numericValue;
              }
            }
          );
        }

        const validNotes:
          Record<string, string> =
          {};

        if (
          run.notes_data &&
          typeof run.notes_data ===
            "object"
        ) {
          Object.entries(
            run.notes_data
          ).forEach(
            ([
              questionId,
              value,
            ]) => {
              if (
                applicableQuestionIds.has(
                  questionId
                ) &&
                typeof value ===
                  "string"
              ) {
                validNotes[
                  questionId
                ] =
                  value;
              }
            }
          );
        }

        setAnswers(
          validAnswers
        );

        setNotes(
          validNotes
        );

        // Resume from first unanswered question.
        const firstUnanswered =
          questions.findIndex(
            (question) =>
              validAnswers[
                question.id
              ] === undefined
          );

        if (
          firstUnanswered >= 0
        ) {
          setCurrentIdx(
            firstUnanswered
          );
        } else {
          setCurrentIdx(
            Math.max(
              questions.length - 1,
              0
            )
          );
        }
      } catch (
        error
      ) {
        console.error(
          "Failed to load assessment:",
          error
        );

        if (
          mounted
        ) {
          setErrorMessage(
            "Unable to load the assessment."
          );
        }
      } finally {
        if (
          mounted
        ) {
          setLoading(false);
        }
      }
    }

    loadRun();

    return () => {
      mounted = false;
    };
  }, [
    runId,
    questions,
    applicableQuestionIds,
  ]);

  // ───────────────────────────────────────────────────────────
  // CLEAN UP AUTOSAVE TIMER
  // ───────────────────────────────────────────────────────────

  useEffect(() => {
    return () => {
      if (
        saveTimer.current
      ) {
        clearTimeout(
          saveTimer.current
        );
      }
    };
  }, []);

  // ───────────────────────────────────────────────────────────
  // SAVE PROGRESS
  // ───────────────────────────────────────────────────────────

  const saveProgress =
    async (
      updatedAnswers: Record<
        string,
        number
      >,
      updatedNotes: Record<
        string,
        string
      >
    ) => {
      if (
        !runId
      ) {
        return true;
      }

      try {
        setSaving(true);
        setErrorMessage(null);

        const result =
          await assessmentService.saveProgress(
            runId,
            updatedAnswers,
            updatedNotes
          );

        if (
          result?.error
        ) {
          throw new Error(
            result.error
          );
        }

        setLastSaved(
          new Date()
        );

        return true;
      } catch (
        error
      ) {
        console.error(
          "Failed to save assessment progress:",
          error
        );

        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Failed to save assessment progress."
        );

        return false;
      } finally {
        setSaving(false);
      }
    };

  // ───────────────────────────────────────────────────────────
  // AUTOSAVE
  // ───────────────────────────────────────────────────────────

  const scheduleAutoSave =
    (
      updatedAnswers: Record<
        string,
        number
      >,
      updatedNotes: Record<
        string,
        string
      >
    ) => {
      if (
        !runId
      ) {
        return;
      }

      if (
        saveTimer.current
      ) {
        clearTimeout(
          saveTimer.current
        );
      }

      saveTimer.current =
        setTimeout(() => {
          saveProgress(
            updatedAnswers,
            updatedNotes
          );
        }, 1000);
    };

  // ───────────────────────────────────────────────────────────
  // EMPTY STATE
  // ───────────────────────────────────────────────────────────

  if (
    questions.length === 0
  ) {
    return (
      <Box
        sx={{
          maxWidth: 900,
          mx: "auto",
        }}
      >
        <Card
          elevation={0}
          sx={{
            border:
              "1px solid #E0E4EC",
            borderRadius: 3,
          }}
        >
          <CardContent
            sx={{
              p: 4,
              textAlign: "center",
            }}
          >
            <Typography
              variant="h6"
              fontWeight={700}
            >
              No assessment questions available
            </Typography>

            <Typography
              variant="body2"
              color="text.secondary"
              sx={{
                mt: 1,
              }}
            >
              Please select at least one
              assessment domain.
            </Typography>

            <Button
              variant="contained"
              sx={{
                mt: 3,
              }}
              onClick={() =>
                navigate(
                  "/assessment/domain-selection",
                  {
                    state,
                  }
                )
              }
            >
              Back to Domain Selection
            </Button>
          </CardContent>
        </Card>
      </Box>
    );
  }

  // ───────────────────────────────────────────────────────────
  // LOADING
  // ───────────────────────────────────────────────────────────

  if (
    loading
  ) {
    return (
      <Box
        sx={{
          maxWidth: 1100,
          mx: "auto",
          pt: 4,
        }}
      >
        <LinearProgress />

        <Typography
          variant="body2"
          color="text.secondary"
          sx={{
            mt: 2,
            textAlign: "center",
          }}
        >
          Loading assessment...
        </Typography>
      </Box>
    );
  }

  // ───────────────────────────────────────────────────────────
  // CURRENT QUESTION
  // ───────────────────────────────────────────────────────────

  const total =
    questions.length;

  const question =
    questions[currentIdx];

  const selectedLevel =
    question
      ? answers[
          question.id
        ]
      : undefined;

  const answeredCount =
    questions.filter(
      (item) =>
        answers[item.id] !==
          undefined &&
        answers[item.id] !==
          null
    ).length;

  const progress =
    total > 0
      ? (
          (currentIdx + 1) /
          total
        ) *
        100
      : 0;

  const domainColor =
    question
      ? DOMAIN_COLORS[
          question.domain
        ] ?? "#2B3E7E"
      : "#2B3E7E";

  // ───────────────────────────────────────────────────────────
  // SELECT ANSWER
  // ───────────────────────────────────────────────────────────

  const handleSelect =
    (
      level: number
    ) => {
      if (
        !question
      ) {
        return;
      }

      const updatedAnswers =
        {
          ...answers,
          [question.id]:
            level,
        };

      setAnswers(
        updatedAnswers
      );

      scheduleAutoSave(
        updatedAnswers,
        notes
      );
    };

  // ───────────────────────────────────────────────────────────
  // UPDATE NOTES
  // ───────────────────────────────────────────────────────────

  const handleNotesChange =
    (
      value: string
    ) => {
      if (
        !question
      ) {
        return;
      }

      const updatedNotes =
        {
          ...notes,
          [question.id]:
            value,
        };

      setNotes(
        updatedNotes
      );

      scheduleAutoSave(
        answers,
        updatedNotes
      );
    };

  // ───────────────────────────────────────────────────────────
// NEXT / COMPLETE
// ───────────────────────────────────────────────────────────

const handleNext = async () => {
  // Move to next question
  if (currentIdx < total - 1) {
    setCurrentIdx((previous) => previous + 1);
    return;
  }

  // All applicable questions must be answered
  const unansweredQuestions = questions.filter(
    (item) =>
      answers[item.id] === undefined ||
      answers[item.id] === null
  );

  if (unansweredQuestions.length > 0) {
    const firstUnansweredIndex = questions.findIndex(
      (item) =>
        answers[item.id] === undefined ||
        answers[item.id] === null
    );

    if (firstUnansweredIndex >= 0) {
      setCurrentIdx(firstUnansweredIndex);
    }

    setErrorMessage(
      "Please answer all applicable questions before viewing the results."
    );

    return;
  }

  // Score ONLY the filtered / applicable questions
  const answeredValues = questions
    .map((item) => answers[item.id])
    .filter(
      (value): value is number =>
        typeof value === "number" &&
        value >= 1 &&
        value <= 5
    );

  const totalScore = answeredValues.reduce(
    (sum, value) => sum + value,
    0
  );

  const averageScore =
    answeredValues.length > 0
      ? totalScore / answeredValues.length
      : 0;

  try {
    setSaving(true);
    setErrorMessage(null);

    if (runId) {
      const completion = await assessmentService.complete(
        runId,
        answers,
        notes,
        averageScore
      );

      if (completion.error) {
        throw new Error(completion.error);
      }

      await auditService.assessmentCompleted(
        runId,
        "QA_MATURITY",
        averageScore
      );

      setLastSaved(new Date());
    }

    const resultsPath =
      runId
        ? `/assessment/results/${runId}`
        : "/assessment/results";

    const resultsState = {
      ...state,
      runId,
      answers,
      notes,
      selectedDomains,
      implementationType,
      totalQuestions: total,
      answeredCount: answeredValues.length,
      averageScore,
    };

    if (isCustomer) {
      // Hold navigation until the confirmation dialog is dismissed.
      setPendingResultsNav({
        path: resultsPath,
        state: resultsState,
      });
    } else {
      navigate(resultsPath, {
        state: resultsState,
      });
    }
  } catch (error) {
    console.error(
      "Failed to complete assessment:",
      error
    );

    setErrorMessage(
      error instanceof Error
        ? error.message
        : "Failed to complete the assessment."
    );
  } finally {
    setSaving(false);
  }
};

// ───────────────────────────────────────────────────────────
// BACK
// ───────────────────────────────────────────────────────────
  // ───────────────────────────────────────────────────────────
  // BACK
  // ───────────────────────────────────────────────────────────

  const handleBack =
    () => {
      if (
        currentIdx > 0
      ) {
        setCurrentIdx(
          (previous) =>
            previous - 1
        );
      }
    };

  // ───────────────────────────────────────────────────────────
  // SAVE & EXIT
  // ───────────────────────────────────────────────────────────

  const handleSaveAndExit =
    async () => {
      if (
        saveTimer.current
      ) {
        clearTimeout(
          saveTimer.current
        );

        saveTimer.current =
          null;
      }

      const saved =
        await saveProgress(
          answers,
          notes
        );

      if (
        saved
      ) {
        navigate(
          "/assessment"
        );
      }
    };

  // ───────────────────────────────────────────────────────────
  // DOMAIN PROGRESS
  // ───────────────────────────────────────────────────────────

  const domainProgress =
    questions.reduce<
      Record<
        string,
        {
          total: number;
          done: number;
        }
      >
    >(
      (
        accumulator,
        item
      ) => {
        if (
          !accumulator[
            item.domain
          ]
        ) {
          accumulator[
            item.domain
          ] = {
            total: 0,
            done: 0,
          };
        }

        accumulator[
          item.domain
        ].total++;

        if (
          answers[
            item.id
          ] !== undefined &&
          answers[
            item.id
          ] !== null
        ) {
          accumulator[
            item.domain
          ].done++;
        }

        return accumulator;
      },
      {}
    );

  // ───────────────────────────────────────────────────────────
  // RENDER
  // ───────────────────────────────────────────────────────────

  if (checkingEntry) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "60vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        maxWidth: 1100,
        mx: "auto",
      }}
    >
      {/* TOP PROGRESS */}

      <Box
        sx={{
          mb: 3,
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems:
              "center",
            mb: 1,
            gap: 2,
            flexWrap:
              "wrap",
          }}
        >
          <Typography
            variant="h5"
            fontWeight={700}
            color="primary.main"
          >
            D365 QA Maturity Assessment
          </Typography>

          <Box
            sx={{
              display: "flex",
              alignItems:
                "center",
              gap: 1.5,
            }}
          >
            {runId &&
              (saving ? (
                <Typography
                  variant="caption"
                  color="text.secondary"
                >
                  Saving…
                </Typography>
              ) : lastSaved ? (
                <Box
                  sx={{
                    display:
                      "flex",
                    alignItems:
                      "center",
                    gap: 0.5,
                  }}
                >
                  <CloudDone
                    sx={{
                      fontSize: 13,
                      color:
                        "#107C10",
                    }}
                  />

                  <Typography
                    variant="caption"
                    color="text.secondary"
                  >
                    Saved{" "}
                    {lastSaved.toLocaleTimeString(
                      [],
                      {
                        hour:
                          "2-digit",
                        minute:
                          "2-digit",
                      }
                    )}
                  </Typography>
                </Box>
              ) : null)}

            <Typography
              variant="body2"
              color="text.secondary"
            >
              {answeredCount} of {total} answered
            </Typography>
          </Box>
        </Box>

        {/* QUESTION NAVIGATION */}

        <Box
          sx={{
            display:
              "flex",
            gap: 0.5,
            mb: 1.5,
            flexWrap:
              "wrap",
          }}
        >
          {questions.map(
            (
              item,
              index
            ) => {
              const completed =
                answers[
                  item.id
                ] !== undefined &&
                answers[
                  item.id
                ] !== null;

              const active =
                index ===
                currentIdx;

              return (
                <Box
                  key={
                    item.id
                  }
                  onClick={() =>
                    setCurrentIdx(
                      index
                    )
                  }
                  title={`Question ${
                    index + 1
                  }`}
                  sx={{
                    width: 28,
                    height: 6,
                    borderRadius: 3,
                    cursor:
                      "pointer",

                    bgcolor:
                      active
                        ? "primary.main"
                        : completed
                        ? "#4DD4AC"
                        : "#E0E4EC",

                    transition:
                      "background-color 0.15s",

                    "&:hover": {
                      opacity:
                        0.8,
                    },
                  }}
                />
              );
            }
          )}
        </Box>

        <LinearProgress
          variant="determinate"
          value={progress}
          sx={{
            height: 4,
            borderRadius: 2,
            bgcolor:
              "#E8ECF4",
          }}
        />

        <Typography
          variant="caption"
          color="text.secondary"
          sx={{
            mt: 0.5,
            display:
              "block",
          }}
        >
          Question{" "}
          {currentIdx + 1} of{" "}
          {total}
        </Typography>
      </Box>

      {/* ERROR */}

      {errorMessage && (
        <Box
          sx={{
            mb: 2,
            p: 1.5,
            borderRadius: 2,
            bgcolor:
              "#FFF5F2",
            border:
              "1px solid #F5C2B8",
          }}
        >
          <Typography
            variant="body2"
            sx={{
              color:
                "#D83B01",
            }}
          >
            {errorMessage}
          </Typography>
        </Box>
      )}

      {/* MAIN CONTENT */}

      <Box
        sx={{
          display:
            "flex",
          gap: 3,
          alignItems:
            "flex-start",

          "@media (max-width: 900px)":
            {
              flexDirection:
                "column",
            },
        }}
      >
        {/* LEFT */}

        <Box
          sx={{
            flex:
              "1 1 0",
            minWidth: 0,
            width:
              "100%",
          }}
        >
          <Card
            elevation={0}
            sx={{
              border:
                "1px solid #E0E4EC",
              borderRadius: 3,
              mb: 2,
            }}
          >
            <CardContent
              sx={{
                p: 3,
              }}
            >
              <Box
                sx={{
                  mb: 2,
                }}
              >
                <Chip
                  label={
                    question.domain
                  }
                  size="small"
                  sx={{
                    bgcolor: `${domainColor}18`,
                    color:
                      domainColor,
                    fontWeight: 700,
                    border: `1px solid ${domainColor}40`,
                    borderRadius: 1,
                  }}
                />
              </Box>

              <Typography
                variant="h6"
                fontWeight={700}
                sx={{
                  lineHeight: 1.5,
                  mb: 3,
                  color:
                    "#1A1D23",
                }}
              >
                {
                  question.question
                }
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
                sx={{
                  mb: 2,
                }}
              >
                Select the maturity level
                that best represents your
                organisation&apos;s current
                capability:
              </Typography>

              <Box
                role="radiogroup"
              >
                {(
                  question.options ??
                  []
                ).map(
                  (
                    option
                  ) => (
                    <LevelCard
                      key={
                        option.level
                      }
                      option={
                        option
                      }
                      selected={
                        selectedLevel ===
                        option.level
                      }
                      onSelect={() =>
                        handleSelect(
                          option.level
                        )
                      }
                      hideLevelBadge={isCustomer}
                    />
                  )
                )}
              </Box>

              {!isCustomer && (
                <Box
                  sx={{
                    mt: 3,
                  }}
                >
                  <TextField
                    fullWidth
                    multiline
                    rows={2}
                    size="small"
                    label="Supporting evidence or notes (optional)"
                    placeholder="Describe any relevant context, evidence, or exceptions…"
                    value={
                      notes[
                        question.id
                      ] ?? ""
                    }
                    onChange={(
                      event
                    ) =>
                      handleNotesChange(
                        event.target
                          .value
                      )
                    }
                    sx={{
                      "& .MuiOutlinedInput-root":
                        {
                          borderRadius: 2,
                        },
                    }}
                  />
                </Box>
              )}
            </CardContent>
          </Card>

          {/* NAVIGATION */}

          <Box
            sx={{
              display:
                "flex",
              justifyContent:
                "space-between",
              alignItems:
                "center",
              gap: 1,
              flexWrap:
                "wrap",
            }}
          >
            <Button
              variant="outlined"
              startIcon={
                <ArrowBack />
              }
              onClick={
                handleBack
              }
              disabled={
                currentIdx ===
                0
              }
            >
              Previous
            </Button>

            <Button
              variant="text"
              startIcon={
                <Save />
              }
              size="small"
              sx={{
                color:
                  "text.secondary",
              }}
              onClick={
                handleSaveAndExit
              }
              disabled={
                saving
              }
            >
              Save & Exit
            </Button>

            <Button
              variant="contained"
              endIcon={
                <ArrowForward />
              }
              onClick={
                handleNext
              }
              disabled={
                selectedLevel ==
                  null ||
                saving
              }
              sx={{
                minWidth: 160,
              }}
            >
              {currentIdx ===
              total - 1
                ? isCustomer
                  ? "Submit the Assessment"
                  : "View Results"
                : "Next Question"}
            </Button>
          </Box>
        </Box>

        {/* RIGHT PROGRESS PANEL */}

        <Box
          sx={{
            flexShrink: 0,
            width: 260,

            "@media (max-width: 900px)":
              {
                width:
                  "100%",
              },
          }}
        >
          <Card
            elevation={0}
            sx={{
              border:
                "1px solid #E0E4EC",
              borderRadius: 3,
              position:
                "sticky",
              top: 80,
            }}
          >
            <CardContent
              sx={{
                p: 2.5,
              }}
            >
              <Typography
                variant="subtitle2"
                fontWeight={700}
                sx={{
                  mb: 2,
                }}
              >
                Your Progress
              </Typography>

              {/* COMPLETION RING */}

              <Box
                sx={{
                  display:
                    "flex",
                  justifyContent:
                    "center",
                  mb: 2.5,
                }}
              >
                <Box
                  sx={{
                    position:
                      "relative",
                    width: 90,
                    height: 90,
                  }}
                >
                  <svg
                    width="90"
                    height="90"
                    style={{
                      transform:
                        "rotate(-90deg)",
                    }}
                  >
                    <circle
                      cx="45"
                      cy="45"
                      r="38"
                      fill="none"
                      stroke="#E8ECF4"
                      strokeWidth="8"
                    />

                    <circle
                      cx="45"
                      cy="45"
                      r="38"
                      fill="none"
                      stroke="#4DD4AC"
                      strokeWidth="8"
                      strokeDasharray={`${
                        2 *
                        Math.PI *
                        38
                      }`}
                      strokeDashoffset={`${
                        2 *
                        Math.PI *
                        38 *
                        (1 -
                          answeredCount /
                            total)
                      }`}
                      strokeLinecap="round"
                      style={{
                        transition:
                          "stroke-dashoffset 0.4s ease",
                      }}
                    />
                  </svg>

                  <Box
                    sx={{
                      position:
                        "absolute",
                      inset: 0,
                      display:
                        "flex",
                      flexDirection:
                        "column",
                      alignItems:
                        "center",
                      justifyContent:
                        "center",
                    }}
                  >
                    <Typography
                      variant="h5"
                      fontWeight={800}
                      color="primary.main"
                    >
                      {Math.round(
                        (
                          answeredCount /
                          total
                        ) *
                          100
                      )}
                      %
                    </Typography>

                    <Typography
                      variant="caption"
                      color="text.secondary"
                      sx={{
                        lineHeight:
                          1,
                      }}
                    >
                      done
                    </Typography>
                  </Box>
                </Box>
              </Box>

              {/* DOMAIN PROGRESS */}

              {Object.entries(
                domainProgress
              ).map(
                ([
                  domain,
                  domainData,
                ]) => (
                  <Box
                    key={
                      domain
                    }
                    sx={{
                      mb: 1.5,
                    }}
                  >
                    <Box
                      sx={{
                        display:
                          "flex",
                        justifyContent:
                          "space-between",
                        mb: 0.3,
                      }}
                    >
                      <Typography
                        variant="caption"
                        fontWeight={600}
                        sx={{
                          color:
                            DOMAIN_COLORS[
                              domain as AssessmentDomain
                            ] ??
                            "text.primary",
                        }}
                      >
                        {
                          domain
                        }
                      </Typography>

                      <Typography
                        variant="caption"
                        color="text.secondary"
                      >
                        {
                          domainData.done
                        }
                        /
                        {
                          domainData.total
                        }
                      </Typography>
                    </Box>

                    <LinearProgress
                      variant="determinate"
                      value={
                        domainData.total >
                        0
                          ? (
                              domainData.done /
                              domainData.total
                            ) *
                            100
                          : 0
                      }
                      sx={{
                        height: 4,
                        borderRadius: 2,
                        bgcolor:
                          "#E8ECF4",

                        "& .MuiLinearProgress-bar":
                          {
                            bgcolor:
                              DOMAIN_COLORS[
                                domain as AssessmentDomain
                              ] ??
                              "primary.main",
                          },
                      }}
                    />
                  </Box>
                )
              )}

              {/* CURRENT SELECTION */}

              {!isCustomer &&
                selectedLevel !=
                null && (
                <Box
                  sx={{
                    mt: 2,
                    pt: 2,
                    borderTop:
                      "1px solid",
                    borderColor:
                      "divider",
                  }}
                >
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    fontWeight={600}
                  >
                    Current selection
                  </Typography>

                  <Box
                    sx={{
                      mt: 0.5,
                      px: 1.5,
                      py: 1,
                      borderRadius:
                        1.5,

                      bgcolor:
                        LEVEL_STYLE[
                          selectedLevel
                        ]?.bg ??
                        "#F5F5F5",

                      border: `1px solid ${
                        LEVEL_STYLE[
                          selectedLevel
                        ]?.border ??
                        "#E0E0E0"
                      }40`,
                    }}
                  >
                    <Typography
                      variant="caption"
                      fontWeight={700}
                      sx={{
                        color:
                          LEVEL_STYLE[
                            selectedLevel
                          ]?.text ??
                          "text.primary",
                      }}
                    >
                      Level{" "}
                      {
                        selectedLevel
                      }{" "}
                      selected
                    </Typography>
                  </Box>
                </Box>
              )}
            </CardContent>
          </Card>
        </Box>
      </Box>

      <Dialog
        open={!!pendingResultsNav}
        maxWidth="xs"
        fullWidth
      >
        <DialogContent
          sx={{
            textAlign: "center",
            py: 5,
          }}
        >
          <CheckCircle
            sx={{
              fontSize: 56,
              color: "success.main",
              mb: 2,
            }}
          />

          <Typography
            variant="h6"
            fontWeight={700}
            sx={{ mb: 1 }}
          >
            Assessment submitted successfully
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
          >
            Thank you for completing the D365 QA Maturity Assessment.
          </Typography>
        </DialogContent>

        <DialogActions
          sx={{ justifyContent: "center", pb: 3 }}
        >
          <Button
            variant="contained"
            onClick={() => {
              if (pendingResultsNav) {
                navigate(
                  pendingResultsNav.path,
                  { state: pendingResultsNav.state }
                );
              }
            }}
          >
            Continue
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}