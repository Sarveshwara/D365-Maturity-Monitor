import { useState } from "react";
import { useNavigate, useLocation } from "react-router";

import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  TextField,
  MenuItem,
  Divider,
} from "@mui/material";

import {
  ArrowBack,
  ArrowForward,
  Business,
} from "@mui/icons-material";

export interface AssessmentCustomerInfoData {
  firstName: string;
  lastName: string;
  email: string;
  companyName: string;
  jobTitle: string;
  industry: string;
  country: string;
  d365Products: string;
  organizationSize: string;
  projectStage: string;
}

const emptyCustomerInfo: AssessmentCustomerInfoData = {
  firstName: "",
  lastName: "",
  email: "",
  companyName: "",
  jobTitle: "",
  industry: "",
  country: "",
  d365Products: "",
  organizationSize: "",
  projectStage: "",
};

export default function AssessmentCustomerInfo() {
  const navigate = useNavigate();
  const location = useLocation();

  const state = (location.state as any) || {};

  const [customerInfo, setCustomerInfo] =
    useState<AssessmentCustomerInfoData>(
      state.customerInfo || emptyCustomerInfo
    );

  const handleChange =
    (field: keyof AssessmentCustomerInfoData) =>
    (
      event: React.ChangeEvent<
        HTMLInputElement | HTMLTextAreaElement
      >
    ) => {
      setCustomerInfo((previous) => ({
        ...previous,
        [field]: event.target.value,
      }));
    };

const handleContinue = () => {
  navigate("/assessment/domain-selection", {
    state: {
      ...location.state,
      customerInfo,
    },
  });
};

  const handleBack = () => {
    navigate("/assessment");
  };

  return (
    <Box
      sx={{
        maxWidth: 900,
        mx: "auto",
      }}
    >
      <Box sx={{ mb: 3 }}>
        <Typography
          variant="h4"
          fontWeight={700}
          color="primary.main"
        >
          Assessment Information
        </Typography>

        <Typography
          variant="body1"
          color="text.secondary"
          sx={{ mt: 1 }}
        >
          Tell us a little about the organisation and the person
          completing this assessment. This information will be
          included in the assessment report.
        </Typography>
      </Box>

      <Card
        elevation={0}
        sx={{
          border: "1px solid #E0E4EC",
          borderRadius: 3,
        }}
      >
        <CardContent sx={{ p: 4 }}>
          {/* CONTACT INFORMATION */}

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1,
              mb: 1,
            }}
          >
            <Business color="primary" />

            <Typography
              variant="h6"
              fontWeight={700}
            >
              Contact Information
            </Typography>
          </Box>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ mb: 3 }}
          >
            Details of the person completing the assessment.
          </Typography>

          <Grid container spacing={2.5}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                required
                label="First Name"
                value={customerInfo.firstName}
                onChange={handleChange("firstName")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                required
                label="Last Name"
                value={customerInfo.lastName}
                onChange={handleChange("lastName")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                required
                type="email"
                label="Business Email"
                value={customerInfo.email}
                onChange={handleChange("email")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Job Title / Role"
                value={customerInfo.jobTitle}
                onChange={handleChange("jobTitle")}
              />
            </Grid>
          </Grid>

          <Divider sx={{ my: 4 }} />

          {/* ORGANISATION INFORMATION */}

          <Typography
            variant="h6"
            fontWeight={700}
            sx={{ mb: 1 }}
          >
            Organisation Information
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ mb: 3 }}
          >
            This helps provide context for your maturity assessment.
          </Typography>

          <Grid container spacing={2.5}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                required
                label="Company Name"
                value={customerInfo.companyName}
                onChange={handleChange("companyName")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Industry"
                value={customerInfo.industry}
                onChange={handleChange("industry")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                select
                fullWidth
                label="Organisation Size"
                value={customerInfo.organizationSize}
                onChange={handleChange("organizationSize")}
              >
                <MenuItem value="">
                  Select organisation size
                </MenuItem>

                <MenuItem value="1-50">
                  1–50 employees
                </MenuItem>

                <MenuItem value="51-250">
                  51–250 employees
                </MenuItem>

                <MenuItem value="251-1000">
                  251–1,000 employees
                </MenuItem>

                <MenuItem value="1001-5000">
                  1,001–5,000 employees
                </MenuItem>

                <MenuItem value="5000+">
                  5,000+ employees
                </MenuItem>
              </TextField>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Country / Region"
                value={customerInfo.country}
                onChange={handleChange("country")}
              />
            </Grid>
          </Grid>

          <Divider sx={{ my: 4 }} />

          {/* D365 CONTEXT */}

          <Typography
            variant="h6"
            fontWeight={700}
            sx={{ mb: 1 }}
          >
            Dynamics 365 Context
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ mb: 3 }}
          >
            Provide some context about your Dynamics 365 landscape.
          </Typography>

          <Grid container spacing={2.5}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="D365 Products / Applications"
                placeholder="For example: Finance, Supply Chain, CE"
                value={customerInfo.d365Products}
                onChange={handleChange("d365Products")}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                select
                fullWidth
                label="Current Project Stage"
                value={customerInfo.projectStage}
                onChange={handleChange("projectStage")}
              >
                <MenuItem value="">
                  Select project stage
                </MenuItem>

                <MenuItem value="Planning">
                  Planning
                </MenuItem>

                <MenuItem value="Implementation">
                  Implementation
                </MenuItem>

                <MenuItem value="Testing">
                  Testing
                </MenuItem>

                <MenuItem value="Go-Live Preparation">
                  Go-Live Preparation
                </MenuItem>

                <MenuItem value="Post Go-Live">
                  Post Go-Live
                </MenuItem>

                <MenuItem value="Operational">
                  Operational / BAU
                </MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* NAVIGATION */}

      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          mt: 3,
        }}
      >
        <Button
          variant="outlined"
          startIcon={<ArrowBack />}
          onClick={handleBack}
        >
          Back
        </Button>

        <Button
          variant="contained"
          endIcon={<ArrowForward />}
          onClick={handleContinue}
          disabled={
            !customerInfo.firstName ||
            !customerInfo.lastName ||
            !customerInfo.email ||
            !customerInfo.companyName
          }
        >
          Continue to Assessment Setup
        </Button>
      </Box>
    </Box>
  );
}