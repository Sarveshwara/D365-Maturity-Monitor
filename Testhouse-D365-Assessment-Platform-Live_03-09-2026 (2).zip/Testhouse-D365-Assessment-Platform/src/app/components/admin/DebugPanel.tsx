import { useState } from "react";
import { useLocation } from "react-router";
import {
  Box, Typography, Card, CardContent, Chip, Divider,
  Collapse, IconButton, Tooltip,
} from "@mui/material";
import { BugReport, ExpandMore, ExpandLess, CheckCircle, Cancel } from "@mui/icons-material";
import { useAuth } from "../../contexts/AuthContext";
import { usePackage } from "../../contexts/PackageContext";
import { PACKAGE_ROUTE_MAP } from "../../contexts/PackageContext";

export default function DebugPanel() {
  const [open, setOpen] = useState(true);
  const location = useLocation();
  const { user, profile, role, isSuperAdmin: authAdmin } = useAuth();
  const {
    orgId, orgName, subscribedPackages, accessibleRoutes,
    isLoading, isSuperAdmin: pkgAdmin, overrideOrgId,
  } = usePackage();

  const allAssessmentRoutes = Object.values(PACKAGE_ROUTE_MAP).flat();
  const uniqueRoutes = [...new Set(allAssessmentRoutes)];

  return (
    <Card elevation={0} sx={{
      border: "2px solid #FFB900", bgcolor: "#FFFBF0",
      mb: 3, borderRadius: 2,
    }}>
      <Box
        sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", px: 2, py: 1.2, cursor: "pointer" }}
        onClick={() => setOpen((p) => !p)}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <BugReport sx={{ fontSize: 18, color: "#B8860B" }} />
          <Typography variant="subtitle2" fontWeight={700} sx={{ color: "#B8860B" }}>
            Authorization Debug Panel
          </Typography>
          <Chip label="TEMP" size="small" sx={{ bgcolor: "#FFB90030", color: "#B8860B", fontWeight: 800, fontSize: "0.6rem", height: 16 }} />
        </Box>
        <IconButton size="small">{open ? <ExpandLess fontSize="small" /> : <ExpandMore fontSize="small" />}</IconButton>
      </Box>

      <Collapse in={open}>
        <Divider />
        <CardContent sx={{ p: 2 }}>
          <Box sx={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 2 }}>

            {/* User info */}
            <Box>
              <Typography variant="caption" fontWeight={800} color="text.secondary" sx={{ textTransform: "uppercase", letterSpacing: 0.5 }}>
                Authenticated User
              </Typography>
              <Box sx={{ mt: 0.5 }}>
                <Row label="Auth UID"      value={user?.id ? user.id.slice(0, 16) + "…" : "—"} />
                <Row label="Email"         value={user?.email ?? "—"} />
                <Row label="Role"          value={role} highlight />
                <Row label="Auth is Super" value={authAdmin ? "YES" : "NO"} color={authAdmin ? "#107C10" : "#999"} />
              </Box>
            </Box>

            {/* Package context */}
            <Box>
              <Typography variant="caption" fontWeight={800} color="text.secondary" sx={{ textTransform: "uppercase", letterSpacing: 0.5 }}>
                PackageContext
              </Typography>
              <Box sx={{ mt: 0.5 }}>
                <Row label="Org ID"        value={orgId ? orgId.slice(0, 16) + "…" : "NOT SET"} color={orgId ? undefined : "#D83B01"} />
                <Row label="Org Name"      value={orgName ?? "—"} />
                <Row label="Override Org"  value={overrideOrgId ? overrideOrgId.slice(0, 12) + "…" : "none"} />
                <Row label="Pkg isSuperAdmin" value={pkgAdmin ? "YES" : "NO"} color={pkgAdmin ? "#107C10" : "#999"} />
                <Row label="isLoading"     value={isLoading ? "YES" : "NO"} color={isLoading ? "#E65C00" : "#107C10"} />
              </Box>
            </Box>

            {/* Subscribed packages */}
            <Box>
              <Typography variant="caption" fontWeight={800} color="text.secondary" sx={{ textTransform: "uppercase", letterSpacing: 0.5 }}>
                Subscribed Packages ({subscribedPackages.length})
              </Typography>
              <Box sx={{ mt: 0.5 }}>
                {subscribedPackages.length === 0 ? (
                  <Typography variant="caption" sx={{ color: "#D83B01", fontWeight: 700 }}>
                    {isLoading ? "Loading…" : "NONE — user will see no assessments"}
                  </Typography>
                ) : (
                  subscribedPackages.map((pkg) => (
                    <Box key={pkg.package_code} sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.3 }}>
                      <CheckCircle sx={{ fontSize: 12, color: "#107C10" }} />
                      <Typography variant="caption" fontWeight={600}>{pkg.package_code}</Typography>
                      <Typography variant="caption" color="text.secondary">({pkg.package_name})</Typography>
                    </Box>
                  ))
                )}
              </Box>
            </Box>

            {/* Accessible routes */}
            <Box>
              <Typography variant="caption" fontWeight={800} color="text.secondary" sx={{ textTransform: "uppercase", letterSpacing: 0.5 }}>
                Accessible Routes
              </Typography>
              <Box sx={{ mt: 0.5 }}>
                {uniqueRoutes.map((route) => {
                  const has = accessibleRoutes.includes(route) || pkgAdmin;
                  return (
                    <Box key={route} sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 0.3 }}>
                      {has
                        ? <CheckCircle sx={{ fontSize: 12, color: "#107C10" }} />
                        : <Cancel sx={{ fontSize: 12, color: "#D83B01" }} />}
                      <Typography variant="caption" fontFamily="monospace" sx={{ color: has ? "#107C10" : "#D83B01" }}>
                        {route}
                      </Typography>
                    </Box>
                  );
                })}
              </Box>
            </Box>

          </Box>

          {/* Current route */}
          <Divider sx={{ my: 1.5 }} />
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Typography variant="caption" fontWeight={800} color="text.secondary" sx={{ textTransform: "uppercase" }}>
              Current Route:
            </Typography>
            <Typography variant="caption" fontFamily="monospace" fontWeight={700} sx={{ color: "#2B3E7E" }}>
              {location.pathname}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              — Access: {" "}
              <strong style={{ color: (pkgAdmin || accessibleRoutes.some(r => location.pathname.startsWith(r))) ? "#107C10" : "#D83B01" }}>
                {pkgAdmin ? "SUPER ADMIN (unrestricted)" : accessibleRoutes.some(r => location.pathname.startsWith(r)) ? "ALLOWED" : "DENIED"}
              </strong>
            </Typography>
          </Box>
        </CardContent>
      </Collapse>
    </Card>
  );
}

function Row({ label, value, highlight = false, color }: { label: string; value: string; highlight?: boolean; color?: string }) {
  return (
    <Box sx={{ display: "flex", gap: 1, alignItems: "baseline", mb: 0.2 }}>
      <Typography variant="caption" color="text.secondary" sx={{ minWidth: 100, flexShrink: 0 }}>{label}:</Typography>
      <Typography variant="caption" fontWeight={highlight ? 800 : 600} fontFamily="monospace"
        sx={{ color: color ?? (highlight ? "#2B3E7E" : "text.primary"), wordBreak: "break-all" }}>
        {value}
      </Typography>
    </Box>
  );
}
