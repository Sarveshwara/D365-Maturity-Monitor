import { useState } from "react";
import {
  Box, Typography, Card, CardContent, Grid, Chip, Checkbox,
  LinearProgress, Divider, Accordion, AccordionSummary, AccordionDetails,
} from "@mui/material";
import { RocketLaunch, ExpandMore, CheckCircle, RadioButtonUnchecked } from "@mui/icons-material";

interface CheckItem {
  id: string;
  label: string;
  detail?: string;
  critical: boolean;
}

interface CheckCategory {
  category: string;
  icon: string;
  items: CheckItem[];
}

const CHECKLIST: CheckCategory[] = [
  {
    category: "Database & Security",
    icon: "🔒",
    items: [
      { id: "db-01", critical: true,  label: "supabase-schema.sql has been run successfully", detail: "Tables: assessment_domains, assessment_packages, package_domains, organizations, customer_subscriptions, app_users" },
      { id: "db-02", critical: true,  label: "supabase-auth-rls.sql has been run", detail: "Profiles table, helper functions (is_super_admin, get_user_org_id), RLS on all 7 tables" },
      { id: "db-03", critical: true,  label: "supabase-sprint2-persistence.sql has been run", detail: "assessment_runs table updated with status, responses_data, notes_data, created_by columns" },
      { id: "db-04", critical: true,  label: "supabase-sprint5-audit.sql has been run", detail: "audit_logs table and vw_audit_logs view created" },
      { id: "db-05", critical: true,  label: "At least one super_admin user has been promoted", detail: "UPDATE profiles SET role = 'super_admin' WHERE id = (SELECT id FROM auth.users WHERE email = 'admin@email.com')" },
      { id: "db-06", critical: true,  label: "RLS tested — Customer A cannot access Customer B data", detail: "Log in as a customer user and verify only their org's data is visible" },
      { id: "db-07", critical: false, label: "Database backup is enabled in Supabase dashboard", detail: "Supabase Dashboard → Settings → Database → Backups" },
    ],
  },
  {
    category: "Authentication",
    icon: "🔑",
    items: [
      { id: "auth-01", critical: true,  label: "Supabase Auth email templates configured", detail: "Dashboard → Auth → Email Templates — Update sender name and confirmation URL" },
      { id: "auth-02", critical: true,  label: "Redirect URLs configured in Supabase Auth", detail: "Dashboard → Auth → URL Configuration — Add production domain to allowed redirects" },
      { id: "auth-03", critical: true,  label: "User sign-up tested end-to-end", detail: "Sign up → receive email → confirm → auto-profile created → log in" },
      { id: "auth-04", critical: true,  label: "Password reset tested end-to-end", detail: "Forgot password → receive email → click link → set new password → log in" },
      { id: "auth-05", critical: false, label: "Google OAuth configured (optional)", detail: "Dashboard → Auth → Providers → Google — add Client ID and Secret" },
      { id: "auth-06", critical: false, label: "Email rate limits reviewed", detail: "Dashboard → Auth → Rate Limits — default is 3 emails/hour per user" },
    ],
  },
  {
    category: "Edge Function",
    icon: "⚡",
    items: [
      { id: "fn-01", critical: true,  label: "Edge function deployed with latest code", detail: "All new endpoints: /profiles, /profiles/invite, /audit-logs, /stats are live" },
      { id: "fn-02", critical: true,  label: "Edge function health check passes", detail: "GET /make-server-c8ac5349/health returns { status: 'ok' }" },
      { id: "fn-03", critical: true,  label: "/packages endpoint returns package data with domains", detail: "Assessment Marketplace screen loads packages and domains" },
      { id: "fn-04", critical: true,  label: "/organizations endpoint returns org list", detail: "Customer Management screen loads organisations" },
      { id: "fn-05", critical: false, label: "CORS configured for production domain", detail: "Edge function currently allows all origins (*) — restrict in production if required" },
    ],
  },
  {
    category: "Seed Data",
    icon: "🌱",
    items: [
      { id: "seed-01", critical: true,  label: "5 assessment packages seeded", detail: "QA_FULL, PERF, SEC, AUTO, DEVOPS — visible in Assessment Marketplace" },
      { id: "seed-02", critical: true,  label: "5 assessment domains seeded", detail: "QA_MATURITY, PERFORMANCE, SECURITY, DEVOPS, BENCHMARKING" },
      { id: "seed-03", critical: true,  label: "Package-domain mappings seeded", detail: "package_domains table populated correctly" },
      { id: "seed-04", critical: false, label: "Demo organisations seeded (or replaced with real ones)", detail: "ACME, TECHSTART, GLBANK, RETAIL — replace with real pilot customers" },
    ],
  },
  {
    category: "Deployment",
    icon: "🚀",
    items: [
      { id: "dep-01", critical: true,  label: "vercel.json present in project root", detail: "SPA rewrites, security headers, asset caching configured" },
      { id: "dep-02", critical: true,  label: "VITE_SUPABASE_URL set in Vercel environment variables", detail: "Project Settings → Environment Variables → Production" },
      { id: "dep-03", critical: true,  label: "VITE_SUPABASE_ANON_KEY set in Vercel environment variables", detail: "Use the public anon key (safe for frontend)" },
      { id: "dep-04", critical: true,  label: "VITE_API_BASE_URL set in Vercel environment variables", detail: "Points to the deployed edge function URL" },
      { id: "dep-05", critical: true,  label: "Custom domain configured and SSL verified", detail: "Vercel Project → Domains — add and verify your domain" },
      { id: "dep-06", critical: false, label: "VITE_APP_URL set to production domain", detail: "Used for OAuth redirect URLs and email links" },
    ],
  },
  {
    category: "UAT Sign-Off",
    icon: "✅",
    items: [
      { id: "uat-01", critical: true,  label: "All Critical test cases passed", detail: "AUTH-01 through SEC-02 — no critical failures" },
      { id: "uat-02", critical: true,  label: "All High priority test cases passed or documented", detail: "Any High failures must have a documented workaround" },
      { id: "uat-03", critical: true,  label: "Pilot customer user account created and tested", detail: "Real customer can log in, see their package, complete assessment" },
      { id: "uat-04", critical: false, label: "Medium priority test cases reviewed", detail: "Known issues documented in UAT sign-off notes" },
      { id: "uat-05", critical: false, label: "Performance tested at expected user load", detail: "Verify response times are acceptable for pilot customer" },
    ],
  },
  {
    category: "Go-Live Operations",
    icon: "📋",
    items: [
      { id: "ops-01", critical: true,  label: "Support contact established for pilot customer", detail: "Email address or Slack channel for pilot customer to raise issues" },
      { id: "ops-02", critical: true,  label: "Admin monitoring dashboard verified", detail: "/admin/monitoring loads with real data" },
      { id: "ops-03", critical: false, label: "Audit log baseline established", detail: "Zero or low event count before go-live — confirms clean state" },
      { id: "ops-04", critical: false, label: "Rollback plan documented", detail: "Know how to disable access if a critical issue is found post-launch" },
      { id: "ops-05", critical: false, label: "Privacy Policy and Terms reviewed by legal", detail: "Ensure legal team has reviewed /privacy and /terms content" },
    ],
  },
];

export default function GoLiveChecklist() {
  const allItems = CHECKLIST.flatMap((c) => c.items);
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  const toggle = (id: string) => setChecked((p) => ({ ...p, [id]: !p[id] }));

  const totalItems    = allItems.length;
  const checkedCount  = Object.values(checked).filter(Boolean).length;
  const criticalItems = allItems.filter((i) => i.critical);
  const criticalDone  = criticalItems.filter((i) => checked[i.id]).length;
  const allCritical   = criticalDone === criticalItems.length;
  const pct           = Math.round((checkedCount / totalItems) * 100);
  const goLiveReady   = allCritical && pct >= 80;

  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 3 }}>
        <RocketLaunch sx={{ fontSize: 28, color: "primary.main" }} />
        <Box>
          <Typography variant="h5" fontWeight={700}>Go-Live Checklist</Typography>
          <Typography variant="body2" color="text.secondary">
            Complete all critical items before launching to pilot customers
          </Typography>
        </Box>
      </Box>

      {/* Summary */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", textAlign: "center", py: 2 }}>
            <Typography variant="h3" fontWeight={800} color="primary.main">{pct}%</Typography>
            <Typography variant="caption" color="text.secondary">Overall Completion</Typography>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card elevation={0} sx={{ border: `1px solid ${allCritical ? "#107C1040" : "#D83B0140"}`,
            bgcolor: allCritical ? "#E8FBF5" : "#FFF0EE", textAlign: "center", py: 2 }}>
            <Typography variant="h3" fontWeight={800} sx={{ color: allCritical ? "#107C10" : "#D83B01" }}>
              {criticalDone}/{criticalItems.length}
            </Typography>
            <Typography variant="caption" sx={{ color: allCritical ? "#107C10" : "#D83B01", fontWeight: 600 }}>
              Critical Items Done
            </Typography>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card elevation={0} sx={{ border: `1px solid ${goLiveReady ? "#107C1040" : "#E0E4EC"}`,
            bgcolor: goLiveReady ? "#E8FBF5" : "#F5F5F5", textAlign: "center", py: 2 }}>
            <Typography variant="h5" fontWeight={800} sx={{ color: goLiveReady ? "#107C10" : "#999", mt: 0.5 }}>
              {goLiveReady ? "✓ GO LIVE" : "NOT READY"}
            </Typography>
            <Typography variant="caption" color="text.secondary">Go-Live Status</Typography>
          </Card>
        </Grid>
      </Grid>

      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent sx={{ p: 2 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.5 }}>
            <Typography variant="caption" fontWeight={700}>Checklist Progress</Typography>
            <Typography variant="caption" fontWeight={700}>{checkedCount} / {totalItems}</Typography>
          </Box>
          <LinearProgress variant="determinate" value={pct}
            sx={{ height: 8, borderRadius: 4, bgcolor: "#E8ECF4",
              "& .MuiLinearProgress-bar": { bgcolor: goLiveReady ? "#107C10" : "#2B3E7E", borderRadius: 4 } }} />
        </CardContent>
      </Card>

      {CHECKLIST.map((cat) => {
        const catDone = cat.items.filter((i) => checked[i.id]).length;
        return (
          <Accordion key={cat.category} elevation={0} defaultExpanded
            sx={{ border: "1px solid #E0E4EC", mb: 1.5, borderRadius: "8px !important", "&:before": { display: "none" } }}>
            <AccordionSummary expandIcon={<ExpandMore />} sx={{ px: 2.5 }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 2, flex: 1 }}>
                <Typography sx={{ fontSize: "1.2rem" }}>{cat.icon}</Typography>
                <Typography variant="subtitle2" fontWeight={700}>{cat.category}</Typography>
                <Chip label={`${catDone}/${cat.items.length}`} size="small"
                  sx={{ bgcolor: catDone === cat.items.length ? "#E8FBF5" : "#F5F5F5",
                    color: catDone === cat.items.length ? "#107C10" : "#666",
                    fontWeight: 700, fontSize: "0.65rem" }} />
              </Box>
            </AccordionSummary>
            <AccordionDetails sx={{ px: 2.5, pt: 0 }}>
              {cat.items.map((item, i) => (
                <Box key={item.id}>
                  <Box
  key={item.id}
  onClick={() => toggle(item.id)}
  sx={{
    cursor: "pointer",
    py: 1.5,
    px: 1,
    display: "flex",
    alignItems: "flex-start",
    gap: 1.5,
    borderRadius: 1,
    "&:hover": {
      bgcolor: "#F7F9FF",
    },
  }}
>
                    <Checkbox
                      checked={!!checked[item.id]}
                      onChange={() => toggle(item.id)}
                      icon={<RadioButtonUnchecked sx={{ color: "#E0E4EC" }} />}
                      checkedIcon={<CheckCircle sx={{ color: "#107C10" }} />}
                      sx={{ p: 0, mt: 0.2 }}
                    />
                    <Box sx={{ flex: 1 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <Typography variant="body2" fontWeight={600}
                          sx={{ textDecoration: checked[item.id] ? "line-through" : "none",
                            color: checked[item.id] ? "text.disabled" : "text.primary" }}>
                          {item.label}
                        </Typography>
                        {item.critical && (
                          <Chip label="Critical" size="small"
                            sx={{ bgcolor: "#D83B0118", color: "#D83B01", fontWeight: 700, fontSize: "0.6rem", height: 18 }} />
                        )}
                      </Box>
                      {item.detail && (
                        <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 0.3 }}>
                          {item.detail}
                        </Typography>
                      )}
                    </Box>
                  </Box>
                  {i < cat.items.length - 1 && <Divider />}
                </Box>
              ))}
            </AccordionDetails>
          </Accordion>
        );
      })}
    </Box>
  );
}
