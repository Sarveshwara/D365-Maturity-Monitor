import { useEffect, useState } from "react";
import { useNavigate } from "react-router";

import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Button,
  CircularProgress,
  Alert,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TableContainer,
  Paper,
} from "@mui/material";

import { OpenInNew } from "@mui/icons-material";

import {
  assessmentService,
  type AssessmentRun,
} from "../../lib/assessment-service";

function statusChip(status: AssessmentRun["status"]) {
  switch (status) {
    case "completed":
      return <Chip label="Completed" size="small" color="success" />;
    case "in_progress":
      return <Chip label="In Progress" size="small" color="warning" />;
    default:
      return <Chip label="Draft" size="small" />;
  }
}

export default function AssessmentSubmissions() {
  const navigate = useNavigate();

  const [runs, setRuns] = useState<AssessmentRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { runs: data, error: err } = await assessmentService.listAllForAdmin();

      if (!mounted) return;

      setRuns(data);
      setError(err);
      setLoading(false);
    })();

    return () => {
      mounted = false;
    };
  }, []);

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700} color="primary.main">
          Assessment Submissions
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
          Every D365 QA Maturity Assessment run, with the contact and
          company info captured for each one.
        </Typography>
      </Box>

      {loading && (
        <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
          <CircularProgress />
        </Box>
      )}

      {!loading && error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {!loading && !error && (
        <Card elevation={0} sx={{ border: "1px solid #E0E4EC", borderRadius: 3 }}>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Company</TableCell>
                  <TableCell>Contact</TableCell>
                  <TableCell>Account Email</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Score</TableCell>
                  <TableCell>Date</TableCell>
                  <TableCell align="right">&nbsp;</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {runs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7}>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ py: 3, textAlign: "center" }}
                      >
                        No assessment submissions yet.
                      </Typography>
                    </TableCell>
                  </TableRow>
                )}

                {runs.map((run) => {
                  const customerInfo = run.assessment_context?.customerInfo;
                  const contactName = [
                    customerInfo?.firstName,
                    customerInfo?.lastName,
                  ]
                    .filter(Boolean)
                    .join(" ");

                  return (
                    <TableRow key={run.id} hover>
                      <TableCell>{customerInfo?.companyName ?? "—"}</TableCell>
                      <TableCell>{contactName || "—"}</TableCell>
                      <TableCell>
                        {customerInfo?.email ??
                          (run as any).created_by_email ??
                          "—"}
                      </TableCell>
                      <TableCell>{statusChip(run.status)}</TableCell>
                      <TableCell>
                        {run.overall_score != null
                          ? `${Number(run.overall_score).toFixed(1)} / 5.0`
                          : "—"}
                      </TableCell>
                      <TableCell>
                        {new Date(
                          run.completed_at ?? run.run_date
                        ).toLocaleDateString()}
                      </TableCell>
                      <TableCell align="right">
                        <Button
                          size="small"
                          endIcon={<OpenInNew fontSize="small" />}
                          disabled={run.status !== "completed"}
                          onClick={() =>
                            navigate(`/assessment/results/${run.id}`)
                          }
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Card>
      )}
    </Box>
  );
}
