import { useEffect, useState } from "react";
import {
  Box, Typography, Card, CardContent, Chip, CircularProgress, Alert,
  IconButton, Tooltip, Table, TableHead, TableRow, TableCell, TableBody,
  Select, MenuItem, FormControl, InputLabel, Button, TextField,
} from "@mui/material";
import { History, Refresh, FilterList, Search, ArrowBack, ArrowForward } from "@mui/icons-material";
import { getAuditLogs, getOrganizations } from "../../lib/api";
import { getEventLabel, getEventColor } from "../../lib/audit-service";

const EVENT_TYPES = [
  "user.login", "user.logout",
  "assessment.started", "assessment.completed", "assessment.exported", "assessment.resumed",
  "user.invited", "user.role_changed", "user.deactivated", "user.reactivated",
  "package.assigned", "package.removed", "org.created", "org.updated",
];

const PAGE_SIZE = 25;

export default function AuditLogViewer() {
  const [logs, setLogs] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [orgs, setOrgs] = useState<any[]>([]);

  // Filters
  const [filterType, setFilterType] = useState("");
  const [filterOrg, setFilterOrg] = useState("");
  const [search, setSearch] = useState("");

  const load = async (pg = page) => {
    setLoading(true);
    setError(null);
    try {
      const [logData, orgData] = await Promise.all([
        getAuditLogs({
          limit: PAGE_SIZE,
          offset: pg * PAGE_SIZE,
          event_type: filterType || undefined,
          org_id: filterOrg || undefined,
        }),
        getOrganizations(),
      ]);
      setLogs(logData.data ?? []);
      setTotal(logData.count ?? 0);
      setOrgs(orgData ?? []);
    } catch (e: any) {
      setError(e.message + " — deploy the edge function from Make settings.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(0); setPage(0); }, [filterType, filterOrg]);
  useEffect(() => { load(page); }, [page]);

  const filtered = search
    ? logs.filter((l) =>
        (l.user_name ?? "").toLowerCase().includes(search.toLowerCase()) ||
        (l.org_name  ?? "").toLowerCase().includes(search.toLowerCase()) ||
        (l.event_type ?? "").includes(search.toLowerCase())
      )
    : logs;

  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <History sx={{ fontSize: 28, color: "primary.main" }} />
          <Box>
            <Typography variant="h5" fontWeight={700}>Audit Log</Typography>
            <Typography variant="body2" color="text.secondary">
              Complete history of platform events and user actions
            </Typography>
          </Box>
        </Box>
        <Tooltip title="Refresh">
          <IconButton onClick={() => load(page)} disabled={loading}><Refresh /></IconButton>
        </Tooltip>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      {/* Filters */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 2 }}>
        <CardContent sx={{ py: 1.5, px: 2, "&:last-child": { pb: 1.5 } }}>
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap", alignItems: "center" }}>
            <FilterList sx={{ color: "text.secondary", fontSize: 20 }} />
            <TextField
              size="small" placeholder="Search user, org, event…"
              value={search} onChange={(e) => setSearch(e.target.value)}
              InputProps={{ startAdornment: <Search sx={{ fontSize: 16, color: "text.disabled", mr: 0.5 }} /> }}
              sx={{ minWidth: 220 }}
            />
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>Event Type</InputLabel>
              <Select value={filterType} label="Event Type"
                onChange={(e) => setFilterType(e.target.value)}>
                <MenuItem value="">All Events</MenuItem>
                {EVENT_TYPES.map((t) => (
                  <MenuItem key={t} value={t}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: getEventColor(t), flexShrink: 0 }} />
                      {getEventLabel(t)}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 180 }}>
              <InputLabel>Organisation</InputLabel>
              <Select value={filterOrg} label="Organisation"
                onChange={(e) => setFilterOrg(e.target.value)}>
                <MenuItem value="">All Organisations</MenuItem>
                {orgs.map((o: any) => <MenuItem key={o.id} value={o.id}>{o.name}</MenuItem>)}
              </Select>
            </FormControl>
            {(filterType || filterOrg || search) && (
              <Button size="small" onClick={() => { setFilterType(""); setFilterOrg(""); setSearch(""); }}>
                Clear filters
              </Button>
            )}
            <Typography variant="caption" color="text.secondary" sx={{ ml: "auto" }}>
              {total} total events
            </Typography>
          </Box>
        </CardContent>
      </Card>

      {/* Log table */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC" }}>
        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}><CircularProgress /></Box>
        ) : filtered.length === 0 ? (
          <Box sx={{ textAlign: "center", py: 6 }}>
            <History sx={{ fontSize: 40, color: "text.disabled", mb: 1 }} />
            <Typography variant="body2" color="text.secondary">No audit events found</Typography>
          </Box>
        ) : (
          <Table size="small">
            <TableHead>
              <TableRow sx={{ bgcolor: "#F7F9FF" }}>
                {["Timestamp", "Event", "User", "Organisation", "Details"].map((h) => (
                  <TableCell key={h} sx={{ fontWeight: 700, fontSize: "0.75rem", color: "text.secondary" }}>
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {filtered.map((log) => {
                const color = getEventColor(log.event_type);
                const meta = log.metadata ?? {};
                return (
                  <TableRow key={log.id} sx={{ "&:hover": { bgcolor: "#F7F9FF" } }}>
                    <TableCell sx={{ whiteSpace: "nowrap" }}>
                      <Typography variant="caption" fontWeight={600}>
                        {new Date(log.created_at).toLocaleDateString([], { month: "short", day: "numeric" })}
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>
                        {new Date(log.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: color, flexShrink: 0 }} />
                        <Chip label={getEventLabel(log.event_type)} size="small"
                          sx={{ bgcolor: `${color}18`, color, fontWeight: 700, fontSize: "0.65rem" }} />
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{log.user_name ?? "System"}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {log.user_id?.slice(0, 8)}…
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{log.org_name ?? "—"}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption" color="text.secondary" sx={{ fontFamily: "monospace", fontSize: "0.7rem" }}>
                        {Object.keys(meta).length > 0
                          ? Object.entries(meta).map(([k, v]) => `${k}: ${v}`).join(" · ")
                          : "—"}
                      </Typography>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <Box sx={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 1, p: 1.5, borderTop: "1px solid #E0E4EC" }}>
            <Typography variant="caption" color="text.secondary">
              Page {page + 1} of {totalPages}
            </Typography>
            <IconButton size="small" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
              <ArrowBack fontSize="small" />
            </IconButton>
            <IconButton size="small" disabled={page >= totalPages - 1} onClick={() => setPage((p) => p + 1)}>
              <ArrowForward fontSize="small" />
            </IconButton>
          </Box>
        )}
      </Card>
    </Box>
  );
}
