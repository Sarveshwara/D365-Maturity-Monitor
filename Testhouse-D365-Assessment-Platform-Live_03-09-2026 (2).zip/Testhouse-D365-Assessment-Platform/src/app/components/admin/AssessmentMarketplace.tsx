import { useEffect, useState } from "react";
import {
  Box, Typography, Card, CardContent, Grid, Chip, Button, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, CircularProgress, Alert, Divider,
  IconButton, Tooltip,
} from "@mui/material";
import {
  Storefront, CheckCircle, PowerSettingsNew, Assessment, Speed, Shield,
  SmartToy, Cloud, Add, Refresh, Domain,
} from "@mui/icons-material";
import { getPackages, togglePackage } from "../../lib/api";

const PACKAGE_ICONS: Record<string, React.ReactNode> = {
  QA_FULL: <Assessment sx={{ fontSize: 28 }} />,
  PERF:    <Speed sx={{ fontSize: 28 }} />,
  SEC:     <Shield sx={{ fontSize: 28 }} />,
  AUTO:    <SmartToy sx={{ fontSize: 28 }} />,
  DEVOPS:  <Cloud sx={{ fontSize: 28 }} />,
};

const DEFAULT_COLORS: Record<string, string> = {
  QA_FULL: "#2B3E7E",
  PERF:    "#0F6CBD",
  SEC:     "#6B3FBE",
  AUTO:    "#107C10",
  DEVOPS:  "#038387",
};

export default function AssessmentMarketplace() {
  const [packages, setPackages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [togglingId, setTogglingId] = useState<string | null>(null);
  const [detailPkg, setDetailPkg] = useState<any | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getPackages();
      setPackages(data ?? []);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleToggle = async (pkg: any) => {
    setTogglingId(pkg.id);
    try {
      const updated = await togglePackage(pkg.id);
      setPackages((prev) => prev.map((p) => (p.id === pkg.id ? { ...p, ...updated } : p)));
    } catch (e: any) {
      setError(e.message);
    } finally {
      setTogglingId(null);
    }
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Storefront sx={{ fontSize: 28, color: "primary.main" }} />
          <Box>
            <Typography variant="h5" fontWeight={700}>Assessment Marketplace</Typography>
            <Typography variant="body2" color="text.secondary">
              Manage assessment packages and configure what customers can access
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Tooltip title="Refresh">
            <IconButton onClick={load} disabled={loading}><Refresh /></IconButton>
          </Tooltip>
          <Button variant="contained" startIcon={<Add />} size="small" disabled>
            New Package
          </Button>
        </Box>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error} — ensure the Supabase schema has been run and the edge function is deployed.
        </Alert>
      )}

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          {/* Summary strip */}
          <Box sx={{ display: "flex", gap: 2, mb: 3, flexWrap: "wrap" }}>
            {[
              { label: "Total Packages", value: packages.length, color: "#2B3E7E" },
              { label: "Active", value: packages.filter((p) => p.active).length, color: "#107C10" },
              { label: "Inactive", value: packages.filter((p) => !p.active).length, color: "#999" },
            ].map((s) => (
              <Card key={s.label} elevation={0} sx={{ border: "1px solid #E0E4EC", flex: "0 0 auto" }}>
                <CardContent sx={{ py: 1.5, px: 2.5, "&:last-child": { pb: 1.5 } }}>
                  <Typography variant="h5" fontWeight={800} sx={{ color: s.color }}>{s.value}</Typography>
                  <Typography variant="caption" color="text.secondary">{s.label}</Typography>
                </CardContent>
              </Card>
            ))}
          </Box>

          {/* Package cards */}
          <Grid container spacing={3}>
            {packages.map((pkg) => {
              const color = pkg.color ?? DEFAULT_COLORS[pkg.package_code] ?? "#2B3E7E";
              const domains: any[] = pkg.package_domains?.map((pd: any) => pd.assessment_domains).filter(Boolean) ?? [];
              const isToggling = togglingId === pkg.id;
              return (
                <Grid size={{ xs: 12, sm: 6, md: 4 }} key={pkg.id}>
                  <Card elevation={0} sx={{
                    border: `1.5px solid ${pkg.active ? color + "40" : "#E0E4EC"}`,
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    opacity: pkg.active ? 1 : 0.65,
                    transition: "all 0.2s",
                    "&:hover": { boxShadow: `0 4px 20px ${color}20` },
                  }}>
                    {/* Card header */}
                    <Box sx={{
                      p: 2.5, display: "flex", alignItems: "flex-start", gap: 2,
                      background: `linear-gradient(135deg, ${color}12 0%, ${color}06 100%)`,
                      borderBottom: `1px solid ${color}20`,
                    }}>
                      <Box sx={{
                        p: 1.2, borderRadius: 2, bgcolor: color,
                        color: "white", display: "flex", flexShrink: 0,
                      }}>
                        {PACKAGE_ICONS[pkg.package_code] ?? <Assessment sx={{ fontSize: 28 }} />}
                      </Box>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1, flexWrap: "wrap" }}>
                          <Typography variant="subtitle1" fontWeight={800} sx={{ color }}>
                            {pkg.package_name}
                          </Typography>
                          <Chip
                            label={pkg.active ? "Active" : "Inactive"}
                            size="small"
                            sx={{
                              bgcolor: pkg.active ? "#E8FBF5" : "#F5F5F5",
                              color: pkg.active ? "#107C10" : "#777",
                              fontWeight: 700, fontSize: "0.65rem",
                            }}
                          />
                        </Box>
                        <Chip
                          label={pkg.package_code}
                          size="small"
                          sx={{ bgcolor: `${color}18`, color, fontWeight: 700, fontSize: "0.65rem", mt: 0.5 }}
                        />
                      </Box>
                    </Box>

                    <CardContent sx={{ flex: 1, p: 2.5 }}>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2, lineHeight: 1.6 }}>
                        {pkg.description}
                      </Typography>

                      {/* Domains */}
                      <Box sx={{ mb: 2 }}>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, mb: 1 }}>
                          <Domain sx={{ fontSize: 14, color: "text.secondary" }} />
                          <Typography variant="caption" fontWeight={700} color="text.secondary">
                            INCLUDED ASSESSMENTS
                          </Typography>
                        </Box>
                        {domains.length > 0 ? (
                          <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                            {domains.map((d: any) => (
                              <Chip
                                key={d.domain_code}
                                label={`${d.icon ?? "📊"} ${d.domain_name}`}
                                size="small"
                                variant="outlined"
                                sx={{ fontSize: "0.65rem", borderColor: `${color}40`, color }}
                              />
                            ))}
                          </Box>
                        ) : (
                          <Typography variant="caption" color="text.secondary" fontStyle="italic">
                            No domains assigned yet
                          </Typography>
                        )}
                      </Box>
                    </CardContent>

                    <Divider />
                    <Box sx={{ p: 1.5, display: "flex", gap: 1 }}>
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => setDetailPkg(pkg)}
                        sx={{ flex: 1, borderColor: `${color}40`, color }}
                      >
                        View Details
                      </Button>
                      <Tooltip title={pkg.active ? "Deactivate" : "Activate"}>
                        <Button
                          size="small"
                          variant={pkg.active ? "outlined" : "contained"}
                          onClick={() => handleToggle(pkg)}
                          disabled={isToggling}
                          startIcon={isToggling ? <CircularProgress size={14} /> : <PowerSettingsNew />}
                          sx={pkg.active
                            ? { color: "#D83B01", borderColor: "#D83B0140" }
                            : { bgcolor: color, "&:hover": { bgcolor: color } }
                          }
                        >
                          {pkg.active ? "Deactivate" : "Activate"}
                        </Button>
                      </Tooltip>
                    </Box>
                  </Card>
                </Grid>
              );
            })}
          </Grid>

          {packages.length === 0 && !error && (
            <Box sx={{ textAlign: "center", py: 8 }}>
              <Storefront sx={{ fontSize: 48, color: "text.disabled", mb: 2 }} />
              <Typography variant="h6" color="text.secondary">No packages found</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Run the schema SQL in Supabase to seed the default packages.
              </Typography>
              <Button variant="outlined" onClick={load}>Retry</Button>
            </Box>
          )}
        </>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!detailPkg} onClose={() => setDetailPkg(null)} maxWidth="sm" fullWidth>
        {detailPkg && (
          <>
            <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
              <Box sx={{
                p: 0.8, borderRadius: 1.5,
                bgcolor: detailPkg.color ?? DEFAULT_COLORS[detailPkg.package_code] ?? "#2B3E7E",
                color: "white", display: "flex",
              }}>
                {PACKAGE_ICONS[detailPkg.package_code] ?? <Assessment sx={{ fontSize: 20 }} />}
              </Box>
              {detailPkg.package_name}
            </DialogTitle>
            <DialogContent dividers>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                {detailPkg.description}
              </Typography>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>
                Included Assessment Domains
              </Typography>
              {detailPkg.package_domains?.map((pd: any) => {
                const d = pd.assessment_domains;
                if (!d) return null;
                return (
                  <Box key={d.domain_code} sx={{
                    display: "flex", alignItems: "center", gap: 1.5, p: 1.5,
                    mb: 1, borderRadius: 1.5, bgcolor: "#F7F9FF", border: "1px solid #E8ECF4",
                  }}>
                    <Typography sx={{ fontSize: "1.2rem" }}>{d.icon}</Typography>
                    <Box>
                      <Typography variant="body2" fontWeight={700}>{d.domain_name}</Typography>
                      <Typography variant="caption" color="text.secondary">{d.route_prefix}</Typography>
                    </Box>
                  </Box>
                );
              })}
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setDetailPkg(null)}>Close</Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
}
