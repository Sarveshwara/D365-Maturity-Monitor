import { useState } from "react";
import {
  Box, Typography, Card, CardContent, Grid, Chip, Button,
  LinearProgress, Divider, Accordion, AccordionSummary,
  AccordionDetails, Table, TableHead, TableRow, TableCell,
  TableBody, TextField, Select, MenuItem, FormControl, InputLabel,
} from "@mui/material";
import {
  CheckCircle, Cancel, RadioButtonUnchecked, ExpandMore,
  Assignment, Download, Warning,
} from "@mui/icons-material";

type TestStatus = "pass" | "fail" | "blocked" | "not_tested";

interface TestCase {
  id: string;
  title: string;
  steps: string[];
  expected: string;
  priority: "Critical" | "High" | "Medium";
}

interface TestArea {
  area: string;
  cases: TestCase[];
}

const UAT_AREAS: TestArea[] = [
  {
    area: "Authentication",
    cases: [
      { id: "AUTH-01", priority: "Critical", title: "User Sign Up", steps: ["Go to /login", "Click Sign Up tab", "Enter email and password (min 6 chars)", "Click Create Account"], expected: "Account created. Email confirmation sent. User redirected on confirm." },
      { id: "AUTH-02", priority: "Critical", title: "User Login", steps: ["Go to /login", "Enter registered email and password", "Click Sign In"], expected: "User is authenticated and redirected to the dashboard." },
      { id: "AUTH-03", priority: "Critical", title: "Protected Route", steps: ["Log out", "Try to navigate to /assessment directly"], expected: "User is redirected to /login." },
      { id: "AUTH-04", priority: "High", title: "Forgot Password", steps: ["Click Forgot Password on login", "Enter email", "Click Send Reset Link"], expected: "Success message shown. Reset email received." },
      { id: "AUTH-05", priority: "High", title: "Password Reset Flow", steps: ["Click reset link in email", "Enter new password", "Click Update Password"], expected: "Password updated. User redirected to dashboard." },
      { id: "AUTH-06", priority: "High", title: "Logout", steps: ["Click avatar in top-right", "Click Logout"], expected: "Session cleared. User redirected to /login." },
    ],
  },
  {
    area: "Package Entitlements",
    cases: [
      { id: "ENT-01", priority: "Critical", title: "Customer sees only assigned assessments", steps: ["Log in as a user assigned Performance package only", "Check the sidebar navigation"], expected: "Only Performance Assessment appears. QA and Security are hidden." },
      { id: "ENT-02", priority: "Critical", title: "Super admin sees all assessments", steps: ["Log in as super_admin", "Check the sidebar navigation"], expected: "All assessment types and admin sections visible." },
      { id: "ENT-03", priority: "High", title: "Org switcher filters nav", steps: ["As super_admin, use org switcher to select TechStart Ltd", "Check sidebar"], expected: "Only Performance Assessment visible (TechStart has PERF package)." },
      { id: "ENT-04", priority: "High", title: "Admin routes blocked for assessors", steps: ["Log in as assessor role user", "Navigate to /admin/marketplace directly"], expected: "Access Denied screen shown with user role displayed." },
    ],
  },
  {
    area: "QA Maturity Assessment",
    cases: [
      { id: "QA-01", priority: "Critical", title: "Start new assessment", steps: ["Go to QA Assessment", "Click Begin New Assessment"], expected: "Assessment run created in DB. Questionnaire opens with blank answers." },
      { id: "QA-02", priority: "Critical", title: "Auto-save on answer", steps: ["Select an answer", "Wait 2 seconds"], expected: "'Saved HH:MM' indicator appears. Run status changes to in_progress in DB." },
      { id: "QA-03", priority: "Critical", title: "Complete all 15 questions", steps: ["Answer all 15 questions", "Click Next on the last question"], expected: "Run status set to completed. Results page opens with scores." },
      { id: "QA-04", priority: "High", title: "Resume draft assessment", steps: ["Start an assessment, answer 5 questions", "Refresh the page", "Go back to QA Assessment start"], expected: "Draft card appears. Click Resume restores all 5 answers." },
      { id: "QA-05", priority: "High", title: "Export PDF report", steps: ["Complete assessment", "On results page click Export PDF"], expected: "PDF file downloads. Contains scores, domain table, and recommendations." },
      { id: "QA-06", priority: "High", title: "Export Excel report", steps: ["Complete assessment", "On results page click Export Excel"], expected: "Excel file downloads with Summary, Domain Scores, and Recommendations sheets." },
    ],
  },
  {
    area: "Performance Assessment",
    cases: [
      { id: "PERF-01", priority: "Critical", title: "Start performance assessment", steps: ["Go to Performance Assessment", "Click Begin Assessment"], expected: "Run created in DB. Questionnaire opens at section 1." },
      { id: "PERF-02", priority: "Critical", title: "Answer all sections and complete", steps: ["Answer all sections", "Click Complete on the last section"], expected: "Run marked completed. Results page with risk recommendation shown." },
      { id: "PERF-03", priority: "High", title: "Export performance PDF", steps: ["Complete assessment", "Click Export PDF on results"], expected: "PDF downloads with risk level, category breakdown table." },
    ],
  },
  {
    area: "Security Assessment",
    cases: [
      { id: "SEC-01", priority: "Critical", title: "Start security assessment", steps: ["Go to Security Assessment", "Click Start Assessment"], expected: "Run created in DB. Questionnaire opens at AppShield module." },
      { id: "SEC-02", priority: "Critical", title: "Answer all 4 modules", steps: ["Complete AppShield, MobileShield, InfraShield, CloudShield", "Click Finish"], expected: "Run completed. Results page with module scores and pentest signal." },
      { id: "SEC-03", priority: "High", title: "Export security PDF", steps: ["Complete assessment", "Click Export PDF"], expected: "PDF downloads with module scores, risk tier, critical gaps list." },
    ],
  },
  {
    area: "Customer Administration",
    cases: [
      { id: "ADMIN-01", priority: "Critical", title: "Create new organisation", steps: ["Go to Admin → Customers", "Click New Customer", "Fill name, code, email", "Click Create"], expected: "Organisation created and appears in the list." },
      { id: "ADMIN-02", priority: "Critical", title: "Assign package to organisation", steps: ["Select an org", "Click Assign Package", "Select PERF package", "Click Assign"], expected: "Subscription created. Package badge appears on org card." },
      { id: "ADMIN-03", priority: "High", title: "Toggle subscription active/inactive", steps: ["In org detail panel, toggle a subscription switch"], expected: "Subscription active state changes. Entitlement view updates." },
      { id: "ADMIN-04", priority: "High", title: "Invite user", steps: ["Go to Admin → Users", "Click Invite User", "Enter email, role, org", "Click Send Invitation"], expected: "Invitation email sent. User appears in list after accepting." },
      { id: "ADMIN-05", priority: "High", title: "Edit user role", steps: ["Click Edit icon on a user", "Change role to customer_admin", "Click Save"], expected: "Role updated in profiles table. User sees updated permissions." },
      { id: "ADMIN-06", priority: "Medium", title: "Deactivate user", steps: ["Click deactivate icon on a user"], expected: "User marked inactive. Cannot log in until reactivated." },
    ],
  },
  {
    area: "Monitoring & Audit",
    cases: [
      { id: "MON-01", priority: "High", title: "Monitoring dashboard loads", steps: ["Go to Admin → Monitoring"], expected: "KPI cards show correct counts. Charts render. Recent activity list shows events." },
      { id: "MON-02", priority: "High", title: "Audit log records login", steps: ["Log out and log back in", "Go to Admin → Audit Log"], expected: "user.login event appears at the top of the audit log." },
      { id: "MON-03", priority: "High", title: "Audit log records assessment", steps: ["Start and complete any assessment", "Check Audit Log"], expected: "assessment.started and assessment.completed events appear." },
      { id: "MON-04", priority: "Medium", title: "Audit log filter by event type", steps: ["In Audit Log, filter by 'Assessment Completed'"], expected: "Only assessment.completed events shown." },
    ],
  },
  {
    area: "Public Pages",
    cases: [
      { id: "PUB-01", priority: "High", title: "Landing page accessible without login", steps: ["Log out", "Navigate to /landing"], expected: "Landing page renders. No redirect to login." },
      { id: "PUB-02", priority: "High", title: "Landing page CTA navigates to login", steps: ["On /landing click Get Started or Start Free Assessment"], expected: "User navigated to /login." },
      { id: "PUB-03", priority: "Medium", title: "Privacy Policy accessible", steps: ["Navigate to /privacy"], expected: "Full Privacy Policy page renders without login." },
      { id: "PUB-04", priority: "Medium", title: "Terms accessible", steps: ["Navigate to /terms"], expected: "Full Terms & Conditions page renders without login." },
      { id: "PUB-05", priority: "Medium", title: "Contact form submits", steps: ["Go to /contact", "Fill all fields", "Click Send Message"], expected: "Success message shown. (Wire to real endpoint in production)" },
    ],
  },
];

const STATUS_CONFIG: Record<TestStatus, { label: string; color: string; icon: React.ReactNode }> = {
  pass:       { label: "Pass",       color: "#107C10", icon: <CheckCircle sx={{ fontSize: 16 }} /> },
  fail:       { label: "Fail",       color: "#D83B01", icon: <Cancel sx={{ fontSize: 16 }} /> },
  blocked:    { label: "Blocked",    color: "#FFB900", icon: <Warning sx={{ fontSize: 16 }} /> },
  not_tested: { label: "Not Tested", color: "#999",    icon: <RadioButtonUnchecked sx={{ fontSize: 16 }} /> },
};

const PRIORITY_COLORS: Record<string, string> = {
  Critical: "#D83B01", High: "#E65C00", Medium: "#FFB900",
};

function statusIcon(s: TestStatus) {
  const cfg = STATUS_CONFIG[s];
  return <Box sx={{ color: cfg.color, display: "flex" }}>{cfg.icon}</Box>;
}

export default function UATDashboard() {
  const totalCases = UAT_AREAS.flatMap((a) => a.cases).length;

  const [results, setResults] = useState<Record<string, TestStatus>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [tester, setTester] = useState("");
  const [signOffDate, setSignOffDate] = useState("");

  const setStatus = (id: string, status: TestStatus) =>
    setResults((p) => ({ ...p, [id]: status }));

  const counts = {
    pass:       Object.values(results).filter((s) => s === "pass").length,
    fail:       Object.values(results).filter((s) => s === "fail").length,
    blocked:    Object.values(results).filter((s) => s === "blocked").length,
    not_tested: totalCases - Object.keys(results).length,
  };

  const passRate = totalCases > 0 ? Math.round((counts.pass / totalCases) * 100) : 0;
  const criticalFails = UAT_AREAS.flatMap((a) =>
    a.cases.filter((c) => c.priority === "Critical" && results[c.id] === "fail")
  );
  const ready = criticalFails.length === 0 && counts.pass >= Math.ceil(totalCases * 0.8);

  const handleExport = () => {
    const rows = [
      ["Test ID", "Area", "Title", "Priority", "Status", "Notes"],
      ...UAT_AREAS.flatMap((area) =>
        area.cases.map((c) => [
          c.id, area.area, c.title, c.priority,
          STATUS_CONFIG[results[c.id] ?? "not_tested"].label,
          notes[c.id] ?? "",
        ])
      ),
    ];
    const csv = rows.map((r) => r.map((v) => `"${v}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "UAT-Results.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Assignment sx={{ fontSize: 28, color: "primary.main" }} />
          <Box>
            <Typography variant="h5" fontWeight={700}>UAT Test Plan</Typography>
            <Typography variant="body2" color="text.secondary">
              User Acceptance Testing — {totalCases} test cases across {UAT_AREAS.length} areas
            </Typography>
          </Box>
        </Box>
        <Button variant="outlined" startIcon={<Download />} size="small" onClick={handleExport}>
          Export CSV
        </Button>
      </Box>

      {/* Summary KPIs */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: "Pass",       count: counts.pass,       color: "#107C10", bg: "#E8FBF5" },
          { label: "Fail",       count: counts.fail,       color: "#D83B01", bg: "#FFF0EE" },
          { label: "Blocked",    count: counts.blocked,    color: "#FFB900", bg: "#FFFBF0" },
          { label: "Not Tested", count: counts.not_tested, color: "#999",    bg: "#F5F5F5" },
        ].map((s) => (
          <Grid size={{ xs: 6, sm: 3 }} key={s.label}>
            <Card elevation={0} sx={{ border: `1px solid ${s.color}30`, bgcolor: s.bg }}>
              <CardContent sx={{ py: 1.5, px: 2, "&:last-child": { pb: 1.5 } }}>
                <Typography variant="h4" fontWeight={800} sx={{ color: s.color }}>{s.count}</Typography>
                <Typography variant="caption" fontWeight={600} sx={{ color: s.color }}>{s.label}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Progress bar */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent sx={{ p: 2.5 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1 }}>
            <Typography variant="body2" fontWeight={700}>Overall Pass Rate</Typography>
            <Typography variant="body2" fontWeight={800} color={passRate >= 80 ? "#107C10" : "#D83B01"}>
              {passRate}%
            </Typography>
          </Box>
          <LinearProgress variant="determinate" value={passRate}
            sx={{ height: 10, borderRadius: 5, bgcolor: "#E8ECF4",
              "& .MuiLinearProgress-bar": { bgcolor: passRate >= 80 ? "#107C10" : "#D83B01", borderRadius: 5 } }} />
          <Box sx={{ display: "flex", justifyContent: "space-between", mt: 1 }}>
            <Typography variant="caption" color="text.secondary">
              {counts.pass} of {totalCases} test cases passed
            </Typography>
            <Chip
              label={ready ? "✓ Ready for Go-Live" : criticalFails.length > 0 ? `${criticalFails.length} Critical Failures` : "In Progress"}
              size="small"
              sx={{
                bgcolor: ready ? "#E8FBF5" : "#FFF0EE",
                color: ready ? "#107C10" : "#D83B01",
                fontWeight: 700, fontSize: "0.65rem",
              }}
            />
          </Box>
        </CardContent>
      </Card>

      {/* Critical failures alert */}
      {criticalFails.length > 0 && (
        <Card elevation={0} sx={{ border: "1px solid #D83B0140", bgcolor: "#FFF0EE", mb: 3 }}>
          <CardContent sx={{ p: 2 }}>
            <Typography variant="subtitle2" fontWeight={700} sx={{ color: "#D83B01", mb: 1 }}>
              ⚠️ Critical Test Failures — Do Not Go Live
            </Typography>
            {criticalFails.map((c) => (
              <Typography key={c.id} variant="caption" sx={{ display: "block", color: "#D83B01" }}>
                • [{c.id}] {c.title}
              </Typography>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Test cases by area */}
      {UAT_AREAS.map((area) => {
        const areaPassed = area.cases.filter((c) => results[c.id] === "pass").length;
        return (
          <Accordion key={area.area} elevation={0}
            sx={{ border: "1px solid #E0E4EC", mb: 1.5, borderRadius: "8px !important", "&:before": { display: "none" } }}>
            <AccordionSummary expandIcon={<ExpandMore />} sx={{ px: 2.5 }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 2, flex: 1 }}>
                <Typography variant="subtitle2" fontWeight={700}>{area.area}</Typography>
                <Chip label={`${areaPassed}/${area.cases.length} passed`} size="small"
                  sx={{ bgcolor: areaPassed === area.cases.length ? "#E8FBF5" : "#F5F5F5",
                    color: areaPassed === area.cases.length ? "#107C10" : "#666",
                    fontWeight: 700, fontSize: "0.65rem" }} />
              </Box>
            </AccordionSummary>
            <AccordionDetails sx={{ p: 0 }}>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: "#F7F9FF" }}>
                    {["ID", "Test Case", "Priority", "Status", "Notes"].map((h) => (
                      <TableCell key={h} sx={{ fontWeight: 700, fontSize: "0.72rem", color: "text.secondary" }}>
                        {h}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {area.cases.map((tc) => {
                    const status = results[tc.id] ?? "not_tested";
                    return (
                      <TableRow key={tc.id} sx={{ "&:hover": { bgcolor: "#F7F9FF" } }}>
                        <TableCell>
                          <Typography variant="caption" fontFamily="monospace" fontWeight={700}>
                            {tc.id}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>{tc.title}</Typography>
                          <Box sx={{ pl: 1 }}>
                            {tc.steps.map((s, i) => (
                              <Typography key={i} variant="caption" color="text.secondary" sx={{ display: "block" }}>
                                {i + 1}. {s}
                              </Typography>
                            ))}
                            <Typography variant="caption" sx={{ color: "#0F6CBD", fontStyle: "italic", display: "block", mt: 0.5 }}>
                              ✓ {tc.expected}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Chip label={tc.priority} size="small"
                            sx={{ bgcolor: `${PRIORITY_COLORS[tc.priority]}18`,
                              color: PRIORITY_COLORS[tc.priority], fontWeight: 700, fontSize: "0.65rem" }} />
                        </TableCell>
                        <TableCell>
                          <FormControl size="small" sx={{ minWidth: 120 }}>
                            <Select value={status}
                              onChange={(e) => setStatus(tc.id, e.target.value as TestStatus)}
                              renderValue={(v) => (
                                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                  {statusIcon(v as TestStatus)}
                                  <Typography variant="caption" fontWeight={700} sx={{ color: STATUS_CONFIG[v as TestStatus].color }}>
                                    {STATUS_CONFIG[v as TestStatus].label}
                                  </Typography>
                                </Box>
                              )}>
                              {(Object.keys(STATUS_CONFIG) as TestStatus[]).map((s) => (
                                <MenuItem key={s} value={s}>
                                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                    {statusIcon(s)}
                                    <Typography variant="caption">{STATUS_CONFIG[s].label}</Typography>
                                  </Box>
                                </MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                        </TableCell>
                        <TableCell>
                          <TextField size="small" placeholder="Notes…" value={notes[tc.id] ?? ""}
                            onChange={(e) => setNotes((p) => ({ ...p, [tc.id]: e.target.value }))}
                            sx={{ minWidth: 160, "& .MuiInputBase-input": { fontSize: "0.75rem" } }} />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </AccordionDetails>
          </Accordion>
        );
      })}

      {/* Sign-off */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mt: 3 }}>
        <CardContent sx={{ p: 2.5 }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>UAT Sign-Off</Typography>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField fullWidth label="Tester Name / Sign-Off By" value={tester} size="small"
                onChange={(e) => setTester(e.target.value)} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField fullWidth label="Sign-Off Date" type="date" value={signOffDate} size="small"
                onChange={(e) => setSignOffDate(e.target.value)}
                InputLabelProps={{ shrink: true }} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ display: "flex", gap: 2, alignItems: "center", flexWrap: "wrap" }}>
                <Chip
                  label={ready ? "✓ APPROVED FOR GO-LIVE" : "NOT APPROVED — Resolve failures first"}
                  sx={{
                    bgcolor: ready ? "#107C10" : "#D83B01", color: "white",
                    fontWeight: 800, px: 1, fontSize: "0.75rem",
                  }}
                />
                {tester && signOffDate && (
                  <Typography variant="caption" color="text.secondary">
                    Signed off by <strong>{tester}</strong> on{" "}
                    {new Date(signOffDate).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
                  </Typography>
                )}
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
}
