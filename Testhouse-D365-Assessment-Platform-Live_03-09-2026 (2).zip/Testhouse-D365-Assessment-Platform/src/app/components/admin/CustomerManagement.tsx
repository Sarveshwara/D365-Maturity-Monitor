import { useEffect, useState } from "react";
import {
  Box, Typography, Card, CardContent, Grid, Chip, Button, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, CircularProgress, Alert, Divider,
  IconButton, Tooltip, Select, MenuItem, FormControl, InputLabel, Table,
  TableHead, TableRow, TableCell, TableBody, Switch,
} from "@mui/material";
import {
  Business, Add, Refresh, PersonAdd, Package, Delete, Edit, Check,
} from "@mui/icons-material";
import {
  getOrganizations, createOrganization, getPackages,
  assignPackage, toggleSubscription, removeSubscription,
} from "../../lib/api";

const PACKAGE_COLORS: Record<string, string> = {
  QA_FULL: "#2B3E7E", PERF: "#0F6CBD", SEC: "#6B3FBE", AUTO: "#107C10", DEVOPS: "#038387",
};

export default function CustomerManagement() {
  const [orgs, setOrgs] = useState<any[]>([]);
  const [packages, setPackages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedOrg, setSelectedOrg] = useState<any | null>(null);

  // New org dialog
  const [newOrgOpen, setNewOrgOpen] = useState(false);
  const [newOrg, setNewOrg] = useState({ name: "", code: "", contact_email: "", industry: "" });
  const [saving, setSaving] = useState(false);

  // Assign package dialog
  const [assignOpen, setAssignOpen] = useState(false);
  const [assignTarget, setAssignTarget] = useState<any | null>(null);
  const [selectedPkgId, setSelectedPkgId] = useState("");
  const [assignNotes, setAssignNotes] = useState("");
  const [assigning, setAssigning] = useState(false);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [orgData, pkgData] = await Promise.all([getOrganizations(), getPackages()]);
      setOrgs(orgData ?? []);
      setPackages(pkgData ?? []);
      // Refresh selected org if open
      if (selectedOrg) {
        const refreshed = (orgData ?? []).find((o: any) => o.id === selectedOrg.id);
        if (refreshed) setSelectedOrg(refreshed);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleCreateOrg = async () => {
    setSaving(true);
    try {
      await createOrganization({ ...newOrg, active: true });
      setNewOrgOpen(false);
      setNewOrg({ name: "", code: "", contact_email: "", industry: "" });
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleAssign = async () => {
    if (!assignTarget || !selectedPkgId) return;
    setAssigning(true);
    try {
      await assignPackage(assignTarget.id, selectedPkgId, assignNotes);
      setAssignOpen(false);
      setSelectedPkgId("");
      setAssignNotes("");
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setAssigning(false);
    }
  };

  const handleToggleSub = async (subId: string) => {
    try {
      await toggleSubscription(subId);
      await load();
    } catch (e: any) {
      setError(e.message);
    }
  };

  const handleRemoveSub = async (subId: string) => {
    try {
      await removeSubscription(subId);
      await load();
    } catch (e: any) {
      setError(e.message);
    }
  };

  const openAssign = (org: any) => {
    setAssignTarget(org);
    setAssignOpen(true);
  };

  // Packages not yet assigned to this org
  const assignedPkgIds = (assignTarget?.customer_subscriptions ?? []).map((s: any) => s.assessment_packages?.id ?? s.package_id);
  const availablePkgs = packages.filter((p) => !assignedPkgIds.includes(p.id) && p.active);

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Business sx={{ fontSize: 28, color: "primary.main" }} />
          <Box>
            <Typography variant="h5" fontWeight={700}>Customer Management</Typography>
            <Typography variant="body2" color="text.secondary">
              Manage organizations and their assessment package subscriptions
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Tooltip title="Refresh">
            <IconButton onClick={load} disabled={loading}><Refresh /></IconButton>
          </Tooltip>
          <Button variant="contained" startIcon={<Add />} size="small" onClick={() => setNewOrgOpen(true)}>
            New Customer
          </Button>
        </Box>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error} — ensure the Supabase schema has been run and the edge function is deployed.
        </Alert>
      )}

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}><CircularProgress /></Box>
      ) : (
        <Grid container spacing={3}>
          {/* Org List */}
          <Grid size={{ xs: 12, md: selectedOrg ? 5 : 12 }}>
            {orgs.length === 0 ? (
              <Box sx={{ textAlign: "center", py: 8 }}>
                <Business sx={{ fontSize: 48, color: "text.disabled", mb: 2 }} />
                <Typography variant="h6" color="text.secondary">No customers found</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  Run the Supabase schema SQL to seed demo customers, or add one below.
                </Typography>
                <Button variant="outlined" onClick={() => setNewOrgOpen(true)} startIcon={<Add />}>
                  Add Customer
                </Button>
              </Box>
            ) : (
              <Box sx={{ display: "flex", flexDirection: "column", gap: 1.5 }}>
                {orgs.map((org) => {
                  const subs = org.customer_subscriptions ?? [];
                  const activeSubs = subs.filter((s: any) => s.active);
                  const isSelected = selectedOrg?.id === org.id;
                  return (
                    <Card
                      key={org.id}
                      elevation={0}
                      onClick={() => setSelectedOrg(isSelected ? null : org)}
                      sx={{
                        border: isSelected ? "1.5px solid #2B3E7E" : "1px solid #E0E4EC",
                        cursor: "pointer",
                        bgcolor: isSelected ? "#F0F4FF" : "white",
                        transition: "all 0.15s",
                        "&:hover": { boxShadow: "0 2px 12px rgba(0,0,0,0.08)" },
                      }}
                    >
                      <CardContent sx={{ py: 2, px: 2.5, "&:last-child": { pb: 2 } }}>
                        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                            <Box sx={{
                              width: 36, height: 36, borderRadius: 1.5,
                              bgcolor: "#2B3E7E18", display: "flex", alignItems: "center",
                              justifyContent: "center",
                            }}>
                              <Business sx={{ fontSize: 18, color: "#2B3E7E" }} />
                            </Box>
                            <Box>
                              <Typography variant="subtitle2" fontWeight={700}>{org.name}</Typography>
                              <Typography variant="caption" color="text.secondary">
                                {org.code} · {org.industry ?? "General"} · {org.contact_email}
                              </Typography>
                            </Box>
                          </Box>
                          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                            {activeSubs.length > 0 ? (
                              <Chip
                                label={`${activeSubs.length} package${activeSubs.length > 1 ? "s" : ""}`}
                                size="small"
                                sx={{ bgcolor: "#E8FBF5", color: "#107C10", fontWeight: 700, fontSize: "0.65rem" }}
                              />
                            ) : (
                              <Chip label="No packages" size="small"
                                sx={{ bgcolor: "#FFF5F0", color: "#D83B01", fontWeight: 700, fontSize: "0.65rem" }} />
                            )}
                            <Chip
                              label={org.active ? "Active" : "Inactive"}
                              size="small"
                              sx={{ bgcolor: org.active ? "#E8FBF5" : "#F5F5F5", color: org.active ? "#107C10" : "#777", fontWeight: 600, fontSize: "0.65rem" }}
                            />
                          </Box>
                        </Box>

                        {/* Package badges */}
                        {activeSubs.length > 0 && (
                          <Box sx={{ display: "flex", gap: 0.5, flexWrap: "wrap", mt: 1.5 }}>
                            {activeSubs.map((s: any) => {
                              const pkg = s.assessment_packages;
                              const col = pkg?.color ?? PACKAGE_COLORS[pkg?.package_code] ?? "#2B3E7E";
                              return (
                                <Chip key={s.id}
                                  label={pkg?.package_name ?? "Unknown Package"}
                                  size="small"
                                  sx={{ bgcolor: `${col}18`, color: col, fontWeight: 700, fontSize: "0.65rem" }}
                                />
                              );
                            })}
                          </Box>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </Box>
            )}
          </Grid>

          {/* Org Detail Panel */}
          {selectedOrg && (
            <Grid size={{ xs: 12, md: 7 }}>
              <Card elevation={0} sx={{ border: "1.5px solid #2B3E7E40", borderRadius: 2 }}>
                <Box sx={{ p: 2.5, bgcolor: "#F0F4FF", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <Box>
                    <Typography variant="subtitle1" fontWeight={800} sx={{ color: "#2B3E7E" }}>
                      {selectedOrg.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {selectedOrg.code} · {selectedOrg.contact_email}
                    </Typography>
                  </Box>
                  <Button variant="contained" startIcon={<Add />} size="small"
                    onClick={() => openAssign(selectedOrg)}
                    disabled={availablePkgs.length === 0}
                    sx={{ bgcolor: "#2B3E7E" }}>
                    Assign Package
                  </Button>
                </Box>
                <Divider />
                <CardContent sx={{ p: 2.5 }}>
                  <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
                    Package Subscriptions
                  </Typography>
                  {(selectedOrg.customer_subscriptions ?? []).length === 0 ? (
                    <Box sx={{ textAlign: "center", py: 3 }}>
                      <Typography variant="body2" color="text.secondary">No packages assigned yet</Typography>
                      <Button size="small" variant="outlined" sx={{ mt: 1 }} onClick={() => openAssign(selectedOrg)}>
                        Assign First Package
                      </Button>
                    </Box>
                  ) : (
                    <Table size="small">
                      <TableHead>
                        <TableRow sx={{ "& th": { fontWeight: 700, fontSize: "0.72rem", color: "text.secondary" } }}>
                          <TableCell>Package</TableCell>
                          <TableCell>Start Date</TableCell>
                          <TableCell>Status</TableCell>
                          <TableCell align="right">Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {selectedOrg.customer_subscriptions.map((sub: any) => {
                          const pkg = sub.assessment_packages;
                          const col = pkg?.color ?? PACKAGE_COLORS[pkg?.package_code] ?? "#2B3E7E";
                          return (
                            <TableRow key={sub.id} sx={{ "&:hover": { bgcolor: "#F7F9FF" } }}>
                              <TableCell>
                                <Chip label={pkg?.package_name ?? "Unknown"}
                                  size="small"
                                  sx={{ bgcolor: `${col}18`, color: col, fontWeight: 700, fontSize: "0.65rem" }} />
                                {sub.notes && (
                                  <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 0.3 }}>
                                    {sub.notes}
                                  </Typography>
                                )}
                              </TableCell>
                              <TableCell>
                                <Typography variant="caption">{sub.start_date}</Typography>
                              </TableCell>
                              <TableCell>
                                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                  <Switch
                                    size="small"
                                    checked={sub.active}
                                    onChange={() => handleToggleSub(sub.id)}
                                    color="success"
                                  />
                                  <Typography variant="caption" sx={{ color: sub.active ? "#107C10" : "#999" }}>
                                    {sub.active ? "Active" : "Inactive"}
                                  </Typography>
                                </Box>
                              </TableCell>
                              <TableCell align="right">
                                <Tooltip title="Remove subscription">
                                  <IconButton size="small" onClick={() => handleRemoveSub(sub.id)}
                                    sx={{ color: "#D83B01" }}>
                                    <Delete fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </Grid>
          )}
        </Grid>
      )}

      {/* New Org Dialog */}
      <Dialog open={newOrgOpen} onClose={() => setNewOrgOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add New Customer</DialogTitle>
        <DialogContent dividers>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
            <TextField label="Organization Name" value={newOrg.name} size="small"
              onChange={(e) => setNewOrg((p) => ({ ...p, name: e.target.value }))} required />
            <TextField label="Code (unique, e.g. ACME)" value={newOrg.code} size="small"
              onChange={(e) => setNewOrg((p) => ({ ...p, code: e.target.value.toUpperCase() }))} required
              helperText="Short identifier used in the system" />
            <TextField label="Contact Email" value={newOrg.contact_email} size="small"
              onChange={(e) => setNewOrg((p) => ({ ...p, contact_email: e.target.value }))} />
            <TextField label="Industry" value={newOrg.industry} size="small"
              onChange={(e) => setNewOrg((p) => ({ ...p, industry: e.target.value }))} />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setNewOrgOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreateOrg} disabled={saving || !newOrg.name || !newOrg.code}>
            {saving ? <CircularProgress size={16} /> : "Create Customer"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Assign Package Dialog */}
      <Dialog open={assignOpen} onClose={() => setAssignOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          Assign Package to {assignTarget?.name}
        </DialogTitle>
        <DialogContent dividers>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
            <FormControl size="small" fullWidth>
              <InputLabel>Assessment Package</InputLabel>
              <Select value={selectedPkgId} label="Assessment Package"
                onChange={(e) => setSelectedPkgId(e.target.value)}>
                {availablePkgs.map((p) => (
                  <MenuItem key={p.id} value={p.id}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <Box sx={{
                        width: 10, height: 10, borderRadius: "50%",
                        bgcolor: p.color ?? PACKAGE_COLORS[p.package_code] ?? "#2B3E7E",
                      }} />
                      {p.package_name}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField label="Notes (optional)" value={assignNotes} size="small" multiline rows={2}
              onChange={(e) => setAssignNotes(e.target.value)}
              placeholder="e.g. Annual enterprise contract, Q4 audit" />
          </Box>
          {availablePkgs.length === 0 && (
            <Alert severity="info" sx={{ mt: 2 }}>
              All available packages are already assigned to this customer.
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAssignOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleAssign}
            disabled={assigning || !selectedPkgId} startIcon={assigning ? <CircularProgress size={16} /> : <Check />}>
            Assign Package
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
