import { useEffect, useState } from "react";
import {
  Box, Typography, Card, CardContent, Grid, Chip, CircularProgress,
  Alert, IconButton, Tooltip, Divider, LinearProgress,
} from "@mui/material";
import {
  MonitorHeart, People, Business, Assessment, CheckCircle,
  TrendingUp, Refresh, FiberManualRecord,
} from "@mui/icons-material";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartTooltip,
  ResponsiveContainer, Cell, LineChart, Line, PieChart, Pie, Legend,
} from "recharts";
import { getPlatformStats } from "../../lib/api";
import { getEventLabel, getEventColor } from "../../lib/audit-service";

const TYPE_COLORS: Record<string, string> = {
  QA_MATURITY:  "#2B3E7E",
  PERFORMANCE:  "#0F6CBD",
  SECURITY:     "#6B3FBE",
};

const TYPE_LABELS: Record<string, string> = {
  QA_MATURITY: "QA Maturity",
  PERFORMANCE: "Performance",
  SECURITY:    "Security",
};

function StatCard({
  label, value, sub, icon, color = "#2B3E7E",
}: {
  label: string; value: string | number; sub?: string; icon: React.ReactNode; color?: string;
}) {
  return (
    <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
      <CardContent sx={{ p: 2.5 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <Box>
            <Typography variant="caption" color="text.secondary" fontWeight={600} sx={{ textTransform: "uppercase", letterSpacing: 0.5 }}>
              {label}
            </Typography>
            <Typography variant="h3" fontWeight={800} sx={{ color, lineHeight: 1.2, mt: 0.5 }}>
              {value}
            </Typography>
            {sub && (
              <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: "block" }}>
                {sub}
              </Typography>
            )}
          </Box>
          <Box sx={{ p: 1.2, borderRadius: 2, bgcolor: `${color}18`, color }}>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
}

export default function MonitoringDashboard() {
  const [stats, setStats] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getPlatformStats();
      setStats(data);
      setLastRefresh(new Date());
    } catch (e: any) {
      setError(e.message + " — deploy the edge function from Make settings.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const byTypeData = stats
    ? Object.entries(stats.byType ?? {}).map(([key, count]) => ({
        name: TYPE_LABELS[key] ?? key,
        count: count as number,
        color: TYPE_COLORS[key] ?? "#2B3E7E",
      }))
    : [];

  const completionPie = stats
    ? [
        { name: "Completed", value: stats.completedRuns, color: "#107C10" },
        { name: "In Progress", value: Math.max(0, stats.totalRuns - stats.completedRuns - stats.draftRuns), color: "#0F6CBD" },
        { name: "Draft", value: stats.draftRuns, color: "#E0E4EC" },
      ].filter((d) => d.value > 0)
    : [];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <MonitorHeart sx={{ fontSize: 28, color: "primary.main" }} />
          <Box>
            <Typography variant="h5" fontWeight={700}>System Monitoring</Typography>
            <Typography variant="body2" color="text.secondary">
              Platform health, usage analytics, and activity
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Typography variant="caption" color="text.secondary">
            Refreshed {lastRefresh.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </Typography>
          <Tooltip title="Refresh">
            <IconButton onClick={load} disabled={loading} size="small">
              <Refresh fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Platform status banner */}
      <Card elevation={0} sx={{ mb: 3, border: "1px solid #107C1040", bgcolor: "#F0FBF2" }}>
        <CardContent sx={{ py: 1.5, px: 2.5, "&:last-child": { pb: 1.5 }, display: "flex", alignItems: "center", gap: 2 }}>
          <FiberManualRecord sx={{ fontSize: 12, color: "#107C10" }} />
          <Typography variant="body2" fontWeight={700} color="#107C10">Platform Operational</Typography>
          <Divider orientation="vertical" flexItem sx={{ mx: 1 }} />
          <Typography variant="caption" color="text.secondary">
            Supabase DB · Edge Functions · Authentication — All systems normal
          </Typography>
        </CardContent>
      </Card>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}

      {loading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}><CircularProgress /></Box>
      ) : stats ? (
        <>
          {/* KPI cards */}
          <Grid container spacing={2.5} sx={{ mb: 3 }}>
            <Grid size={{ xs: 6, sm: 3 }}>
              <StatCard label="Total Users" value={stats.users}
                sub="Registered profiles" color="#2B3E7E"
                icon={<People sx={{ fontSize: 22 }} />} />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <StatCard label="Organisations" value={stats.activeOrgs}
                sub={`${stats.organizations} total`} color="#038387"
                icon={<Business sx={{ fontSize: 22 }} />} />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <StatCard label="Assessments Run" value={stats.totalRuns}
                sub={`${stats.completedRuns} completed`} color="#0F6CBD"
                icon={<Assessment sx={{ fontSize: 22 }} />} />
            </Grid>
            <Grid size={{ xs: 6, sm: 3 }}>
              <StatCard label="Completion Rate" value={`${stats.completionRate}%`}
                sub="Of all started assessments" color="#107C10"
                icon={<CheckCircle sx={{ fontSize: 22 }} />} />
            </Grid>
          </Grid>

          {/* Charts row */}
          <Grid container spacing={2.5} sx={{ mb: 3 }}>
            {/* Assessments by type */}
            <Grid size={{ xs: 12, md: 7 }}>
              <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
                <CardContent>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                    Completed Assessments by Type
                  </Typography>
                  {byTypeData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={byTypeData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                        <RechartTooltip />
                        <Bar key="mon-bar-count" dataKey="count" name="Completed" radius={[4, 4, 0, 0]}>
                          {byTypeData.map((entry, i) => (
                            <Cell key={`mon-cell-${i}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: 220 }}>
                      <Typography variant="body2" color="text.secondary">
                        No completed assessments yet
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>

            {/* Completion breakdown pie */}
            <Grid size={{ xs: 12, md: 5 }}>
              <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
                <CardContent>
                  <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                    Assessment Status Breakdown
                  </Typography>
                  {completionPie.length > 0 ? (
                    <ResponsiveContainer width="100%" height={220}>
                      <PieChart>
                        <Pie key="mon-pie" data={completionPie} cx="50%" cy="45%"
                          innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}>
                          {completionPie.map((entry, i) => (
                            <Cell key={`mon-pie-cell-${i}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Legend />
                        <RechartTooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", height: 220 }}>
                      <Typography variant="body2" color="text.secondary">No data yet</Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Completion rate progress */}
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2 }}>
                Platform Usage Summary
              </Typography>
              <Grid container spacing={3}>
                {[
                  { label: "Assessment Completion Rate", value: stats.completionRate, color: "#107C10" },
                  { label: "Organisation Activation Rate",
                    value: stats.organizations > 0 ? Math.round((stats.activeOrgs / stats.organizations) * 100) : 0,
                    color: "#0F6CBD" },
                  { label: "Draft → Completion Conversion",
                    value: stats.totalRuns > 0 ? Math.round((stats.completedRuns / stats.totalRuns) * 100) : 0,
                    color: "#2B3E7E" },
                ].map((m) => (
                  <Grid size={{ xs: 12, md: 4 }} key={m.label}>
                    <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>{m.label}</Typography>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                      <LinearProgress variant="determinate" value={m.value}
                        sx={{ flex: 1, height: 8, borderRadius: 4,
                          bgcolor: "#E8ECF4",
                          "& .MuiLinearProgress-bar": { bgcolor: m.color, borderRadius: 4 } }} />
                      <Typography variant="body2" fontWeight={700} sx={{ color: m.color, minWidth: 36 }}>
                        {m.value}%
                      </Typography>
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>

          {/* Recent activity */}
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC" }}>
            <CardContent sx={{ p: 2.5 }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
                <Typography variant="subtitle1" fontWeight={700}>Recent Activity</Typography>
                <Chip label="Last 10 events" size="small" sx={{ bgcolor: "#F0F4FF", color: "#2B3E7E", fontSize: "0.65rem" }} />
              </Box>
              {(stats.recentEvents ?? []).length === 0 ? (
                <Typography variant="body2" color="text.secondary">No activity recorded yet.</Typography>
              ) : (
                <Box>
                  {(stats.recentEvents as any[]).map((ev: any, i: number) => (
                    <Box key={i} sx={{
                      display: "flex", alignItems: "center", gap: 2, py: 1.2,
                      borderBottom: i < stats.recentEvents.length - 1 ? "1px solid #F0F0F0" : "none",
                    }}>
                      <Box sx={{
                        width: 8, height: 8, borderRadius: "50%", flexShrink: 0,
                        bgcolor: getEventColor(ev.event_type),
                      }} />
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography variant="body2" fontWeight={600}>
                          {getEventLabel(ev.event_type)}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {ev.user_name ?? "System"}{ev.org_name ? ` · ${ev.org_name}` : ""}
                        </Typography>
                      </Box>
                      <Typography variant="caption" color="text.secondary" sx={{ flexShrink: 0 }}>
                        {new Date(ev.created_at).toLocaleString([], {
                          month: "short", day: "numeric",
                          hour: "2-digit", minute: "2-digit",
                        })}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>
        </>
      ) : null}
    </Box>
  );
}
