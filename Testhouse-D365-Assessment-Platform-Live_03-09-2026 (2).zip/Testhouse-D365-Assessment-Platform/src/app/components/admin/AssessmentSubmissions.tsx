import { useEffect, useState } from "react";
import { useNavigate } from "react-router";

import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Button,
  CircularProgress,
  Alert,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TableContainer,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Divider,
  IconButton,
} from "@mui/material";

import { OpenInNew, Info, Close } from "@mui/icons-material";

import {
  assessmentService,
  type AssessmentRun,
} from "../../lib/assessment-service";

function statusChip(status: AssessmentRun["status"]) {
  switch (status) {
    case "completed":
      return <Chip label="Completed" size="small" color="success" />;
    case "in_progress":
      return <Chip label="In Progress" size="small" color="warning" />;
    default:
      return <Chip label="Draft" size="small" />;
  }
}

function DetailField({
  label,
  value,
}: {
  label: string;
  value: string | undefined | null;
}) {
  return (
    <Grid size={{ xs: 12, sm: 6 }}>
      <Typography variant="caption" color="text.secondary">
        {label}
      </Typography>
      <Typography variant="body2" fontWeight={500}>
        {value?.trim() || "—"}
      </Typography>
    </Grid>
  );
}

export default function AssessmentSubmissions() {
  const navigate = useNavigate();

  const [runs, setRuns] = useState<AssessmentRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [detailsRun, setDetailsRun] = useState<AssessmentRun | null>(null);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { runs: data, error: err } = await assessmentService.listAllForAdmin();

      if (!mounted) return;

      setRuns(data);
      setError(err);
      setLoading(false);
    })();

    return () => {
      mounted = false;
    };
  }, []);

  const detailsInfo = detailsRun?.assessment_context?.customerInfo;

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700} color="primary.main">
          Assessment Submissions
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
          Every D365 QA Maturity Assessment run — including ones still
          in progress — with the contact and company info captured for
          each one.
        </Typography>
      </Box>

      {loading && (
        <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
          <CircularProgress />
        </Box>
      )}

      {!loading && error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {!loading && !error && (
        <Card elevation={0} sx={{ border: "1px solid #E0E4EC", borderRadius: 3 }}>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Company</TableCell>
                  <TableCell>Contact</TableCell>
                  <TableCell>Account Email</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Score</TableCell>
                  <TableCell>Date</TableCell>
                  <TableCell align="right">&nbsp;</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {runs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7}>
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{ py: 3, textAlign: "center" }}
                      >
                        No assessment submissions yet.
                      </Typography>
                    </TableCell>
                  </TableRow>
                )}

                {runs.map((run) => {
                  const customerInfo = run.assessment_context?.customerInfo;
                  const contactName = [
                    customerInfo?.firstName,
                    customerInfo?.lastName,
                  ]
                    .filter(Boolean)
                    .join(" ");

                  return (
                    <TableRow key={run.id} hover>
                      <TableCell>{customerInfo?.companyName ?? "—"}</TableCell>
                      <TableCell>{contactName || "—"}</TableCell>
                      <TableCell>
                        {customerInfo?.email ??
                          (run as any).created_by_email ??
                          "—"}
                      </TableCell>
                      <TableCell>{statusChip(run.status)}</TableCell>
                      <TableCell>
                        {run.overall_score != null
                          ? `${Number(run.overall_score).toFixed(1)} / 5.0`
                          : "—"}
                      </TableCell>
                      <TableCell>
                        {new Date(
                          run.completed_at ?? run.run_date
                        ).toLocaleDateString()}
                      </TableCell>
                      <TableCell align="right">
                        <Button
                          size="small"
                          startIcon={<Info fontSize="small" />}
                          onClick={() => setDetailsRun(run)}
                          sx={{ mr: 1 }}
                        >
                          Details
                        </Button>

                        <Button
                          size="small"
                          endIcon={<OpenInNew fontSize="small" />}
                          disabled={run.status !== "completed"}
                          onClick={() =>
                            navigate(`/assessment/results/${run.id}`)
                          }
                        >
                          Report
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Card>
      )}

      {/* DETAILS DIALOG — every field captured on Customer Info,
          available regardless of completion status, for follow-up
          on anyone who started but hasn't finished. */}
      <Dialog
        open={!!detailsRun}
        onClose={() => setDetailsRun(null)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle
          sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}
        >
          {detailsInfo?.companyName || "Assessment details"}
          <IconButton size="small" onClick={() => setDetailsRun(null)}>
            <Close fontSize="small" />
          </IconButton>
        </DialogTitle>

        <DialogContent dividers>
          {detailsRun && (
            <Box>
              <Box sx={{ display: "flex", gap: 1, mb: 2 }}>
                {statusChip(detailsRun.status)}
                {detailsRun.overall_score != null && (
                  <Chip
                    size="small"
                    variant="outlined"
                    label={`Score: ${Number(detailsRun.overall_score).toFixed(1)} / 5.0`}
                  />
                )}
              </Box>

              <Typography variant="overline" color="text.secondary">
                Contact
              </Typography>
              <Grid container spacing={2} sx={{ mb: 2, mt: 0.5 }}>
                <DetailField
                  label="Name"
                  value={[detailsInfo?.firstName, detailsInfo?.lastName]
                    .filter(Boolean)
                    .join(" ")}
                />
                <DetailField
                  label="Email"
                  value={detailsInfo?.email ?? (detailsRun as any).created_by_email}
                />
                <DetailField label="Job Title" value={detailsInfo?.jobTitle} />
                <DetailField
                  label="Phone"
                  value={
                    detailsInfo?.phone
                      ? `${detailsInfo.countryCode ?? ""} ${detailsInfo.phone}`.trim()
                      : undefined
                  }
                />
              </Grid>

              <Divider sx={{ mb: 2 }} />

              <Typography variant="overline" color="text.secondary">
                Organisation
              </Typography>
              <Grid container spacing={2} sx={{ mb: 2, mt: 0.5 }}>
                <DetailField label="Company" value={detailsInfo?.companyName} />
                <DetailField label="Industry" value={detailsInfo?.industry} />
                <DetailField label="Country / Region" value={detailsInfo?.country} />
                <DetailField
                  label="Organisation Size"
                  value={detailsInfo?.organizationSize}
                />
              </Grid>

              <Divider sx={{ mb: 2 }} />

              <Grid container spacing={2}>
                <DetailField
                  label="Started"
                  value={new Date(detailsRun.run_date).toLocaleString()}
                />
                <DetailField
                  label="Completed"
                  value={
                    detailsRun.completed_at
                      ? new Date(detailsRun.completed_at).toLocaleString()
                      : "Not yet completed"
                  }
                />
              </Grid>
            </Box>
          )}
        </DialogContent>

        <DialogActions>
          {detailsRun?.status === "completed" && (
            <Button
              onClick={() => navigate(`/assessment/results/${detailsRun.id}`)}
            >
              View Full Report
            </Button>
          )}
          <Button onClick={() => setDetailsRun(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
