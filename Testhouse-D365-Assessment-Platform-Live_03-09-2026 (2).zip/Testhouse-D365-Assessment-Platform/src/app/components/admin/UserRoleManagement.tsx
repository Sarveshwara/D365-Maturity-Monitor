import { useEffect, useState } from "react";
import {
  Box, Typography, Card, CardContent, Chip, Button, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, CircularProgress, Alert,
  IconButton, Tooltip, Table, TableHead, TableRow, TableCell, TableBody,
  Select, MenuItem, FormControl, InputLabel, Tab, Tabs, Avatar,
} from "@mui/material";
import {
  People, Add, Refresh, PersonOff, PersonAdd, LockReset,
  Edit, CheckCircle, Cancel, AdminPanelSettings,
} from "@mui/icons-material";
import {
  getProfiles, updateProfile, inviteUser, toggleUserActive,
  sendPasswordReset, getOrganizations,
} from "../../lib/api";
import { useAuth } from "../../contexts/AuthContext";

const ROLE_COLORS: Record<string, { bg: string; color: string }> = {
  super_admin:    { bg: "#2B3E7E18", color: "#2B3E7E" },
  customer_admin: { bg: "#0F6CBD18", color: "#0F6CBD" },
  assessor:       { bg: "#107C1018", color: "#107C10" },
  viewer:         { bg: "#76767618", color: "#767676" },
};

const ROLE_OPTIONS = ["super_admin", "customer_admin", "assessor", "viewer"];

const ROLE_MATRIX = [
  { permission: "Manage Organizations",   super_admin: true,  customer_admin: false, assessor: false, viewer: false },
  { permission: "Manage Packages",        super_admin: true,  customer_admin: false, assessor: false, viewer: false },
  { permission: "Manage Users",           super_admin: true,  customer_admin: true,  assessor: false, viewer: false },
  { permission: "Assign Assessors",       super_admin: true,  customer_admin: true,  assessor: false, viewer: false },
  { permission: "Start Assessment",       super_admin: true,  customer_admin: true,  assessor: true,  viewer: false },
  { permission: "Complete Questionnaire", super_admin: true,  customer_admin: true,  assessor: true,  viewer: false },
  { permission: "View Reports",           super_admin: true,  customer_admin: true,  assessor: true,  viewer: true  },
  { permission: "Export Reports",         super_admin: true,  customer_admin: true,  assessor: true,  viewer: false },
  { permission: "View All Org Data",      super_admin: true,  customer_admin: false, assessor: false, viewer: false },
];

export default function UserRoleManagement() {
  const { isSuperAdmin } = useAuth();
  const [tab, setTab] = useState(0);
  const [users, setUsers] = useState<any[]>([]);
  const [orgs, setOrgs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteForm, setInviteForm] = useState({ email: "", full_name: "", role: "assessor", organization_id: "" });
  const [inviting, setInviting] = useState(false);

  const [editUser, setEditUser] = useState<any | null>(null);
  const [editRole, setEditRole] = useState("");
  const [editOrg, setEditOrg] = useState("");
  const [saving, setSaving] = useState(false);
  const [actionId, setActionId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const [profileData, orgData] = await Promise.all([getProfiles(), getOrganizations()]);
      setUsers(profileData ?? []);
      setOrgs(orgData ?? []);
    } catch (e: any) {
      setError(e.message + " — deploy the edge function from Make settings.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleInvite = async () => {
    setInviting(true);
    setError(null);
    try {
      await inviteUser({
        email: inviteForm.email,
        full_name: inviteForm.full_name,
        role: inviteForm.role,
        organization_id: inviteForm.organization_id || undefined,
      });
      setSuccess(`Invitation sent to ${inviteForm.email}`);
      setInviteOpen(false);
      setInviteForm({ email: "", full_name: "", role: "assessor", organization_id: "" });
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setInviting(false);
    }
  };

  const handleSaveRole = async () => {
    if (!editUser) return;
    setSaving(true);
    try {
      await updateProfile(editUser.id, { role: editRole, organization_id: editOrg || null });
      setSuccess("User updated successfully");
      setEditUser(null);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (userId: string, name: string, active: boolean) => {
    setActionId(userId);
    try {
      await toggleUserActive(userId);
      setSuccess(`${name} ${active ? "deactivated" : "reactivated"}`);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setActionId(null);
    }
  };

  const handleResetPassword = async (userId: string, name: string) => {
    setActionId(userId + "-reset");
    try {
      await sendPasswordReset(userId);
      setSuccess(`Password reset email sent to ${name}`);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setActionId(null);
    }
  };

  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <People sx={{ fontSize: 28, color: "primary.main" }} />
          <Box>
            <Typography variant="h5" fontWeight={700}>Users & Roles</Typography>
            <Typography variant="body2" color="text.secondary">
              Manage platform users, roles, and permissions
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Tooltip title="Refresh">
            <IconButton onClick={load} disabled={loading}><Refresh /></IconButton>
          </Tooltip>
          {isSuperAdmin && (
            <Button variant="contained" startIcon={<Add />} size="small"
              onClick={() => setInviteOpen(true)}>
              Invite User
            </Button>
          )}
        </Box>
      </Box>

      {error   && <Alert severity="error"   sx={{ mb: 2 }} onClose={() => setError(null)}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess(null)}>{success}</Alert>}

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 3, borderBottom: "1px solid #E0E4EC" }}>
        <Tab label={`Users (${users.length})`} />
        <Tab label="Role & Permission Matrix" />
      </Tabs>

      {/* ── Users Tab ─────────────────────────────────────────── */}
      {tab === 0 && (
        loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", py: 8 }}>
            <CircularProgress />
          </Box>
        ) : users.length === 0 ? (
          <Box sx={{ textAlign: "center", py: 8 }}>
            <People sx={{ fontSize: 48, color: "text.disabled", mb: 2 }} />
            <Typography variant="h6" color="text.secondary">No users found</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Invite the first user to get started.
            </Typography>
            <Button variant="outlined" startIcon={<PersonAdd />} onClick={() => setInviteOpen(true)}>
              Invite User
            </Button>
          </Box>
        ) : (
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC" }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: "#F7F9FF" }}>
                  {["User", "Role", "Organisation", "Status", "Actions"].map((h) => (
                    <TableCell key={h} sx={{ fontWeight: 700, fontSize: "0.75rem", color: "text.secondary" }}>
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {users.map((user) => {
                  const roleStyle = ROLE_COLORS[user.role] ?? { bg: "#F5F5F5", color: "#666" };
                  const orgName = user.organizations?.name
                    ?? orgs.find((o: any) => o.id === user.organization_id)?.name ?? "—";
                  const isActing = actionId === user.id || actionId === user.id + "-reset";
                  return (
                    <TableRow key={user.id} sx={{ "&:hover": { bgcolor: "#F7F9FF" } }}>
                      <TableCell>
                        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                          <Avatar sx={{ width: 32, height: 32, bgcolor: roleStyle.color, fontSize: "0.8rem" }}>
                            {(user.full_name ?? "?")[0].toUpperCase()}
                          </Avatar>
                          <Box>
                            <Typography variant="body2" fontWeight={600}>
                              {user.full_name ?? "Unknown"}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {user.id?.slice(0, 8)}…
                            </Typography>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Chip label={user.role?.replace("_", " ")} size="small"
                          sx={{ bgcolor: roleStyle.bg, color: roleStyle.color,
                            fontWeight: 700, fontSize: "0.65rem", textTransform: "capitalize" }} />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{orgName}</Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={user.active !== false ? "Active" : "Inactive"}
                          size="small"
                          sx={{
                            bgcolor: user.active !== false ? "#E8FBF5" : "#F5F5F5",
                            color: user.active !== false ? "#107C10" : "#999",
                            fontWeight: 700, fontSize: "0.65rem",
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: "flex", gap: 0.5 }}>
                          <Tooltip title="Edit role & org">
                            <IconButton size="small" onClick={() => {
                              setEditUser(user);
                              setEditRole(user.role ?? "assessor");
                              setEditOrg(user.organization_id ?? "");
                            }}>
                              <Edit fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="Send password reset email">
                            <IconButton size="small" disabled={isActing}
                              onClick={() => handleResetPassword(user.id, user.full_name ?? user.id)}>
                              {actionId === user.id + "-reset"
                                ? <CircularProgress size={14} />
                                : <LockReset fontSize="small" />}
                            </IconButton>
                          </Tooltip>
                          <Tooltip title={user.active !== false ? "Deactivate" : "Reactivate"}>
                            <IconButton size="small" disabled={isActing}
                              sx={{ color: user.active !== false ? "#D83B01" : "#107C10" }}
                              onClick={() => handleToggle(user.id, user.full_name ?? "User", user.active !== false)}>
                              {actionId === user.id
                                ? <CircularProgress size={14} />
                                : user.active !== false
                                  ? <PersonOff fontSize="small" />
                                  : <PersonAdd fontSize="small" />}
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Card>
        )
      )}

      {/* ── Role Matrix Tab ───────────────────────────────────── */}
      {tab === 1 && (
        <Card elevation={0} sx={{ border: "1px solid #E0E4EC" }}>
          <CardContent sx={{ p: 0 }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: "#F7F9FF" }}>
                  <TableCell sx={{ fontWeight: 700, fontSize: "0.75rem", color: "text.secondary", width: 220 }}>
                    Permission
                  </TableCell>
                  {["Super Admin", "Customer Admin", "Assessor", "Viewer"].map((r) => (
                    <TableCell key={r} align="center"
                      sx={{ fontWeight: 700, fontSize: "0.75rem", color: "text.secondary" }}>
                      {r}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {ROLE_MATRIX.map((row) => (
                  <TableRow key={row.permission} sx={{ "&:hover": { bgcolor: "#F7F9FF" } }}>
                    <TableCell sx={{ fontWeight: 600, fontSize: "0.82rem" }}>{row.permission}</TableCell>
                    {(["super_admin", "customer_admin", "assessor", "viewer"] as const).map((role) => (
                      <TableCell key={role} align="center">
                        {row[role]
                          ? <CheckCircle sx={{ fontSize: 18, color: "#107C10" }} />
                          : <Cancel sx={{ fontSize: 18, color: "#E0E4EC" }} />}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* ── Invite Dialog ─────────────────────────────────────── */}
      <Dialog open={inviteOpen} onClose={() => setInviteOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <PersonAdd sx={{ color: "primary.main" }} /> Invite New User
        </DialogTitle>
        <DialogContent dividers>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
            <TextField label="Full Name" value={inviteForm.full_name} size="small"
              onChange={(e) => setInviteForm((p) => ({ ...p, full_name: e.target.value }))} />
            <TextField label="Email Address" type="email" value={inviteForm.email} size="small" required
              onChange={(e) => setInviteForm((p) => ({ ...p, email: e.target.value }))} />
            <FormControl size="small" fullWidth>
              <InputLabel>Role</InputLabel>
              <Select value={inviteForm.role} label="Role"
                onChange={(e) => setInviteForm((p) => ({ ...p, role: e.target.value }))}>
                {ROLE_OPTIONS.map((r) => (
                  <MenuItem key={r} value={r} sx={{ textTransform: "capitalize" }}>
                    {r.replace("_", " ")}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel>Organisation (optional)</InputLabel>
              <Select value={inviteForm.organization_id} label="Organisation (optional)"
                onChange={(e) => setInviteForm((p) => ({ ...p, organization_id: e.target.value }))}>
                <MenuItem value="">— None —</MenuItem>
                {orgs.map((o: any) => <MenuItem key={o.id} value={o.id}>{o.name}</MenuItem>)}
              </Select>
            </FormControl>
            <Alert severity="info" sx={{ fontSize: "0.78rem" }}>
              An invitation email will be sent. The user sets their own password on first login.
            </Alert>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setInviteOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleInvite}
            disabled={inviting || !inviteForm.email}
            startIcon={inviting ? <CircularProgress size={16} /> : <PersonAdd />}>
            Send Invitation
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Edit Role Dialog ──────────────────────────────────── */}
      <Dialog open={!!editUser} onClose={() => setEditUser(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <AdminPanelSettings sx={{ color: "primary.main" }} /> Edit User
        </DialogTitle>
        <DialogContent dividers>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Editing: <strong>{editUser?.full_name}</strong>
            </Typography>
            <FormControl size="small" fullWidth>
              <InputLabel>Role</InputLabel>
              <Select value={editRole} label="Role"
                onChange={(e) => setEditRole(e.target.value)}>
                {ROLE_OPTIONS.map((r) => (
                  <MenuItem key={r} value={r} sx={{ textTransform: "capitalize" }}>
                    {r.replace("_", " ")}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel>Organisation</InputLabel>
              <Select value={editOrg} label="Organisation"
                onChange={(e) => setEditOrg(e.target.value)}>
                <MenuItem value="">— None —</MenuItem>
                {orgs.map((o: any) => <MenuItem key={o.id} value={o.id}>{o.name}</MenuItem>)}
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditUser(null)}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveRole} disabled={saving}
            startIcon={saving ? <CircularProgress size={16} /> : <CheckCircle />}>
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
