import { useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router";
import {
  AppBar, Toolbar, IconButton, Typography, Drawer, List, ListItem,
  ListItemButton, ListItemIcon, ListItemText, Box, Divider, Avatar,
  Menu, MenuItem, Select, Chip, Tooltip, FormControl, InputLabel,
  CircularProgress,
} from "@mui/material";
import {
  Menu as MenuIcon, Dashboard, Assessment, UploadFile, Psychology, BarChart,
  Settings, Notifications, Person, Speed, TrendingUp, CheckCircle, BugReport,
  Timeline, Science, ViewList, Analytics, Lightbulb, Description, People,
  AdminPanelSettings, ChevronRight, Shield, Storefront, Business,
  MonitorHeart, History, Assignment, RocketLaunch, FactCheck,
} from "@mui/icons-material";
import { usePackage } from "../contexts/PackageContext";
import { useAuth } from "../contexts/AuthContext";
import TesthouseLogo from "./shared/TesthouseLogo";

const drawerWidth = 280;

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  routePrefix?: string;   // used for entitlement check
  children?: NavItem[];
  alwaysVisible?: boolean; // dashboards, admin — always show to super_admin
}

const navigationItems: NavItem[] = [
  // ── Hidden for pilot — none of these are wired to real data yet.
  // Restore by uncommenting once each has a real backend behind it.
  // {
  //   label: "Dashboards",
  //   path: "/",
  //   icon: <Dashboard />,
  //   alwaysVisible: true,
  //   children: [
  //     { label: "Program Dashboard",  path: "/",                   icon: <Dashboard />,  alwaysVisible: true },
  //     { label: "Executive Dashboard", path: "/executive",          icon: <Speed />,      alwaysVisible: true },
  //     { label: "QA Maturity",         path: "/qa-maturity",        icon: <CheckCircle />,routePrefix: "/qa-maturity" },
  //     { label: "DevOps Maturity",     path: "/devops-maturity",    icon: <TrendingUp />, routePrefix: "/devops-maturity" },
  //     { label: "Success by Design",   path: "/success-by-design",  icon: <Lightbulb />,  alwaysVisible: true },
  //     { label: "Benchmarking",        path: "/benchmarking",       icon: <BarChart />,   routePrefix: "/benchmarking" },
  //     { label: "Defect Intelligence", path: "/defect-intelligence", icon: <BugReport />, alwaysVisible: true },
  //   ],
  // },
    {
  label: "Assessment",
  path: "/assessment",
  icon: <Assessment />,
  alwaysVisible: true,
  children: [
    {
      label: "D365 Assessment",
      path: "/assessment",
      icon: <Assessment />,
      alwaysVisible: true,
    },
    {
      label: "Questionnaire",
      path: "/assessment/questionnaire",
      icon: <Description />,
      alwaysVisible: true,
    },
    {
      label: "Results",
      path: "/assessment/results",
      icon: <Analytics />,
      alwaysVisible: true,
    },
  ],
},
  // {
  //   label: "Artifacts",
  //   path: "/artifacts/upload",
  //   icon: <UploadFile />,
  //   alwaysVisible: true,
  //   children: [
  //     { label: "Upload",            path: "/artifacts/upload",     icon: <UploadFile />, alwaysVisible: true },
  //     { label: "Integration",       path: "/artifacts/integration", icon: <Timeline />,  alwaysVisible: true },
  //     { label: "Processing Status", path: "/artifacts/status",     icon: <TrendingUp />, alwaysVisible: true },
  //   ],
  // },
  // {
  //   label: "Intelligence",
  //   path: "/intelligence/traceability",
  //   icon: <Psychology />,
  //   alwaysVisible: true,
  //   children: [
  //     { label: "Traceability Graph", path: "/intelligence/traceability",   icon: <Timeline />,  alwaysVisible: true },
  //     { label: "Test Intelligence",  path: "/intelligence/test-workspace", icon: <Science />,   alwaysVisible: true },
  //     { label: "Generated Tests",    path: "/intelligence/generated-tests",icon: <ViewList />,  alwaysVisible: true },
  //     { label: "Test Impact Analysis",path:"/intelligence/test-impact",    icon: <Analytics />, alwaysVisible: true },
  //   ],
  // },
  // {
  //   label: "Reports",
  //   path: "/reports/recommendations",
  //   icon: <BarChart />,
  //   alwaysVisible: true,
  //   children: [
  //     { label: "Recommendations",  path: "/reports/recommendations", icon: <Lightbulb />,   alwaysVisible: true },
  //     { label: "Report Generator", path: "/reports/generator",       icon: <Description />, alwaysVisible: true },
  //   ],
  // },
  {
    label: "Administration",
    path: "/admin/assessment-submissions",
    icon: <Settings />,
    // No alwaysVisible here — this section itself now goes through
    // the real "/admin" role check in isNavVisible() below, so
    // customers won't see it in the sidebar at all (RoleGuard was
    // already blocking the page; the link itself was the miss).
    children: [
      { label: "Assessment Submissions", path: "/admin/assessment-submissions", icon: <FactCheck /> },
      // Everything below still calls Supabase directly and isn't
      // wired to the real backend yet — hidden until each is
      // migrated, same as Dashboards/Artifacts/Intelligence/Reports
      // above.
      // { label: "Assessment Marketplace", path: "/admin/marketplace",  icon: <Storefront /> },
      // { label: "Customers",              path: "/admin/customers",     icon: <Business /> },
      // { label: "Users & Roles",          path: "/admin/users",         icon: <People /> },
      // { label: "Monitoring",             path: "/admin/monitoring",    icon: <MonitorHeart /> },
      // { label: "Audit Log",              path: "/admin/audit",         icon: <History /> },
      // { label: "UAT Test Plan",          path: "/admin/uat",           icon: <Assignment /> },
      // { label: "Go-Live Checklist",      path: "/admin/go-live",       icon: <RocketLaunch /> },
      // { label: "Auth Debug",             path: "/admin/debug",         icon: <BugReport /> },
      // { label: "Platform Settings",      path: "/admin/settings",      icon: <AdminPanelSettings /> },
      // { label: "Notifications",          path: "/admin/notifications", icon: <Notifications /> },
    ],
  },
];

export default function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>(["Dashboards"]);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { orgName, organizations, isSuperAdmin, overrideOrgId, switchOrg, canAccess, isLoading, subscribedPackages } = usePackage();
  const { profile, role: currentRole, isSuperAdmin: authIsSuperAdmin, signOut } = useAuth();

  const handleLogout = async () => {
    setAnchorEl(null);
    await signOut();
    navigate("/login");
  };

  /**
   * isNavVisible — single source of truth for sidebar visibility.
   * ONLY uses canAccess() from PackageContext for package-gated items.
   * No role checks for assessment items — canAccess() handles super admin internally.
   */
 const isNavVisible = (item: NavItem): boolean => {
  // Explicitly visible navigation items
  if (item.alwaysVisible) {
    return true;
  }

  // Admin items: role-based
  if (item.path.startsWith("/admin")) {
    return currentRole === "super_admin" || currentRole === "customer_admin";
  }

  // Items without package restrictions
  if (!item.routePrefix) {
    return true;
  }

  // Package-gated items
  if (isLoading) {
    return false;
  }

  return canAccess(item.routePrefix);
};

  const toggleExpand = (label: string) => {
    setExpandedItems((prev) =>
      prev.includes(label) ? prev.filter((i) => i !== label) : [...prev, label]
    );
  };

  const handleNavigation = (path: string) => {
    navigate(path);
    setMobileOpen(false);
  };

  const drawer = (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* Logo */}
      <Toolbar sx={{ bgcolor: "primary.main", color: "white", display: "flex", alignItems: "center", gap: 2 }}>
        <TesthouseLogo variant="nav" />
      </Toolbar>
      <Divider />

      {/* Org Switcher — super admins only */}
      {authIsSuperAdmin && <Box sx={{ px: 2, py: 1.5, bgcolor: "#F7F9FF", borderBottom: "1px solid #E0E4EC" }}>
        <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ display: "block", mb: 1 }}>
          VIEWING AS
        </Typography>
        <FormControl size="small" fullWidth>
          <Select
            value={overrideOrgId ?? "__admin__"}
            onChange={(e) => {
              const val = e.target.value;
              switchOrg(val === "__admin__" ? null : val);
            }}
            displayEmpty
            sx={{ fontSize: "0.8rem", bgcolor: "white" }}
          >
            <MenuItem value="__admin__">
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Chip label="ADMIN" size="small"
                  sx={{ bgcolor: "#2B3E7E", color: "white", fontWeight: 700, fontSize: "0.6rem", height: 18 }} />
                <Typography variant="body2" fontWeight={700}>Super Admin</Typography>
              </Box>
            </MenuItem>
            <Divider key="org-switcher-divider" />
            {isLoading ? (
              <MenuItem disabled>
                <CircularProgress size={14} sx={{ mr: 1 }} /> Loading…
              </MenuItem>
            ) : (
              organizations.map((org) => (
                <MenuItem key={org.id} value={org.id}>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Business sx={{ fontSize: 14, color: "text.secondary" }} />
                    <Box>
                      <Typography variant="body2">{org.name}</Typography>
                      <Typography variant="caption" color="text.secondary">{org.code}</Typography>
                    </Box>
                  </Box>
                </MenuItem>
              ))
            )}
          </Select>
        </FormControl>
        {/* Show subscribed packages under the switcher */}
        {subscribedPackages.length > 0 && (
          <Box sx={{ mt: 1, display: "flex", gap: 0.5, flexWrap: "wrap" }}>
            {subscribedPackages.map((pkg) => (
              <Chip key={pkg.package_code} label={pkg.package_name} size="small"
                sx={{ bgcolor: `${pkg.color ?? "#2B3E7E"}18`, color: pkg.color ?? "#2B3E7E",
                  fontWeight: 700, fontSize: "0.6rem", height: 18 }} />
            ))}
          </Box>
        )}
      </Box>}

      {/* Package chips for non-admin users */}
      {!authIsSuperAdmin && subscribedPackages.length > 0 && (
        <Box sx={{ px: 2, py: 1, bgcolor: "#F7F9FF", borderBottom: "1px solid #E0E4EC", display: "flex", gap: 0.5, flexWrap: "wrap" }}>
          {subscribedPackages.map((pkg) => (
            <Chip key={pkg.package_code} label={pkg.package_name} size="small"
              sx={{ bgcolor: `${pkg.color ?? "#2B3E7E"}18`, color: pkg.color ?? "#2B3E7E",
                fontWeight: 700, fontSize: "0.6rem", height: 18 }} />
          ))}
        </Box>
      )}

      {/* Nav items */}
      <List sx={{ flex: 1, overflowY: "auto", py: 1 }}>
        {/* Loading skeleton while subscriptions are being fetched */}
        {isLoading && (
          <Box sx={{ px: 2, py: 3, textAlign: "center" }}>
            <CircularProgress size={20} />
            <Typography variant="caption" color="text.secondary" sx={{ display: "block", mt: 1 }}>
              Loading your access…
            </Typography>
          </Box>
        )}
        {!isLoading && navigationItems.map((item) => {
          if (!isNavVisible(item)) return null;

          // Filter children by entitlement
          const visibleChildren = item.children?.filter((c) => isNavVisible(c));
          if (item.children && visibleChildren?.length === 0) return null;

          return (
            <Box key={item.label}>
              <ListItem disablePadding>
                <ListItemButton
                  onClick={() => {
                    if (item.children) toggleExpand(item.label);
                    else handleNavigation(item.path);
                  }}
                  selected={location.pathname === item.path && !item.children}
                  sx={{ py: 0.8 }}
                >
                  <ListItemIcon sx={{ minWidth: 36 }}>{item.icon}</ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    primaryTypographyProps={{ fontSize: "0.85rem", fontWeight: 600 }}
                  />
                  {item.children && (
                    <ChevronRight sx={{
                      fontSize: 16,
                      transform: expandedItems.includes(item.label) ? "rotate(90deg)" : "rotate(0deg)",
                      transition: "transform 0.2s",
                    }} />
                  )}
                </ListItemButton>
              </ListItem>

              {item.children && expandedItems.includes(item.label) && (
                <List disablePadding sx={{ pl: 2 }}>
                  {visibleChildren?.map((child) => (
                    <ListItem key={child.label} disablePadding>
                      <ListItemButton
                        onClick={() => handleNavigation(child.path)}
                        selected={location.pathname === child.path}
                        sx={{ py: 0.5 }}
                      >
                        <ListItemIcon sx={{ minWidth: 32 }}>{child.icon}</ListItemIcon>
                        <ListItemText
                          primary={child.label}
                          primaryTypographyProps={{ fontSize: "0.8rem" }}
                        />
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
              )}
            </Box>
          );
        })}
      </List>
    </Box>
  );

  return (
    <Box sx={{ display: "flex" }}>
      <AppBar position="fixed" sx={{
        width: { sm: `calc(100% - ${drawerWidth}px)` },
        ml: { sm: `${drawerWidth}px` },
      }}>
        <Toolbar>
          <IconButton color="inherit" edge="start" onClick={() => setMobileOpen(!mobileOpen)}
            sx={{ mr: 2, display: { sm: "none" } }}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1, fontSize: "0.95rem", fontWeight: 600 }}>
            Quality Engineering Intelligence Platform
          </Typography>

          {/* Current org indicator in top bar */}
          {orgName && (
            <Chip
              label={orgName}
              size="small"
              icon={<Business sx={{ fontSize: "14px !important" }} />}
              sx={{ mr: 2, bgcolor: "rgba(255,255,255,0.2)", color: "white", fontWeight: 700, fontSize: "0.72rem" }}
            />
          )}

          <IconButton color="inherit" sx={{ mr: 1 }}>
            <Notifications />
          </IconButton>
          <IconButton onClick={(e) => setAnchorEl(e.currentTarget)} color="inherit">
            <Avatar sx={{ width: 32, height: 32 }}><Person /></Avatar>
          </IconButton>
          <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={() => setAnchorEl(null)}>
            <MenuItem disabled>
              <Box>
                <Typography variant="body2" fontWeight={700}>
                  {profile?.full_name ?? "User"}
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ textTransform: "capitalize" }}>
                  {currentRole.replace("_", " ")}
                </Typography>
              </Box>
            </MenuItem>
            <Divider />
            <MenuItem onClick={() => { setAnchorEl(null); navigate("/profile/my-assessments"); }}>My Assessments</MenuItem>
            <MenuItem onClick={handleLogout} sx={{ color: "error.main" }}>Logout</MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      <Box component="nav" sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}>
        <Drawer variant="temporary" open={mobileOpen} onClose={() => setMobileOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{ display: { xs: "block", sm: "none" }, "& .MuiDrawer-paper": { boxSizing: "border-box", width: drawerWidth } }}>
          {drawer}
        </Drawer>
        <Drawer variant="permanent"
          sx={{ display: { xs: "none", sm: "block" }, "& .MuiDrawer-paper": { boxSizing: "border-box", width: drawerWidth } }}
          open>
          {drawer}
        </Drawer>
      </Box>

      <Box component="main" sx={{
        flexGrow: 1, p: 3, width: { sm: `calc(100% - ${drawerWidth}px)` },
        mt: 8, bgcolor: "grey.100", minHeight: "100vh",
      }}>
        <Outlet />
      </Box>
    </Box>
  );
}
