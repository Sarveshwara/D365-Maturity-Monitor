const API_URL = "http://localhost:3001/api";

export interface LoginResponse {
  success: boolean;
  message: string;
  token: string;
  user: {
    id: string;
    organizationId: string | null;
    name: string;
    email: string;
    role: string;
  };
}

/**
 * Generic API request helper.
 *
 * Automatically attaches the Project Orbit JWT token
 * stored during login.
 */
export async function apiRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {

  const token = localStorage.getItem(
    "project_orbit_token"
  );

  const response = await fetch(
    `${API_URL}${endpoint}`,
    {
      ...options,

      headers: {
        "Content-Type": "application/json",

        ...(token
          ? {
              Authorization: `Bearer ${token}`,
            }
          : {}),

        ...(options.headers || {}),
      },
    }
  );

  const data = await response.json();

  if (!response.ok) {

    throw new Error(
      data.message ||
      `Request failed with status ${response.status}`
    );

  }

  return data;
}


/**
 * Backend Login
 */
export async function login(
  email: string,
  password: string
): Promise<LoginResponse> {

  try {

    const response = await fetch(
      `${API_URL}/auth/login`,
      {
        method: "POST",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify({
          email,
          password,
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {

      throw new Error(
        data.message || "Login failed"
      );

    }

    return data;

  } catch (error) {

    if (error instanceof Error) {
      throw error;
    }

    throw new Error(
      "Unable to connect to Project Orbit API"
    );
  }
}


/**
 * Logout helper
 */
export function logout() {

  localStorage.removeItem(
    "project_orbit_token"
  );

  localStorage.removeItem(
    "project_orbit_user"
  );

}