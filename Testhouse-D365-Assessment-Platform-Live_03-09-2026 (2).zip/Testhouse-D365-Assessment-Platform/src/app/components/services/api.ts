const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:3001/api";

export interface AuthUser {
  id: string;
  organizationId: string | null;
  name: string;
  email: string;
  role: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  token: string;
  user: AuthUser;
}

/**
 * Generic API request helper.
 *
 * Automatically attaches the Project Orbit JWT token
 * stored during login.
 */
export async function apiRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {

  const token = localStorage.getItem(
    "project_orbit_token"
  );

  const response = await fetch(
    `${API_URL}${endpoint}`,
    {
      ...options,

      headers: {
        "Content-Type": "application/json",

        ...(token
          ? {
              Authorization: `Bearer ${token}`,
            }
          : {}),

        ...(options.headers || {}),
      },
    }
  );

  const data = await response.json();

  if (!response.ok) {

    throw new Error(
      data.message ||
      `Request failed with status ${response.status}`
    );

  }

  return data;
}


/**
 * Backend Login
 */
export async function login(
  email: string,
  password: string
): Promise<LoginResponse> {

  try {

    const response = await fetch(
      `${API_URL}/auth/login`,
      {
        method: "POST",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify({
          email,
          password,
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {

      throw new Error(
        data.message || "Login failed"
      );

    }

    return data;

  } catch (error) {

    if (error instanceof Error) {
      throw error;
    }

    throw new Error(
      "Unable to connect to Project Orbit API"
    );
  }
}


/**
 * Backend Register (self-service signup)
 *
 * Returns the same shape as login — the server issues a token
 * immediately so a new signup is authenticated right away.
 */
export async function register(
  name: string,
  email: string,
  password: string
): Promise<LoginResponse> {

  try {

    const response = await fetch(
      `${API_URL}/auth/register`,
      {
        method: "POST",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify({
          name,
          email,
          password,
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {

      throw new Error(
        data.message || "Sign up failed"
      );

    }

    return data;

  } catch (error) {

    if (error instanceof Error) {
      throw error;
    }

    throw new Error(
      "Unable to connect to Project Orbit API"
    );
  }
}


/**
 * Request a password reset email.
 * Always resolves — the backend responds success either way so this
 * can't be used to check which emails are registered.
 */
export async function forgotPassword(
  email: string
): Promise<{ success: boolean; message: string }> {

  const response = await fetch(
    `${API_URL}/auth/forgot-password`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "Unable to send reset email");
  }

  return data;
}


/**
 * Complete a password reset using the token from the emailed link.
 */
export async function resetPassword(
  token: string,
  password: string
): Promise<{ success: boolean; message: string }> {

  const response = await fetch(
    `${API_URL}/auth/reset-password`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, password }),
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || "Unable to reset password");
  }

  return data;
}


/**
 * Logout helper
 */
export function logout() {

  localStorage.removeItem(
    "project_orbit_token"
  );

  localStorage.removeItem(
    "project_orbit_user"
  );

}
