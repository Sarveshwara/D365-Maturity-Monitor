import { useState } from "react";
import { useLocation, useNavigate } from "react-router";
import {
  Card, CardContent, Typography, Box, Grid, Chip, Button,
  LinearProgress, Table, TableBody, TableCell, TableHead,
  TableRow, Divider,
} from "@mui/material";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Cell, PieChart, Pie, Legend,
} from "recharts";
import {
  Download, Share, Warning, CheckCircle, Error as ErrorIcon,
  Speed, Assessment, ArrowForward,
} from "@mui/icons-material";
import {
  performanceCategories, scorePerformanceAssessment,
  getRiskColor,
} from "../../data/performanceQuestions";

const CAT_COLORS: Record<string, string> = {
  TRAFFIC: "#0F6CBD", SLA: "#107C10", BUSINESS: "#D83B01",
  ARCHITECTURE: "#8764B8", DATA: "#038387", INCIDENTS: "#C43501",
  RELEASE: "#E65C00", REGULATORY: "#004E8C",
};

const RECOMMENDATION_CONFIG = {
  CRITICAL: { color: "#D83B01", bg: "#FFF0EE", label: "MANDATORY", icon: <ErrorIcon sx={{ color: "#D83B01" }} />, detail: "Performance Testing is mandatory. Critical risk factors identified. Do not release without completing a full performance test cycle." },
  HIGH: { color: "#D83B01", bg: "#FFF5F2", label: "STRONGLY RECOMMENDED", icon: <Warning sx={{ color: "#E65C00" }} />, detail: "Performance Testing is strongly recommended. Significant risk factors identified. Schedule performance testing in the current sprint/cycle." },
  MEDIUM: { color: "#FFB900", bg: "#FFFBF0", label: "RECOMMENDED", icon: <Warning sx={{ color: "#FFB900" }} />, detail: "Performance Testing is recommended. Risk factors present. Plan performance testing in the next release cycle." },
  LOW: { color: "#107C10", bg: "#F0FBF2", label: "OPTIONAL", icon: <CheckCircle sx={{ color: "#107C10" }} />, detail: "Performance Testing is optional. Low risk profile. Consider lightweight smoke testing as a precaution." },
};

const MITIGATION_ACTIONS = [
  { priority: "P0", label: "Enable real-time APM monitoring (Dynatrace / Datadog / New Relic) on all critical paths", urgency: "Immediate" },
  { priority: "P0", label: "Implement auto-scaling policies with validated scale-out triggers", urgency: "Immediate" },
  { priority: "P0", label: "Configure circuit breakers and timeout controls on all external API calls", urgency: "Immediate" },
  { priority: "P0", label: "Set proactive alerting: CPU > 70%, Memory > 80%, Response Time > SLA", urgency: "Immediate" },
  { priority: "P1", label: "Conduct smoke performance test at 25% of expected peak load", urgency: "This Week" },
  { priority: "P1", label: "Review and optimise slow database queries via APM profiling", urgency: "This Week" },
  { priority: "P1", label: "Enable CDN caching for static assets and API responses where applicable", urgency: "This Week" },
  { priority: "P2", label: "Define and document target performance baselines (response time, TPS, error rate)", urgency: "This Sprint" },
  { priority: "P2", label: "Establish performance regression gates in the CI/CD pipeline", urgency: "This Sprint" },
  { priority: "P3", label: "Schedule quarterly performance benchmark reviews", urgency: "Next Release" },
];

const CONSEQUENCE_TABLE = [
  { risk: "Production Outage", consequence: "App crashes under real peak load", impact: "Revenue loss, SLA breach, emergency response", cost: "$10K–$5M+ per hour" },
  { risk: "Performance Degradation", consequence: "Pages > 5–10s response — cart abandonment", impact: "Bounce rate increase, negative reviews", cost: "$50K–$1M per event" },
  { risk: "SLA Penalty", consequence: "Contractual breaches trigger penalties", impact: "Direct financial loss, contract risk", cost: "$25K–$500K per breach" },
  { risk: "Customer Churn", consequence: "Users switch to competitors permanently", impact: "Long-term revenue reduction", cost: "$100–$5K per churned user" },
  { risk: "Compliance Breach", consequence: "Regulated system failures trigger audit", impact: "Regulatory fines, mandatory remediation", cost: "$50K–$20M+" },
];

function RiskBadge({ level }: { level: string }) {
  const color = level === "High" ? "#D83B01" : level === "Medium" ? "#FFB900" : "#107C10";
  return (
    <Box sx={{ display: "inline-flex", px: 1, py: 0.2, borderRadius: 1, bgcolor: `${color}18`, border: `1px solid ${color}40` }}>
      <Typography variant="caption" fontWeight={700} sx={{ color }}>{level}</Typography>
    </Box>
  );
}

export default function PerformanceResults() {
  const location = useLocation();
  const navigate = useNavigate();
  const { answers = {} } = (location.state as any) ?? {};
  const result = scorePerformanceAssessment(answers);
  const [exporting, setExporting] = useState<"pdf" | "excel" | null>(null);

  const buildExportData = () => ({
    overallScore: result.overallScore,
    recommendation: result.recommendation,
    answers,
    categoryScores: performanceCategories.map((cat) => {
      const cs = result.categoryScores[cat.id];
      return { id: cat.id, name: cat.name, score: cs?.raw ?? 0, maxScore: cat.maxScore, pct: cs?.pct ?? 0, risk: result.recommendation };
    }),
  });

  const handleExportPDF = async () => {
    setExporting("pdf");
    const { exportPerformancePDF } = await import("../../lib/export-service");
    exportPerformancePDF(buildExportData());
    setExporting(null);
  };

  const handleExportExcel = async () => {
    setExporting("excel");
    const { exportPerformanceExcel } = await import("../../lib/export-service");
    exportPerformanceExcel(buildExportData());
    setExporting(null);
  };
  const recConfig = RECOMMENDATION_CONFIG[result.recommendation];

  // Chart data
  const barData = performanceCategories.map((cat) => ({
    name: cat.name.split(" ")[0],
    score: result.categoryScores[cat.id]?.pct ?? 0,
    fill: CAT_COLORS[cat.id] ?? "#2B3E7E",
  }));

  const radarData = performanceCategories.map((cat) => ({
    domain: cat.name.split(" ").slice(0, 2).join(" "),
    score: result.categoryScores[cat.id]?.pct ?? 0,
    fullMark: 100,
  }));

  const pieData = [
    { name: "High Risk Sections", value: Object.values(result.categoryScores).filter((s) => s.pct >= 75).length, color: "#D83B01" },
    { name: "Medium Risk Sections", value: Object.values(result.categoryScores).filter((s) => s.pct >= 40 && s.pct < 75).length, color: "#FFB900" },
    { name: "Low Risk Sections", value: Object.values(result.categoryScores).filter((s) => s.pct < 40).length, color: "#107C10" },
  ].filter((d) => d.value > 0);

  return (
    <Box sx={{ maxWidth: 1100, mx: "auto" }}>
      {/* Header */}
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 3 }}>
        <Box>
          <Typography variant="h4" fontWeight={800} sx={{ color: "#0F6CBD" }}>
            Performance Testing Assessment Report
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            {result.totalAnswered} of {result.totalQuestions} questions answered · Generated{" "}
            {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
          </Typography>
        </Box>
        <Box sx={{ display: "flex", gap: 1.5 }}>
          <Button variant="outlined" startIcon={<Download />} size="small"
            onClick={handleExportExcel} disabled={!!exporting}>
            {exporting === "excel" ? "Exporting…" : "Export Excel"}
          </Button>
          <Button variant="contained" startIcon={<Download />} size="small"
            onClick={handleExportPDF} disabled={!!exporting}
            sx={{ bgcolor: "#0F6CBD" }}>
            {exporting === "pdf" ? "Exporting…" : "Export PDF"}
          </Button>
        </Box>
      </Box>

      {/* ── Main recommendation card ─────────────────────────────────────────── */}
      <Card sx={{ mb: 3, border: `2px solid ${recConfig.color}`, bgcolor: recConfig.bg }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: "flex", gap: 3, flexWrap: "wrap" }}>
            {/* Score gauge */}
            <Box sx={{ textAlign: "center", flexShrink: 0 }}>
              <Box sx={{ position: "relative", width: 110, height: 110, mx: "auto" }}>
                <svg width="110" height="110" style={{ transform: "rotate(-90deg)" }}>
                  <circle cx="55" cy="55" r="46" fill="none" stroke="#E8ECF4" strokeWidth="10" />
                  <circle cx="55" cy="55" r="46" fill="none"
                    stroke={recConfig.color} strokeWidth="10"
                    strokeDasharray={`${2 * Math.PI * 46}`}
                    strokeDashoffset={`${2 * Math.PI * 46 * (1 - result.normalizedScore / 100)}`}
                    strokeLinecap="round" />
                </svg>
                <Box sx={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
                  <Typography variant="h3" fontWeight={900} sx={{ color: recConfig.color, lineHeight: 1 }}>
                    {result.normalizedScore}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">/100</Typography>
                </Box>
              </Box>
              <Typography variant="caption" color="text.secondary">Normalised Score</Typography>
            </Box>

            <Box sx={{ flex: 1 }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
                {recConfig.icon}
                <Chip label={recConfig.label} size="small"
                  sx={{ bgcolor: recConfig.color, color: "white", fontWeight: 800, fontSize: "0.8rem" }} />
              </Box>
              <Typography variant="h5" fontWeight={800} sx={{ color: recConfig.color, mb: 1 }}>
                {result.riskLabel}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.6 }}>
                {recConfig.detail}
              </Typography>
              <Box sx={{ display: "flex", gap: 2, mt: 2, flexWrap: "wrap" }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">Questions Answered</Typography>
                  <Typography variant="h6" fontWeight={800}>{result.totalAnswered}/{result.totalQuestions}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">High Risk Sections</Typography>
                  <Typography variant="h6" fontWeight={800} sx={{ color: "#D83B01" }}>
                    {Object.values(result.categoryScores).filter((s) => s.pct >= 75).length}
                  </Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">Incident Probability</Typography>
                  <Typography variant="h6" fontWeight={800}>
                    {result.normalizedScore >= 75 ? "65–90%" : result.normalizedScore >= 50 ? "40–65%" : result.normalizedScore >= 25 ? "15–40%" : "< 15%"}
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>

      {/* ── Category Breakdown Table ─────────────────────────────────────────── */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Category-Wise Score Breakdown</Typography>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ bgcolor: "#F0F6FF" }}>
                {["Category", "Questions", "Raw Score", "Max Score", "Category %", "Risk"].map((h) => (
                  <TableCell key={h} sx={{ fontWeight: 700, color: "#0F6CBD", fontSize: "0.75rem" }}>{h}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {performanceCategories.map((cat) => {
                const cs = result.categoryScores[cat.id];
                return (
                  <TableRow key={cat.id} hover>
                    <TableCell>
                      <Typography variant="body2" fontWeight={600} sx={{ color: CAT_COLORS[cat.id] }}>
                        {cat.name}
                      </Typography>
                    </TableCell>
                    <TableCell>{cat.questions.length}</TableCell>
                    <TableCell>{cs.raw}</TableCell>
                    <TableCell>{cs.max}</TableCell>
                    <TableCell>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <LinearProgress variant="determinate" value={cs.pct}
                          sx={{ flex: 1, height: 6, borderRadius: 3, bgcolor: "#F0F0F0",
                            "& .MuiLinearProgress-bar": { bgcolor: getRiskColor(cs.pct) } }} />
                        <Typography variant="caption" fontWeight={700} sx={{ minWidth: 35, color: getRiskColor(cs.pct) }}>
                          {cs.pct}%
                        </Typography>
                      </Box>
                    </TableCell>
                    <TableCell><RiskBadge level={cs.risk} /></TableCell>
                  </TableRow>
                );
              })}
              <TableRow sx={{ bgcolor: "#F7F9FF" }}>
                <TableCell colSpan={4}>
                  <Typography variant="body2" fontWeight={800}>FINAL NORMALISED SCORE</Typography>
                </TableCell>
                <TableCell>
                  <Typography variant="body2" fontWeight={900} sx={{ color: getRiskColor(result.normalizedScore) }}>
                    {result.normalizedScore}%
                  </Typography>
                </TableCell>
                <TableCell>
                  <RiskBadge level={result.normalizedScore >= 75 ? "High" : result.normalizedScore >= 40 ? "Medium" : "Low"} />
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* ── Charts ──────────────────────────────────────────────────────────── */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, md: 7 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC" }}>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Risk Score by Category</Typography>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={barData} layout="vertical" margin={{ left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: 11 }} />
                  <YAxis dataKey="name" type="category" width={90} tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: number) => [`${v}%`, "Risk Score"]} />
                  <Bar dataKey="score" radius={[0, 4, 4, 0]}>
                    {barData.map((entry, i) => (
                      <Cell key={`perf-bar-cell-${i}`} fill={getRiskColor(entry.score)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 5 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC" }}>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Risk Distribution</Typography>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80}
                    paddingAngle={3} dataKey="value">
                    {pieData.map((entry, i) => (
                      <Cell key={`perf-pie-cell-${i}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* ── Business Impact ──────────────────────────────────────────────────── */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>
            Business Risk Analysis — Impact of Not Conducting Performance Testing
          </Typography>
          <Box sx={{ overflowX: "auto" }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: "#FFF5F2" }}>
                  {["Risk Category", "Consequence", "Business Impact", "Estimated Cost Exposure"].map((h) => (
                    <TableCell key={h} sx={{ fontWeight: 700, color: "#D83B01", fontSize: "0.75rem", whiteSpace: "nowrap" }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {CONSEQUENCE_TABLE.map((row, i) => (
                  <TableRow key={i} hover>
                    <TableCell><Typography variant="body2" fontWeight={700}>{row.risk}</Typography></TableCell>
                    <TableCell><Typography variant="caption">{row.consequence}</Typography></TableCell>
                    <TableCell><Typography variant="caption" color="text.secondary">{row.impact}</Typography></TableCell>
                    <TableCell>
                      <Typography variant="caption" fontWeight={700} sx={{ color: "#D83B01" }}>{row.cost}</Typography>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        </CardContent>
      </Card>

      {/* ── Mitigation Actions ───────────────────────────────────────────────── */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 0.5 }}>
            Risk Mitigation Actions
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: "block", mb: 2 }}>
            If performance testing cannot be conducted immediately, implement these interim mitigations. These do not replace a full PT engagement.
          </Typography>
          {MITIGATION_ACTIONS.map((action, i) => {
            const pColor = action.priority === "P0" ? "#D83B01" : action.priority === "P1" ? "#E65C00" : action.priority === "P2" ? "#FFB900" : "#107C10";
            return (
              <Box key={i} sx={{
                display: "flex", gap: 2, p: 1.5, mb: 1, borderRadius: 2,
                border: "1px solid", borderColor: "divider", alignItems: "center",
                borderLeft: `4px solid ${pColor}`,
              }}>
                <Chip label={action.priority} size="small"
                  sx={{ bgcolor: `${pColor}15`, color: pColor, fontWeight: 800, minWidth: 36 }} />
                <Typography variant="body2" sx={{ flex: 1 }}>{action.label}</Typography>
                <Chip label={action.urgency} size="small" variant="outlined"
                  sx={{ fontSize: "0.65rem", flexShrink: 0 }} />
              </Box>
            );
          })}
        </CardContent>
      </Card>

      {/* ── Sign-off ─────────────────────────────────────────────────────────── */}
      <Card elevation={0} sx={{ border: "1px solid #E0E4EC", mb: 3 }}>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Assessment Sign-Off & Next Steps</Typography>
          <Grid container spacing={2}>
            {[
              { label: "Assessment Reviewed By", value: "" },
              { label: "Review Date", value: new Date().toLocaleDateString("en-GB") },
              { label: "Approved By / Authority", value: "" },
              { label: "Next Review Date", value: "" },
              { label: "PT Tool Recommended", value: "JMeter / k6 / Gatling / Locust" },
              { label: "PT Environment", value: "Performance / Staging" },
              { label: "Estimated PT Effort", value: "3–5 days" },
              { label: "PT Priority", value: result.recommendation },
            ].map((item) => (
              <Grid size={{ xs: 12, sm: 6, md: 3 }} key={item.label}>
                <Box sx={{ p: 1.5, border: "1px solid", borderColor: "divider", borderRadius: 1.5 }}>
                  <Typography variant="caption" color="text.secondary" fontWeight={600}>{item.label}</Typography>
                  <Typography variant="body2" fontWeight={item.value ? 600 : 400}
                    sx={{ color: item.value ? "text.primary" : "text.disabled", mt: 0.3 }}>
                    {item.value || "—"}
                  </Typography>
                </Box>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>

      {/* Footer actions */}
      <Box sx={{ display: "flex", gap: 2, justifyContent: "flex-end" }}>
        <Button variant="outlined" startIcon={<Speed />} onClick={() => navigate("/performance")}>
          New Assessment
        </Button>
        <Button variant="outlined" startIcon={<Download />}
          onClick={handleExportExcel} disabled={!!exporting}>
          {exporting === "excel" ? "Exporting…" : "Export Excel"}
        </Button>
        <Button variant="contained" startIcon={<Download />}
          onClick={handleExportPDF} disabled={!!exporting}
          sx={{ bgcolor: "#0F6CBD" }}>
          {exporting === "pdf" ? "Exporting…" : "Export PDF Report"}
        </Button>
      </Box>
    </Box>
  );
}
