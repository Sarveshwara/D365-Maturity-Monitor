import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Card, CardContent, Typography, Box, Button, LinearProgress,
  Chip, TextField, Divider,
} from "@mui/material";
import { ArrowForward, ArrowBack, Save, CheckCircle } from "@mui/icons-material";
import {
  performanceCategories,
  scorePerformanceAssessment,
  getRiskColor,
  type PerformanceQuestion,
} from "../../data/performanceQuestions";

// ─── Category colours ─────────────────────────────────────────────────────────
const CAT_COLORS: Record<string, string> = {
  TRAFFIC: "#0F6CBD",
  SLA: "#107C10",
  BUSINESS: "#D83B01",
  ARCHITECTURE: "#8764B8",
  DATA: "#038387",
  INCIDENTS: "#C43501",
  RELEASE: "#E65C00",
  REGULATORY: "#004E8C",
};

// Score option labels colour bands
const SCORE_STYLES: Record<number, { border: string; bg: string; text: string }> = {
  0: { border: "#107C10", bg: "#F0FBF2", text: "#107C10" },
  1: { border: "#4CAF50", bg: "#F5FBF5", text: "#2E7D32" },
  2: { border: "#FFB900", bg: "#FFFBF0", text: "#B8860B" },
  3: { border: "#E65C00", bg: "#FFF5F0", text: "#E65C00" },
  4: { border: "#D83B01", bg: "#FFF0EE", text: "#D83B01" },
};

const SCORE_LABELS = ["None / N/A", "Low", "Medium", "High", "Critical"];

function OptionCard({
  q, option, selected, onSelect,
}: {
  q: PerformanceQuestion;
  option: { score: number; label: string; description: string };
  selected: boolean;
  onSelect: () => void;
}) {
  const s = SCORE_STYLES[option.score];
  return (
    <Box
      onClick={onSelect}
      role="radio"
      aria-checked={selected}
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && onSelect()}
      sx={{
        display: "flex",
        alignItems: "flex-start",
        gap: 2,
        p: 1.5,
        mb: 1,
        border: `2px solid ${selected ? s.border : "#E0E4EC"}`,
        borderRadius: 2,
        bgcolor: selected ? s.bg : "background.paper",
        cursor: "pointer",
        transition: "all 0.12s",
        "&:hover": { borderColor: s.border, bgcolor: s.bg },
      }}
    >
      {/* Radio */}
      <Box sx={{
        flexShrink: 0, width: 20, height: 20, borderRadius: "50%",
        border: `2px solid ${selected ? s.border : "#BDBDBD"}`,
        bgcolor: selected ? s.border : "transparent",
        display: "flex", alignItems: "center", justifyContent: "center", mt: 0.1,
      }}>
        {selected && <Box sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: "white" }} />}
      </Box>

      <Box sx={{ flex: 1 }}>
        <Box sx={{ display: "inline-flex", alignItems: "center", gap: 1, mb: 0.3 }}>
          <Box sx={{ px: 1, py: 0.1, borderRadius: 0.8, bgcolor: `${s.border}20` }}>
            <Typography variant="caption" fontWeight={800} sx={{ color: s.text }}>
              {SCORE_LABELS[option.score]}
            </Typography>
          </Box>
        </Box>
        <Typography variant="body2" color="text.primary" sx={{ lineHeight: 1.5 }}>
          {option.description}
        </Typography>
      </Box>

      {selected && <CheckCircle sx={{ color: s.border, fontSize: 18, flexShrink: 0, mt: 0.15 }} />}
    </Box>
  );
}

export default function PerformanceQuestionnaire() {
  const navigate = useNavigate();
  const [sectionIdx, setSectionIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});

  const totalQuestions = performanceCategories.reduce((s, c) => s + c.questions.length, 0);
  const answeredCount = Object.keys(answers).length;
  const currentCat = performanceCategories[sectionIdx];
  const catColor = CAT_COLORS[currentCat.id] ?? "#2B3E7E";

  // Live section score
  const sectionAnswered = currentCat.questions.filter((q) => answers[q.id] != null);
  const sectionRaw = currentCat.questions.reduce((s, q) => s + (answers[q.id] ?? 0) * q.weight, 0);
  const sectionPct = currentCat.maxScore > 0 ? Math.round((sectionRaw / currentCat.maxScore) * 100) : 0;

  // Overall live score
  const liveResult = scorePerformanceAssessment(answers);

  const allSectionAnswered = currentCat.questions.every((q) => answers[q.id] != null);
  const isLast = sectionIdx === performanceCategories.length - 1;

  const handleNext = () => {
    if (isLast) {
      navigate("/performance/results", { state: { answers, notes } });
    } else {
      setSectionIdx(sectionIdx + 1);
      window.scrollTo(0, 0);
    }
  };

  return (
    <Box sx={{ maxWidth: 1100, mx: "auto" }}>
      {/* Top header */}
      <Box sx={{ mb: 3 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 }}>
          <Typography variant="h5" fontWeight={700} sx={{ color: catColor }}>
            Performance Testing Assessment
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {answeredCount} of {totalQuestions} answered
          </Typography>
        </Box>

        {/* Section tabs */}
        <Box sx={{ display: "flex", gap: 0.5, mb: 1.5, flexWrap: "wrap" }}>
          {performanceCategories.map((cat, i) => {
            const done = cat.questions.every((q) => answers[q.id] != null);
            const active = i === sectionIdx;
            return (
              <Box
                key={cat.id}
                onClick={() => setSectionIdx(i)}
                sx={{
                  px: 1.5, py: 0.4, borderRadius: 2, cursor: "pointer", fontSize: "0.7rem",
                  fontWeight: active ? 700 : 500,
                  border: `1px solid ${active ? catColor : done ? "#4DD4AC" : "#E0E4EC"}`,
                  bgcolor: active ? catColor : done ? "#E8FBF5" : "#F7F9FF",
                  color: active ? "white" : done ? "#107C10" : "text.secondary",
                  transition: "all 0.15s",
                  "&:hover": { opacity: 0.8 },
                }}
              >
                {i + 1}. {cat.name.split(" ")[0]}
              </Box>
            );
          })}
        </Box>

        <LinearProgress variant="determinate" value={(answeredCount / totalQuestions) * 100}
          sx={{ height: 4, borderRadius: 2, bgcolor: "#E8ECF4" }} />
        <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: "block" }}>
          Section {sectionIdx + 1} of {performanceCategories.length} — {currentCat.name}
        </Typography>
      </Box>

      <Box sx={{ display: "flex", gap: 3, alignItems: "flex-start" }}>
        {/* Left — questions */}
        <Box sx={{ flex: "1 1 0", minWidth: 0 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", borderRadius: 3, mb: 2 }}>
            <CardContent sx={{ p: 3 }}>
              {/* Section header */}
              <Box sx={{
                display: "flex", alignItems: "center", gap: 1.5, mb: 2.5,
                p: 2, borderRadius: 2, bgcolor: `${catColor}0D`, border: `1px solid ${catColor}30`,
              }}>
                <Box>
                  <Typography variant="subtitle1" fontWeight={800} sx={{ color: catColor }}>
                    {currentCat.name}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {currentCat.description}
                  </Typography>
                </Box>
                <Box sx={{ ml: "auto", textAlign: "right", flexShrink: 0 }}>
                  <Typography variant="caption" color="text.secondary">Section Progress</Typography>
                  <Typography variant="h6" fontWeight={800} sx={{ color: catColor }}>
                    {sectionAnswered.length}/{currentCat.questions.length}
                  </Typography>
                </Box>
              </Box>

              {/* Questions */}
              {currentCat.questions.map((q, qi) => (
                <Box key={q.id} sx={{ mb: 4 }}>
                  <Box sx={{ display: "flex", gap: 1.5, mb: 1.5 }}>
                    <Box sx={{
                      flexShrink: 0, width: 26, height: 26, borderRadius: "50%",
                      bgcolor: answers[q.id] != null ? catColor : "#E0E4EC",
                      color: answers[q.id] != null ? "white" : "text.secondary",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: "0.75rem", fontWeight: 700,
                    }}>
                      {qi + 1}
                    </Box>
                    <Box sx={{ flex: 1 }}>
                      <Box sx={{ display: "flex", gap: 1, mb: 0.5 }}>
                        <Chip label={q.id} size="small"
                          sx={{ bgcolor: `${catColor}18`, color: catColor, fontWeight: 700, fontSize: "0.65rem" }} />
                        <Chip label={`Weight: ${q.weight}`} size="small" variant="outlined"
                          sx={{ fontSize: "0.65rem" }} />
                      </Box>
                      <Typography variant="body1" fontWeight={600} sx={{ mb: 1.5, lineHeight: 1.5 }}>
                        {q.question}
                      </Typography>

                      {q.options.map((opt) => (
                        <OptionCard
                          key={opt.score}
                          q={q}
                          option={opt}
                          selected={answers[q.id] === opt.score}
                          onSelect={() => setAnswers((prev) => ({ ...prev, [q.id]: opt.score }))}
                        />
                      ))}

                      <TextField
                        fullWidth
                        size="small"
                        multiline
                        rows={1}
                        label="Notes / observations (optional)"
                        placeholder="Add context or evidence for this answer…"
                        value={notes[q.id] ?? ""}
                        onChange={(e) => setNotes((prev) => ({ ...prev, [q.id]: e.target.value }))}
                        sx={{ mt: 1.5, "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
                      />
                    </Box>
                  </Box>
                  {qi < currentCat.questions.length - 1 && <Divider sx={{ mt: 2 }} />}
                </Box>
              ))}
            </CardContent>
          </Card>

          {/* Navigation */}
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Button variant="outlined" startIcon={<ArrowBack />}
              onClick={() => { setSectionIdx(Math.max(0, sectionIdx - 1)); window.scrollTo(0, 0); }}
              disabled={sectionIdx === 0}>
              Previous Section
            </Button>
            <Button variant="text" startIcon={<Save />} size="small" sx={{ color: "text.secondary" }}>
              Save Draft
            </Button>
            <Button variant="contained" endIcon={<ArrowForward />}
              onClick={handleNext}
              sx={{ bgcolor: catColor, "&:hover": { bgcolor: `${catColor}CC` }, minWidth: 160 }}>
              {isLast ? "View Results" : "Next Section"}
            </Button>
          </Box>
        </Box>

        {/* Right — intelligence panel */}
        <Box sx={{ flexShrink: 0, width: 260 }}>
          <Card elevation={0} sx={{ border: "1px solid #E0E4EC", borderRadius: 3, position: "sticky", top: 80 }}>
            <CardContent sx={{ p: 2.5 }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 2 }}>
                Live Assessment Score
              </Typography>

              {/* Overall score ring */}
              <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
                <Box sx={{ position: "relative", width: 90, height: 90 }}>
                  <svg width="90" height="90" style={{ transform: "rotate(-90deg)" }}>
                    <circle cx="45" cy="45" r="38" fill="none" stroke="#E8ECF4" strokeWidth="8" />
                    <circle cx="45" cy="45" r="38" fill="none"
                      stroke={getRiskColor(liveResult.normalizedScore)}
                      strokeWidth="8"
                      strokeDasharray={`${2 * Math.PI * 38}`}
                      strokeDashoffset={`${2 * Math.PI * 38 * (1 - liveResult.normalizedScore / 100)}`}
                      strokeLinecap="round"
                      style={{ transition: "stroke-dashoffset 0.4s ease" }}
                    />
                  </svg>
                  <Box sx={{
                    position: "absolute", inset: 0, display: "flex",
                    flexDirection: "column", alignItems: "center", justifyContent: "center",
                  }}>
                    <Typography variant="h5" fontWeight={900}
                      sx={{ color: getRiskColor(liveResult.normalizedScore) }}>
                      {liveResult.normalizedScore}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1 }}>/100</Typography>
                  </Box>
                </Box>
              </Box>

              {/* Recommendation badge */}
              <Box sx={{
                textAlign: "center", mb: 2, px: 1.5, py: 1, borderRadius: 2,
                bgcolor: `${getRiskColor(liveResult.normalizedScore)}15`,
                border: `1px solid ${getRiskColor(liveResult.normalizedScore)}40`,
              }}>
                <Typography variant="caption" fontWeight={800}
                  sx={{ color: getRiskColor(liveResult.normalizedScore) }}>
                  {liveResult.recommendation} RISK
                </Typography>
              </Box>

              {/* Section scores */}
              <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ display: "block", mb: 1 }}>
                Section Scores
              </Typography>
              {performanceCategories.map((cat) => {
                const cs = liveResult.categoryScores[cat.id];
                const col = CAT_COLORS[cat.id] ?? "#2B3E7E";
                return (
                  <Box key={cat.id} sx={{ mb: 1 }}>
                    <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.2 }}>
                      <Typography variant="caption" sx={{ color: col, fontWeight: sectionIdx === performanceCategories.indexOf(cat) ? 700 : 400 }}>
                        {cat.name.split(" ")[0]}
                      </Typography>
                      <Typography variant="caption" fontWeight={700} sx={{ color: getRiskColor(cs.pct) }}>
                        {cs.pct}%
                      </Typography>
                    </Box>
                    <LinearProgress variant="determinate" value={cs.pct}
                      sx={{
                        height: 4, borderRadius: 2, bgcolor: "#E8ECF4",
                        "& .MuiLinearProgress-bar": { bgcolor: getRiskColor(cs.pct) },
                      }}
                    />
                  </Box>
                );
              })}

              {/* Current section highlight */}
              <Box sx={{ mt: 2, pt: 2, borderTop: "1px solid", borderColor: "divider" }}>
                <Typography variant="caption" color="text.secondary" fontWeight={600}>
                  Current section risk
                </Typography>
                <Box sx={{ mt: 0.5, px: 1.5, py: 0.8, borderRadius: 1.5, bgcolor: `${getRiskColor(sectionPct)}10`, border: `1px solid ${getRiskColor(sectionPct)}40` }}>
                  <Typography variant="caption" fontWeight={700} sx={{ color: getRiskColor(sectionPct) }}>
                    {sectionPct}% — {sectionPct >= 75 ? "High" : sectionPct >= 40 ? "Medium" : "Low"} Risk
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>
      </Box>
    </Box>
  );
}
