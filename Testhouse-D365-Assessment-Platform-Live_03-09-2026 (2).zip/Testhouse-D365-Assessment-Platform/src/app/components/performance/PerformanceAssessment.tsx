import { useNavigate } from "react-router";
import {
  Card, CardContent, Typography, Box, Button, Grid, Chip, Divider,
} from "@mui/material";
import {
  Speed, PlayArrow, BarChart, Shield, Assignment, Warning,
  TrendingUp, CheckCircle, Schedule,
} from "@mui/icons-material";
import { performanceCategories } from "../../data/performanceQuestions";

const CATEGORY_COLORS: Record<string, string> = {
  TRAFFIC: "#0F6CBD",
  SLA: "#107C10",
  BUSINESS: "#D83B01",
  ARCHITECTURE: "#8764B8",
  DATA: "#038387",
  INCIDENTS: "#C43501",
  RELEASE: "#E65C00",
  REGULATORY: "#004E8C",
};

const RISK_STATS = [
  { icon: <Warning sx={{ color: "#D83B01", fontSize: 22 }} />, label: "65–90%", sublabel: "Incident probability without PT" },
  { icon: <TrendingUp sx={{ color: "#D83B01", fontSize: 22 }} />, label: "$100K–$5M+", sublabel: "Revenue loss per unplanned outage hour" },
  { icon: <Speed sx={{ color: "#FFB900", fontSize: 22 }} />, label: "1% / 100ms", sublabel: "Revenue drop per extra latency" },
  { icon: <CheckCircle sx={{ color: "#107C10", fontSize: 22 }} />, label: "53%", sublabel: "Users abandon pages > 3 seconds" },
];

export default function PerformanceAssessment() {
  const navigate = useNavigate();
  const totalQuestions = performanceCategories.reduce((s, c) => s + c.questions.length, 0);

  return (
    <Box sx={{ maxWidth: 1000, mx: "auto" }}>
      {/* Hero */}
      <Box
        sx={{
          background: "linear-gradient(135deg, #0D2137 0%, #1B365D 55%, #0F6CBD 100%)",
          borderRadius: 3,
          p: { xs: 3, md: 5 },
          mb: 4,
          color: "white",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <Box sx={{ position: "absolute", top: -30, right: -30, width: 180, height: 180, borderRadius: "50%", bgcolor: "rgba(15,108,189,0.2)" }} />
        <Box sx={{ position: "absolute", bottom: -50, right: 100, width: 120, height: 120, borderRadius: "50%", bgcolor: "rgba(15,108,189,0.12)" }} />

        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 2 }}>
          <Speed sx={{ fontSize: 32, color: "#4DD4AC" }} />
          <Chip label="Performance Engineering Assessment" size="small"
            sx={{ bgcolor: "rgba(77,212,172,0.2)", color: "#4DD4AC", fontWeight: 700, border: "1px solid rgba(77,212,172,0.4)" }} />
        </Box>

        <Typography variant="h3" fontWeight={800} sx={{ mb: 1.5, lineHeight: 1.2 }}>
          Performance Testing<br />Need Assessment
        </Typography>
        <Typography variant="body1" sx={{ opacity: 0.85, maxWidth: 560, mb: 4, lineHeight: 1.7 }}>
          A structured risk-based evaluation to determine whether performance testing is required before your next release. Generates a scored recommendation with business risk analysis.
        </Typography>

        <Box sx={{ display: "flex", gap: 4, flexWrap: "wrap", mb: 4 }}>
          {[
            { icon: <Assignment sx={{ fontSize: 18 }} />, label: `${totalQuestions} Questions` },
            { icon: <Schedule sx={{ fontSize: 18 }} />, label: "~15 Minutes" },
            { icon: <BarChart sx={{ fontSize: 18 }} />, label: "8 Risk Categories" },
            { icon: <Shield sx={{ fontSize: 18 }} />, label: "Scored Report" },
          ].map((stat) => (
            <Box key={stat.label} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
              <Box sx={{ color: "#4DD4AC" }}>{stat.icon}</Box>
              <Typography variant="body2" fontWeight={600}>{stat.label}</Typography>
            </Box>
          ))}
        </Box>

        <Button
          variant="contained"
          size="large"
          endIcon={<PlayArrow />}
          onClick={() => navigate("/performance/questionnaire")}
          sx={{
            bgcolor: "#4DD4AC", color: "#0D2137", fontWeight: 800, fontSize: "1rem",
            px: 4, py: 1.5, "&:hover": { bgcolor: "#3ab892" },
            boxShadow: "0 4px 20px rgba(77,212,172,0.4)",
          }}
        >
          Start Assessment
        </Button>
      </Box>

      {/* Industry risk benchmarks */}
      <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Why This Matters</Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {RISK_STATS.map((s) => (
          <Grid size={{ xs: 12, sm: 6, md: 3 }} key={s.label}>
            <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%", textAlign: "center" }}>
              <CardContent sx={{ py: 2.5 }}>
                <Box sx={{ mb: 1 }}>{s.icon}</Box>
                <Typography variant="h5" fontWeight={900} sx={{ lineHeight: 1.1 }}>{s.label}</Typography>
                <Typography variant="caption" color="text.secondary">{s.sublabel}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Assessment categories */}
      <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Assessment Categories</Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {performanceCategories.map((cat) => (
          <Grid size={{ xs: 12, sm: 6, md: 4 }} key={cat.id}>
            <Card elevation={0} sx={{ border: "1px solid #E0E4EC", height: "100%" }}>
              <CardContent sx={{ py: 2, px: 2.5 }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 0.5 }}>
                  <Typography variant="subtitle2" fontWeight={700}
                    sx={{ color: CATEGORY_COLORS[cat.id] ?? "#2B3E7E" }}>
                    {cat.name}
                  </Typography>
                  <Chip label={`${cat.questions.length}Q`} size="small"
                    sx={{ bgcolor: `${CATEGORY_COLORS[cat.id]}18`, color: CATEGORY_COLORS[cat.id], fontSize: "0.65rem", fontWeight: 700 }} />
                </Box>
                <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1.4 }}>
                  {cat.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* What you get */}
      <Card sx={{ bgcolor: "#F0F6FF", border: "1px solid #C9DCF5" }}>
        <CardContent sx={{ p: 3 }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 2, color: "#0F6CBD" }}>
            Assessment Output
          </Typography>
          <Grid container spacing={2}>
            {[
              { title: "Normalised Risk Score (0–100)", desc: "Weighted score across all 8 categories" },
              { title: "PT Decision Recommendation", desc: "Low / Medium / High / Critical with justification" },
              { title: "Category Breakdown", desc: "Score and risk level per assessment area" },
              { title: "Business Impact Analysis", desc: "Financial exposure and consequence matrix" },
              { title: "Priority Mitigation Actions", desc: "Immediate and planned risk reduction steps" },
              { title: "Sign-Off Ready Report", desc: "Reviewer, approver, and next steps documented" },
            ].map((item) => (
              <Grid size={{ xs: 12, sm: 6 }} key={item.title}>
                <Box sx={{ display: "flex", gap: 1.5 }}>
                  <Box sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: "#0F6CBD", mt: 0.7, flexShrink: 0 }} />
                  <Box>
                    <Typography variant="body2" fontWeight={700}>{item.title}</Typography>
                    <Typography variant="caption" color="text.secondary">{item.desc}</Typography>
                  </Box>
                </Box>
              </Grid>
            ))}
          </Grid>

          <Divider sx={{ my: 2.5 }} />

          <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
            <Button variant="contained" endIcon={<PlayArrow />}
              onClick={() => navigate("/performance/questionnaire")} size="large"
              sx={{ bgcolor: "#0F6CBD", "&:hover": { bgcolor: "#0a4f96" } }}>
              Begin Performance Assessment
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
