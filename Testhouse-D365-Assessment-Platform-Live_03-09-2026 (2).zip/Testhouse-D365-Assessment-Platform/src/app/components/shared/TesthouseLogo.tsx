import { useState } from "react";
import { Box, Typography } from "@mui/material";
import logoSrc from "../../../assets/testhouse-logo.png";

interface TesthouseLogoProps {
  height?: number;
  /** "auto" uses natural aspect ratio; a number forces that height in px */
  variant?: "default" | "nav" | "login" | "pdf-header";
  /** If true, show white wordmark fallback (for dark backgrounds) */
  darkBg?: boolean;
}

const HEIGHT_MAP: Record<string, number> = {
  nav:        44,
  login:      90,
  "pdf-header": 40,
  default:    40,
};

export default function TesthouseLogo({
  height,
  variant = "default",
  darkBg = false,
}: TesthouseLogoProps) {
  const [errored, setErrored] = useState(false);
  const h = height ?? HEIGHT_MAP[variant] ?? 40;

  if (errored) {
    return (
      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
        <Box sx={{
          width: h * 0.7, height: h * 0.7,
          borderRadius: 1,
          bgcolor: "#4DD4AC",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Typography sx={{
            color: "#1B2F6E", fontWeight: 900,
            fontSize: h * 0.4, lineHeight: 1,
          }}>T</Typography>
        </Box>
        <Typography sx={{
          color: darkBg ? "white" : "#1B2F6E",
          fontWeight: 800,
          fontSize: h * 0.38,
          letterSpacing: 0.5,
          lineHeight: 1,
        }}>
          TESTHOUSE
        </Typography>
      </Box>
    );
  }

  return (
    <img
      src={logoSrc}
      alt="Testhouse"
      height={h}
      style={{ objectFit: "contain", display: "block" }}
      onError={() => setErrored(true)}
    />
  );
}

/** Thin export of just the logo src path for use in jsPDF etc. */
export { logoSrc as testhouseLogoSrc };
