import { useEffect, useState } from "react";
import { useNavigate } from "react-router";

import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Button,
  CircularProgress,
  Alert,
  Divider,
} from "@mui/material";

import {
  Assignment,
  ArrowForward,
  CheckCircle,
  Edit,
} from "@mui/icons-material";

import {
  assessmentService,
  type AssessmentRun,
} from "../../lib/assessment-service";
import { useAuth } from "../../contexts/AuthContext";

function statusChip(status: AssessmentRun["status"]) {
  switch (status) {
    case "completed":
      return <Chip label="Completed" size="small" color="success" />;
    case "in_progress":
      return <Chip label="In Progress" size="small" color="warning" />;
    default:
      return <Chip label="Draft" size="small" />;
  }
}

export default function MyAssessments() {
  const navigate = useNavigate();
  const { role } = useAuth();
  const isCustomer = role === "customer";

  const [runs, setRuns] = useState<AssessmentRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { runs: data, error: err } = await assessmentService.list(
        "QA_MATURITY",
        50
      );

      if (!mounted) return;

      setRuns(data);
      setError(err);
      setLoading(false);
    })();

    return () => {
      mounted = false;
    };
  }, []);

  const handleOpen = (run: AssessmentRun) => {
    if (run.status === "completed") {
      navigate(`/assessment/results/${run.id}`);
    } else if (run.assessment_context?.selectedDomains) {
      // Made it past Customer Info — resume straight into the
      // questions. Questionnaire.tsx loads everything else it needs
      // (answers, notes, context) from the run itself.
      navigate("/assessment/questionnaire", { state: { runId: run.id } });
    } else {
      // Never got past Customer Info — resume there instead, with
      // whatever was already typed pre-filled.
      navigate("/assessment/customer-info", {
        state: {
          runId: run.id,
          customerInfo: run.assessment_context?.customerInfo,
          assessmentType: "D365",
          implementationType: "Greenfield",
        },
      });
    }
  };

  return (
    <Box sx={{ maxWidth: 900, mx: "auto" }}>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700} color="primary.main">
          My Assessments
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
          Everything you've started or completed, in one place.
        </Typography>
      </Box>

      {loading && (
        <Box sx={{ display: "flex", justifyContent: "center", py: 6 }}>
          <CircularProgress />
        </Box>
      )}

      {!loading && error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {!loading && !error && runs.length === 0 && (
        <Card
          elevation={0}
          sx={{ border: "1px solid #E0E4EC", borderRadius: 3 }}
        >
          <CardContent sx={{ p: 4, textAlign: "center" }}>
            <Assignment sx={{ fontSize: 40, color: "text.secondary", mb: 1 }} />
            <Typography variant="h6" fontWeight={700}>
              No assessments yet
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Start the D365 QA Maturity Assessment to see it here.
            </Typography>
            <Button
              variant="contained"
              endIcon={<ArrowForward />}
              onClick={() => navigate("/assessment")}
            >
              Start Assessment
            </Button>
          </CardContent>
        </Card>
      )}

      {!loading &&
        !error &&
        runs.map((run, index) => (
          <Card
            key={run.id}
            elevation={0}
            sx={{
              border: "1px solid #E0E4EC",
              borderRadius: 3,
              mb: index < runs.length - 1 ? 2 : 0,
            }}
          >
            <CardContent
              sx={{
                p: 3,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                flexWrap: "wrap",
                gap: 2,
              }}
            >
              <Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
                  <Typography variant="subtitle1" fontWeight={700}>
                    {run.assessment_name}
                  </Typography>
                  {statusChip(run.status)}
                </Box>

                <Typography variant="caption" color="text.secondary">
                  {run.status === "completed" && run.completed_at
                    ? `Completed ${new Date(run.completed_at).toLocaleDateString()}`
                    : `Started ${new Date(run.run_date).toLocaleDateString()}`}
                  {run.status === "completed" && run.overall_score != null && (
                    <> · Score {run.overall_score.toFixed?.(1) ?? run.overall_score} / 5.0</>
                  )}
                </Typography>
              </Box>

              {isCustomer && run.status === "completed" ? null : (
                <Button
                  variant={run.status === "completed" ? "outlined" : "contained"}
                  startIcon={run.status === "completed" ? <CheckCircle /> : <Edit />}
                  endIcon={<ArrowForward />}
                  onClick={() => handleOpen(run)}
                >
                  {run.status === "completed" ? "View Results" : "Continue"}
                </Button>
              )}
            </CardContent>

            {index < runs.length - 1 && <Divider />}
          </Card>
        ))}
    </Box>
  );
}
