// Security Assessment Toolkit — AppShield · MobileShield · InfraShield · CloudShield
// Scoring: Yes = 2pts | Partial = 1pt | No = 0pts | N/A = excluded from score
// Risk Tiers: CRITICAL 0-39% | HIGH 40-59% | MEDIUM 60-74% | LOW 75-89% | SECURE 90-100%

export type SecurityResponse = "Yes" | "Partial" | "No" | "N/A" | null;

export interface SecurityCheck {
  ref: string;
  check: string;
  whatToLookFor: string;
  criticality: "Critical" | "High" | "Medium";
}

export interface SecurityModule {
  id: "APPSHIELD" | "MOBILESHIELD" | "INFRASHIELD" | "CLOUDSHIELD";
  name: string;
  label: string;
  icon: string;
  description: string;
  checks: SecurityCheck[];
}

export const securityModules: SecurityModule[] = [
  {
    id: "APPSHIELD",
    name: "AppShield",
    label: "Web Application Security",
    icon: "🌐",
    description: "Security readiness checks for web-facing applications covering authentication, data protection, injection risks, and API security.",
    checks: [
      { ref: "AS-01", criticality: "Critical", check: "Access is only granted to users with a valid, server-enforced session — authentication applied on all routes and endpoints.", whatToLookFor: "Verify all routes require auth; unauthenticated requests return 401/403, not redirect to login only on client." },
      { ref: "AS-02", criticality: "Critical", check: "Admin and privileged accounts are protected with Multi-Factor Authentication (MFA).", whatToLookFor: "Admin console, API keys, CI/CD service accounts — all require MFA. Check IdP/SSO config." },
      { ref: "AS-03", criticality: "Critical", check: "All user input is validated server-side using an allowlist (whitelist) approach before processing.", whatToLookFor: "Input validation exists on backend, not just frontend. Allowlist schemas, not blacklists. Include file upload validation." },
      { ref: "AS-04", criticality: "Critical", check: "Output encoding applied consistently to prevent Cross-Site Scripting (XSS) — HTML, JS, URL contexts covered.", whatToLookFor: "JS/CSS/URL encoding libraries used, CSP headers set, template engine auto-escaping enabled. No dangerouslySetInnerHTML." },
      { ref: "AS-05", criticality: "Critical", check: "Parameterised queries or a trusted ORM are used for all database interactions — no string-concatenated SQL.", whatToLookFor: "Code review for raw SQL string building. ORM configured with parameterisation. Stored procedures reviewed." },
      { ref: "AS-06", criticality: "Critical", check: "All communication uses TLS 1.2+ with HSTS enforced; weak cipher suites disabled.", whatToLookFor: "SSL Labs scan ≥ A grade. HSTS header with includeSubDomains and min 1-year max-age. No TLS 1.0/1.1 in prod." },
      { ref: "AS-07", criticality: "Critical", check: "Secrets, API keys, and credentials are not stored in source code, config files, or version control.", whatToLookFor: "Git history scan (trufflehog/gitleaks). Secrets in env vars or vault. .gitignore covers .env files." },
      { ref: "AS-08", criticality: "Critical", check: "All API endpoints require authentication and enforce authorisation — IDOR and privilege escalation prevented.", whatToLookFor: "Every endpoint checked for auth. Object-level auth enforced server-side. Function-level auth tested (low-priv to high-priv)." },
      { ref: "AS-09", criticality: "High", check: "Rate limiting and abuse protection applied to login, registration, password reset, and public APIs.", whatToLookFor: "429 responses on repeated requests. CAPTCHA on auth flows. API gateway rate limits configured and tested." },
      { ref: "AS-10", criticality: "High", check: "No direct internet exposure of management interfaces (admin panels, RDP, SSH, internal APIs).", whatToLookFor: "Port scan / Shodan check. Management interfaces behind VPN or IP allowlist. No public admin-panel route." },
      { ref: "AS-11", criticality: "High", check: "Security-relevant events are logged — failed logins, auth events, admin actions, HTTP 5xx errors.", whatToLookFor: "Logs include timestamp, user, action, IP, outcome. Logs shipped to SIEM. Log tampering protections in place." },
      { ref: "AS-12", criticality: "High", check: "CSRF protection implemented on all state-changing forms and endpoints.", whatToLookFor: "CSRF tokens on forms. SameSite cookie attribute set. Double-submit cookie pattern or equivalent." },
      { ref: "AS-13", criticality: "High", check: "Session tokens are long (≥128-bit entropy), invalidated on logout, and not exposed in URLs.", whatToLookFor: "Token length and randomness verified. Logout invalidates server-side session. No session IDs in URL query strings." },
      { ref: "AS-14", criticality: "High", check: "Third-party libraries and dependencies are tracked, up-to-date, and scanned for known CVEs.", whatToLookFor: "SCA tool in CI pipeline (Snyk, Dependabot). CVSS critical/high findings have SLA for remediation. SBOM available." },
      { ref: "AS-15", criticality: "High", check: "Business logic enforced server-side — no reliance on hidden fields, cookies, or client-side checks for access control.", whatToLookFor: "Test by intercepting requests and modifying client-side values. Price, quantity, role changes rejected server-side." },
      { ref: "AS-16", criticality: "Medium", check: "Error messages returned to users contain no sensitive stack traces, database info, or internal paths.", whatToLookFor: "Trigger 400/500 errors and inspect responses. Generic user-facing messages; detail in server logs only." },
      { ref: "AS-17", criticality: "Medium", check: "Security HTTP headers are configured: X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy.", whatToLookFor: "securityheaders.com scan or manual review. All recommended headers present and correctly configured." },
      { ref: "AS-18", criticality: "Medium", check: "File upload functionality restricts file types, scans for malware, and prevents path traversal.", whatToLookFor: "Server-side type validation (magic bytes, not extension). Upload stored outside webroot. Virus scan on inbound files." },
      { ref: "AS-19", criticality: "Medium", check: "Password policy enforces minimum length (≥12 chars), complexity, and bcrypt/Argon2 hashing.", whatToLookFor: "Hashing algorithm confirmed (no MD5/SHA1). Minimum length policy enforced at registration and change." },
      { ref: "AS-20", criticality: "Medium", check: "Account lockout or progressive delay applied after repeated failed authentication attempts.", whatToLookFor: "Lockout after 5-10 failed attempts or exponential backoff. Lockout bypass tested (IP rotation, username variation)." },
      { ref: "AS-21", criticality: "Medium", check: "Sensitive data (PII, payment, health data) encrypted at rest with AES-256 or equivalent.", whatToLookFor: "Database column/disk encryption confirmed. Key management process documented. KMS or HSM used." },
      { ref: "AS-22", criticality: "Medium", check: "Business continuity and data recovery plans validated for the application — RTO and RPO defined.", whatToLookFor: "Documented RTO/RPO. Backup tested and verified (not just scheduled). Failover procedure rehearsed." },
    ],
  },
  {
    id: "MOBILESHIELD",
    name: "MobileShield",
    label: "Mobile Application Security",
    icon: "📱",
    description: "Security checks for iOS and Android mobile applications covering data storage, transport security, authentication, and binary protections.",
    checks: [
      { ref: "M2-01", criticality: "Critical", check: "No sensitive data (tokens, PII, credentials) stored in plaintext on the device — SQLite, SharedPrefs, NSUserDefaults checked.", whatToLookFor: "Inspect device storage post-login. Android: inspect /data/data/<app>. iOS: inspect app container. No cleartext secrets." },
      { ref: "M2-02", criticality: "Critical", check: "Platform credential storage used — Android Keystore / iOS Keychain for tokens and cryptographic keys.", whatToLookFor: "Token storage code reviewed. Keychain/Keystore APIs used, not UserDefaults or SharedPreferences for secrets." },
      { ref: "M2-03", criticality: "Critical", check: "Certificate pinning implemented and validated — app rejects untrusted certificates.", whatToLookFor: "Intercept traffic with Burp + custom CA. App should reject. Pinning bypass resistance (frida hooks tested)." },
      { ref: "M2-04", criticality: "Critical", check: "No hardcoded credentials, API keys, or secrets in the application binary or source code.", whatToLookFor: "strings / grep on IPA/APK. Automated secret scanning in CICD. Firebase/AWS keys not embedded." },
      { ref: "M2-05", criticality: "Critical", check: "All network communication uses TLS 1.2+ — no HTTP endpoints, no cleartext traffic allowed.", whatToLookFor: "Network Security Config (Android) / ATS (iOS) enforces HTTPS. Proxy test to confirm no HTTP fallback." },
      { ref: "M2-06", criticality: "Critical", check: "Authentication tokens have short expiry and are invalidated server-side on logout.", whatToLookFor: "Token TTL < 15 min for access tokens. Refresh tokens invalidated on logout. Server-side session revocation works." },
      { ref: "M2-07", criticality: "Critical", check: "Sensitive data not logged to device logs — no PII, tokens, or passwords in logcat/console output.", whatToLookFor: "Run app and inspect logcat/Xcode console. Ensure prod builds have logging disabled or redacted." },
      { ref: "M2-08", criticality: "High", check: "App requires device authentication (biometric/PIN) before accessing sensitive features.", whatToLookFor: "Re-authentication required after background timeout. Biometric prompt uses platform APIs correctly." },
      { ref: "M2-09", criticality: "High", check: "Jailbreak/root detection implemented and app behaviour restricted on compromised devices.", whatToLookFor: "Test on jailbroken/rooted device. App should warn or restrict functionality. Bypass resistance evaluated." },
      { ref: "M2-10", criticality: "High", check: "Inter-process communication (IPC) restricted — intents, deep links, and URL schemes validated.", whatToLookFor: "Exported activities/services reviewed in AndroidManifest. Deep link parameters validated and sanitised." },
      { ref: "M2-11", criticality: "High", check: "Code obfuscation applied to production binary (ProGuard/R8 for Android, bitcode/obfuscation for iOS).", whatToLookFor: "Decompile APK/IPA and verify class/method names obfuscated. Sensitive algorithm protection confirmed." },
      { ref: "M2-12", criticality: "High", check: "Clipboard access restricted for sensitive fields — passwords and card numbers not copyable.", whatToLookFor: "Test copy/paste on password and payment fields. Verify clipboard cleared on app background." },
      { ref: "M2-13", criticality: "High", check: "Screenshots and screen recording prevented for sensitive screens on both platforms.", whatToLookFor: "FLAG_SECURE (Android) and allowScreenshots=false (iOS) set on sensitive views." },
      { ref: "M2-14", criticality: "High", check: "Third-party SDKs and libraries used in the app are reviewed and updated — known-vulnerable SDKs removed.", whatToLookFor: "SDK inventory maintained. CVSS critical SDK CVEs remediated. Firebase, analytics, ad SDKs data access reviewed." },
      { ref: "M2-15", criticality: "High", check: "Binary integrity checks implemented — app detects tampering and modification.", whatToLookFor: "App signature verified at runtime. Repackaged/resigned app detected and refused (where applicable)." },
      { ref: "M2-16", criticality: "Medium", check: "App permissions follow least privilege — only requested permissions are necessary for functionality.", whatToLookFor: "Permission audit against feature requirements. Dangerous permissions (CAMERA, CONTACTS, LOCATION) justified." },
      { ref: "M2-17", criticality: "Medium", check: "Sensitive data excluded from iOS/Android backups — BackupAgent restricted, NSURLIsExcludedFromBackupKey set.", whatToLookFor: "Verify backup exclusion flags on sensitive data directories. iCloud/Google backup tested to confirm exclusion." },
      { ref: "M2-18", criticality: "Medium", check: "WebView usage is secure — JavaScript enabled only where necessary, local file access disabled.", whatToLookFor: "WebView settings reviewed. allowFileAccess, allowUniversalAccess disabled. addJavascriptInterface reviewed." },
      { ref: "M2-19", criticality: "Medium", check: "Error handling in the app does not expose technical detail to the user or device logs.", whatToLookFor: "Force errors and observe user-facing messages. No stack traces or server errors surfaced in UI." },
      { ref: "M2-20", criticality: "Medium", check: "Automated static analysis (SAST) run on mobile codebase in CI pipeline.", whatToLookFor: "MobSF, Semgrep, or equivalent integrated in CI. Critical findings gated in pipeline." },
      { ref: "M2-21", criticality: "Medium", check: "Dynamic analysis (DAST) / penetration test conducted on the mobile app within the last 12 months.", whatToLookFor: "Pentest report available. Findings remediated and verified. OWASP Mobile Top 10 coverage confirmed." },
      { ref: "M2-22", criticality: "Medium", check: "Privacy policy accessible in-app and data collection practices accurately declared (GDPR/CCPA/PDPA).", whatToLookFor: "In-app privacy policy link works. Data types collected match policy. User consent mechanisms reviewed." },
    ],
  },
  {
    id: "INFRASHIELD",
    name: "InfraShield",
    label: "On-Premises Infrastructure Security",
    icon: "🏗️",
    description: "Security readiness checks for on-premises data centres, servers, networks, and operational infrastructure.",
    checks: [
      { ref: "IS-01", criticality: "Critical", check: "Authorised asset inventory maintained and kept current — all servers, endpoints, and network devices accounted for.", whatToLookFor: "CMDB or asset register verified against network scan. Unknown/rogue devices identified and investigated." },
      { ref: "IS-02", criticality: "Critical", check: "Hardening baselines applied to all servers and network devices (CIS Benchmarks or equivalent).", whatToLookFor: "CIS benchmark score ≥ Level 1 on critical systems. Default credentials changed. Unnecessary services disabled." },
      { ref: "IS-03", criticality: "Critical", check: "Privileged access management (PAM) in place — no standing admin access, just-in-time (JIT) provisioning.", whatToLookFor: "PAM solution deployed (CyberArk, BeyondTrust, etc.). Admin sessions recorded. Shared admin accounts eliminated." },
      { ref: "IS-04", criticality: "Critical", check: "Network segmentation implemented — production, dev, DMZ, and management networks separated.", whatToLookFor: "Network diagram reviewed. VLAN isolation confirmed. Lateral movement paths between segments limited by firewall rules." },
      { ref: "IS-05", criticality: "Critical", check: "Patch management process documented and executed — critical CVEs patched within defined SLA (e.g., 72hrs for critical).", whatToLookFor: "Patch compliance report. Critical patches within SLA. Legacy/unsupported OS identified and risk-accepted or migrated." },
      { ref: "IS-06", criticality: "Critical", check: "MFA enforced for all remote access (VPN, RDP, SSH) and privileged console access.", whatToLookFor: "VPN gateway MFA config confirmed. SSH key-based auth + MFA. No password-only remote access." },
      { ref: "IS-07", criticality: "Critical", check: "Firewall rules follow least-privilege — deny-by-default, no ANY:ANY rules, regular review cycle in place.", whatToLookFor: "Firewall ruleset reviewed. Unused rules removed. Any rules (0.0.0.0/0 inbound) flagged and justified." },
      { ref: "IS-08", criticality: "High", check: "Vulnerability scanning run on all network-accessible systems at least monthly with findings tracked.", whatToLookFor: "Scan tool (Nessus, Qualys, OpenVAS) results reviewed. CVSS critical/high findings tracked to closure." },
      { ref: "IS-09", criticality: "High", check: "Intrusion Detection / Prevention System (IDS/IPS) deployed and alerts actively monitored.", whatToLookFor: "IDS/IPS coverage on internet-facing and lateral segments. Alert triage SLA defined. Tuning to reduce false positives." },
      { ref: "IS-10", criticality: "High", check: "Endpoint Detection and Response (EDR) deployed on all servers and workstations with up-to-date signatures.", whatToLookFor: "EDR coverage report — all endpoints enrolled. Detections reviewed and investigated. Auto-quarantine configured." },
      { ref: "IS-11", criticality: "High", check: "Data classified and handled according to sensitivity — encryption at rest for confidential and above.", whatToLookFor: "Data classification policy exists. Disk encryption on servers holding sensitive data. Key management process documented." },
      { ref: "IS-12", criticality: "High", check: "Backup and recovery tested — verified restore from backup within last 3 months.", whatToLookFor: "Backup restore test documented and dated. Recovery time meets RTO. Offsite/air-gapped copy maintained." },
      { ref: "IS-13", criticality: "High", check: "DNS, DHCP, and Active Directory secured — DNSSEC, AD tiering model, Kerberoasting protections in place.", whatToLookFor: "AD tier model (admin forest or equivalent). SPNs reviewed. DNSSEC configured. DNS logging enabled." },
      { ref: "IS-14", criticality: "High", check: "Physical access to server rooms and network equipment is controlled, logged, and reviewed.", whatToLookFor: "Access control list for server room. Badge/biometric entry logs reviewed. CCTV coverage. Visitor log maintained." },
      { ref: "IS-15", criticality: "High", check: "Security event logging centralised to SIEM — retention meets regulatory requirements (min 12 months).", whatToLookFor: "SIEM ingesting syslog, Windows events, firewall, AD. Log retention policy enforced. Alerts configured for key events." },
      { ref: "IS-16", criticality: "High", check: "Change management process enforced — no unauthorised changes to production infrastructure.", whatToLookFor: "Change tickets for infrastructure changes. Peer review on firewall rule changes. Emergency change process defined." },
      { ref: "IS-17", criticality: "Medium", check: "Network Time Protocol (NTP) synchronised across all systems — critical for log correlation and Kerberos.", whatToLookFor: "All systems sync to authoritative NTP server. Time drift < 5 minutes (Kerberos requirement). NTP server hardened." },
      { ref: "IS-18", criticality: "Medium", check: "Email security controls in place — SPF, DKIM, DMARC configured and enforced.", whatToLookFor: "SPF/DKIM/DMARC DNS records verified. DMARC policy = reject or quarantine. Anti-phishing gateway active." },
      { ref: "IS-19", criticality: "Medium", check: "Anti-malware / AV deployed on all endpoints with real-time scanning and regular definition updates.", whatToLookFor: "AV coverage report. Last definition update < 24hrs. Scan schedule confirmed. Exclusions reviewed and justified." },
      { ref: "IS-20", criticality: "Medium", check: "Security awareness training delivered to all staff annually — phishing simulation results tracked.", whatToLookFor: "Training completion rate ≥ 90%. Phishing simulation click rates tracked and improving. Escalation process for incidents." },
      { ref: "IS-21", criticality: "Medium", check: "Incident response plan documented, tested, and key personnel trained — tabletop exercise in last 12 months.", whatToLookFor: "IR plan document current and signed off. Tabletop exercise report available. RACI/contacts up-to-date." },
      { ref: "IS-22", criticality: "Medium", check: "Third-party and supplier access reviewed — external connections inventoried, access time-limited and audited.", whatToLookFor: "Supplier access register maintained. VPN accounts for third parties reviewed and disabled when not needed." },
    ],
  },
  {
    id: "CLOUDSHIELD",
    name: "CloudShield",
    label: "Cloud Security Posture",
    icon: "☁️",
    description: "Security checks for cloud-hosted environments (AWS, Azure, GCP) covering IAM, configuration, data security, and DevSecOps practices.",
    checks: [
      { ref: "CS-01", criticality: "Critical", check: "Root / super-admin cloud account secured with MFA and not used for day-to-day operations.", whatToLookFor: "Root account MFA confirmed. No access keys on root. CloudTrail / Audit Log shows no routine root usage." },
      { ref: "CS-02", criticality: "Critical", check: "Least-privilege IAM enforced — no wildcard (*) policies, no AdministratorAccess attached to users/roles routinely.", whatToLookFor: "IAM policy audit tool (IAM Access Analyzer, Cloudsplaining). Service roles scoped to needed actions only." },
      { ref: "CS-03", criticality: "Critical", check: "No public S3 / Blob / GCS buckets containing sensitive data — ACL and bucket policy reviewed.", whatToLookFor: "Cloud Security Posture scan (Prowler, ScoutSuite). Public bucket ACL check in console. S3 Block Public Access enabled account-wide." },
      { ref: "CS-04", criticality: "Critical", check: "Secrets and credentials managed via cloud secret store (AWS Secrets Manager, Azure Key Vault, GCP Secret Manager).", whatToLookFor: "No secrets in Lambda env vars, EC2 user-data, or cloud console plaintext. Secrets rotated automatically." },
      { ref: "CS-05", criticality: "Critical", check: "All cloud management APIs and console access require MFA — federated identity (SSO) used where possible.", whatToLookFor: "SSO/IdP integration confirmed. MFA enforcement policy active. API key usage audited and minimised." },
      { ref: "CS-06", criticality: "Critical", check: "Cloud audit logging enabled across all accounts and regions — CloudTrail / Activity Log / Cloud Audit Log shipping to SIEM.", whatToLookFor: "Multi-region CloudTrail active. Log bucket protected from deletion. Alerts on config changes and root usage." },
      { ref: "CS-07", criticality: "Critical", check: "Network Security Groups / Security Groups restrict inbound access — no 0.0.0.0/0 on SSH/RDP ports.", whatToLookFor: "Security group audit — SSH (22), RDP (3389) not open to internet. VPC Flow Logs enabled." },
      { ref: "CS-08", criticality: "High", check: "Cloud Security Posture Management (CSPM) tool active — continuous compliance monitoring against CIS Cloud Benchmarks.", whatToLookFor: "AWS Security Hub, Defender for Cloud, or equivalent enabled. Critical findings tracked to closure with SLA." },
      { ref: "CS-09", criticality: "High", check: "Data in cloud storage encrypted at rest with customer-managed keys (CMK) for sensitive classifications.", whatToLookFor: "KMS key assignment on RDS, S3, blob storage. CMK rotation policy ≤ 12 months. Key access logged." },
      { ref: "CS-10", criticality: "High", check: "Container images scanned for vulnerabilities in CI pipeline and only approved base images used.", whatToLookFor: "Container registry scan (ECR, ACR, Artifact Registry). Critical CVE images blocked from deployment. Base image policy enforced." },
      { ref: "CS-11", criticality: "High", check: "Kubernetes / container orchestration secured — RBAC enforced, privileged containers prohibited, pod security policies active.", whatToLookFor: "RBAC audit. No containers running as root. Network policies limiting pod-to-pod communication. Admission controllers active." },
      { ref: "CS-12", criticality: "High", check: "Compliance frameworks mapped and assessed — CIS, SOC 2, ISO 27001, PCI, HIPAA applicable controls covered.", whatToLookFor: "Compliance dashboard in CSPM tool. Framework gap analysis documented. Evidence packs for applicable controls." },
      { ref: "CS-13", criticality: "High", check: "IaC (Terraform, CloudFormation, Bicep) security scanning in CI/CD pipeline — misconfigurations blocked before deployment.", whatToLookFor: "tfsec, Checkov, or equivalent in pipeline. Policy-as-code gates block critical misconfigs. Drift detection active." },
      { ref: "CS-14", criticality: "High", check: "Cloud threat detection active — GuardDuty, Microsoft Defender for Cloud, or GCP Security Command Centre.", whatToLookFor: "Threat detection service enabled in all regions/accounts. Alerts forwarded to SIEM. Investigation playbooks defined." },
      { ref: "CS-15", criticality: "High", check: "Automated patch management for cloud-hosted OS — SSM Patch Manager, Azure Update Manager, or equivalent.", whatToLookFor: "Patch baselines defined. Critical patching SLA < 72hrs. Compliance report showing patched vs unpatched instances." },
      { ref: "CS-16", criticality: "Medium", check: "Cost and resource anomaly detection active — unexpected resource creation (cryptomining indicators) alerted.", whatToLookFor: "Budget alerts configured. AWS Cost Anomaly Detection / Azure Cost Alerts active. CloudWatch / Monitor billing alarms set." },
      { ref: "CS-17", criticality: "Medium", check: "Third-party marketplace apps and cross-account roles reviewed and least-privilege access confirmed.", whatToLookFor: "Cross-account role audit. Marketplace SaaS OAuth permissions reviewed. Unnecessary integrations revoked." },
      { ref: "CS-18", criticality: "Medium", check: "Disaster recovery and cloud resilience tested — multi-region failover or backup restore exercised in last 6 months.", whatToLookFor: "DR runbook current. Restore test report available. RTO/RPO validated against business requirements." },
    ],
  },
];

export function scoreSecurityModule(
  moduleId: string,
  answers: Record<string, SecurityResponse>
): { earned: number; maxPossible: number; score: number; criticalGaps: number; answered: number; skipped: number; notAnswered: number } {
  const module = securityModules.find((m) => m.id === moduleId);
  if (!module) return { earned: 0, maxPossible: 0, score: 0, criticalGaps: 0, answered: 0, skipped: 0, notAnswered: 0 };

  let earned = 0;
  let maxPossible = 0;
  let criticalGaps = 0;
  let answered = 0;
  let skipped = 0;
  let notAnswered = 0;

  for (const check of module.checks) {
    const response = answers[check.ref];
    if (response === "N/A") {
      skipped++;
    } else if (response == null) {
      notAnswered++;
      maxPossible += 2;
    } else {
      answered++;
      maxPossible += 2;
      if (response === "Yes") {
        earned += 2;
      } else if (response === "Partial") {
        earned += 1;
      } else if (response === "No") {
        if (check.criticality === "Critical") criticalGaps++;
      }
    }
  }

  const score = maxPossible > 0 ? Math.round((earned / maxPossible) * 100 * 10) / 10 : 0;
  return { earned, maxPossible, score, criticalGaps, answered, skipped, notAnswered };
}

export function getSecurityRiskTier(score: number): { tier: string; color: string; label: string; description: string } {
  if (score >= 90) return { tier: "SECURE", color: "#107C10", label: "Secure", description: "Strong controls. Pentest for validation / compliance." };
  if (score >= 75) return { tier: "LOW", color: "#4CAF50", label: "Low Risk", description: "Good posture with minor gaps. Targeted pentest suggested." };
  if (score >= 60) return { tier: "MEDIUM", color: "#FFB900", label: "Medium Risk", description: "Moderate risk. Pentest advisable before next release." };
  if (score >= 40) return { tier: "HIGH", color: "#E65C00", label: "High Risk", description: "Significant weaknesses. Pentest recommended urgently." };
  return { tier: "CRITICAL", color: "#D83B01", label: "Critical Risk", description: "Severe gaps. Pentest strongly recommended. Immediate action." };
}

export function getPentestSignal(score: number): string {
  if (score >= 90) return "Validation Only";
  if (score >= 75) return "Targeted Pentest";
  if (score >= 60) return "Advisable";
  if (score >= 40) return "Recommended";
  return "Immediate";
}

export function scoreOverall(answers: Record<string, SecurityResponse>): {
  overallScore: number;
  modules: Record<string, ReturnType<typeof scoreSecurityModule>>;
  riskTier: ReturnType<typeof getSecurityRiskTier>;
} {
  let totalEarned = 0;
  let totalMax = 0;
  const modules: Record<string, ReturnType<typeof scoreSecurityModule>> = {};

  for (const mod of securityModules) {
    const result = scoreSecurityModule(mod.id, answers);
    modules[mod.id] = result;
    totalEarned += result.earned;
    totalMax += result.maxPossible;
  }

  const overallScore = totalMax > 0 ? Math.round((totalEarned / totalMax) * 100 * 10) / 10 : 0;
  return { overallScore, modules, riskTier: getSecurityRiskTier(overallScore) };
}
