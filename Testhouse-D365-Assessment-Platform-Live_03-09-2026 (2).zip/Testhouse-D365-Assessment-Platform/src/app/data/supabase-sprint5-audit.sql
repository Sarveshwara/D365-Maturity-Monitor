-- ============================================================
-- Sprint 5: Audit Logs & Activity Tracking
-- Run in Supabase SQL Editor
-- ============================================================

-- ── 1. AUDIT LOGS TABLE ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type      TEXT        NOT NULL,
  -- e.g. user.login | assessment.started | assessment.completed |
  --      assessment.exported | user.invited | user.role_changed |
  --      package.assigned | org.created | org.updated
  user_id         UUID        REFERENCES auth.users(id),
  organization_id UUID        REFERENCES organizations(id),
  entity_type     TEXT,       -- 'assessment_run' | 'user' | 'org' | 'package'
  entity_id       TEXT,       -- UUID of the affected entity
  metadata        JSONB       DEFAULT '{}',
  ip_address      TEXT,
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- Indexes for fast filtering
CREATE INDEX IF NOT EXISTS idx_audit_user   ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_org    ON audit_logs(organization_id);
CREATE INDEX IF NOT EXISTS idx_audit_type   ON audit_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_time   ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);

-- ── 2. RLS ────────────────────────────────────────────────────
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "audit_select" ON audit_logs;
DROP POLICY IF EXISTS "audit_insert" ON audit_logs;

-- Super admin sees all; others see only their org's logs
CREATE POLICY "audit_select" ON audit_logs FOR SELECT
  USING (
    is_super_admin()
    OR organization_id = get_user_org_id()
    OR user_id = auth.uid()
  );

-- Any authenticated user can write audit events
CREATE POLICY "audit_insert" ON audit_logs FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

-- ── 3. HELPER VIEW ────────────────────────────────────────────
-- Enriched audit log view joining profile display names
CREATE OR REPLACE VIEW vw_audit_logs AS
SELECT
  al.id,
  al.event_type,
  al.user_id,
  p.full_name  AS user_name,
  al.organization_id,
  o.name       AS org_name,
  al.entity_type,
  al.entity_id,
  al.metadata,
  al.ip_address,
  al.created_at
FROM audit_logs al
LEFT JOIN profiles     p ON p.id = al.user_id
LEFT JOIN organizations o ON o.id = al.organization_id
ORDER BY al.created_at DESC;
