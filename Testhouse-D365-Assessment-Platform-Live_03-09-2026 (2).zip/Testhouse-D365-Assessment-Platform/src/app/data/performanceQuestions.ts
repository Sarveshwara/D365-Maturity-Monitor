export interface PerformanceAnswerOption {
  score: number; // 0-4
  label: string;
  description: string;
}

export interface PerformanceQuestion {
  id: string;
  question: string;
  weight: number; // 2, 3, or 4
  options: PerformanceAnswerOption[];
}

export interface PerformanceCategory {
  id: string;
  name: string;
  description: string;
  questions: PerformanceQuestion[];
  maxScore: number; // computed: questions.length × 4 × weight
}

const makeOptions = (
  l0: string, l1: string, l2: string, l3: string, l4: string
): PerformanceAnswerOption[] => [
  { score: 0, label: "None / Not applicable", description: l0 },
  { score: 1, label: "Low", description: l1 },
  { score: 2, label: "Medium", description: l2 },
  { score: 3, label: "High", description: l3 },
  { score: 4, label: "Critical", description: l4 },
];

export const performanceCategories: PerformanceCategory[] = [
  // ── Section 1 ──────────────────────────────────────────────────────────────
  {
    id: "TRAFFIC",
    name: "Traffic & Load Characteristics",
    description: "Understanding expected user concurrency, traffic patterns, and transaction volumes",
    maxScore: 48, // 4 questions × weight 3 × max score 4
    questions: [
      {
        id: "PERF-001",
        question: "How many concurrent users are expected during peak usage?",
        weight: 3,
        options: makeOptions(
          "Unknown / not defined",
          "< 100 concurrent users",
          "100–500 concurrent users",
          "500–2,000 concurrent users",
          "> 2,000 concurrent users or unknown spikes"
        ),
      },
      {
        id: "PERF-002",
        question: "How significant is the traffic variability or spike pattern?",
        weight: 3,
        options: makeOptions(
          "Flat / predictable traffic only",
          "Minor variability (< 20% spike)",
          "Moderate spikes (20–100% above normal)",
          "Significant spikes (2–5× normal traffic)",
          "Extreme or unpredictable spikes (> 5× or flash-crowd events)"
        ),
      },
      {
        id: "PERF-003",
        question: "Is the application expected to grow significantly in user base or load within 12 months?",
        weight: 3,
        options: makeOptions(
          "No growth expected",
          "< 10% user / load growth",
          "10–30% growth",
          "30–100% growth",
          "> 100% growth or aggressive expansion planned"
        ),
      },
      {
        id: "PERF-004",
        question: "What is the transaction volume per hour at peak load?",
        weight: 3,
        options: makeOptions(
          "Not known or measured",
          "< 1,000 TPS/hour",
          "1,000–10,000 TPS/hour",
          "10,000–100,000 TPS/hour",
          "> 100,000 TPS/hour or undefined high volume"
        ),
      },
    ],
  },
  // ── Section 2 ──────────────────────────────────────────────────────────────
  {
    id: "SLA",
    name: "Response Time & SLA Requirements",
    description: "Defined response time targets, availability SLAs, and throughput requirements",
    maxScore: 48,
    questions: [
      {
        id: "PERF-005",
        question: "What is the acceptable API / page response time target (SLA) for end-points?",
        weight: 3,
        options: makeOptions(
          "No SLA defined",
          "Lenient (> 5 seconds acceptable)",
          "Standard (2–5 seconds)",
          "Stringent (< 2 seconds)",
          "Critical (< 500ms — financial, real-time, or regulated)"
        ),
      },
      {
        id: "PERF-006",
        question: "Is there a defined availability / uptime SLA in place?",
        weight: 3,
        options: makeOptions(
          "No availability SLA defined",
          "Informal availability expectation",
          "99% uptime SLA",
          "99.9% uptime SLA",
          "99.99%+ SLA with contractual penalties"
        ),
      },
      {
        id: "PERF-007",
        question: "Are there defined throughput or transaction processing rate requirements?",
        weight: 3,
        options: makeOptions(
          "No throughput requirements defined",
          "Vague or informal throughput expectations",
          "Documented throughput targets without validation",
          "Formally defined and partially tested",
          "Formally defined, contractually bound, and continuously validated"
        ),
      },
      {
        id: "PERF-008",
        question: "Is the current application performance meeting its defined SLA / target?",
        weight: 3,
        options: makeOptions(
          "No baseline or SLA exists — unknown",
          "Meeting SLA with no recent review",
          "Partially meeting SLA — some breaches",
          "Frequently breaching SLA targets",
          "Critical SLA failures with business / financial impact"
        ),
      },
    ],
  },
  // ── Section 3 ──────────────────────────────────────────────────────────────
  {
    id: "BUSINESS",
    name: "Business Criticality & Risk",
    description: "Revenue impact, customer-facing exposure, and reputational risk if performance degrades",
    maxScore: 64, // 4 questions × weight 4 × max score 4
    questions: [
      {
        id: "PERF-009",
        question: "What is the business impact if this application experiences downtime or severe degradation?",
        weight: 4,
        options: makeOptions(
          "Negligible — internal tool, low usage",
          "Minor disruption — workarounds available",
          "Significant — delays operations or revenue impact",
          "Major — direct revenue loss or customer-facing outage",
          "Critical — complete business stoppage, regulatory exposure, or SLA breach"
        ),
      },
      {
        id: "PERF-010",
        question: "Is this a customer-facing or revenue-generating application?",
        weight: 4,
        options: makeOptions(
          "Internal only — no customer exposure",
          "Indirect customer impact",
          "Partially customer-facing or B2B",
          "Directly customer-facing — affects end users",
          "Core revenue channel — eCommerce, payments, or mission-critical service"
        ),
      },
      {
        id: "PERF-011",
        question: "What is the financial cost of performance failure per incident?",
        weight: 4,
        options: makeOptions(
          "Negligible or unknown",
          "< $10,000 per incident",
          "$10,000–$100,000 per incident",
          "$100,000–$1M per incident",
          "> $1M per incident or enterprise-wide impact"
        ),
      },
      {
        id: "PERF-012",
        question: "What is the reputational risk if performance degrades publicly?",
        weight: 4,
        options: makeOptions(
          "No public exposure",
          "Low reputational risk — limited user base",
          "Moderate — social media amplification possible",
          "High — brand-sensitive or regulated industry",
          "Severe — publicly traded, high media exposure, or government-facing"
        ),
      },
    ],
  },
  // ── Section 4 ──────────────────────────────────────────────────────────────
  {
    id: "ARCHITECTURE",
    name: "Architecture & Technical Complexity",
    description: "System complexity, third-party dependencies, database type, and CI/CD maturity",
    maxScore: 60, // 5 questions × weight 3 × max score 4
    questions: [
      {
        id: "PERF-013",
        question: "How complex is the overall system architecture?",
        weight: 3,
        options: makeOptions(
          "Simple monolith with minimal integrations",
          "Monolith with a few external API calls",
          "Service-oriented with moderate complexity",
          "Microservices with multiple distributed components",
          "Complex distributed system — event-driven, real-time, multi-cloud"
        ),
      },
      {
        id: "PERF-014",
        question: "Does the application call third-party APIs or external services in its critical paths?",
        weight: 3,
        options: makeOptions(
          "No external dependencies",
          "1–2 non-critical external calls",
          "Several external calls on non-critical paths",
          "Multiple external dependencies on critical paths",
          "Heavy reliance on third-party services with no SLA control"
        ),
      },
      {
        id: "PERF-015",
        question: "What type of database or data storage platform is used?",
        weight: 3,
        options: makeOptions(
          "Simple SQLite or file-based storage",
          "Single relational DB (MySQL/Postgres) — low volume",
          "Multi-database with moderate read/write load",
          "High-volume relational DB with complex queries or ORM",
          "Distributed DB, NoSQL, or real-time data platform under significant load"
        ),
      },
      {
        id: "PERF-016",
        question: "Is there significant background processing, batch jobs, or scheduled tasks?",
        weight: 3,
        options: makeOptions(
          "No background processing",
          "Minimal — infrequent lightweight jobs",
          "Moderate batch jobs on non-critical paths",
          "Heavy batch processing affecting DB or resource availability",
          "Mission-critical batch jobs competing with real-time traffic"
        ),
      },
      {
        id: "PERF-017",
        question: "How mature is the CI/CD and deployment process?",
        weight: 3,
        options: makeOptions(
          "Manual deployments with no automation",
          "Basic CI with manual deployment",
          "CI/CD pipeline — no performance gates",
          "CI/CD with some automated quality gates",
          "Mature pipeline with performance regression gates and automated rollback"
        ),
      },
    ],
  },
  // ── Section 5 ──────────────────────────────────────────────────────────────
  {
    id: "DATA",
    name: "Data Volume & Integration",
    description: "Database size, query complexity, integration pipelines, and message queue usage",
    maxScore: 32, // 4 questions × weight 2 × max score 4
    questions: [
      {
        id: "PERF-018",
        question: "What is the current database size or record count?",
        weight: 2,
        options: makeOptions(
          "< 1GB / minimal records",
          "1–10GB / moderate records",
          "10–100GB / large dataset",
          "100GB–1TB / very large dataset",
          "> 1TB / petabyte-scale or rapidly growing"
        ),
      },
      {
        id: "PERF-019",
        question: "Are critical API calls dependent on complex joins, sub-queries, or unoptimised queries?",
        weight: 2,
        options: makeOptions(
          "No — simple indexed queries only",
          "Mostly simple queries with occasional joins",
          "Some complex queries — partially optimised",
          "Frequent complex joins and unoptimised queries",
          "Business-critical paths rely on highly complex or unindexed queries"
        ),
      },
      {
        id: "PERF-020",
        question: "How complex are the data integrations or ETL pipelines?",
        weight: 2,
        options: makeOptions(
          "No integrations or simple file transfers",
          "Basic integrations with low data volume",
          "Moderate integrations — some transformation logic",
          "Complex ETL with multiple source systems",
          "Real-time high-volume data pipelines with strict latency requirements"
        ),
      },
      {
        id: "PERF-021",
        question: "Does the application use a message queue, event streaming, or async processing platform?",
        weight: 2,
        options: makeOptions(
          "No async or queue-based processing",
          "Basic queue with low throughput",
          "Message queue used for non-critical flows",
          "Kafka / RabbitMQ / SQS on critical paths",
          "High-throughput event streaming underpinning core business flows"
        ),
      },
    ],
  },
  // ── Section 6 ──────────────────────────────────────────────────────────────
  {
    id: "INCIDENTS",
    name: "Past Performance & Incidents",
    description: "History of performance issues, user complaints, and previous testing coverage",
    maxScore: 64,
    questions: [
      {
        id: "PERF-022",
        question: "Has the application experienced performance issues or incidents in the past 12 months?",
        weight: 4,
        options: makeOptions(
          "No known performance issues",
          "Minor one-off incidents — quickly resolved",
          "A few incidents with moderate impact",
          "Recurring performance incidents with business impact",
          "Frequent or severe performance failures — P0/P1 incidents"
        ),
      },
      {
        id: "PERF-023",
        question: "Have users reported slow performance, timeouts, or degraded experience?",
        weight: 4,
        options: makeOptions(
          "No user complaints on performance",
          "Isolated reports — not widespread",
          "Occasional reports during peak usage",
          "Regular user complaints affecting satisfaction",
          "Widespread performance complaints — high ticket volume or NPS impact"
        ),
      },
      {
        id: "PERF-024",
        question: "Has any formal performance testing been conducted previously?",
        weight: 4,
        options: makeOptions(
          "Full performance test suite — continuous validation",
          "Recent and comprehensive performance testing done",
          "Basic load test conducted — limited coverage",
          "Ad-hoc testing only — no structured approach",
          "No performance testing has ever been conducted"
        ),
      },
      {
        id: "PERF-025",
        question: "Were there any performance-related production incidents in the last 3 months?",
        weight: 4,
        options: makeOptions(
          "Zero incidents in 3 months",
          "1 minor incident — resolved quickly",
          "2–3 incidents with limited impact",
          "Multiple incidents with escalated business impact",
          "Severe or ongoing production incidents causing business loss"
        ),
      },
    ],
  },
  // ── Section 7 ──────────────────────────────────────────────────────────────
  {
    id: "RELEASE",
    name: "Upcoming Changes & Release Impact",
    description: "Planned releases, major feature changes, and capacity planning readiness",
    maxScore: 48,
    questions: [
      {
        id: "PERF-026",
        question: "Is a major release, go-live, or campaign event approaching?",
        weight: 3,
        options: makeOptions(
          "No major release planned",
          "Minor release > 3 months away",
          "Moderate release in 1–3 months",
          "Significant release within 4 weeks",
          "Critical go-live or campaign within 2 weeks"
        ),
      },
      {
        id: "PERF-027",
        question: "Does the upcoming release contain significant architectural or technical changes?",
        weight: 3,
        options: makeOptions(
          "No architectural changes",
          "Minor configuration changes only",
          "Moderate new features with some architectural impact",
          "Major new feature set with significant technical changes",
          "Full re-architecture, platform migration, or major scaling initiative"
        ),
      },
      {
        id: "PERF-028",
        question: "Has the team performed capacity planning for the upcoming release?",
        weight: 3,
        options: makeOptions(
          "Full capacity planning completed and validated",
          "Capacity planning done — not fully validated",
          "Partial capacity review completed",
          "Minimal capacity planning — informal estimates only",
          "No capacity planning conducted"
        ),
      },
      {
        id: "PERF-029",
        question: "Will a significant new feature increase resource usage, database load, or traffic?",
        weight: 3,
        options: makeOptions(
          "No resource impact expected",
          "Minimal resource increase (< 10%)",
          "Moderate increase (10–30%)",
          "Significant increase (30–100%)",
          "Major resource surge expected (> 100% or unknown impact)"
        ),
      },
    ],
  },
  // ── Section 8 ──────────────────────────────────────────────────────────────
  {
    id: "REGULATORY",
    name: "Regulatory, Compliance & Security",
    description: "Industry regulations, compliance requirements, and security/audit obligations",
    maxScore: 48,
    questions: [
      {
        id: "PERF-030",
        question: "Is the application subject to regulatory requirements (PCI-DSS, HIPAA, GDPR, SOC2, ISO 27001)?",
        weight: 3,
        options: makeOptions(
          "No regulatory requirements apply",
          "Low-regulation industry — minimal compliance",
          "Industry-standard compliance required (ISO 9001)",
          "Strict compliance required (SOC2, GDPR, ISO 27001)",
          "Critical regulated environment (PCI-DSS, HIPAA, FINRA, RBI, FDA)"
        ),
      },
      {
        id: "PERF-031",
        question: "Are performance levels monitored for compliance with accessibility or SLA obligations?",
        weight: 3,
        options: makeOptions(
          "No compliance-related performance obligations",
          "Informal performance expectations only",
          "Documented performance SLAs — not contractual",
          "Contractual SLA with monitoring in place",
          "Regulated performance targets with audit requirements and penalties"
        ),
      },
      {
        id: "PERF-032",
        question: "Is audit trail, traceability, or logging important for performance scenarios?",
        weight: 3,
        options: makeOptions(
          "No audit trail requirements",
          "Basic logging — no audit obligation",
          "Standard application logging required",
          "Audit trail required — some gaps in coverage",
          "Full audit trail mandatory — regulatory or legal obligation"
        ),
      },
      {
        id: "PERF-033",
        question: "Has a penetration test or security assessment been conducted recently?",
        weight: 3,
        options: makeOptions(
          "No security testing required or planned",
          "Internal security review only",
          "Penetration test > 12 months ago",
          "Penetration test within last 12 months",
          "Continuous security testing with mandatory compliance validation"
        ),
      },
    ],
  },
];

// ── Scoring helpers ───────────────────────────────────────────────────────────

export interface PerformanceScoreResult {
  normalizedScore: number; // 0–100
  recommendation: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  riskLabel: string;
  categoryScores: Record<string, { raw: number; max: number; pct: number; risk: string }>;
  totalAnswered: number;
  totalQuestions: number;
}

export function scorePerformanceAssessment(
  answers: Record<string, number>
): PerformanceScoreResult {
  const categoryScores: PerformanceScoreResult["categoryScores"] = {};
  let totalWeightedRaw = 0;
  let totalWeightedMax = 0;
  let totalAnswered = 0;
  const totalQuestions = performanceCategories.reduce((s, c) => s + c.questions.length, 0);

  for (const cat of performanceCategories) {
    let raw = 0;
    let max = 0;
    for (const q of cat.questions) {
      const ans = answers[q.id];
      max += q.weight * 4;
      if (ans != null) {
        raw += q.weight * ans;
        totalAnswered++;
      }
    }
    const pct = max > 0 ? Math.round((raw / max) * 100) : 0;
    categoryScores[cat.id] = {
      raw,
      max,
      pct,
      risk: pct >= 75 ? "High" : pct >= 40 ? "Medium" : "Low",
    };
    totalWeightedRaw += raw;
    totalWeightedMax += max;
  }

  const normalizedScore =
    totalWeightedMax > 0 ? Math.round((totalWeightedRaw / totalWeightedMax) * 100) : 0;

  let recommendation: PerformanceScoreResult["recommendation"];
  let riskLabel: string;
  if (normalizedScore >= 75) {
    recommendation = "CRITICAL";
    riskLabel = "Critical Risk — Performance Testing is Mandatory";
  } else if (normalizedScore >= 50) {
    recommendation = "HIGH";
    riskLabel = "High Risk — Performance Testing is Strongly Recommended";
  } else if (normalizedScore >= 25) {
    recommendation = "MEDIUM";
    riskLabel = "Medium Risk — Performance Testing is Recommended";
  } else {
    recommendation = "LOW";
    riskLabel = "Low Risk — Performance Testing is Optional";
  }

  return { normalizedScore, recommendation, riskLabel, categoryScores, totalAnswered, totalQuestions };
}

export function getRiskColor(score: number): string {
  if (score >= 75) return "#D83B01";
  if (score >= 40) return "#FFB900";
  return "#107C10";
}
