-- ============================================================
-- Testhouse QA Intelligence Platform — Assessment Packages Schema
-- Run this in: https://supabase.com/dashboard/project/duiguffglsmymsrfzuqo/sql/new
-- ============================================================

-- ── 1. ASSESSMENT DOMAINS ────────────────────────────────────
-- Represents individual assessment types the platform supports.
CREATE TABLE IF NOT EXISTS assessment_domains (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  domain_code   TEXT        UNIQUE NOT NULL,
  domain_name   TEXT        NOT NULL,
  route_prefix  TEXT        NOT NULL,   -- frontend route e.g. '/performance'
  description   TEXT,
  icon          TEXT,                   -- emoji or icon name
  active        BOOLEAN     DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- ── 2. ASSESSMENT PACKAGES ───────────────────────────────────
-- Products offered to customers (what they purchase).
CREATE TABLE IF NOT EXISTS assessment_packages (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  package_code  TEXT        UNIQUE NOT NULL,
  package_name  TEXT        NOT NULL,
  description   TEXT,
  color         TEXT        DEFAULT '#2B3E7E',
  active        BOOLEAN     DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- ── 3. PACKAGE → DOMAIN MAPPING ──────────────────────────────
-- Which domains are included in each package.
CREATE TABLE IF NOT EXISTS package_domains (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id  UUID        NOT NULL REFERENCES assessment_packages(id) ON DELETE CASCADE,
  domain_id   UUID        NOT NULL REFERENCES assessment_domains(id)  ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT now(),
  UNIQUE (package_id, domain_id)
);

-- ── 4. ORGANIZATIONS ─────────────────────────────────────────
-- Customer organizations / tenants.
CREATE TABLE IF NOT EXISTS organizations (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT        NOT NULL,
  code          TEXT        UNIQUE NOT NULL,
  contact_email TEXT,
  industry      TEXT,
  active        BOOLEAN     DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- ── 5. CUSTOMER SUBSCRIPTIONS ────────────────────────────────
-- Assigns a package to an organization (the entitlement).
CREATE TABLE IF NOT EXISTS customer_subscriptions (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID        NOT NULL REFERENCES organizations(id)        ON DELETE CASCADE,
  package_id      UUID        NOT NULL REFERENCES assessment_packages(id)  ON DELETE CASCADE,
  active          BOOLEAN     DEFAULT true,
  start_date      DATE        DEFAULT CURRENT_DATE,
  end_date        DATE,
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE (organization_id, package_id)
);

-- ── 6. APP USERS (pre-auth placeholder) ─────────────────────
-- Simplified user table; replace with Supabase Auth + profiles later.
CREATE TABLE IF NOT EXISTS app_users (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  email           TEXT        UNIQUE NOT NULL,
  full_name       TEXT,
  organization_id UUID        REFERENCES organizations(id),
  role            TEXT        NOT NULL DEFAULT 'assessor',
  -- roles: super_admin | customer_admin | assessor | viewer
  active          BOOLEAN     DEFAULT true,
  created_at      TIMESTAMPTZ DEFAULT now()
);

-- ── 7. VIEWS ─────────────────────────────────────────────────

-- vw_customer_domains: domains visible to each customer
CREATE OR REPLACE VIEW vw_customer_domains AS
SELECT
  o.id            AS organization_id,
  o.name          AS organization_name,
  p.package_code,
  p.package_name,
  d.domain_code,
  d.domain_name,
  d.route_prefix,
  d.icon
FROM organizations            o
JOIN customer_subscriptions   cs ON cs.organization_id = o.id   AND cs.active = true
JOIN assessment_packages       p  ON p.id = cs.package_id        AND p.active  = true
JOIN package_domains           pd ON pd.package_id = p.id
JOIN assessment_domains        d  ON d.id  = pd.domain_id        AND d.active  = true;

-- vw_org_accessible_routes: just the route prefixes per org (for quick frontend lookup)
CREATE OR REPLACE VIEW vw_org_accessible_routes AS
SELECT DISTINCT
  o.id            AS organization_id,
  d.route_prefix
FROM organizations            o
JOIN customer_subscriptions   cs ON cs.organization_id = o.id   AND cs.active = true
JOIN assessment_packages       p  ON p.id = cs.package_id        AND p.active  = true
JOIN package_domains           pd ON pd.package_id = p.id
JOIN assessment_domains        d  ON d.id  = pd.domain_id        AND d.active  = true;

-- ── 8. SEED DATA ─────────────────────────────────────────────

-- Domains
INSERT INTO assessment_domains (domain_code, domain_name, route_prefix, description, icon) VALUES
('QA_MATURITY',  'QA Maturity Assessment',   '/assessment', 'Full QA maturity covering strategy, process, automation, and governance', '📊'),
('PERFORMANCE',  'Performance Assessment',    '/performance','Performance engineering, load testing, and environment readiness',          '⚡'),
('SECURITY',     'Security Assessment',       '/security',   'Security posture across AppShield, MobileShield, InfraShield, CloudShield', '🔒'),
('DEVOPS',       'DevOps Assessment',         '/devops-maturity', 'DevOps maturity, CI/CD pipeline, and release engineering',             '🚀'),
('BENCHMARKING', 'Benchmarking & Analytics',  '/benchmarking','Industry benchmarking and comparative analytics',                          '📈')
ON CONFLICT (domain_code) DO NOTHING;

-- Packages
INSERT INTO assessment_packages (package_code, package_name, description, color) VALUES
('QA_FULL', 'QA Maturity Assessment',     'Complete QA maturity assessment across all domains: strategy, automation, tools, process, skills, and metrics', '#2B3E7E'),
('PERF',    'Performance Assessment',     'Performance engineering readiness covering architecture, environment configuration, and load testing practices',  '#0F6CBD'),
('SEC',     'Security Assessment',        'Security posture and pentest readiness across web application, mobile, on-premises infrastructure, and cloud',    '#6B3FBE'),
('AUTO',    'Test Automation Assessment', 'Test automation strategy, toolchain selection, framework maturity, and CI/CD integration assessment',             '#107C10'),
('DEVOPS',  'DevOps Assessment',          'DevOps maturity covering CI/CD pipelines, infrastructure as code, release engineering, and quality gates',       '#038387')
ON CONFLICT (package_code) DO NOTHING;

-- Package → Domain mappings
DO $$
DECLARE
  v_qa_full  UUID; v_perf  UUID; v_sec  UUID; v_auto UUID; v_devops_pkg UUID;
  v_qa_mat   UUID; v_perf_d UUID; v_sec_d UUID; v_devops_d UUID; v_bench UUID;
BEGIN
  -- Package IDs
  SELECT id INTO v_qa_full   FROM assessment_packages WHERE package_code = 'QA_FULL';
  SELECT id INTO v_perf      FROM assessment_packages WHERE package_code = 'PERF';
  SELECT id INTO v_sec       FROM assessment_packages WHERE package_code = 'SEC';
  SELECT id INTO v_auto      FROM assessment_packages WHERE package_code = 'AUTO';
  SELECT id INTO v_devops_pkg FROM assessment_packages WHERE package_code = 'DEVOPS';

  -- Domain IDs
  SELECT id INTO v_qa_mat    FROM assessment_domains WHERE domain_code = 'QA_MATURITY';
  SELECT id INTO v_perf_d    FROM assessment_domains WHERE domain_code = 'PERFORMANCE';
  SELECT id INTO v_sec_d     FROM assessment_domains WHERE domain_code = 'SECURITY';
  SELECT id INTO v_devops_d  FROM assessment_domains WHERE domain_code = 'DEVOPS';
  SELECT id INTO v_bench     FROM assessment_domains WHERE domain_code = 'BENCHMARKING';

  -- QA_FULL → all domains
  INSERT INTO package_domains (package_id, domain_id) VALUES
    (v_qa_full, v_qa_mat), (v_qa_full, v_perf_d), (v_qa_full, v_sec_d),
    (v_qa_full, v_devops_d), (v_qa_full, v_bench)
  ON CONFLICT DO NOTHING;

  -- PERF → Performance + Benchmarking
  INSERT INTO package_domains (package_id, domain_id) VALUES
    (v_perf, v_perf_d), (v_perf, v_bench)
  ON CONFLICT DO NOTHING;

  -- SEC → Security
  INSERT INTO package_domains (package_id, domain_id) VALUES
    (v_sec, v_sec_d)
  ON CONFLICT DO NOTHING;

  -- AUTO → QA Maturity (automation-focused subset)
  INSERT INTO package_domains (package_id, domain_id) VALUES
    (v_auto, v_qa_mat)
  ON CONFLICT DO NOTHING;

  -- DEVOPS → DevOps + Benchmarking
  INSERT INTO package_domains (package_id, domain_id) VALUES
    (v_devops_pkg, v_devops_d), (v_devops_pkg, v_bench)
  ON CONFLICT DO NOTHING;
END $$;

-- Demo Organizations
INSERT INTO organizations (name, code, contact_email, industry) VALUES
('Acme Corp',         'ACME',     'admin@acme.com',       'Financial Services'),
('TechStart Ltd',     'TECHSTART', 'cto@techstart.io',    'Technology'),
('GlobalBank Plc',    'GLBANK',   'qa@globalbank.com',    'Banking'),
('RetailNow Inc',     'RETAIL',   'testing@retailnow.com','Retail')
ON CONFLICT (code) DO NOTHING;

-- Demo Subscriptions
DO $$
DECLARE
  v_acme    UUID; v_techstart UUID; v_glbank UUID; v_retail UUID;
  v_qa_full UUID; v_perf      UUID; v_sec    UUID;
BEGIN
  SELECT id INTO v_acme      FROM organizations WHERE code = 'ACME';
  SELECT id INTO v_techstart FROM organizations WHERE code = 'TECHSTART';
  SELECT id INTO v_glbank    FROM organizations WHERE code = 'GLBANK';
  SELECT id INTO v_retail    FROM organizations WHERE code = 'RETAIL';

  SELECT id INTO v_qa_full FROM assessment_packages WHERE package_code = 'QA_FULL';
  SELECT id INTO v_perf    FROM assessment_packages WHERE package_code = 'PERF';
  SELECT id INTO v_sec     FROM assessment_packages WHERE package_code = 'SEC';

  -- Acme → Full QA
  INSERT INTO customer_subscriptions (organization_id, package_id, notes)
  VALUES (v_acme, v_qa_full, 'Annual enterprise contract')
  ON CONFLICT DO NOTHING;

  -- TechStart → Performance only
  INSERT INTO customer_subscriptions (organization_id, package_id, notes)
  VALUES (v_techstart, v_perf, 'Pre-launch performance audit')
  ON CONFLICT DO NOTHING;

  -- GlobalBank → Security only
  INSERT INTO customer_subscriptions (organization_id, package_id, notes)
  VALUES (v_glbank, v_sec, 'Regulatory compliance requirement')
  ON CONFLICT DO NOTHING;

  -- RetailNow → Performance + Security
  INSERT INTO customer_subscriptions (organization_id, package_id, notes)
  VALUES (v_retail, v_perf, 'Q4 load testing readiness')
  ON CONFLICT DO NOTHING;
  INSERT INTO customer_subscriptions (organization_id, package_id, notes)
  VALUES (v_retail, v_sec, 'PCI DSS compliance audit')
  ON CONFLICT DO NOTHING;
END $$;
