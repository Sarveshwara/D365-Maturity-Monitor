// ============================================================
// D365 EXECUTIVE QA ASSESSMENT
// CENTRAL QUESTION BANK + SCORING ENGINE
// ============================================================

// ============================================================
// TYPES
// ============================================================

export type ImplementationType =
  | "Greenfield"
  | "Brownfield"
  | "Big Bang"
  | "Phased Rollout"
  | "Lift & Shift"
  | "Template Rollout";

export type AssessmentDomain =
  | "Architecture"
  | "Implementation"
  | "Product"
  | "Fit for Purpose"
  | "Project Governance"
  | "Competency"
  | "Support"
  | "Release Management"
  | "Quality Engineering"
  | "Data Quality"
  | "Security & Access Governance"
  | "Integration Testing";

export interface AnswerOption {
  level: number;
  label: string;
  score: number;
  response: string;
  recommendation: string;
  businessImpact: string;
}

export interface AssessmentQuestion {
  id: string;
  domain: AssessmentDomain;
  capability?: string;
  question: string;

  /**
   * If defined, this question is applicable only
   * to the specified implementation type.
   */
  implementationType?: ImplementationType;

  options: AnswerOption[];
}

export interface AssessmentAnswer {
  questionId: string;
  level: number;
}

export interface DomainResult {
  domain: AssessmentDomain;
  score: number;
  percentage: number;
  answered: number;
  total: number;
  completion: number;
}

export interface Recommendation {
  questionId: string;
  domain: AssessmentDomain;
  question: string;
  level: number;
  score: number;
  recommendation: string;
  businessImpact: string;
}

export interface AssessmentResult {
  overallScore: number;
  overallPercentage: number;
  maturityLevel: string;
  answeredQuestions: number;
  totalQuestions: number;
  completion: number;
  domainResults: DomainResult[];
  strengths: Recommendation[];
  improvementAreas: Recommendation[];
}


// ============================================================
// MATURITY LEVELS
// ============================================================

export function getMaturityLevel(
  score: number
): string {
  if (score < 1.5) {
    return "Initial";
  }

  if (score < 2.5) {
    return "Developing";
  }

  if (score < 3.5) {
    return "Defined";
  }

  if (score < 4.5) {
    return "Managed";
  }

  return "Optimized";
}


// ============================================================
// SCORE CONVERSION
// ============================================================

export function getPercentageFromLevel(
  level: number
): number {
  const percentages: Record<
    number,
    number
  > = {
    1: 20,
    2: 40,
    3: 60,
    4: 80,
    5: 100,
  };

  return percentages[level] ?? 0;
}


// ============================================================
// VALIDATION HELPERS
// ============================================================

export function isValidMaturityLevel(
  value: unknown
): value is number {
  return (
    typeof value === "number" &&
    Number.isFinite(value) &&
    value >= 1 &&
    value <= 5
  );
}

export function isValidAnswer(
  answers: Record<string, number>,
  questionId: string
): boolean {
  return isValidMaturityLevel(
    answers[questionId]
  );
}


// ============================================================
// QUESTION BANK
// ============================================================

export const assessmentQuestions: AssessmentQuestion[] = [
  {
    id: "Q-001",
    domain: "Architecture",
    capability: "Architecture",
    question:
      "How are business-critical data validation controls, test data management practices, reconciliation accuracy, and post-go-live data quality trends continuously governed to ensure operational integrity across the D365 lifecycle?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Test data and reconciliation validation are manually managed with limited governance or post-go-live monitoring.",
        recommendation:
          "Establish formal test data governance, reconciliation standards, and operational quality KPIs.",
        businessImpact:
          "High probability of financial inconsistencies, audit failures, and production disruption.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic reconciliation and test data controls exist for selected business entities, but governance remains inconsistent.",
        recommendation:
          "Expand test data management coverage and standardize reconciliation monitoring across modules.",
        businessImpact:
          "Recurring data quality issues increase operational support overhead.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Critical data validation and test data controls are formally governed with periodic KPI reviews and partial automation.",
        recommendation:
          "Increase automated reconciliation coverage and implement trend-based operational monitoring.",
        businessImpact:
          "Improved data reliability with reduced migration-related defects.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Data validation and reconciliation risks are proactively monitored using automated controls and quality indicators.",
        recommendation:
          "Introduce predictive data quality analytics and intelligent anomaly detection.",
        businessImpact:
          "Strong operational data integrity with reduced financial and compliance exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Data quality controls continuously adapt using predictive insights and intelligent monitoring across the D365 lifecycle.",
        recommendation:
          "Sustain intelligent data quality engineering and continuously optimize preventive controls.",
        businessImpact:
          "Highly resilient and continuously optimized data quality governance.",
      },
    ],
  },

  {
    id: "Q-002",
    domain: "Product",
    capability: "Product",
    question:
      "How effectively are D365 product capabilities, customizations, extensions, and configuration changes validated to ensure functional quality and maintainability?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Validation is largely manual and focused on individual functional changes with limited regression coverage.",
        recommendation:
          "Establish structured functional regression testing and customization impact assessment.",
        businessImpact:
          "High risk of functional regression and unstable business processes.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Core product capabilities are tested, but customization and extension impacts are inconsistently assessed.",
        recommendation:
          "Standardize regression coverage and introduce customization dependency analysis.",
        businessImpact:
          "Moderate risk of recurring defects and increased maintenance effort.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Functional and customization testing follows defined standards with planned regression coverage.",
        recommendation:
          "Expand automated regression testing and change impact analysis.",
        businessImpact:
          "Improved product stability and reduced functional regression risk.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Product quality and customization risks are proactively monitored using automated validation and quality KPIs.",
        recommendation:
          "Introduce predictive change-risk analytics and intelligent regression optimization.",
        businessImpact:
          "Strong product reliability with controlled change risk.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Product quality continuously adapts to usage patterns, change history, and predictive quality signals.",
        recommendation:
          "Sustain intelligent product quality engineering and continuous optimization.",
        businessImpact:
          "Highly resilient and continuously optimized product quality.",
      },
    ],
  },

  {
    id: "Q-003",
    domain: "Fit for Purpose",
    capability: "Fit for Purpose",
    question:
      "How effectively are D365 business processes validated against real operational scenarios, transaction volumes, user journeys, and business outcomes?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Business validation focuses on isolated functional scenarios with limited production alignment.",
        recommendation:
          "Introduce end-to-end business process validation using real-world transaction flows.",
        businessImpact:
          "High probability of operational process failures after go-live.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Core business processes are tested, but production-like volumes and operational metrics are inconsistently validated.",
        recommendation:
          "Expand production-aligned scenario coverage and operational KPI validation.",
        businessImpact:
          "Moderate operational inefficiencies and reduced user confidence.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Business-critical scenarios are formally validated using representative transaction patterns and partial operational analytics.",
        recommendation:
          "Implement continuous business process monitoring and trend-based validation.",
        businessImpact:
          "Improved operational reliability and reduced business disruption.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Operational process quality and business KPIs are proactively monitored across release cycles.",
        recommendation:
          "Introduce predictive business analytics and process observability dashboards.",
        businessImpact:
          "Strong business continuity with improved process stability.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven operational intelligence continuously optimizes business process quality and user experience outcomes.",
        recommendation:
          "Maintain predictive business quality engineering and continuous optimization initiatives.",
        businessImpact:
          "Enterprise-grade business process resilience with highly reliable operations.",
      },
    ],
  },

  {
    id: "Q-004",
    domain: "Release Management",
    capability: "Release Management",
    question:
      "How are D365 releases, hotfixes, configuration changes, and deployment dependencies validated and governed across environments?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Release validation is largely manual with limited dependency analysis and inconsistent deployment controls.",
        recommendation:
          "Establish formal release validation, environment controls, and deployment readiness criteria.",
        businessImpact:
          "High risk of failed deployments and production instability.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic release controls exist, but dependency validation and regression coverage remain inconsistent.",
        recommendation:
          "Standardize release governance and introduce automated regression checkpoints.",
        businessImpact:
          "Moderate deployment risk and increased post-release defects.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Release readiness follows defined governance with documented validation and environment controls.",
        recommendation:
          "Expand automated release validation and deployment risk analytics.",
        businessImpact:
          "Improved release predictability and reduced production disruption.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Release risks and deployment KPIs are proactively monitored using automated quality gates.",
        recommendation:
          "Introduce predictive release-risk analytics and intelligent deployment governance.",
        businessImpact:
          "Strong deployment resilience with controlled operational exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Release quality continuously adapts using predictive intelligence and automated deployment assurance.",
        recommendation:
          "Maintain intelligent release engineering and continuous deployment optimization.",
        businessImpact:
          "Highly reliable and continuously optimized release operations.",
      },
    ],
  },

  {
    id: "Q-005",
    domain: "Quality Engineering",
    capability: "Quality Engineering",
    question:
      "How mature are the D365 test strategy, automation capabilities, quality governance, regression coverage, and continuous quality engineering practices?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Testing is primarily manual, reactive, and dependent on individual team practices.",
        recommendation:
          "Establish a D365 quality engineering strategy with defined test governance and automation foundations.",
        businessImpact:
          "High defect leakage and unpredictable delivery quality.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic test processes and automation initiatives exist, but coverage and governance are inconsistent.",
        recommendation:
          "Standardize QA processes and prioritize scalable regression automation.",
        businessImpact:
          "Moderate quality risk and increased testing effort.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Quality engineering practices are defined with measurable coverage and structured automation.",
        recommendation:
          "Expand continuous testing, risk-based regression, and quality analytics.",
        businessImpact:
          "Improved delivery confidence and reduced regression exposure.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Quality metrics and automated testing are proactively governed across delivery pipelines.",
        recommendation:
          "Introduce predictive quality analytics and intelligent test optimization.",
        businessImpact:
          "Strong quality resilience with controlled delivery risk.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven quality engineering continuously optimizes testing, coverage, and defect prevention.",
        recommendation:
          "Maintain intelligent quality engineering and continuous optimization.",
        businessImpact:
          "Enterprise-grade quality performance with highly predictable delivery outcomes.",
      },
    ],
  },

  {
    id: "Q-006",
    domain: "Data Quality",
    capability: "Data Quality",
    question:
      "How are data migration, master data, reconciliation, validation rules, and ongoing D365 data quality risks tested and governed?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Data validation is primarily manual with limited reconciliation or quality governance.",
        recommendation:
          "Establish structured migration validation, reconciliation controls, and data quality ownership.",
        businessImpact:
          "High risk of inaccurate business data and operational disruption.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic validation exists for critical data, but governance and exception management are inconsistent.",
        recommendation:
          "Standardize data validation rules and introduce measurable data quality KPIs.",
        businessImpact:
          "Recurring data issues and increased operational support effort.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Data quality controls are formally governed with reconciliation and periodic quality reviews.",
        recommendation:
          "Expand automated data validation and continuous quality monitoring.",
        businessImpact:
          "Improved data reliability and reduced operational defects.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Data quality risks are proactively monitored using automated controls and quality indicators.",
        recommendation:
          "Introduce predictive data quality analytics and anomaly detection.",
        businessImpact:
          "Strong data reliability with controlled operational exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Data quality continuously adapts using predictive intelligence and automated preventive controls.",
        recommendation:
          "Maintain intelligent data quality engineering and continuous optimization.",
        businessImpact:
          "Highly resilient and optimized enterprise data operations.",
      },
    ],
  },

  {
    id: "Q-007",
    domain: "Project Governance",
    capability: "Project Governance",
    question:
      "How are quality gates, role-based access validations, segregation-of-duties controls, and release KPIs continuously governed across SIT, UAT, and deployment cycles?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Role-based access and SoD validations are manually reviewed with inconsistent release governance.",
        recommendation:
          "Define formal quality gate criteria and implement RBAC governance standards.",
        businessImpact:
          "High compliance exposure and uncontrolled release risk.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic SoD and access reviews exist, but KPI enforcement and audit traceability remain inconsistent.",
        recommendation:
          "Strengthen release governance and automate role validation workflows.",
        businessImpact:
          "Moderate audit risk and inconsistent deployment quality.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Quality gates and role validations are formally governed with periodic KPI reviews.",
        recommendation:
          "Expand automated SoD testing and continuous governance reporting.",
        businessImpact:
          "Improved compliance readiness and release predictability.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Access governance and release KPIs are proactively monitored using automated controls and dashboards.",
        recommendation:
          "Introduce predictive compliance analytics and intelligent governance monitoring.",
        businessImpact:
          "Strong governance maturity with controlled operational exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Governance continuously adapts using intelligent compliance insights and automated preventive controls.",
        recommendation:
          "Maintain intelligent governance using predictive audit and compliance analytics.",
        businessImpact:
          "Enterprise-grade governance resilience with optimized compliance readiness.",
      },
    ],
  },

  {
    id: "Q-008",
    domain: "Project Governance",
    capability: "Project Governance",
    question:
      "How are QA risks, defect trends, operational quality insights, and business impact metrics continuously communicated to leadership for decision-making?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Quality reporting is reactive and limited to defect counts without business impact visibility.",
        recommendation:
          "Establish executive QA dashboards and standardized operational reporting.",
        businessImpact:
          "Limited leadership visibility increases delivery and operational risk.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Periodic quality reviews exist, but reporting lacks predictive insights and trend analysis.",
        recommendation:
          "Improve KPI standardization and integrate business impact reporting.",
        businessImpact:
          "Moderate governance gaps reduce informed decision-making capability.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Defect trends and operational quality metrics are formally reviewed across release cycles.",
        recommendation:
          "Expand predictive quality analytics and continuous executive reporting.",
        businessImpact:
          "Improved leadership visibility and proactive risk management.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Operational quality insights and business KPIs are proactively governed through centralized dashboards.",
        recommendation:
          "Introduce enterprise-wide predictive QA intelligence and governance analytics.",
        businessImpact:
          "Strong executive decision support with controlled delivery risk.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven quality intelligence continuously supports strategic governance and business optimization.",
        recommendation:
          "Maintain intelligent operational reporting using predictive quality analytics.",
        businessImpact:
          "Enterprise-grade governance visibility with optimized decision-making.",
      },
    ],
  },

  {
    id: "Q-009",
    domain: "Competency",
    capability: "Competency",
    question:
      "How are QA teams continuously enabled with D365 functional knowledge, automation engineering capabilities, and quality engineering practices to support scalable delivery?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "QA capability development is informal and dependent on individual experience.",
        recommendation:
          "Establish structured D365 QA training and competency frameworks.",
        businessImpact:
          "High delivery risk due to inconsistent QA capability maturity.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic training programs exist, but automation engineering and functional specialization are inconsistent.",
        recommendation:
          "Implement measurable capability assessments and targeted upskilling programs.",
        businessImpact:
          "Moderate scalability challenges and inconsistent delivery quality.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "QA competency development is formally governed with periodic certification and capability reviews.",
        recommendation:
          "Expand automation engineering expertise and continuous learning initiatives.",
        businessImpact:
          "Improved delivery scalability and engineering consistency.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "QA capability maturity is proactively monitored using measurable workforce and performance KPIs.",
        recommendation:
          "Introduce predictive workforce planning and intelligent skill analytics.",
        businessImpact:
          "Strong delivery resilience with scalable QA engineering capability.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven capability intelligence continuously optimizes workforce readiness and quality engineering maturity.",
        recommendation:
          "Maintain predictive competency governance and intelligent workforce optimization.",
        businessImpact:
          "Enterprise-grade QA capability with optimized delivery performance.",
      },
    ],
  },

  {
    id: "Q-010",
    domain: "Support",
    capability: "Support",
    question:
      "How are production defects, hypercare insights, support trends, and recurring operational issues continuously analyzed to improve quality governance and operational resilience?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Production incidents are managed reactively with limited root cause analysis.",
        recommendation:
          "Establish structured hypercare governance and production defect analytics.",
        businessImpact:
          "High operational instability and recurring production incidents.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Critical production defects are reviewed periodically, but operational trend visibility is limited.",
        recommendation:
          "Improve incident trend analysis and root cause governance.",
        businessImpact:
          "Moderate operational disruption and increased support overhead.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Production quality insights are formally reviewed with periodic defect trend analysis.",
        recommendation:
          "Expand continuous monitoring and operational quality analytics.",
        businessImpact:
          "Improved operational stability with reduced recurring incidents.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Hypercare metrics and operational KPIs are proactively governed using centralized monitoring.",
        recommendation:
          "Introduce predictive support analytics and intelligent incident management.",
        businessImpact:
          "Strong operational resilience with controlled support exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven operational intelligence continuously optimizes production quality and incident prevention.",
        recommendation:
          "Maintain predictive support engineering and intelligent resilience optimization.",
        businessImpact:
          "Enterprise-grade operational continuity with minimal production disruption.",
      },
    ],
  },

  {
    id: "Q-011",
    domain: "Implementation",
    capability: "Brownfield",
    implementationType: "Brownfield",
    question:
      "How are legacy process inefficiencies, historical defect patterns, technical debt, and unsupported customizations continuously assessed and remediated during migration to D365?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Legacy processes are migrated with minimal rationalization or technical debt assessment.",
        recommendation:
          "Introduce legacy modernization governance and technical debt reviews.",
        businessImpact:
          "High migration risk and increased post-go-live instability.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Historical defect patterns are partially analyzed, but remediation activities are inconsistent.",
        recommendation:
          "Implement structured technical debt reduction and recurring defect analytics.",
        businessImpact:
          "Moderate migration instability and recurring operational inefficiencies.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Legacy risks and technical debt are formally reviewed with periodic remediation planning.",
        recommendation:
          "Expand modernization analytics and automated compatibility assessments.",
        businessImpact:
          "Improved migration quality with reduced legacy-related defects.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Migration risks and technical debt KPIs are proactively monitored across deployment cycles.",
        recommendation:
          "Introduce predictive modernization analytics and intelligent migration governance.",
        businessImpact:
          "Strong migration resilience with controlled operational exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven modernization intelligence continuously optimizes technical debt reduction and migration quality.",
        recommendation:
          "Maintain predictive migration governance using intelligent transformation analytics.",
        businessImpact:
          "Enterprise-grade migration stability with optimized modernization outcomes.",
      },
    ],
  },

  {
    id: "Q-012",
    domain: "Implementation",
    capability: "Big Bang",
    implementationType: "Big Bang",
    question:
      "How is end-to-end operational readiness, release risk exposure, business continuity, and cutover stability continuously validated during a single enterprise-wide go-live?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Cutover readiness is manually coordinated with limited operational rehearsal.",
        recommendation:
          "Establish structured mock cutovers and measurable release readiness KPIs.",
        businessImpact:
          "High probability of go-live disruption and business downtime.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic cutover rehearsals exist, but business continuity validation remains inconsistent.",
        recommendation:
          "Strengthen operational readiness governance and continuity testing.",
        businessImpact:
          "Moderate deployment instability and increased hypercare dependency.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Operational readiness and cutover validation are formally governed with periodic rehearsals.",
        recommendation:
          "Expand end-to-end simulation testing and operational analytics.",
        businessImpact:
          "Improved go-live stability with reduced deployment disruption.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Cutover quality KPIs and operational risks are proactively monitored through centralized governance.",
        recommendation:
          "Introduce predictive deployment analytics and intelligent cutover dashboards.",
        businessImpact:
          "Strong deployment resilience with controlled operational risk.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven operational intelligence continuously optimizes cutover quality and business continuity readiness.",
        recommendation:
          "Maintain predictive deployment engineering and intelligent release governance.",
        businessImpact:
          "Enterprise-grade go-live resilience with minimal operational disruption.",
      },
    ],
  },

  {
    id: "Q-013",
    domain: "Implementation",
    capability: "Phased Rollout",
    implementationType: "Phased Rollout",
    question:
      "How are regression risks, deployment dependencies, and cross-phase integration impacts continuously governed across phased rollout waves?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Regression and integration impacts are assessed independently for each rollout phase.",
        recommendation:
          "Establish cross-phase governance and dependency traceability controls.",
        businessImpact:
          "High risk of defects impacting previously deployed phases.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Critical deployment dependencies are tracked, but regression coordination remains inconsistent.",
        recommendation:
          "Implement centralized regression governance and phased release analytics.",
        businessImpact:
          "Moderate rollout instability and recurring cross-phase issues.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Cross-phase dependencies and regression risks are formally governed with periodic reviews.",
        recommendation:
          "Expand automated dependency validation and cross-wave regression intelligence.",
        businessImpact:
          "Improved rollout stability and reduced regression exposure.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Deployment dependencies and quality risks are proactively monitored across rollout waves.",
        recommendation:
          "Introduce predictive rollout analytics and intelligent dependency monitoring.",
        businessImpact:
          "Strong phased deployment resilience with controlled operational exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven deployment intelligence continuously optimizes rollout sequencing and regression prevention.",
        recommendation:
          "Maintain predictive rollout governance and intelligent release optimization.",
        businessImpact:
          "Enterprise-grade rollout stability with highly optimized deployment outcomes.",
      },
    ],
  },

  {
    id: "Q-014",
    domain: "Implementation",
    capability: "Greenfield",
    implementationType: "Greenfield",
    question:
      "How are solution design assumptions, business process readiness, configuration quality, and end-to-end implementation risks validated during a new D365 implementation?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Solution validation is largely reactive with limited design traceability and end-to-end readiness testing.",
        recommendation:
          "Establish structured design validation, requirements traceability, and implementation quality gates.",
        businessImpact:
          "High implementation risk and increased probability of late-cycle defects.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Core solution areas are validated, but cross-functional process and configuration dependencies remain inconsistent.",
        recommendation:
          "Standardize design assurance and expand end-to-end implementation validation.",
        businessImpact:
          "Moderate implementation risk and increased rework.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Implementation quality is governed through defined validation processes and cross-functional reviews.",
        recommendation:
          "Expand automated configuration validation and implementation risk analytics.",
        businessImpact:
          "Improved implementation predictability and reduced defect leakage.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Implementation risks and quality KPIs are proactively monitored across delivery phases.",
        recommendation:
          "Introduce predictive implementation analytics and intelligent quality governance.",
        businessImpact:
          "Strong implementation resilience with controlled delivery exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven quality intelligence continuously optimizes implementation readiness and delivery outcomes.",
        recommendation:
          "Maintain intelligent implementation governance and continuous quality optimization.",
        businessImpact:
          "Enterprise-grade implementation quality with highly predictable outcomes.",
      },
    ],
  },

  {
    id: "Q-015",
    domain: "Implementation",
    capability: "Lift & Shift",
    implementationType: "Lift & Shift",
    question:
      "How are migration compatibility, infrastructure dependencies, application behavior, performance risks, and post-migration quality validated during a lift-and-shift transformation?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Migration validation focuses primarily on technical completion with limited end-to-end operational assurance.",
        recommendation:
          "Establish structured compatibility, performance, and post-migration validation controls.",
        businessImpact:
          "High migration instability and production performance risk.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic compatibility testing exists, but dependency and performance validation are inconsistent.",
        recommendation:
          "Standardize migration quality checks and dependency-based testing.",
        businessImpact:
          "Moderate operational instability and increased support effort.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Migration quality is governed through defined compatibility and performance validation processes.",
        recommendation:
          "Expand automated migration validation and continuous performance monitoring.",
        businessImpact:
          "Improved migration stability with reduced operational disruption.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Migration risks are proactively monitored using automated quality indicators and predictive analysis.",
        recommendation:
          "Introduce predictive migration-risk analytics and intelligent validation.",
        businessImpact:
          "Strong migration resilience with controlled production exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Migration quality continuously adapts using predictive intelligence and automated operational assurance.",
        recommendation:
          "Maintain intelligent migration engineering and continuous transformation optimization.",
        businessImpact:
          "Highly resilient and optimized migration outcomes.",
      },
    ],
  },

  {
    id: "Q-016",
    domain: "Implementation",
    capability: "Template Rollout",
    implementationType: "Template Rollout",
    question:
      "How are global templates, localization requirements, configuration deviations, regression risks, and rollout quality validated across countries or business units?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Template validation is performed independently by rollout teams with limited global governance.",
        recommendation:
          "Establish centralized template governance and localization validation standards.",
        businessImpact:
          "High risk of inconsistent rollout quality and template deviations.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Core template controls exist, but localization and regression validation are inconsistent.",
        recommendation:
          "Standardize localization testing and cross-rollout regression governance.",
        businessImpact:
          "Moderate rollout risk and increased rework.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Template and localization validation follow defined standards with coordinated regression testing.",
        recommendation:
          "Expand automated template validation and rollout analytics.",
        businessImpact:
          "Improved rollout consistency and reduced regression exposure.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Template deviations and rollout risks are proactively monitored across business units.",
        recommendation:
          "Introduce predictive rollout analytics and intelligent template governance.",
        businessImpact:
          "Strong rollout consistency with controlled localization risk.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven intelligence continuously optimizes template governance and localization quality.",
        recommendation:
          "Maintain intelligent rollout governance and continuous template optimization.",
        businessImpact:
          "Enterprise-grade global rollout quality and optimized delivery outcomes.",
      },
    ],
  },

  {
    id: "Q-017",
    domain: "Security & Access Governance",
    capability: "Security & Access Governance",
    question:
      "How are security roles, access controls, segregation-of-duties risks, privileged access, and authorization changes validated across the D365 lifecycle?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Security validation is largely manual with limited continuous governance.",
        recommendation:
          "Establish structured RBAC, SoD, and authorization validation controls.",
        businessImpact:
          "High security and compliance exposure.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic access validation exists, but governance and role-change testing are inconsistent.",
        recommendation:
          "Standardize access validation and automate critical security test scenarios.",
        businessImpact:
          "Moderate compliance and authorization risk.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Security and access validation are formally governed with defined controls and periodic reviews.",
        recommendation:
          "Expand automated SoD testing and continuous access monitoring.",
        businessImpact:
          "Improved security posture with reduced compliance exposure.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Access risks and authorization changes are proactively monitored using measurable security indicators.",
        recommendation:
          "Introduce risk-based security test prioritization and predictive access-risk monitoring.",
        businessImpact:
          "Proactive access risk management with stronger security resilience.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Security validation continuously adapts to role changes, access patterns, and emerging authorization risks.",
        recommendation:
          "Sustain intelligent security quality engineering and continuously optimize access validation controls.",
        businessImpact:
          "Optimized security resilience and highly reliable authorization controls.",
      },
    ],
  },

  {
    id: "Q-018",
    domain: "Quality Engineering",
    capability: "Test Automation",
    question:
      "How effectively are automated D365 test assets designed, maintained, executed, and integrated into continuous delivery and regression processes?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Automation is limited, isolated, or heavily dependent on manual maintenance.",
        recommendation:
          "Establish a scalable D365 automation strategy and prioritize critical regression scenarios.",
        businessImpact:
          "High regression effort and increased defect leakage.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Automation covers selected processes, but maintenance and execution are inconsistent.",
        recommendation:
          "Standardize automation frameworks, reusable components, and execution governance.",
        businessImpact:
          "Moderate automation efficiency and inconsistent regression confidence.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Automation is governed with defined coverage targets and integrated execution processes.",
        recommendation:
          "Expand CI/CD integration and risk-based automation prioritization.",
        businessImpact:
          "Improved regression efficiency and delivery confidence.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Automation effectiveness and coverage are proactively monitored using quality and execution metrics.",
        recommendation:
          "Introduce intelligent test optimization and predictive automation analytics.",
        businessImpact:
          "Strong automation resilience with optimized regression execution.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven automation continuously optimizes test selection, maintenance, and execution quality.",
        recommendation:
          "Maintain intelligent test automation and continuous optimization.",
        businessImpact:
          "Highly efficient and continuously optimized quality engineering.",
      },
    ],
  },

  {
    id: "Q-019",
    domain: "Project Governance",
    capability: "Risk & Quality Governance",
    question:
      "How are quality risks, delivery dependencies, defect trends, and readiness decisions governed across the D365 programme lifecycle?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Quality risks are managed reactively with limited visibility or formal escalation.",
        recommendation:
          "Establish formal quality risk governance, escalation paths, and measurable readiness criteria.",
        businessImpact:
          "High programme risk and unpredictable delivery outcomes.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Basic risk reporting exists, but cross-functional dependencies and trends are inconsistently managed.",
        recommendation:
          "Standardize risk reporting and dependency management across delivery teams.",
        businessImpact:
          "Moderate governance gaps and delayed risk resolution.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Quality risks and delivery readiness are governed through defined processes and periodic reviews.",
        recommendation:
          "Expand predictive risk analytics and continuous readiness monitoring.",
        businessImpact:
          "Improved delivery predictability and proactive risk management.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Quality risks and programme readiness are proactively monitored using centralized analytics and dashboards.",
        recommendation:
          "Introduce intelligent risk prediction and automated governance insights.",
        businessImpact:
          "Strong programme resilience with controlled delivery exposure.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "AI-driven governance continuously optimizes quality risk prevention and delivery decisions.",
        recommendation:
          "Maintain intelligent programme governance and continuous risk optimization.",
        businessImpact:
          "Enterprise-grade governance with highly predictable delivery outcomes.",
      },
    ],
  },

  {
    id: "Q-020",
    domain: "Integration Testing",
    capability: "Integration Testing",
    question:
      "How are end-to-end D365 integrations tested and governed across connected applications, interfaces, APIs, batch processes, error handling, and business process dependencies?",
    options: [
      {
        level: 1,
        label: "Level 1",
        score: 20,
        response:
          "Integration testing is performed primarily on individual interfaces, with limited end-to-end business process validation.",
        recommendation:
          "Establish an integration test strategy covering critical interfaces, end-to-end flows, failures, retries, and data validation.",
        businessImpact:
          "High risk of interface failure and business disruption.",
      },
      {
        level: 2,
        label: "Level 2",
        score: 40,
        response:
          "Key integrations are tested, but dependency coverage, negative scenarios, and error handling validation are inconsistent.",
        recommendation:
          "Standardize integration test coverage and introduce dependency mapping and failure scenario testing.",
        businessImpact:
          "Recurring integration defects and inconsistent end-to-end reliability.",
      },
      {
        level: 3,
        label: "Level 3",
        score: 60,
        response:
          "Integration testing is formally governed with documented end-to-end scenarios, interface coverage, and defect management.",
        recommendation:
          "Expand automated integration testing and continuous validation of critical business interfaces.",
        businessImpact:
          "Controlled end-to-end reliability with reduced integration-related incidents.",
      },
      {
        level: 4,
        label: "Level 4",
        score: 80,
        response:
          "Integration health, test outcomes, and dependency risks are proactively monitored using measurable quality indicators.",
        recommendation:
          "Introduce predictive integration-risk analytics and intelligent prioritization of regression scenarios.",
        businessImpact:
          "Proactive dependency management and resilient connected business processes.",
      },
      {
        level: 5,
        label: "Level 5",
        score: 100,
        response:
          "Integration quality continuously adapts to change, historical failures, and dependency risk using intelligent quality signals.",
        recommendation:
          "Sustain intelligent integration quality engineering and continuously optimize end-to-end resilience.",
        businessImpact:
          "Highly resilient and continuously optimized connected business processes.",
      },
    ],
  },
];


// ============================================================
// QUESTION RETRIEVAL
// ============================================================

/**
 * Returns questions applicable to the selected domains
 * and implementation type.
 *
 * Rules:
 *
 * 1. Questions without implementationType are generic
 *    and applicable to all implementation types.
 *
 * 2. Questions with implementationType are included only
 *    when they match the selected implementation type.
 *
 * 3. If selectedDomains is empty or undefined, all domains
 *    are included.
 *
 * 4. Implementation-specific questions are still subject
 *    to domain filtering.
 */
export function getAssessmentQuestions(
  _selectedDomains?: AssessmentDomain[],
  _implementationType?: ImplementationType
): AssessmentQuestion[] {
  return assessmentQuestions;
}

// ============================================================
// QUESTION LOOKUP
// ============================================================

export function getQuestionById(
  questionId: string
): AssessmentQuestion | undefined {
  return assessmentQuestions.find(
    (question) =>
      question.id === questionId
  );
}


// ============================================================
// DOMAIN RESULTS
// ============================================================

export function calculateDomainResults(
  questions: AssessmentQuestion[],
  answers: Record<string, number>
): DomainResult[] {
  const domains = Array.from(
    new Set(
      questions.map(
        (question) =>
          question.domain
      )
    )
  );

  return domains.map(
    (domain) => {
      const domainQuestions =
        questions.filter(
          (question) =>
            question.domain === domain
        );

      const answeredQuestions =
        domainQuestions.filter(
          (question) =>
            isValidAnswer(
              answers,
              question.id
            )
        );

      const totalScore =
        answeredQuestions.reduce(
          (sum, question) =>
            sum +
            answers[
              question.id
            ],
          0
        );

      const averageScore =
        answeredQuestions.length > 0
          ? totalScore /
            answeredQuestions.length
          : 0;

      const completion =
        domainQuestions.length > 0
          ? (
              answeredQuestions.length /
              domainQuestions.length
            ) *
            100
          : 0;

      return {
        domain,

        score:
          Number(
            averageScore.toFixed(1)
          ),

        percentage:
          Number(
            (
              averageScore * 20
            ).toFixed(1)
          ),

        answered:
          answeredQuestions.length,

        total:
          domainQuestions.length,

        completion:
          Number(
            completion.toFixed(0)
          ),
      };
    }
  );
}


// ============================================================
// OVERALL RESULT
// ============================================================

export function calculateAssessmentResult(
  questions: AssessmentQuestion[],
  answers: Record<string, number>
): AssessmentResult {
  const answeredQuestions =
    questions.filter(
      (question) =>
        isValidAnswer(
          answers,
          question.id
        )
    );

  const totalScore =
    answeredQuestions.reduce(
      (sum, question) =>
        sum +
        answers[
          question.id
        ],
      0
    );

  const overallScore =
    answeredQuestions.length > 0
      ? totalScore /
        answeredQuestions.length
      : 0;

  const totalQuestions =
    questions.length;

  const completion =
    totalQuestions > 0
      ? (
          answeredQuestions.length /
          totalQuestions
        ) *
        100
      : 0;

  const domainResults =
    calculateDomainResults(
      questions,
      answers
    );

  const recommendationItems =
    answeredQuestions
      .map(
        (question) => {
          const level =
            answers[
              question.id
            ];

          const option =
            question.options.find(
              (item) =>
                item.level === level
            );

          if (!option) {
            return null;
          }

          return {
            questionId:
              question.id,

            domain:
              question.domain,

            question:
              question.question,

            level,

            score:
              option.score,

            recommendation:
              option.recommendation,

            businessImpact:
              option.businessImpact,
          };
        }
      )
      .filter(
        (
          item
        ): item is Recommendation =>
          item !== null
      );

  const strengths =
    recommendationItems.filter(
      (item) =>
        item.level >= 4
    );

  const improvementAreas =
    recommendationItems
      .filter(
        (item) =>
          item.level <= 3
      )
      .sort(
        (a, b) =>
          a.level -
          b.level
      );

  return {
    overallScore:
      Number(
        overallScore.toFixed(1)
      ),

    overallPercentage:
      Number(
        (
          overallScore * 20
        ).toFixed(1)
      ),

    maturityLevel:
      getMaturityLevel(
        overallScore
      ),

    answeredQuestions:
      answeredQuestions.length,

    totalQuestions,

    completion:
      Number(
        completion.toFixed(1)
      ),

    domainResults,

    strengths,

    improvementAreas,
  };
}


// ============================================================
// RECOMMENDATION HELPER
// ============================================================

export function getAssessmentRecommendations(
  questions: AssessmentQuestion[],
  answers: Record<string, number>
): Recommendation[] {
  return questions
    .filter(
      (question) =>
        isValidAnswer(
          answers,
          question.id
        ) &&
        answers[
          question.id
        ] <= 3
    )
    .map(
      (question) => {
        const level =
          answers[
            question.id
          ];

        const option =
          question.options.find(
            (item) =>
              item.level === level
          );

        if (!option) {
          return null;
        }

        return {
          questionId:
            question.id,

          domain:
            question.domain,

          question:
            question.question,

          level,

          score:
            option.score,

          recommendation:
            option.recommendation,

          businessImpact:
            option.businessImpact,
        };
      }
    )
    .filter(
      (
        item
      ): item is Recommendation =>
        item !== null
    )
    .sort(
      (a, b) =>
        a.level -
        b.level
    );
}


// ============================================================
// STRENGTH HELPER
// ============================================================

export function getAssessmentStrengths(
  questions: AssessmentQuestion[],
  answers: Record<string, number>
): Recommendation[] {
  return questions
    .filter(
      (question) =>
        isValidAnswer(
          answers,
          question.id
        ) &&
        answers[
          question.id
        ] >= 4
    )
    .map(
      (question) => {
        const level =
          answers[
            question.id
          ];

        const option =
          question.options.find(
            (item) =>
              item.level === level
          );

        if (!option) {
          return null;
        }

        return {
          questionId:
            question.id,

          domain:
            question.domain,

          question:
            question.question,

          level,

          score:
            option.score,

          recommendation:
            option.recommendation,

          businessImpact:
            option.businessImpact,
        };
      }
    )
    .filter(
      (
        item
      ): item is Recommendation =>
        item !== null
    )
    .sort(
      (a, b) =>
        b.level -
        a.level
    );
}


// ============================================================
// QUESTION COUNT HELPER
// ============================================================

export function getApplicableQuestionCount(
  selectedDomains?: AssessmentDomain[],
  implementationType?: ImplementationType
): number {
  return getAssessmentQuestions(
    selectedDomains,
    implementationType
  ).length;
}