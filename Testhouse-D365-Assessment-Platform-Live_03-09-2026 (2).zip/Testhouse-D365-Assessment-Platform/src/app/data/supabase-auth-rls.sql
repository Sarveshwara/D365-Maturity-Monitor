-- ============================================================
-- Sprint 1: Authentication + Row Level Security
-- Run AFTER supabase-schema.sql
-- https://supabase.com/dashboard/project/duiguffglsmymsrfzuqo/sql/new
-- ============================================================

-- ── 1. PROFILES TABLE ────────────────────────────────────────
-- Extends auth.users with app-specific fields (org, role, etc.)
CREATE TABLE IF NOT EXISTS profiles (
  id              UUID        PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name       TEXT,
  organization_id UUID        REFERENCES organizations(id),
  role            TEXT        NOT NULL DEFAULT 'assessor',
  -- roles: super_admin | customer_admin | assessor | viewer
  active          BOOLEAN     DEFAULT true,
  avatar_url      TEXT,
  created_at      TIMESTAMPTZ DEFAULT now(),
  updated_at      TIMESTAMPTZ DEFAULT now()
);

-- ── 2. AUTO-CREATE PROFILE ON SIGNUP ─────────────────────────
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    COALESCE(NEW.raw_user_meta_data->>'role', 'assessor')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Auto-update updated_at on profiles
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── 3. HELPER FUNCTIONS (used in RLS policies) ───────────────
CREATE OR REPLACE FUNCTION get_user_role()
RETURNS TEXT LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM profiles WHERE id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION get_user_org_id()
RETURNS UUID LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT organization_id FROM profiles WHERE id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION is_super_admin()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'super_admin')
$$;

-- ── 4. ENABLE RLS ON ALL TABLES ──────────────────────────────
ALTER TABLE profiles                ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations           ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_packages     ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_domains      ENABLE ROW LEVEL SECURITY;
ALTER TABLE package_domains         ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_subscriptions  ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_users               ENABLE ROW LEVEL SECURITY;

-- ── 5. PROFILES POLICIES ─────────────────────────────────────
DROP POLICY IF EXISTS "profiles_select_own"   ON profiles;
DROP POLICY IF EXISTS "profiles_select_admin" ON profiles;
DROP POLICY IF EXISTS "profiles_update_own"   ON profiles;
DROP POLICY IF EXISTS "profiles_update_admin" ON profiles;
DROP POLICY IF EXISTS "profiles_insert_self"  ON profiles;

-- Users can read their own profile; super_admin reads all
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
  USING (id = auth.uid() OR is_super_admin());

-- Users can update their own non-sensitive fields
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  USING (id = auth.uid() OR is_super_admin())
  WITH CHECK (id = auth.uid() OR is_super_admin());

-- Trigger inserts profile on signup
CREATE POLICY "profiles_insert_self" ON profiles FOR INSERT
  WITH CHECK (id = auth.uid());

-- ── 6. ORGANIZATIONS POLICIES ────────────────────────────────
DROP POLICY IF EXISTS "orgs_select" ON organizations;
DROP POLICY IF EXISTS "orgs_insert" ON organizations;
DROP POLICY IF EXISTS "orgs_update" ON organizations;
DROP POLICY IF EXISTS "orgs_delete" ON organizations;

-- Users see only their own org; super_admin sees all
CREATE POLICY "orgs_select" ON organizations FOR SELECT
  USING (id = get_user_org_id() OR is_super_admin());

-- Only super_admin can create/modify/delete organizations
CREATE POLICY "orgs_insert" ON organizations FOR INSERT
  WITH CHECK (is_super_admin());

CREATE POLICY "orgs_update" ON organizations FOR UPDATE
  USING (is_super_admin());

CREATE POLICY "orgs_delete" ON organizations FOR DELETE
  USING (is_super_admin());

-- ── 7. ASSESSMENT PACKAGES POLICIES (catalog — readable by all) ──
DROP POLICY IF EXISTS "packages_select"  ON assessment_packages;
DROP POLICY IF EXISTS "packages_write"   ON assessment_packages;

CREATE POLICY "packages_select" ON assessment_packages FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "packages_write" ON assessment_packages FOR ALL
  USING (is_super_admin())
  WITH CHECK (is_super_admin());

-- ── 8. ASSESSMENT DOMAINS POLICIES ───────────────────────────
DROP POLICY IF EXISTS "domains_select" ON assessment_domains;
DROP POLICY IF EXISTS "domains_write"  ON assessment_domains;

CREATE POLICY "domains_select" ON assessment_domains FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "domains_write" ON assessment_domains FOR ALL
  USING (is_super_admin())
  WITH CHECK (is_super_admin());

-- ── 9. PACKAGE_DOMAINS POLICIES ──────────────────────────────
DROP POLICY IF EXISTS "pkg_domains_select" ON package_domains;
DROP POLICY IF EXISTS "pkg_domains_write"  ON package_domains;

CREATE POLICY "pkg_domains_select" ON package_domains FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "pkg_domains_write" ON package_domains FOR ALL
  USING (is_super_admin())
  WITH CHECK (is_super_admin());

-- ── 10. CUSTOMER SUBSCRIPTIONS POLICIES ──────────────────────
DROP POLICY IF EXISTS "subs_select" ON customer_subscriptions;
DROP POLICY IF EXISTS "subs_write"  ON customer_subscriptions;

-- Users see subscriptions for their org only; super_admin sees all
CREATE POLICY "subs_select" ON customer_subscriptions FOR SELECT
  USING (organization_id = get_user_org_id() OR is_super_admin());

CREATE POLICY "subs_write" ON customer_subscriptions FOR ALL
  USING (is_super_admin())
  WITH CHECK (is_super_admin());

-- ── 11. APP_USERS POLICIES ───────────────────────────────────
DROP POLICY IF EXISTS "app_users_select" ON app_users;
DROP POLICY IF EXISTS "app_users_write"  ON app_users;

CREATE POLICY "app_users_select" ON app_users FOR SELECT
  USING (organization_id = get_user_org_id() OR is_super_admin());

CREATE POLICY "app_users_write" ON app_users FOR ALL
  USING (is_super_admin() OR get_user_role() = 'customer_admin')
  WITH CHECK (is_super_admin() OR get_user_role() = 'customer_admin');

-- ── 12. SEED SUPER ADMIN (update after creating your account) ─
-- After signing up via the app, run this with your auth user ID:
-- UPDATE profiles SET role = 'super_admin' WHERE id = '<your-auth-user-id>';
--
-- Or promote by email:
-- UPDATE profiles SET role = 'super_admin'
--   WHERE id = (SELECT id FROM auth.users WHERE email = 'your@email.com');
