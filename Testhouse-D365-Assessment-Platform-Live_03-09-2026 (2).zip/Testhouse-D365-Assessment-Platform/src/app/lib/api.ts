import { projectId } from "../../../utils/supabase/info";


// Prefer explicit env var (Vercel); fall back to Figma Make auto-injected project ID
const BASE = import.meta.env.VITE_API_BASE_URL
  ?? `https://${projectId}.supabase.co/functions/v1/make-server-c8ac5349`;

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? res.statusText);
  }
  return res.json();
}

// ── Packages ──────────────────────────────────────────────────
export const getPackages = () => request<any[]>("/packages");
export const createPackage = (body: any) =>
  request("/packages", { method: "POST", body: JSON.stringify(body) });
export const togglePackage = (id: string) =>
  request(`/packages/${id}/toggle`, { method: "PUT" });

// ── Organizations ─────────────────────────────────────────────
export const getOrganizations = () => request<any[]>("/organizations");
export const createOrganization = (body: any) =>
  request("/organizations", { method: "POST", body: JSON.stringify(body) });
export const updateOrganization = (id: string, body: any) =>
  request(`/organizations/${id}`, { method: "PUT", body: JSON.stringify(body) });

// ── Subscriptions ─────────────────────────────────────────────
export const getSubscriptions = (orgId?: string) =>
  request<any[]>(`/subscriptions${orgId ? `?org_id=${orgId}` : ""}`);
export const assignPackage = (orgId: string, packageId: string, notes?: string) =>
  request("/subscriptions", {
    method: "POST",
    body: JSON.stringify({ organization_id: orgId, package_id: packageId, notes }),
  });
export const toggleSubscription = (id: string) =>
  request(`/subscriptions/${id}/toggle`, { method: "PUT" });
export const removeSubscription = (id: string) =>
  request(`/subscriptions/${id}`, { method: "DELETE" });

// ── Entitlements ──────────────────────────────────────────────
export const getEntitlements = (orgId: string) =>
  request<{ organization_id: string; accessible_routes: string[] }>(
    `/organizations/${orgId}/entitlements`
  );

// ── Users (app_users legacy) ──────────────────────────────────
export const getUsers = (orgId?: string) =>
  request<any[]>(`/users${orgId ? `?org_id=${orgId}` : ""}`);
export const createUser = (body: any) =>
  request("/users", { method: "POST", body: JSON.stringify(body) });
export const updateUser = (id: string, body: any) =>
  request(`/users/${id}`, { method: "PUT", body: JSON.stringify(body) });

// ── Profiles (auth-linked user management) ────────────────────
export const getProfiles = (orgId?: string) =>
  request<any[]>(`/profiles${orgId ? `?org_id=${orgId}` : ""}`);
export const updateProfile = (id: string, body: any) =>
  request(`/profiles/${id}`, { method: "PUT", body: JSON.stringify(body) });
export const inviteUser = (body: { email: string; role: string; organization_id?: string; full_name?: string }) =>
  request("/profiles/invite", { method: "POST", body: JSON.stringify(body) });
export const toggleUserActive = (id: string) =>
  request(`/profiles/${id}/toggle`, { method: "PUT" });
export const sendPasswordReset = (id: string) =>
  request(`/profiles/${id}/reset-password`, { method: "POST" });

// ── Audit Logs ────────────────────────────────────────────────
export const getAuditLogs = (params?: { limit?: number; offset?: number; org_id?: string; event_type?: string }) => {
  const qs = new URLSearchParams();
  if (params?.limit)      qs.set("limit",      String(params.limit));
  if (params?.offset)     qs.set("offset",     String(params.offset));
  if (params?.org_id)     qs.set("org_id",     params.org_id);
  if (params?.event_type) qs.set("event_type", params.event_type);
  return request<{ data: any[]; count: number }>(`/audit-logs?${qs.toString()}`);
};

// ── Platform Stats ────────────────────────────────────────────
export const getPlatformStats = () => request<any>("/stats");

// ── Dashboard Stats (real assessment data) ────────────────────
export async function getDashboardStats() {
  return apiRequest(
    "/dashboard-stats"
  );
}
