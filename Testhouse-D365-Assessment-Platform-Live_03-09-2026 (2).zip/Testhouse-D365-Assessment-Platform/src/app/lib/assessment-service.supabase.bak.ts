import { supabase } from "./supabase-client";

// ============================================================
// TYPES
// ============================================================

export type AssessmentType =
  | "QA_MATURITY"
  | "PERFORMANCE"
  | "SECURITY";

export type AssessmentStatus =
  | "draft"
  | "in_progress"
  | "completed";

export interface AssessmentContext {
  /**
   * Selected assessment domains/categories.
   *
   * Example:
   * ["Test Strategy", "Automation", "Performance"]
   */
  selectedDomains?: string[];

  /**
   * Selected implementation type.
   *
   * Example:
   * "D365 F&O"
   * "D365 CE"
   * "Greenfield"
   * "Brownfield"
   */
  implementationType?: string;

  /**
   * Allows additional assessment-specific metadata
   * without requiring future database schema changes.
   */
  [key: string]: any;
}

export interface AssessmentRun {
  id: string;

  assessment_type: AssessmentType;

  assessment_name: string;

  status: AssessmentStatus;

  /**
   * Stores selected maturity levels / responses.
   *
   * Example:
   * {
   *   "qa-001": 3,
   *   "qa-002": 4
   * }
   */
  responses_data: Record<string, any>;

  /**
   * Stores optional notes against questions.
   */
  notes_data: Record<string, string>;

  /**
   * Assessment configuration/context.
   *
   * This may be stored inside responses_data for
   * backward compatibility if a dedicated database
   * column does not exist.
   */
  assessment_context?: AssessmentContext;

  overall_score: number | null;

  created_by: string;

  organization_id: string | null;

  run_date: string;

  completed_at: string | null;
}

export interface AssessmentServiceResult<T> {
  data: T;
  error: string | null;
}

// ============================================================
// INTERNAL HELPERS
// ============================================================

async function getCurrentUser() {
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error) {
    return null;
  }

  return user;
}

async function getUserOrgId(
  userId: string
): Promise<string | null> {
  const { data, error } = await supabase
    .from("profiles")
    .select("organization_id")
    .eq("id", userId)
    .maybeSingle();

  if (error) {
    console.error(
      "Unable to retrieve organization:",
      error.message
    );

    return null;
  }

  return data?.organization_id ?? null;
}

/**
 * Separates assessment context from responses.
 *
 * Context is stored inside responses_data using
 * the reserved key "__assessment_context".
 *
 * This avoids requiring a database migration while
 * still allowing:
 *
 * - Selected domains
 * - Implementation type
 * - Future assessment metadata
 *
 * Existing runs without this field remain supported.
 */
function extractContext(
  responses: Record<string, any>
): AssessmentContext {
  const context =
    responses?.__assessment_context;

  if (
    context &&
    typeof context === "object" &&
    !Array.isArray(context)
  ) {
    return context as AssessmentContext;
  }

  return {};
}

/**
 * Removes internal context metadata before
 * assessment scoring/export if required.
 */
function cleanResponses(
  responses: Record<string, any>
): Record<string, any> {
  if (!responses) {
    return {};
  }

  const {
    __assessment_context,
    ...assessmentResponses
  } = responses;

  return assessmentResponses;
}

/**
 * Combines assessment answers and context into
 * the format stored in responses_data.
 */
function buildStoredResponses(
  responses: Record<string, any>,
  context?: AssessmentContext
): Record<string, any> {
  const cleanedResponses =
    cleanResponses(responses);

  if (
    !context ||
    Object.keys(context).length === 0
  ) {
    return cleanedResponses;
  }

  return {
    ...cleanedResponses,

    __assessment_context: context,
  };
}

/**
 * Normalizes a database assessment run.
 *
 * Supports:
 * - Existing runs without context
 * - New runs with __assessment_context
 */
function normalizeRun(
  run: any
): AssessmentRun {
  const rawResponses =
    run?.responses_data ?? {};

  const context =
    extractContext(rawResponses);

  return {
    ...run,

    responses_data:
      cleanResponses(rawResponses),

    notes_data:
      run?.notes_data ?? {},

    assessment_context:
      context,

    overall_score:
      run?.overall_score ?? null,

    completed_at:
      run?.completed_at ?? null,
  } as AssessmentRun;
}

// ============================================================
// ASSESSMENT SERVICE
// ============================================================

export const assessmentService = {
  // ----------------------------------------------------------
  // CREATE NEW ASSESSMENT RUN
  // ----------------------------------------------------------

  /**
   * Creates a new assessment run.
   *
   * Optional context supports:
   * - selectedDomains
   * - implementationType
   * - future metadata
   */
  async start(
    type: AssessmentType,
    name: string,
    context: AssessmentContext = {}
  ): Promise<{
    runId: string | null;
    error: string | null;
  }> {
    const user =
      await getCurrentUser();

    if (!user) {
      return {
        runId: null,
        error: "Not authenticated",
      };
    }

    const orgId =
      await getUserOrgId(user.id);

    const responsesData =
      buildStoredResponses(
        {},
        context
      );

    const { data, error } =
      await supabase
        .from("assessment_runs")
        .insert({
          assessment_type:
            type,

          assessment_name:
            name,

          status:
            "draft",

          responses_data:
            responsesData,

          notes_data:
            {},

          overall_score:
            null,

          created_by:
            user.id,

          organization_id:
            orgId,

          run_date:
            new Date().toISOString(),
        })
        .select("id")
        .single();

    if (error) {
      console.error(
        "Unable to create assessment:",
        error.message
      );
    }

    return {
      runId:
        data?.id ?? null,

      error:
        error?.message ?? null,
    };
  },

  // ----------------------------------------------------------
  // AUTO-SAVE PROGRESS
  // ----------------------------------------------------------

  /**
   * Saves assessment progress.
   *
   * Context is preserved automatically if it already
   * exists in the assessment run.
   *
   * Optional context can also be supplied when the
   * domain selection or implementation type changes.
   */
  async saveProgress(
    runId: string,
    responses: Record<string, any>,
    notes: Record<string, string> = {},
    context?: AssessmentContext
  ): Promise<{
    error: string | null;
  }> {
    if (!runId) {
      return {
        error:
          "Assessment run ID is required",
      };
    }

    const user =
      await getCurrentUser();

    if (!user) {
      return {
        error:
          "Not authenticated",
      };
    }

    /**
     * Load the existing run so we can preserve
     * previously stored context.
     */
    const {
      data: existingRun,
      error: existingError,
    } =
      await supabase
        .from("assessment_runs")
        .select(
          "responses_data, status"
        )
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        )
        .maybeSingle();

    if (existingError) {
      return {
        error:
          existingError.message,
      };
    }

    if (!existingRun) {
      return {
        error:
          "Assessment run not found",
      };
    }

    const existingContext =
      extractContext(
        existingRun.responses_data ??
          {}
      );

    const finalContext = {
      ...existingContext,

      ...(context ?? {}),
    };

    const storedResponses =
      buildStoredResponses(
        responses,
        finalContext
      );

    /**
     * Do not move a completed assessment back
     * to in_progress.
     */
    const nextStatus =
      existingRun.status ===
      "completed"
        ? "completed"
        : "in_progress";

    const { error } =
      await supabase
        .from("assessment_runs")
        .update({
          responses_data:
            storedResponses,

          notes_data:
            notes ?? {},

          status:
            nextStatus,
        })
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        );

    if (error) {
      console.error(
        "Unable to save assessment progress:",
        error.message
      );
    }

    return {
      error:
        error?.message ?? null,
    };
  },

  // ----------------------------------------------------------
  // COMPLETE ASSESSMENT
  // ----------------------------------------------------------

  /**
   * Marks an assessment as completed.
   *
   * The final score should already be calculated
   * by the assessment scoring logic.
   */
  async complete(
    runId: string,
    responses: Record<string, any>,
    notes: Record<string, string>,
    score: number,
    context?: AssessmentContext
  ): Promise<{
    error: string | null;
  }> {
    if (!runId) {
      return {
        error:
          "Assessment run ID is required",
      };
    }

    const user =
      await getCurrentUser();

    if (!user) {
      return {
        error:
          "Not authenticated",
      };
    }

    /**
     * Retrieve existing context so it is not lost
     * when completing the assessment.
     */
    const {
      data: existingRun,
      error: existingError,
    } =
      await supabase
        .from("assessment_runs")
        .select(
          "responses_data"
        )
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        )
        .maybeSingle();

    if (existingError) {
      return {
        error:
          existingError.message,
      };
    }

    if (!existingRun) {
      return {
        error:
          "Assessment run not found",
      };
    }

    const existingContext =
      extractContext(
        existingRun.responses_data ??
          {}
      );

    const finalContext = {
      ...existingContext,

      ...(context ?? {}),
    };

    const storedResponses =
      buildStoredResponses(
        responses,
        finalContext
      );

    const { error } =
      await supabase
        .from("assessment_runs")
        .update({
          responses_data:
            storedResponses,

          notes_data:
            notes ?? {},

          status:
            "completed",

          overall_score:
            score,

          completed_at:
            new Date().toISOString(),
        })
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        );

    if (error) {
      console.error(
        "Unable to complete assessment:",
        error.message
      );
    }

    return {
      error:
        error?.message ?? null,
    };
  },

  // ----------------------------------------------------------
  // LOAD SPECIFIC ASSESSMENT RUN
  // ----------------------------------------------------------

  /**
   * Loads an assessment run.
   *
   * Used by:
   * - Resume Assessment
   * - Assessment Results
   * - PDF / Excel export
   */
  async get(
    runId: string
  ): Promise<{
    run: AssessmentRun | null;
    error: string | null;
  }> {
    if (!runId) {
      return {
        run: null,
        error:
          "Assessment run ID is required",
      };
    }

    const user =
      await getCurrentUser();

    if (!user) {
      return {
        run: null,
        error:
          "Not authenticated",
      };
    }

    const { data, error } =
      await supabase
        .from("assessment_runs")
        .select("*")
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        )
        .maybeSingle();

    if (error) {
      return {
        run: null,
        error:
          error.message,
      };
    }

    if (!data) {
      return {
        run: null,
        error:
          "Assessment run not found",
      };
    }

    return {
      run:
        normalizeRun(data),

      error:
        null,
    };
  },

  // ----------------------------------------------------------
  // LIST RECENT RUNS
  // ----------------------------------------------------------

  /**
   * Lists recent assessment runs for the
   * currently authenticated user.
   *
   * Optional type filter:
   *
   * assessmentService.list("QA_MATURITY")
   */
  async list(
    type?: AssessmentType,
    limit = 5
  ): Promise<{
    runs: AssessmentRun[];
    error: string | null;
  }> {
    const user =
      await getCurrentUser();

    if (!user) {
      return {
        runs: [],
        error:
          "Not authenticated",
      };
    }

    let query =
      supabase
        .from("assessment_runs")
        .select("*")
        .eq(
          "created_by",
          user.id
        )
        .order(
          "run_date",
          {
            ascending:
              false,
          }
        )
        .limit(limit);

    if (type) {
      query =
        query.eq(
          "assessment_type",
          type
        );
    }

    const { data, error } =
      await query;

    if (error) {
      console.error(
        "Unable to retrieve assessment runs:",
        error.message
      );

      return {
        runs: [],
        error:
          error.message,
      };
    }

    return {
      runs:
        (data ?? []).map(
          normalizeRun
        ),

      error:
        null,
    };
  },

  // ----------------------------------------------------------
  // GET LATEST RESUMABLE ASSESSMENT
  // ----------------------------------------------------------

  /**
   * Returns the most recent draft or in-progress
   * assessment for a given assessment type.
   *
   * This supports the Resume Assessment workflow.
   */
  async getLatestResumable(
    type: AssessmentType
  ): Promise<{
    run: AssessmentRun | null;
    error: string | null;
  }> {
    const user =
      await getCurrentUser();

    if (!user) {
      return {
        run: null,
        error:
          "Not authenticated",
      };
    }

    const { data, error } =
      await supabase
        .from("assessment_runs")
        .select("*")
        .eq(
          "created_by",
          user.id
        )
        .eq(
          "assessment_type",
          type
        )
        .in(
          "status",
          [
            "draft",
            "in_progress",
          ]
        )
        .order(
          "run_date",
          {
            ascending:
              false,
          }
        )
        .limit(1)
        .maybeSingle();

    if (error) {
      return {
        run: null,
        error:
          error.message,
      };
    }

    return {
      run:
        data
          ? normalizeRun(data)
          : null,

      error:
        null,
    };
  },

  // ----------------------------------------------------------
  // UPDATE ASSESSMENT CONTEXT
  // ----------------------------------------------------------

  /**
   * Updates only the assessment configuration.
   *
   * Useful when the user changes:
   * - selected domains
   * - implementation type
   *
   * Existing answers are preserved.
   */
  async updateContext(
    runId: string,
    context: AssessmentContext
  ): Promise<{
    error: string | null;
  }> {
    if (!runId) {
      return {
        error:
          "Assessment run ID is required",
      };
    }

    const user =
      await getCurrentUser();

    if (!user) {
      return {
        error:
          "Not authenticated",
      };
    }

    const {
      data: existingRun,
      error: existingError,
    } =
      await supabase
        .from("assessment_runs")
        .select(
          "responses_data"
        )
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        )
        .maybeSingle();

    if (existingError) {
      return {
        error:
          existingError.message,
      };
    }

    if (!existingRun) {
      return {
        error:
          "Assessment run not found",
      };
    }

    const existingResponses =
      cleanResponses(
        existingRun.responses_data ??
          {}
      );

    const existingContext =
      extractContext(
        existingRun.responses_data ??
          {}
      );

    const finalContext = {
      ...existingContext,
      ...context,
    };

    const storedResponses =
      buildStoredResponses(
        existingResponses,
        finalContext
      );

    const { error } =
      await supabase
        .from("assessment_runs")
        .update({
          responses_data:
            storedResponses,
        })
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        );

    return {
      error:
        error?.message ?? null,
    };
  },

  // ----------------------------------------------------------
  // DELETE DRAFT
  // ----------------------------------------------------------

  /**
   * Deletes only draft/in-progress assessments.
   *
   * Completed assessments are protected.
   */
  async deleteDraft(
    runId: string
  ): Promise<{
    error: string | null;
  }> {
    if (!runId) {
      return {
        error:
          "Assessment run ID is required",
      };
    }

    const user =
      await getCurrentUser();

    if (!user) {
      return {
        error:
          "Not authenticated",
      };
    }

    const { error } =
      await supabase
        .from("assessment_runs")
        .delete()
        .eq("id", runId)
        .eq(
          "created_by",
          user.id
        )
        .in(
          "status",
          [
            "draft",
            "in_progress",
          ]
        );

    if (error) {
      console.error(
        "Unable to delete assessment draft:",
        error.message
      );
    }

    return {
      error:
        error?.message ?? null,
    };
  },
};