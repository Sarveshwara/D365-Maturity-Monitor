import { createClient } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "../../../utils/supabase/info";

// Prefer explicit env vars (Vercel deployment); fall back to Figma Make auto-injected values
const supabaseUrl  = import.meta.env.VITE_SUPABASE_URL  ?? `https://${projectId}.supabase.co`;
const supabaseKey  = import.meta.env.VITE_SUPABASE_ANON_KEY ?? publicAnonKey;

export const supabase = createClient(
  supabaseUrl,
  supabaseKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true, // handles password reset redirect
    },
  }
);

export type UserRole = "super_admin" | "customer_admin" | "assessor" | "viewer";

export interface UserProfile {
  id: string;
  full_name: string | null;
  organization_id: string | null;
  role: UserRole;
  active: boolean;
  created_at: string;
}
