import { apiRequest } from "../components/services/api";

// ============================================================
// TYPES
//
// Unchanged from the original Supabase-backed version on purpose —
// every component importing from this file (Questionnaire.tsx,
// AssessmentResults.tsx, QAMaturityDashboard.tsx) keeps working
// without modification.
// ============================================================

export type AssessmentType = "QA_MATURITY" | "PERFORMANCE" | "SECURITY";

export type AssessmentStatus = "draft" | "in_progress" | "completed";

export interface AssessmentContext {
  /**
   * Selected assessment domains/categories.
   */
  selectedDomains?: string[];

  /**
   * Selected implementation type.
   */
  implementationType?: string;

  /**
   * Contact/organisation details. firstName/lastName/email come
   * from the account's own signup details and are locked (not
   * re-entered) on the Assessment Information step — carried
   * through so it can be displayed on the PDF report and looked up
   * later by an admin.
   */
  customerInfo?: {
    firstName?: string;
    lastName?: string;
    email?: string;
    countryCode?: string;
    phone?: string;
    companyName?: string;
    jobTitle?: string;
    industry?: string;
    country?: string;
    organizationSize?: string;
  };

  /**
   * Allows additional assessment-specific metadata without requiring
   * future schema changes.
   */
  [key: string]: any;
}

export interface AssessmentRun {
  id: string;
  assessment_type: AssessmentType;
  assessment_name: string;
  status: AssessmentStatus;
  responses_data: Record<string, any>;
  notes_data: Record<string, string>;
  assessment_context?: AssessmentContext;
  overall_score: number | null;
  created_by: string;
  organization_id: string | null;
  run_date: string;
  completed_at: string | null;
}

export interface AssessmentServiceResult<T> {
  data: T;
  error: string | null;
}

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}

// ============================================================
// ASSESSMENT SERVICE
// ============================================================

export const assessmentService = {
  // ----------------------------------------------------------
  // CREATE NEW ASSESSMENT RUN
  // ----------------------------------------------------------
  async start(
    type: AssessmentType,
    name: string,
    context: AssessmentContext = {}
  ): Promise<{ runId: string | null; error: string | null }> {
    try {
      const data = await apiRequest<{ runId: string }>("/assessments", {
        method: "POST",
        body: JSON.stringify({ assessmentType: type, name, context }),
      });

      return { runId: data.runId, error: null };
    } catch (error) {
      return { runId: null, error: errorMessage(error, "Unable to start assessment") };
    }
  },

  // ----------------------------------------------------------
  // AUTO-SAVE PROGRESS
  // ----------------------------------------------------------
  async saveProgress(
    runId: string,
    responses: Record<string, any>,
    notes: Record<string, string> = {},
    context?: AssessmentContext
  ): Promise<{ error: string | null }> {
    if (!runId) {
      return { error: "Assessment run ID is required" };
    }

    try {
      await apiRequest(`/assessments/${runId}/progress`, {
        method: "PUT",
        body: JSON.stringify({ responses, notes, context }),
      });

      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Failed to save assessment progress") };
    }
  },

  // ----------------------------------------------------------
  // COMPLETE ASSESSMENT
  // ----------------------------------------------------------
  async complete(
    runId: string,
    responses: Record<string, any>,
    notes: Record<string, string>,
    score: number,
    context?: AssessmentContext
  ): Promise<{ error: string | null }> {
    if (!runId) {
      return { error: "Assessment run ID is required" };
    }

    try {
      await apiRequest(`/assessments/${runId}/complete`, {
        method: "PUT",
        body: JSON.stringify({ responses, notes, score, context }),
      });

      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Failed to complete the assessment") };
    }
  },

  // ----------------------------------------------------------
  // LOAD SPECIFIC ASSESSMENT RUN
  // ----------------------------------------------------------
  async get(
    runId: string
  ): Promise<{ run: AssessmentRun | null; error: string | null }> {
    if (!runId) {
      return { run: null, error: "Assessment run ID is required" };
    }

    try {
      const data = await apiRequest<{ run: AssessmentRun }>(`/assessments/${runId}`);
      return { run: data.run, error: null };
    } catch (error) {
      return { run: null, error: errorMessage(error, "Unable to load the assessment") };
    }
  },

  // ----------------------------------------------------------
  // LIST RECENT RUNS
  // ----------------------------------------------------------
  async list(
    type?: AssessmentType,
    limit = 5
  ): Promise<{ runs: AssessmentRun[]; error: string | null }> {
    try {
      const params = new URLSearchParams({ limit: String(limit) });
      if (type) params.set("type", type);

      const data = await apiRequest<{ runs: AssessmentRun[] }>(
        `/assessments?${params.toString()}`
      );

      return { runs: data.runs, error: null };
    } catch (error) {
      return { runs: [], error: errorMessage(error, "Unable to retrieve assessment runs") };
    }
  },

  // ----------------------------------------------------------
  // GET LATEST RESUMABLE ASSESSMENT
  // ----------------------------------------------------------
  async getLatestResumable(
    type: AssessmentType
  ): Promise<{ run: AssessmentRun | null; error: string | null }> {
    try {
      const data = await apiRequest<{ run: AssessmentRun | null }>(
        `/assessments/resumable/${type}`
      );
      return { run: data.run, error: null };
    } catch (error) {
      return { run: null, error: errorMessage(error, "Unable to load assessment") };
    }
  },

  // ----------------------------------------------------------
  // UPDATE ASSESSMENT CONTEXT
  // ----------------------------------------------------------
  async updateContext(
    runId: string,
    context: AssessmentContext,
    name?: string
  ): Promise<{ error: string | null }> {
    if (!runId) {
      return { error: "Assessment run ID is required" };
    }

    try {
      await apiRequest(`/assessments/${runId}/context`, {
        method: "PATCH",
        body: JSON.stringify({ context, name }),
      });

      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Failed to update assessment context") };
    }
  },

  // ----------------------------------------------------------
  // DELETE DRAFT
  // ----------------------------------------------------------
  async deleteDraft(runId: string): Promise<{ error: string | null }> {
    if (!runId) {
      return { error: "Assessment run ID is required" };
    }

    try {
      await apiRequest(`/assessments/${runId}`, { method: "DELETE" });
      return { error: null };
    } catch (error) {
      return { error: errorMessage(error, "Failed to delete assessment draft") };
    }
  },

  // ----------------------------------------------------------
  // ADMIN: LIST ALL RUNS (super_admin / customer_admin only)
  // ----------------------------------------------------------
  async listAllForAdmin(): Promise<{ runs: AssessmentRun[]; error: string | null }> {
    try {
      const data = await apiRequest<{ runs: AssessmentRun[] }>("/assessments/admin/all");
      return { runs: data.runs, error: null };
    } catch (error) {
      return { runs: [], error: errorMessage(error, "Unable to retrieve assessment runs") };
    }
  },
};
