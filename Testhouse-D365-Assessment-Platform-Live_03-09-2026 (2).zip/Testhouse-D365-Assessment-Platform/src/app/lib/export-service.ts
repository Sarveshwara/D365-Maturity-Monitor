import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { testhouseLogoSrc } from "../components/shared/TesthouseLogo";

// ============================================================
// LOGO
// ============================================================

async function getLogoBase64(): Promise<string | null> {
  try {
    const response = await fetch(testhouseLogoSrc);

    if (!response.ok) {
      return null;
    }

    const blob = await response.blob();

    return await new Promise<string>((resolve) => {
      const reader = new FileReader();

      reader.onloadend = () => {
        resolve(reader.result as string);
      };

      reader.onerror = () => {
        resolve("");
      };

      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}

// ============================================================
// BRAND CONSTANTS
// ============================================================

const NAVY: [number, number, number] = [
  43,
  62,
  126,
];

const TEAL: [number, number, number] = [
  77,
  212,
  172,
];

const WHITE: [number, number, number] = [
  255,
  255,
  255,
];

const LIGHT: [number, number, number] = [
  247,
  249,
  255,
];

const GRAY: [number, number, number] = [
  100,
  100,
  100,
];

const RED: [number, number, number] = [
  216,
  59,
  1,
];

const ORANGE: [number, number, number] = [
  230,
  92,
  0,
];

const AMBER: [number, number, number] = [
  255,
  185,
  0,
];

const GREEN: [number, number, number] = [
  16,
  124,
  16,
];

// ============================================================
// COMMON HELPERS
// ============================================================

function getGeneratedDate(): string {
  return new Date().toLocaleString(
    "en-GB",
    {
      day: "2-digit",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }
  );
}

function getSafePercentage(
  value: number,
  total: number
): number {
  if (!total || total <= 0) {
    return 0;
  }

  return (value / total) * 100;
}

function pdfHeader(
  doc: jsPDF,
  title: string,
  subtitle: string,
  logoB64?: string | null,
  restrictedView?: boolean
): number {
  // Header background
  doc.setFillColor(...NAVY);

  doc.rect(
    0,
    0,
    210,
    30,
    "F"
  );

  // ----------------------------------------------------------
  // LOGO
  // ----------------------------------------------------------

  if (logoB64) {
    try {
      doc.addImage(
        logoB64,
        "PNG",
        12,
        4,
        52,
        22
      );
    } catch {
      doc.setTextColor(...WHITE);

      doc.setFontSize(14);

      doc.setFont(
        "helvetica",
        "bold"
      );

      doc.text(
        "TESTHOUSE",
        14,
        18
      );
    }
  } else {
    doc.setTextColor(...WHITE);

    doc.setFontSize(14);

    doc.setFont(
      "helvetica",
      "bold"
    );

    doc.text(
      "TESTHOUSE",
      14,
      13
    );

    doc.setFontSize(7);

    doc.setFont(
      "helvetica",
      "normal"
    );

    doc.text(
      "Quality Engineering Intelligence Platform",
      14,
      19
    );
  }

  // ----------------------------------------------------------
  // HEADER TITLE
  //
  // Skipped for restrictedView (customer-facing) — it just repeats
  // the big body title a few lines below, which is exactly what
  // "remove the repetitive header text" meant.
  // ----------------------------------------------------------

  if (!restrictedView) {
    doc.setTextColor(...WHITE);

    doc.setFontSize(9);

    doc.setFont(
      "helvetica",
      "bold"
    );

    doc.text(
      title,
      196,
      12,
      {
        align: "right",
      }
    );

    doc.setFontSize(7);

    doc.setFont(
      "helvetica",
      "normal"
    );

    doc.text(
      subtitle,
      196,
      18,
      {
        align: "right",
      }
    );
  }

  // Accent line

  doc.setFillColor(...TEAL);

  doc.rect(
    0,
    30,
    210,
    2,
    "F"
  );

  // ----------------------------------------------------------
  // MAIN TITLE
  // ----------------------------------------------------------

  doc.setTextColor(...NAVY);

  doc.setFontSize(18);

  doc.setFont(
    "helvetica",
    "bold"
  );

  doc.text(
    title,
    14,
    46
  );

  doc.setFontSize(10);

  doc.setFont(
    "helvetica",
    "normal"
  );

  doc.setTextColor(...GRAY);

  doc.text(
    subtitle,
    14,
    54
  );

  doc.text(
    `Generated: ${getGeneratedDate()}`,
    196,
    54,
    {
      align: "right",
    }
  );

  return 62;
}

/**
 * Draws a "Prepared for" block under the header with the customer's
 * name, company, and contact details captured on the Assessment
 * Information step. Returns the new y cursor position.
 */
function pdfCustomerInfoBlock(
  doc: jsPDF,
  y: number,
  customerInfo?: QAExportData["customerInfo"]
): number {
  if (
    !customerInfo ||
    (!customerInfo.firstName &&
      !customerInfo.lastName &&
      !customerInfo.companyName)
  ) {
    return y;
  }

  const fullName = [customerInfo.firstName, customerInfo.lastName]
    .filter(Boolean)
    .join(" ");

  doc.setDrawColor(...NAVY);
  doc.setLineWidth(0.2);
  doc.roundedRect(14, y, 182, 20, 1.5, 1.5);

  doc.setFontSize(7);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...GRAY);
  doc.text("PREPARED FOR", 18, y + 6);

  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...NAVY);
  doc.text(
    fullName || customerInfo.companyName || "—",
    18,
    y + 12.5
  );

  const detailParts = [
    customerInfo.companyName && fullName ? customerInfo.companyName : null,
    customerInfo.jobTitle,
    customerInfo.email,
    customerInfo.phone
      ? `${customerInfo.countryCode ?? ""} ${customerInfo.phone}`.trim()
      : null,
  ].filter(Boolean);

  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...GRAY);
  doc.text(detailParts.join("  ·  "), 18, y + 17.5);

  return y + 26;
}

function pdfFooter(
  doc: jsPDF
) {
  const pageCount =
    (doc as any)
      .internal
      .getNumberOfPages();

  for (
    let page = 1;
    page <= pageCount;
    page++
  ) {
    doc.setPage(page);

    doc.setFillColor(...LIGHT);

    doc.rect(
      0,
      284,
      210,
      13,
      "F"
    );

    doc.setDrawColor(...NAVY);

    doc.setLineWidth(0.3);

    doc.line(
      14,
      284,
      196,
      284
    );

    doc.setFontSize(7);

    doc.setTextColor(...GRAY);

    doc.text(
      "Confidential — Testhouse Quality Engineering Intelligence Platform",
      14,
      290
    );

    doc.text(
      `Page ${page} of ${pageCount}`,
      196,
      290,
      {
        align: "right",
      }
    );
  }
}

function scoreChip(
  doc: jsPDF,
  x: number,
  y: number,
  label: string,
  value: string,
  color: [number, number, number]
) {
  doc.setFillColor(...color);

  doc.roundedRect(
    x,
    y,
    52,
    22,
    3,
    3,
    "F"
  );

  doc.setTextColor(...WHITE);

  doc.setFontSize(7);

  doc.setFont(
    "helvetica",
    "normal"
  );

  doc.text(
    label.toUpperCase(),
    x + 26,
    y + 8,
    {
      align: "center",
    }
  );

  doc.setFontSize(12);

  doc.setFont(
    "helvetica",
    "bold"
  );

  doc.text(
    value,
    x + 26,
    y + 18,
    {
      align: "center",
    }
  );
}

function riskColor(
  tier: string
): [number, number, number] {
  const value =
    tier.toUpperCase();

  if (
    value === "CRITICAL"
  ) {
    return RED;
  }

  if (
    value === "HIGH"
  ) {
    return ORANGE;
  }

  if (
    value === "MEDIUM"
  ) {
    return AMBER;
  }

  return GREEN;
}

function getDomainStatus(
  score: number
): string {
  if (
    score >= 4
  ) {
    return "Strong";
  }

  if (
    score >= 3
  ) {
    return "Developing";
  }

  return "Needs Attention";
}

function getPriorityColor(
  priority: string
): [number, number, number] {
  const normalized =
    priority.toLowerCase();

  if (
    normalized === "critical"
  ) {
    return RED;
  }

  if (
    normalized === "high"
  ) {
    return ORANGE;
  }

  if (
    normalized === "medium"
  ) {
    return AMBER;
  }

  return GREEN;
}

// ============================================================
// QA MATURITY ASSESSMENT
// ============================================================

export interface QARecommendation {
  questionId?: string;

  priority: string;

  category?: string;

  area?: string;

  question: string;

  businessImpact: string;

  action: string;

  timeline?: string;

  level?: number;
}

export interface QAExportData {
  answers: Record<string, number>;

  overall: number;

  maturityLabel: string;

  riskLabel: string;

  byCategory: Record<
    string,
    number
  >;

  /**
   * Contact/organisation details. Optional so existing callers (and
   * any run saved before this was added) don't break.
   */
  customerInfo?: {
    firstName?: string;
    lastName?: string;
    email?: string;
    countryCode?: string;
    phone?: string;
    companyName?: string;
    jobTitle?: string;
    industry?: string;
    country?: string;
    organizationSize?: string;
  };

  recommendations: QARecommendation[];

  totalAnswered: number;

  totalQuestions: number;
}

// ============================================================
// QA NORMALIZATION
// ============================================================

function getRecommendationDomain(
  recommendation: QARecommendation
): string {
  return (
    recommendation.category ??
    recommendation.area ??
    "Unclassified"
  );
}

function normalizeRecommendations(
  recommendations: QARecommendation[]
): Array<
  QARecommendation & {
    domain: string;
  }
> {
  const priorityOrder:
    Record<string, number> = {
      Critical: 0,
      High: 1,
      Medium: 2,
      Low: 3,
    };

  return recommendations
    .map(
      (
        recommendation
      ) => ({
        ...recommendation,

        domain:
          getRecommendationDomain(
            recommendation
          ),
      })
    )
    .sort(
      (
        a,
        b
      ) => {
        const priorityDifference =
          (
            priorityOrder[
              a.priority
            ] ?? 99
          ) -
          (
            priorityOrder[
              b.priority
            ] ?? 99
          );

        if (
          priorityDifference !== 0
        ) {
          return priorityDifference;
        }

        return a.domain.localeCompare(
          b.domain
        );
      }
    );
}

// ============================================================
// QA PDF EXPORT
// ============================================================

export async function exportQAPDF(
  data: QAExportData,
  options?: {
    filename?: string;
    /**
     * Customer-facing exports: no repeated title in the header, a
     * different main heading, and no Prioritised Recommendations
     * section at all (which also means no page 2 — nothing else
     * currently adds a second page for this report). Leave
     * undefined/false for the full internal report — the default,
     * unchanged behavior.
     */
    restrictedView?: boolean;
  }
) {
  const filename =
    options?.filename ??
    "QA-Maturity-Assessment.pdf";
  const restrictedView = !!options?.restrictedView;

  const logoB64 =
    await getLogoBase64();

  const doc =
    new jsPDF({
      unit: "mm",
      format: "a4",
    });

  const totalQuestions =
    Math.max(
      data.totalQuestions ?? 0,
      1
    );

  const recommendations =
    normalizeRecommendations(
      data.recommendations ?? []
    );

  let y =
    pdfHeader(
      doc,
      restrictedView
        ? "D365 QA Maturity Assessment Report"
        : "QA Maturity Assessment",
      "D365 Quality Engineering Maturity Report",
      logoB64,
      restrictedView
    );

  y = pdfCustomerInfoBlock(doc, y, data.customerInfo);

  // ----------------------------------------------------------
  // SUMMARY
  // ----------------------------------------------------------

  scoreChip(
    doc,
    14,
    y,
    "Overall Score",
    `${data.overall.toFixed(1)} / 5.0`,
    NAVY
  );

  scoreChip(
    doc,
    72,
    y,
    "Maturity Level",
    data.maturityLabel,
    TEAL
  );

  scoreChip(
    doc,
    130,
    y,
    "Questions",
    `${data.totalAnswered} / ${totalQuestions}`,
    GRAY
  );

  y += 30;

  // ----------------------------------------------------------
  // DOMAIN SCORES
  // ----------------------------------------------------------

  doc.setFontSize(11);

  doc.setFont(
    "helvetica",
    "bold"
  );

  doc.setTextColor(...NAVY);

  doc.text(
    "Assessment Scores",
    14,
    y
  );

  y += 4;

  const domainRows =
    Object.entries(
      data.byCategory ?? {}
    ).map(
      (
        [
          domain,
          score,
        ]
      ) => [
        domain,

        score.toFixed(1),

        `${(
          (score / 5) * 100
        ).toFixed(0)}%`,

        getDomainStatus(score),
      ]
    );

  if (
    domainRows.length > 0
  ) {
    autoTable(
      doc,
      {
        startY: y,

        head: [
          [
            "Assessment Areas",
            "Score (1–5)",
            "Current Maturity (%)",
            { content: "Status", styles: { halign: "right" } },
          ],
        ],

        body:
          domainRows,

        styles: {
          fontSize: 8,
          cellPadding: 3,
          valign: "middle",
        },

        headStyles: {
          fillColor: NAVY,
          textColor: WHITE,
          fontStyle: "bold",
        },

        alternateRowStyles: {
          fillColor: LIGHT,
        },

        columnStyles: {
          0: {
            cellWidth: 65,
            fontStyle: "bold",
          },

          1: {
            cellWidth: 30,
            halign: "center",
          },

          2: {
            cellWidth: 35,
            halign: "center",
          },

          3: {
            halign: "right",
            cellWidth: 40,
          },
        },

        didParseCell: (
          tableData
        ) => {
          if (
            tableData.section ===
              "body" &&
            tableData.column.index === 3
          ) {
            const status =
              String(
                tableData.cell.raw
              );

            if (
              status ===
              "Needs Attention"
            ) {
              tableData.cell.styles.textColor =
                RED;
            } else if (
              status ===
              "Developing"
            ) {
              tableData.cell.styles.textColor =
                AMBER;
            } else {
              tableData.cell.styles.textColor =
                GREEN;
            }

            tableData.cell.styles.fontStyle =
              "bold";
          }
        },
      }
    );

    y =
      (doc as any)
        .lastAutoTable
        .finalY + 10;
  } else {
    doc.setFontSize(8);

    doc.setFont(
      "helvetica",
      "normal"
    );

    doc.setTextColor(...GRAY);

    doc.text(
      "No domain score data available.",
      14,
      y + 5
    );

    y += 12;
  }

  // ----------------------------------------------------------
  // PRIORITISED RECOMMENDATIONS
  //
  // Skipped entirely for restrictedView (customer-facing PDF) — this
  // is also what naturally keeps the customer PDF to page 1 only,
  // since this section is the only thing in this report that ever
  // calls doc.addPage().
  // ----------------------------------------------------------

  if (
    !restrictedView &&
    recommendations.length > 0
  ) {
    if (
      y > 210
    ) {
      doc.addPage();

      y = 20;
    }

    doc.setFontSize(11);

    doc.setFont(
      "helvetica",
      "bold"
    );

    doc.setTextColor(...NAVY);

    doc.text(
      `Prioritised Recommendations (${recommendations.length})`,
      14,
      y
    );

    y += 4;

    autoTable(
      doc,
      {
        startY: y,

        margin: {
          left: 10,
          right: 10,
          bottom: 18,
        },

        head: [
          [
            "Priority",
            "Domain",
            "Assessment Question",
            "Business Impact",
            "Recommended Action",
            "Timeline",
          ],
        ],

        body:
          recommendations.map(
            (
              recommendation
            ) => [
              recommendation.priority,
              recommendation.domain,
              recommendation.question,
              recommendation.businessImpact,
              recommendation.action,
              recommendation.timeline ?? "",
            ]
          ),

        styles: {
          fontSize: 6.2,
          cellPadding: 2,
          valign: "top",
          overflow: "linebreak",
        },

        headStyles: {
          fillColor: NAVY,
          textColor: WHITE,
          fontStyle: "bold",
          fontSize: 6.5,
          halign: "center",
        },

        alternateRowStyles: {
          fillColor: LIGHT,
        },

        columnStyles: {
          0: {
            cellWidth: 17,
            fontStyle: "bold",
          },

          1: {
            cellWidth: 24,
          },

          2: {
            cellWidth: 42,
          },

          3: {
            cellWidth: 38,
          },

          4: {
            cellWidth: 43,
          },

          5: {
            cellWidth: 18,
          },
        },

        didParseCell: (
          tableData
        ) => {
          if (
            tableData.section ===
              "body" &&
            tableData.column.index === 0
          ) {
            const priority =
              String(
                tableData.cell.raw
              );

            tableData.cell.styles.textColor =
              getPriorityColor(
                priority
              );

            tableData.cell.styles.fontStyle =
              "bold";
          }
        },
      }
    );
  } else if (!restrictedView) {
    if (
      y > 230
    ) {
      doc.addPage();

      y = 20;
    }

    doc.setFillColor(
      240,
      249,
      244
    );

    doc.roundedRect(
      14,
      y,
      182,
      24,
      3,
      3,
      "F"
    );

    doc.setTextColor(...GREEN);

    doc.setFontSize(12);

    doc.setFont(
      "helvetica",
      "bold"
    );

    doc.text(
      "Excellent maturity level",
      105,
      y + 10,
      {
        align: "center",
      }
    );

    doc.setTextColor(...GRAY);

    doc.setFontSize(8);

    doc.setFont(
      "helvetica",
      "normal"
    );

    doc.text(
      "No improvement recommendations were generated for the current responses.",
      105,
      y + 17,
      {
        align: "center",
      }
    );
  }

  // ----------------------------------------------------------
  // FOOTER
  // ----------------------------------------------------------

  pdfFooter(doc);

  doc.save(filename);
}

// ============================================================
// QA EXCEL EXPORT
// ============================================================

export function exportQAExcel(
  data: QAExportData,
  filename =
    "QA-Maturity-Assessment.xlsx"
) {
  const workbook =
    XLSX.utils.book_new();

  const totalQuestions =
    Math.max(
      data.totalQuestions ?? 0,
      1
    );

  const recommendations =
    normalizeRecommendations(
      data.recommendations ?? []
    );

  // ----------------------------------------------------------
  // SHEET 1 — SUMMARY
  // ----------------------------------------------------------

  const summaryData = [
    [
      "QA Maturity Assessment Report",
    ],

    [
      "Generated",
      getGeneratedDate(),
    ],

    ...(data.customerInfo
      ? [
          [],
          [
            "Prepared For",
            [data.customerInfo.firstName, data.customerInfo.lastName]
              .filter(Boolean)
              .join(" ") || "—",
          ],
          ["Company", data.customerInfo.companyName ?? "—"],
          ["Email", data.customerInfo.email ?? "—"],
          [
            "Phone",
            data.customerInfo.phone
              ? `${data.customerInfo.countryCode ?? ""} ${data.customerInfo.phone}`.trim()
              : "—",
          ],
          ["Job Title", data.customerInfo.jobTitle ?? "—"],
        ]
      : []),

    [],

    [
      "Overall Score",
      Number(
        data.overall.toFixed(2)
      ),
    ],

    [
      "Maturity Level",
      data.maturityLabel,
    ],

    [
      "Risk Rating",
      data.riskLabel,
    ],

    [
      "Questions Answered",
      data.totalAnswered,
    ],

    [
      "Total Applicable Questions",
      totalQuestions,
    ],

    [
      "Completion",
      `${getSafePercentage(
        data.totalAnswered,
        totalQuestions
      ).toFixed(1)}%`,
    ],

    [
      "Priority Actions",
      recommendations.length,
    ],
  ];

  const summarySheet =
    XLSX.utils.aoa_to_sheet(
      summaryData
    );

  summarySheet["!cols"] = [
    {
      wch: 30,
    },
    {
      wch: 40,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    summarySheet,
    "Summary"
  );

  // ----------------------------------------------------------
  // SHEET 2 — DOMAIN SCORES
  // ----------------------------------------------------------

  const domainRows =
    Object.entries(
      data.byCategory ?? {}
    ).map(
      (
        [
          domain,
          score,
        ]
      ) => [
        domain,

        Number(
          score.toFixed(2)
        ),

        Number(
          (
            score * 20
          ).toFixed(1)
        ),

        getDomainStatus(score),
      ]
    );

  const domainSheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Assessment Areas",
          "Score (1–5)",
          "Completion %",
          "Status",
        ],

        ...domainRows,
      ]
    );

  domainSheet["!cols"] = [
    {
      wch: 32,
    },
    {
      wch: 14,
    },
    {
      wch: 16,
    },
    {
      wch: 20,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    domainSheet,
    "Assessment Scores"
  );

  // ----------------------------------------------------------
  // SHEET 3 — RECOMMENDATIONS
  // ----------------------------------------------------------

  const recommendationRows =
    recommendations.map(
      (
        recommendation
      ) => [
        recommendation.priority,
        recommendation.domain,
        recommendation.question,
        recommendation.businessImpact,
        recommendation.action,
        recommendation.timeline ?? "",
        recommendation.level ?? "",
        recommendation.questionId ?? "",
      ]
    );

  const recommendationSheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Priority",
          "Domain",
          "Assessment Question",
          "Business Impact",
          "Recommended Action",
          "Timeline",
          "Selected Level",
          "Question ID",
        ],

        ...recommendationRows,
      ]
    );

  recommendationSheet["!cols"] = [
    {
      wch: 14,
    },
    {
      wch: 28,
    },
    {
      wch: 65,
    },
    {
      wch: 55,
    },
    {
      wch: 65,
    },
    {
      wch: 16,
    },
    {
      wch: 16,
    },
    {
      wch: 20,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    recommendationSheet,
    "Recommendations"
  );

  // ----------------------------------------------------------
  // SHEET 4 — ANSWERS
  // ----------------------------------------------------------

  const answerRows =
    Object.entries(
      data.answers ?? {}
    ).map(
      (
        [
          questionId,
          level,
        ]
      ) => [
        questionId,
        level,
      ]
    );

  const answersSheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Question ID",
          "Selected Maturity Level",
        ],

        ...answerRows,
      ]
    );

  answersSheet["!cols"] = [
    {
      wch: 25,
    },
    {
      wch: 25,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    answersSheet,
    "Answers"
  );

  XLSX.writeFile(
    workbook,
    filename
  );
}

// ============================================================
// PERFORMANCE ASSESSMENT
// ============================================================

export interface PerfExportData {
  overallScore: number;

  recommendation: string;

  categoryScores: Array<{
    id: string;
    name: string;
    score: number;
    maxScore: number;
    pct: number;
    risk: string;
  }>;

  answers: Record<
    string,
    number
  >;
}

export async function exportPerformancePDF(
  data: PerfExportData,
  filename =
    "Performance-Assessment.pdf"
) {
  const logoB64 =
    await getLogoBase64();

  const doc =
    new jsPDF({
      unit: "mm",
      format: "a4",
    });

  let y =
    pdfHeader(
      doc,
      "Performance Assessment",
      "Performance Engineering Risk & Readiness Report",
      logoB64
    );

  const tier =
    data.recommendation.toUpperCase();

  const color =
    riskColor(tier);

  scoreChip(
    doc,
    14,
    y,
    "Overall Score",
    `${data.overallScore.toFixed(1)}%`,
    NAVY
  );

  scoreChip(
    doc,
    72,
    y,
    "Risk Level",
    data.recommendation,
    color
  );

  scoreChip(
    doc,
    130,
    y,
    "Categories",
    `${data.categoryScores.length}`,
    GRAY
  );

  y += 30;

  autoTable(
    doc,
    {
      startY: y,

      head: [
        [
          "Category",
          "Score",
          "Max",
          "Risk %",
          "Risk Level",
        ],
      ],

      body:
        data.categoryScores.map(
          (
            category
          ) => [
            category.name,
            category.score.toFixed(1),
            category.maxScore.toFixed(1),
            `${category.pct}%`,
            category.risk,
          ]
        ),

      styles: {
        fontSize: 9,
        cellPadding: 3,
      },

      headStyles: {
        fillColor: NAVY,
        textColor: WHITE,
        fontStyle: "bold",
      },

      alternateRowStyles: {
        fillColor: LIGHT,
      },
    }
  );

  pdfFooter(doc);

  doc.save(filename);
}

export function exportPerformanceExcel(
  data: PerfExportData,
  filename =
    "Performance-Assessment.xlsx"
) {
  const workbook =
    XLSX.utils.book_new();

  const summarySheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Performance Assessment Report",
        ],

        [
          "Generated",
          getGeneratedDate(),
        ],

        [],

        [
          "Overall Score",
          `${data.overallScore.toFixed(1)}%`,
        ],

        [
          "Risk Level",
          data.recommendation,
        ],
      ]
    );

  summarySheet["!cols"] = [
    {
      wch: 24,
    },
    {
      wch: 28,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    summarySheet,
    "Summary"
  );

  const categorySheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Category",
          "Score",
          "Max Score",
          "Percentage",
          "Risk Level",
        ],

        ...data.categoryScores.map(
          (
            category
          ) => [
            category.name,
            category.score,
            category.maxScore,
            `${category.pct}%`,
            category.risk,
          ]
        ),
      ]
    );

  categorySheet["!cols"] = [
    {
      wch: 28,
    },
    {
      wch: 12,
    },
    {
      wch: 14,
    },
    {
      wch: 14,
    },
    {
      wch: 16,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    categorySheet,
    "Category Scores"
  );

  XLSX.writeFile(
    workbook,
    filename
  );
}

// ============================================================
// SECURITY ASSESSMENT
// ============================================================

export interface SecurityExportData {
  overallScore: number;

  riskTier: string;

  pentestSignal: string;

  modules: Array<{
    id: string;
    name: string;
    score: number;
    maxPossible: number;
    risk: string;
    criticalGaps: string[];
  }>;

  answers: Record<
    string,
    any
  >;
}

export async function exportSecurityPDF(
  data: SecurityExportData,
  filename =
    "Security-Assessment.pdf"
) {
  const logoB64 =
    await getLogoBase64();

  const doc =
    new jsPDF({
      unit: "mm",
      format: "a4",
    });

  let y =
    pdfHeader(
      doc,
      "Security Assessment",
      "Security Posture & Penetration Testing Readiness Report",
      logoB64
    );

  const color =
    riskColor(
      data.riskTier
    );

  scoreChip(
    doc,
    14,
    y,
    "Overall Score",
    `${data.overallScore.toFixed(0)}%`,
    NAVY
  );

  scoreChip(
    doc,
    72,
    y,
    "Risk Tier",
    data.riskTier,
    color
  );

  scoreChip(
    doc,
    130,
    y,
    "Pentest Signal",
    data.pentestSignal,
    color
  );

  y += 30;

  autoTable(
    doc,
    {
      startY: y,

      head: [
        [
          "Module",
          "Score %",
          "Risk Tier",
          "Critical Gaps",
        ],
      ],

      body:
        data.modules.map(
          (
            module
          ) => [
            module.name,
            `${module.score.toFixed(0)}%`,
            module.risk,
            module.criticalGaps.length.toString(),
          ]
        ),

      styles: {
        fontSize: 9,
        cellPadding: 3,
      },

      headStyles: {
        fillColor: NAVY,
        textColor: WHITE,
        fontStyle: "bold",
      },

      alternateRowStyles: {
        fillColor: LIGHT,
      },
    }
  );

  y =
    (doc as any)
      .lastAutoTable
      .finalY + 10;

  const allGaps =
    data.modules.flatMap(
      (
        module
      ) =>
        module.criticalGaps.map(
          (
            gap
          ) => [
            module.name,
            gap,
          ]
        )
    );

  if (
    allGaps.length > 0
  ) {
    if (
      y > 220
    ) {
      doc.addPage();

      y = 20;
    }

    doc.setFontSize(11);

    doc.setFont(
      "helvetica",
      "bold"
    );

    doc.setTextColor(...NAVY);

    doc.text(
      "Critical Security Gaps",
      14,
      y
    );

    y += 4;

    autoTable(
      doc,
      {
        startY: y,

        head: [
          [
            "Module",
            "Critical Gap",
          ],
        ],

        body:
          allGaps,

        styles: {
          fontSize: 8,
          cellPadding: 3,
        },

        headStyles: {
          fillColor: RED,
          textColor: WHITE,
          fontStyle: "bold",
        },

        alternateRowStyles: {
          fillColor: [
            255,
            245,
            242,
          ],
        },

        columnStyles: {
          0: {
            cellWidth: 40,
            fontStyle: "bold",
          },
        },
      }
    );
  }

  pdfFooter(doc);

  doc.save(filename);
}

export function exportSecurityExcel(
  data: SecurityExportData,
  filename =
    "Security-Assessment.xlsx"
) {
  const workbook =
    XLSX.utils.book_new();

  const summarySheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Security Assessment Report",
        ],

        [
          "Generated",
          getGeneratedDate(),
        ],

        [],

        [
          "Overall Score",
          `${data.overallScore.toFixed(1)}%`,
        ],

        [
          "Risk Tier",
          data.riskTier,
        ],

        [
          "Pentest Signal",
          data.pentestSignal,
        ],
      ]
    );

  summarySheet["!cols"] = [
    {
      wch: 24,
    },
    {
      wch: 28,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    summarySheet,
    "Summary"
  );

  const moduleSheet =
    XLSX.utils.aoa_to_sheet(
      [
        [
          "Module",
          "Score %",
          "Max Possible",
          "Risk Tier",
          "Critical Gaps",
        ],

        ...data.modules.map(
          (
            module
          ) => [
            module.name,
            `${module.score.toFixed(1)}%`,
            module.maxPossible,
            module.risk,
            module.criticalGaps.length,
          ]
        ),
      ]
    );

  moduleSheet["!cols"] = [
    {
      wch: 25,
    },
    {
      wch: 12,
    },
    {
      wch: 16,
    },
    {
      wch: 16,
    },
    {
      wch: 16,
    },
  ];

  XLSX.utils.book_append_sheet(
    workbook,
    moduleSheet,
    "Module Scores"
  );

  const gapRows =
    data.modules.flatMap(
      (
        module
      ) =>
        module.criticalGaps.map(
          (
            gap
          ) => [
            module.name,
            gap,
          ]
        )
    );

  if (
    gapRows.length > 0
  ) {
    const gapSheet =
      XLSX.utils.aoa_to_sheet(
        [
          [
            "Module",
            "Critical Gap",
          ],

          ...gapRows,
        ]
      );

    gapSheet["!cols"] = [
      {
        wch: 25,
      },
      {
        wch: 90,
      },
    ];

    XLSX.utils.book_append_sheet(
      workbook,
      gapSheet,
      "Critical Gaps"
    );
  }

  XLSX.writeFile(
    workbook,
    filename
  );
}