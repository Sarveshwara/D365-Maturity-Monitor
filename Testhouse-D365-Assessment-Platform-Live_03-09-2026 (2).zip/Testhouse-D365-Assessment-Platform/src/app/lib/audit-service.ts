import { supabase } from "./supabase-client";

export type AuditEventType =
  | "user.login"
  | "user.logout"
  | "assessment.started"
  | "assessment.completed"
  | "assessment.exported"
  | "assessment.resumed"
  | "user.invited"
  | "user.role_changed"
  | "user.deactivated"
  | "user.reactivated"
  | "package.assigned"
  | "package.removed"
  | "org.created"
  | "org.updated";

export interface AuditEvent {
  id: string;
  event_type: AuditEventType;
  user_id: string | null;
  user_name: string | null;
  organization_id: string | null;
  org_name: string | null;
  entity_type: string | null;
  entity_id: string | null;
  metadata: Record<string, any>;
  created_at: string;
}

const EVENT_LABELS: Record<string, string> = {
  "user.login":              "User Logged In",
  "user.logout":             "User Logged Out",
  "assessment.started":      "Assessment Started",
  "assessment.completed":    "Assessment Completed",
  "assessment.exported":     "Report Exported",
  "assessment.resumed":      "Assessment Resumed",
  "user.invited":            "User Invited",
  "user.role_changed":       "Role Changed",
  "user.deactivated":        "User Deactivated",
  "user.reactivated":        "User Reactivated",
  "package.assigned":        "Package Assigned",
  "package.removed":         "Package Removed",
  "org.created":             "Organisation Created",
  "org.updated":             "Organisation Updated",
};

const EVENT_COLORS: Record<string, string> = {
  "user.login":           "#107C10",
  "user.logout":          "#767676",
  "assessment.started":   "#0F6CBD",
  "assessment.completed": "#107C10",
  "assessment.exported":  "#4DD4AC",
  "assessment.resumed":   "#0F6CBD",
  "user.invited":         "#8764B8",
  "user.role_changed":    "#FFB900",
  "user.deactivated":     "#D83B01",
  "user.reactivated":     "#107C10",
  "package.assigned":     "#2B3E7E",
  "package.removed":      "#E65C00",
  "org.created":          "#038387",
  "org.updated":          "#038387",
};

export const getEventLabel = (type: string) => EVENT_LABELS[type] ?? type;
export const getEventColor = (type: string) => EVENT_COLORS[type] ?? "#767676";

export const auditService = {
  // Log an event — fire-and-forget, never throws
  async log(
    eventType: AuditEventType,
    metadata: Record<string, any> = {},
    entityType?: string,
    entityId?: string
  ): Promise<void> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: profile } = await supabase
        .from("profiles")
        .select("organization_id")
        .eq("id", user.id)
        .single();

      await supabase.from("audit_logs").insert({
        event_type: eventType,
        user_id: user.id,
        organization_id: profile?.organization_id ?? null,
        entity_type: entityType ?? null,
        entity_id: entityId ?? null,
        metadata,
      });
    } catch {
      // Audit logging must never break the app
    }
  },

  // Convenience wrappers
  loginSuccess: () =>
    auditService.log("user.login", {}),

  logout: () =>
    auditService.log("user.logout", {}),

  assessmentStarted: (runId: string, type: string, name: string) =>
    auditService.log("assessment.started", { type, name }, "assessment_run", runId),

  assessmentCompleted: (runId: string, type: string, score: number) =>
    auditService.log("assessment.completed", { type, score }, "assessment_run", runId),

  reportExported: (runId: string, format: string, type: string) =>
    auditService.log("assessment.exported", { format, type }, "assessment_run", runId),

  userInvited: (email: string, role: string) =>
    auditService.log("user.invited", { email, role }),

  roleChanged: (targetId: string, oldRole: string, newRole: string) =>
    auditService.log("user.role_changed", { old_role: oldRole, new_role: newRole }, "user", targetId),

  packageAssigned: (orgId: string, packageCode: string) =>
    auditService.log("package.assigned", { package_code: packageCode }, "org", orgId),
};
