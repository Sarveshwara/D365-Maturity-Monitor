import { createBrowserRouter, Navigate } from "react-router"
import Layout from "./components/Layout"
import ProtectedRoute from "./components/auth/ProtectedRoute"
import RoleGuard from "./components/auth/RoleGuard"
import PackageGuard from "./components/auth/PackageGuard"
import Login from "./components/auth/Login"
import Signup from "./components/auth/Signup"
import ForgotPassword from "./components/auth/ForgotPassword"
import ResetPassword from "./components/auth/ResetPassword"
import LandingPage from "./components/public/LandingPage"
import PrivacyPolicy from "./components/public/PrivacyPolicy"
import TermsAndConditions from "./components/public/TermsAndConditions"
import AboutPage from "./components/public/AboutPage"
import ContactPage from "./components/public/ContactPage"
// ProgramDashboard: no longer routed (was the default "/" — see the
// index route below) since it only ever showed mock data for the
// pilot. Left as a file in case it's wired to real data later.
import ExecutiveDashboard from "./components/dashboards/ExecutiveDashboard"
import QAMaturityDashboard from "./components/dashboards/QAMaturityDashboard"
import DevOpsMaturityDashboard from "./components/dashboards/DevOpsMaturityDashboard"
import SuccessByDesignDashboard from "./components/dashboards/SuccessByDesignDashboard"
import BenchmarkingDashboard from "./components/dashboards/BenchmarkingDashboard"
import DefectIntelligenceDashboard from "./components/dashboards/DefectIntelligenceDashboard"
import AssessmentWizard from "./components/assessments/AssessmentWizard"
import DomainSelection from "./components/assessments/DomainSelection"
import Questionnaire from "./components/assessments/Questionnaire"
import AssessmentReview from "./components/assessments/AssessmentReview"
import AssessmentResults from "./components/assessments/AssessmentResults"
import ArtifactUpload from "./components/artifacts/ArtifactUpload"
import ArtifactIntegration from "./components/artifacts/ArtifactIntegration"
import ArtifactProcessingStatus from "./components/artifacts/ArtifactProcessingStatus"
import TraceabilityGraph from "./components/intelligence/TraceabilityGraph"
import TestIntelligenceWorkspace from "./components/intelligence/TestIntelligenceWorkspace"
import GeneratedTestViewer from "./components/intelligence/GeneratedTestViewer"
import TestImpactAnalysis from "./components/intelligence/TestImpactAnalysis"
import RecommendationsCenter from "./components/reports/RecommendationsCenter"
import ReportGenerator from "./components/reports/ReportGenerator"
import UserRoleManagement from "./components/admin/UserRoleManagement"
import PlatformSettings from "./components/admin/PlatformSettings"
import NotificationCenter from "./components/admin/NotificationCenter"
import AssessmentMarketplace from "./components/admin/AssessmentMarketplace"
import CustomerManagement from "./components/admin/CustomerManagement"
import MonitoringDashboard from "./components/admin/MonitoringDashboard"
import AuditLogViewer from "./components/admin/AuditLogViewer"
import UATDashboard from "./components/admin/UATDashboard"
import GoLiveChecklist from "./components/admin/GoLiveChecklist"
import DebugPanel from "./components/admin/DebugPanel"
import AssessmentCustomerInfo from "./components/assessments/AssessmentCustomerInfo"
import MyAssessments from "./components/profile/MyAssessments"
import AssessmentSubmissions from "./components/admin/AssessmentSubmissions"

// Wrap the authenticated layout in ProtectedRoute
function AuthenticatedLayout() {
  return (
    <ProtectedRoute>
      <Layout />
    </ProtectedRoute>
  )
}

export const router = createBrowserRouter(
  [
    // ── Public routes (no auth required) ─────────────────────
    { path: "/landing", Component: LandingPage },
    { path: "/about", Component: AboutPage },
    { path: "/contact", Component: ContactPage },
    { path: "/privacy", Component: PrivacyPolicy },
    { path: "/terms", Component: TermsAndConditions },
    { path: "/login", Component: Login },
    { path: "/signup", Component: Signup },
    { path: "/forgot-password", Component: ForgotPassword },
    { path: "/reset-password", Component: ResetPassword },

    // ── Protected app routes ──────────────────────────────────
    {
      path: "/",
      Component: AuthenticatedLayout,
      children: [
        // Was ProgramDashboard (mock data, "apiRequest is not defined"
        // banner) — every login/signup, and several error-recovery
        // buttons elsewhere in the app, land on "/" after
        // authenticating. For the pilot, that should go straight to
        // the assessment, not a broken dashboard.
        { index: true, element: <Navigate to="/assessment" replace /> },
        { path: "executive", Component: ExecutiveDashboard },
        { path: "qa-maturity", Component: QAMaturityDashboard },
        { path: "success-by-design", Component: SuccessByDesignDashboard },
        { path: "defect-intelligence", Component: DefectIntelligenceDashboard },
        // ── Assessment routes — guarded by package subscription ──
        // ── D365 Assessment routes ──────────────────────────────────
        {
          path: "assessment",
          Component: AssessmentWizard,
        },
        {
          path: "assessment/customer-info",
          Component: AssessmentCustomerInfo,
        },
        {
          path: "assessment/wizard",
          Component: AssessmentWizard,
        },
        {
          path: "assessment/domain-selection",
          Component: DomainSelection,
        },
        {
          path: "assessment/questionnaire",
          Component: Questionnaire,
        },
        {
          path: "assessment/review",
          Component: AssessmentReview,
        },
        {
          path: "assessment/results",
          Component: AssessmentResults,
        },
        {
          path: "assessment/results/:runId",
          Component: AssessmentResults,
        },
        {
          path: "profile/my-assessments",
          Component: MyAssessments,
        },
        {
          path: "devops-maturity",
          element: (
            <PackageGuard
              routePrefix="/devops-maturity"
              label="DevOps Assessment"
            >
              <DevOpsMaturityDashboard />
            </PackageGuard>
          ),
        },
        {
          path: "benchmarking",
          element: (
            <PackageGuard routePrefix="/benchmarking" label="Benchmarking">
              <BenchmarkingDashboard />
            </PackageGuard>
          ),
        },
        { path: "artifacts/upload", Component: ArtifactUpload },
        { path: "artifacts/integration", Component: ArtifactIntegration },
        { path: "artifacts/status", Component: ArtifactProcessingStatus },
        { path: "intelligence/traceability", Component: TraceabilityGraph },
        {
          path: "intelligence/test-workspace",
          Component: TestIntelligenceWorkspace,
        },
        {
          path: "intelligence/generated-tests",
          Component: GeneratedTestViewer,
        },
        { path: "intelligence/test-impact", Component: TestImpactAnalysis },
        { path: "reports/recommendations", Component: RecommendationsCenter },
        { path: "reports/generator", Component: ReportGenerator },
        {
          path: "admin/marketplace",
          element: (
            <RoleGuard allowedRoles={["super_admin"]}>
              <AssessmentMarketplace />
            </RoleGuard>
          ),
        },
        {
          path: "admin/customers",
          element: (
            <RoleGuard allowedRoles={["super_admin", "customer_admin"]}>
              <CustomerManagement />
            </RoleGuard>
          ),
        },
        {
          path: "admin/assessment-submissions",
          element: (
            <RoleGuard allowedRoles={["super_admin", "customer_admin"]}>
              <AssessmentSubmissions />
            </RoleGuard>
          ),
        },
        {
          path: "admin/users",
          element: (
            <RoleGuard allowedRoles={["super_admin", "customer_admin"]}>
              <UserRoleManagement />
            </RoleGuard>
          ),
        },
        {
          path: "admin/settings",
          element: (
            <RoleGuard allowedRoles={["super_admin"]}>
              <PlatformSettings />
            </RoleGuard>
          ),
        },
        {
          path: "admin/notifications",
          element: (
            <RoleGuard allowedRoles={["super_admin", "customer_admin"]}>
              <NotificationCenter />
            </RoleGuard>
          ),
        },
        {
          path: "admin/monitoring",
          element: (
            <RoleGuard allowedRoles={["super_admin"]}>
              <MonitoringDashboard />
            </RoleGuard>
          ),
        },
        {
          path: "admin/audit",
          element: (
            <RoleGuard allowedRoles={["super_admin"]}>
              <AuditLogViewer />
            </RoleGuard>
          ),
        },
        {
          path: "admin/uat",
          element: (
            <RoleGuard allowedRoles={["super_admin"]}>
              <UATDashboard />
            </RoleGuard>
          ),
        },
        {
          path: "admin/go-live",
          element: (
            <RoleGuard allowedRoles={["super_admin"]}>
              <GoLiveChecklist />
            </RoleGuard>
          ),
        },
        {
          path: "admin/debug",
          element: <DebugPanel />,
        },
      ],
    },
  ],
  {
    // Tell React Router that the application lives under /d365
    basename: "/orbit365-assessment",
  },
)
