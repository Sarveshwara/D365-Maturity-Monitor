Understood — this is an important correction.

I agree with removing **Implementation Types** now because the product direction has changed:

Earlier:

> D365 F&O QA Maturity Advisor (implementation-context driven)

Now:

> **Enterprise Quality Engineering Intelligence Platform** (technology/application agnostic)

So Performance and Security should NOT inherit:

* Greenfield
* Brownfield
* Rollout
* Big Bang
* Migration

Those belong to ERP transformation assessments, not standalone QE maturity.

The model should become:

```text
Assessment Domain
      ↓
Capability Area
      ↓
Control / Practice
      ↓
Question
      ↓
Evidence
      ↓
Maturity Score
      ↓
Risk
      ↓
Recommendation
      ↓
Business Outcome
```

Below is the corrected **Figma Make frontend input**.

---

# FIGMA MAKE PROMPT

# Enterprise Quality Engineering Intelligence Platform

## Product Objective

Design an enterprise SaaS platform that assesses:

* Quality Engineering maturity
* Performance engineering maturity
* Security engineering posture
* Delivery readiness
* Operational risk

The application provides:

* maturity scoring
* risk visibility
* recommendations
* transformation roadmap
* executive insights

Do NOT design as a survey tool.

Design as:

**Quality Intelligence Command Center**

---

# Global Application Layout

## Shell

```
+------------------------------------------------+
| Quality Intelligence Platform                  |
| Org | Application | Assessment | User          |
+------------------------------------------------+

| Sidebar        | Main Workspace                |
|                |                               |
| Dashboard      |                               |
| Assessments    |                               |
| Performance    |                               |
| Security       |                               |
| Recommendations|                               |
| Roadmap        |                               |
| Reports        |                               |
+------------------------------------------------+
```

---

# Navigation

Create left navigation:

```
Dashboard

Assessment Center

Quality Domains

   Functional Quality
   Test Automation
   Performance Engineering
   Security Engineering
   DevOps Quality
   Test Data
   Environment
   Governance

Insights

   Risks
   Recommendations
   Roadmap

Reports

Administration
```

---

# SCREEN 1

# Executive Dashboard

Purpose:

Leadership quality health view.

---

## KPI Cards

Create cards:

### Overall Quality Score

```
Quality Maturity

74%

Level 4
Managed
```

---

### Performance Readiness

```
Performance Score

68%

Medium Risk
```

---

### Security Posture

```
Security Score

57%

High Risk
```

---

### Automation Health

```
Automation

72%

Optimized Coverage
```

---

### Risk Exposure

```
Open Quality Risks

14

3 Critical
```

---

# Quality Radar Chart

Create radar chart with:

```
Functional Testing

Automation

Performance

Security

DevOps

Test Data

Environment

Governance

Support
```

---

# Risk Heatmap

Component:

Quality Risk Matrix

Columns:

```
Domain
Capability
Score
Risk
Priority
```

Example:

```
Security
Identity Controls
45%
High
P1


Performance
Load Testing
60%
Medium
P2
```

---

# SCREEN 2

# Assessment Center

Purpose:

Start maturity assessment.

---

Assessment selection cards:

```
Quality Assessment

Performance Assessment

Security Assessment

DevOps Assessment

Automation Assessment
```

---

Each card:

Shows:

```
Questions

Estimated Time

Last Score

Risk Status
```

---

# SCREEN 3

# Question Workspace

Layout:

Left:

Question

Right:

Live Intelligence Panel

---

# Question Header

Example:

```
Domain:
Performance Engineering

Capability:
Load Testing Strategy
```

---

# Question Card

Example Performance:

```
Are peak workload scenarios identified,
modelled and validated against production
transaction patterns?
```

---

Example Security:

```
Are application security vulnerabilities
identified and remediated before production
release?
```

---

# Answer Types

Support:

## Maturity Slider

```
0 --------------------100

Current Score:
65%
```

---

## Control Assessment

For security:

```
Not Implemented

Partially Implemented

Implemented

Optimized

Not Applicable
```

Scoring:

```
0
50
75
100
Excluded
```

---

# Evidence Upload

Component:

```
Evidence

Upload:

Architecture Documents

Test Reports

Security Scan Reports

Monitoring Reports

Pipeline Evidence
```

---

# Right Intelligence Panel

Always visible.

---

## Current Assessment

```
Score

65%

Level 3

Medium Risk
```

---

## Gap Identified

Example:

```
Performance testing coverage does not
represent expected production workload.
```

---

## Recommendation

Example:

```
Implement workload modelling and continuous
performance validation.
```

---

## Business Impact

Example:

```
Reduce production incidents

Improve customer experience

Improve release confidence
```

---

# SCREEN 4

# Performance Engineering Dashboard

Based on uploaded Performance Assessment.

Create sections:

---

## Performance Score

Gauge:

```
Performance Maturity

68 /100

Medium Risk
```

---

## Capability Cards

Create:

```
Performance Strategy

Workload Modelling

Test Environment

Load Testing

Stress Testing

Scalability Testing

Monitoring

Capacity Planning

Performance Governance
```

---

# Performance Metrics Panel

Display:

```
Response Time

Throughput

Concurrent Users

CPU / Memory

Error Rate

SLA Compliance
```

---

# Performance Recommendations

Cards:

Example:

```
Priority HIGH


Gap:

No continuous performance validation


Action:

Integrate performance tests into pipeline


Impact:

Reduce production degradation
```

---

# SCREEN 5

# Security Engineering Dashboard

Based on Security Assessment workbook.

Create security pillars:

---

## Security Domains

Tabs:

```
Application Security

Mobile Security

Infrastructure Security

Cloud Security
```

---

# Security Overview

```
Security Maturity

61%

High Risk
```

---

# Security Findings

Cards:

```
Critical

High

Medium

Low
```

---

# Control Assessment Grid

Columns:

```
Control

Description

Criticality

Status

Evidence

Score

Recommendation
```

---

# SCREEN 6

# Recommendation Center

Unified improvement backlog.

---

Layout:

```
Priority

Domain

Gap

Recommendation

Effort

Impact

Owner

Status
```

---

Example Card:

```
HIGH PRIORITY


Domain:
Security


Gap:
Weak access governance


Recommendation:

Strengthen IAM controls


Effort:
Medium


Impact:
High

```

---

# SCREEN 7

# Transformation Roadmap

Timeline generated from recommendations.

---

## Now (0-30 Days)

```
Critical Security Fixes

Performance Baseline

Risk Remediation
```

---

## Next (30-60 Days)

```
Automation Expansion

Monitoring Improvements

Process Optimization
```

---

## Future (60-90 Days)

```
Continuous Quality Engineering

Predictive Analytics
```

---

# Component Library

Create reusable components:

```
ScoreGauge

MaturityCard

RiskBadge

QuestionCard

EvidenceUploader

RecommendationCard

Heatmap

RadarChart

RoadmapTimeline

ControlGrid
```

---

# UX Principles

Important:

DO NOT create:
❌ questionnaire UI

Create:
✅ advisory experience

Every question must lead to:

```
Assessment
 ↓
Insight
 ↓
Recommendation
 ↓
Business Outcome
```

---

This revised Figma input now matches the uploaded **Performance + Security assessment direction** and is no longer D365 F&O dependent.

Next logical artifact for development is:
**Supabase backend schema + tables + questionnaire ingestion design**, because the Excel structure needs to become configurable data rather than hardcoded screens.
