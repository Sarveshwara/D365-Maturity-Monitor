Understood. For the uploaded **Performance Testing Assessment** and **Security Assessment** questionnaires, the frontend should not render them as a normal form. We need to convert the Excel questionnaire structure into a **dynamic assessment experience**.

Below is the **Figma Make input specifically for Questionnaire UI generation**.

---

# FIGMA MAKE PROMPT

# Enterprise Quality Assessment Questionnaire Experience

## Objective

Design a dynamic questionnaire experience for an Enterprise Quality Intelligence Platform.

The questionnaire supports:

* Quality Engineering Assessment
* Performance Engineering Assessment
* Security Engineering Assessment

Questions are loaded dynamically from backend configuration.

The UI must convert questionnaire answers into:

```
Response
 ↓
Score
 ↓
Risk Level
 ↓
Gap Analysis
 ↓
Recommendation
 ↓
Business Outcome
```

Do NOT design as a survey.

Design as an expert assessment workflow.

---

# SCREEN: Assessment Questionnaire Workspace

Frame:

`Assessment_Workspace`

---

## Layout

Use two-column enterprise layout.

```text
--------------------------------------------------
| Header                                         |
| Assessment Name | Progress | Save             |
--------------------------------------------------

| LEFT PANEL                  | RIGHT PANEL      |
|                             |                  |
| Domain Navigator            | Intelligence     |
|                             | Panel            |
| Question Workspace          |                  |
|                             | Score            |
|                             | Risk             |
|                             | Recommendation  |
--------------------------------------------------
```

---

# LEFT SIDE

# Assessment Navigation

Create vertical domain navigator.

---

## Performance Assessment Domains

Create expandable sections:

```
Performance Engineering

├── Application Profile
├── Performance Requirements
├── Workload Modelling
├── Test Strategy
├── Test Environment
├── Load Testing
├── Stress Testing
├── Scalability Testing
├── Monitoring
├── Risk & Compliance
```

---

## Security Assessment Domains

Create expandable sections:

```
Security Engineering

├── Application Security
├── Mobile Security
├── Infrastructure Security
├── Cloud Security
├── Identity & Access
├── Vulnerability Management
├── Compliance Controls
```

---

Each section shows:

Example:

```
Load Testing

Questions: 12

Completed: 8/12

Score: 68%

Risk: Medium
```

---

# CENTER QUESTION CARD

Component:

`AssessmentQuestionCard`

---

## Header

Show metadata:

Example:

```
Domain:
Performance Engineering

Capability:
Load Testing Strategy

Criticality:
High
```

---

## Question Display

Large readable format.

Example:

Performance:

```
Are expected user concurrency and transaction
volumes defined before performance execution?
```

Security:

```
Are vulnerabilities identified, tracked and
remediated before production deployment?
```

---

# Answer Components

The UI must support multiple answer types.

---

# Type 1: Maturity Score Question

Component:

`MaturitySlider`

Example:

```
Current Maturity


0 -------------------------100


Selected:
65%


Level:
Defined
```

---

# Type 2: Security Control Question

Component:

`ControlSelector`

Options:

```
○ Not Implemented

○ Partially Implemented

○ Implemented

○ Optimized

○ Not Applicable
```

---

Scoring:

```
Not Implemented = 0

Partial = 50

Implemented = 75

Optimized = 100
```

---

# Type 3: Metric Input

Component:

`MetricInput`

Examples:

Performance:

```
Average Response Time

[     ] seconds
```

```
Concurrent Users

[     ] users
```

```
Error Rate

[     ] %
```

---

# Type 4: Evidence Question

Component:

`EvidenceUploader`

---

Display:

```
Supporting Evidence

Upload:

+ Test Results
+ Performance Reports
+ Security Reports
+ Architecture Documents
+ Monitoring Evidence
```

---

# RIGHT SIDE

# Intelligence Panel

Always visible.

Component:

`AssessmentInsightPanel`

---

## Current Score

```
Current Score

67%

Level 3

Medium Risk
```

---

## Target Benchmark

```
Expected Target

85%

Gap

-18%
```

---

## Risk Explanation

Example:

```
Risk:

Performance coverage does not represent
expected production workload.
```

---

## Recommendation

Example:

```
Recommendation:

Introduce workload modelling and continuous
performance testing.
```

---

## Business Impact

Example:

```
Impact:

• Reduce production incidents

• Improve application reliability

• Increase release confidence
```

---

# QUESTION LIST VIEW

Create table mode.

Used by assessors.

---

Columns:

```
Question ID

Domain

Capability

Question

Response

Score

Risk

Evidence

Status
```

---

Status badges:

```
Not Started

In Progress

Completed

Needs Evidence
```

---

# Assessment Progress Header

Top sticky bar.

Example:

```
Performance Assessment


Progress:
72% Complete


Questions:
58 / 80


Current Score:
68%


Risk:
Medium
```

---

# Bulk Navigation

Buttons:

```
Previous Question

Save Draft

Next Question

Complete Assessment
```

---

# After Completion Screen

Generate:

## Assessment Summary

```
Performance Engineering Score

68%

Level 3

Medium Risk
```

---

## Capability Breakdown

Cards:

```
Load Testing

75%

Low Risk


Monitoring

45%

High Risk


Capacity Planning

55%

Medium Risk
```

---

# Gap Analysis

```
Top Gaps


1. Missing performance baseline

2. Limited monitoring coverage

3. Security controls incomplete
```

---

# Recommendation Output

Cards:

```
Priority:
HIGH


Recommendation:

Implement continuous performance testing


Effort:

Medium


Impact:

High

```

---

# Design System

Use:

Enterprise style similar to:

* Azure Portal
* Power BI
* Microsoft Defender dashboards

---

Colors:

```
Primary:
Microsoft Blue


Success:
Green


Warning:
Amber


Critical:
Red


Neutral:
Grey
```

---

# Components Required in Figma

Create reusable:

```
AssessmentShell

DomainNavigator

QuestionCard

MaturitySlider

ControlSelector

MetricInput

EvidenceUploader

ScoreGauge

RiskBadge

RecommendationPanel

CapabilityScoreCard

AssessmentSummary
```

---

# Frontend Data Binding Model

Prepare components for this JSON:

```json
{
 "questionId":"PERF-001",
 "domain":"Performance",
 "capability":"Load Testing",
 "question":"Are peak workloads validated?",
 "answerType":"slider",
 "weight":5,
 "targetScore":85
}
```

---

# Final UX Requirement

The user journey must feel like:

```
Expert Consultant Interview
        +
Live Risk Advisor
        +
Transformation Recommendation Engine
```

NOT:

```
Excel Questionnaire converted to web form
```

---

This Figma input is aligned to the uploaded questionnaire direction and ready for frontend generation.
