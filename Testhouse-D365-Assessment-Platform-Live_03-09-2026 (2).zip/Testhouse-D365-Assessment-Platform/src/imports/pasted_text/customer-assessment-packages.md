# Phase 2A – Customer-Specific Assessment Packages & Dynamic Questionnaire Loading

## Background

The D365 QA Maturity Assessment Platform currently supports:

* Organizations
* Applications
* Assessments
* Assessment Runs
* Assessment Responses
* Question Bank
* Domain Scoring
* Capability Scoring
* Maturity Model
* Reporting

Management feedback requires customer-specific assessment visibility.

Currently every customer can potentially access all assessment domains.

The system must now support package-based assessments where customers only see the assessments they have purchased or been assigned.

---

# Business Requirement

A customer should only see assessment domains assigned to their organization.

Examples:

## Customer A

Package:
Performance Assessment

Visible Domains:

* Performance Engineering
* Environment
* Architecture

Hidden Domains:

* Security Engineering
* Test Automation
* Governance
* Support

---

## Customer B

Package:
Security Assessment

Visible Domains:

* Security Engineering
* Governance
* Architecture

Hidden Domains:

* Performance Engineering
* Test Automation

---

## Customer C

Package:
QA Maturity Assessment

Visible Domains:

* All Domains

---

# New Database Objects

## Table: assessment_packages

Purpose:
Defines assessment products offered to customers.

Columns:

* id (uuid primary key)
* package_code (unique)
* package_name
* description
* active
* created_at

Seed Data:

QA_FULL
QA Maturity Assessment

PERF
Performance Assessment

SEC
Security Assessment

AUTO
Test Automation Assessment

DEVOPS
DevOps Assessment

---

## Table: package_domains

Purpose:
Maps assessment packages to domains.

Columns:

* id
* package_id
* domain_id
* created_at

Relationships:

assessment_packages -> package_domains -> domains

---

## Table: customer_subscriptions

Purpose:
Assign assessment packages to customers.

Columns:

* id
* organization_id
* package_id
* active
* start_date
* end_date
* created_at

Relationships:

organizations -> customer_subscriptions -> assessment_packages

---

# Package Definitions

## QA_FULL

Includes all domains

---

## PERF

Includes:

* Architecture
* Environment
* Performance Engineering

---

## SEC

Includes:

* Architecture
* Governance
* Security Engineering

---

## AUTO

Includes:

* Test Automation
* Functional Testing
* Test Data
* DevOps Quality

---

## DEVOPS

Includes:

* Architecture
* Environment
* DevOps Quality

---

# Required Views

## View: vw_customer_domains

Purpose:

Return domains visible to a customer.

Output:

Organization Name
Package Name
Domain Name

---

## View: vw_customer_questions

Purpose:

Return only questions available for the customer's assigned package.

Output:

Organization Name
Package Name
Question Code
Question Text
Domain Name
Capability Name

Filter using:

customer_subscriptions
package_domains
question_bank

---

# UI Requirements

## Screen: Assessment Marketplace

Visible to Admin Users

Shows:

Assessment Packages

Cards:

* QA Maturity Assessment
* Performance Assessment
* Security Assessment
* Test Automation Assessment
* DevOps Assessment

Actions:

* Assign Package
* View Domains
* Activate
* Deactivate

---

## Screen: Customer Assessment Dashboard

When customer logs in:

Retrieve assigned package

Show only assigned assessments

Example:

Performance Assessment

Start Assessment Button

No visibility of unassigned assessments

---

## Screen: Assessment Questionnaire

Load questions dynamically using:

vw_customer_questions

Group questions by:

Domain
Capability

Display:

Question
Response Options 1-5
Comments

Save Responses

---

## Screen: Assessment Results

Display:

Overall Score

Maturity Level

Initial
Developing
Defined
Managed
Optimized

---

## Charts

Domain Scores

Radar Chart

Capability Scores

Bar Chart

Low Scoring Areas

Top Improvement Opportunities

---

# Roles

Super Admin

* Manage Packages
* Manage Customers
* Manage Domains
* Manage Question Bank

Customer Admin

* Start Assessments
* View Reports
* Manage Internal Users

Assessor

* Complete Questionnaire
* View Assigned Assessments

Viewer

* Read Only

---

# API Requirements

Create APIs for:

GET Packages

GET Customer Packages

GET Customer Domains

GET Customer Questions

Assign Package To Organization

Deactivate Package

Activate Package

---

# Success Criteria

Customer logs in

System retrieves customer subscription

Only assigned package appears

Only assigned domains load

Only assigned questions display

Assessment scoring continues using existing scoring engine

Domain scoring, capability scoring, maturity model, and reporting remain unchanged

Platform becomes multi-tenant and assessment-package driven.
