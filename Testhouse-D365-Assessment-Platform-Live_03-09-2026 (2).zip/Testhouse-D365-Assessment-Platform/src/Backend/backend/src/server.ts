import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { pool } from "./db.js";
import authRoutes from "./routes/auth.js";
import assessmentRoutes from "./routes/assessments.js";

dotenv.config();

const app = express();

const PORT = Number(process.env.PORT) || 3001;

// Single CORS config — the original had this called twice with
// conflicting origins (one falling back to itself on :3001, which
// looked like a copy-paste mistake), which meant only the second
// call's headers actually took effect. Consolidated into one.
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(express.json());

app.get("/api/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");

    res.json({
      success: true,
      status: "healthy",
      database: "connected",
    });
  } catch (error) {
    console.error("Health check failed:", error);

    res.status(500).json({
      success: false,
      status: "unhealthy",
      database: "disconnected",
    });
  }
});

app.use("/api/auth", authRoutes);
app.use("/api/assessments", assessmentRoutes);

app.listen(PORT, () => {
  console.log(`Project Orbit API running on port ${PORT}`);
});
