import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { pool } from "./db.js";
import authRoutes from "./routes/auth.js";


dotenv.config();

const app = express();

const PORT = 3001;

app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:3001",
    credentials: true
  })
);

app.use(express.json());

app.get("/api/health", async (_req, res) => {
  try {

    await pool.query("SELECT 1");

    res.json({
      success: true,
      status: "healthy",
      database: "connected"
    });

  } catch (error) {

    console.error("Health check failed:", error);

    res.status(500).json({
      success: false,
      status: "unhealthy",
      database: "disconnected"
    });
  }
});

app.use(
  cors({
    origin: "http://localhost:5173",
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(express.json());

app.use("/api/auth", authRoutes);

app.listen(PORT, () => {
  console.log(`Project Orbit API running on port ${PORT}`);
});