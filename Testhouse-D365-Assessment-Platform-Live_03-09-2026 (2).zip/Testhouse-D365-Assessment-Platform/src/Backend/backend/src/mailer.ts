import nodemailer from "nodemailer";

const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM } =
  process.env;

const smtpConfigured = Boolean(SMTP_HOST && SMTP_USER && SMTP_PASSWORD);

const transporter = smtpConfigured
  ? nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT) || 587,
      secure: Number(SMTP_PORT) === 465,
      auth: { user: SMTP_USER, pass: SMTP_PASSWORD },
    })
  : null;

/**
 * Sends the password reset email if SMTP is configured. Otherwise —
 * e.g. on a local dev machine with no mail provider set up yet — just
 * logs the link so the flow can still be tested end to end.
 *
 * Deliberately never throws: a broken/blocked mail server (wrong
 * credentials, an outbound port a cloud provider blocks by default,
 * a timeout) should not turn "forgot password" into a full request
 * failure for the end user. Either way the token is already saved in
 * the database by the caller before this runs — falling back to
 * logging the link means it's still recoverable by an admin even
 * when real email delivery is down.
 */
export async function sendPasswordResetEmail(
  toEmail: string,
  resetUrl: string
): Promise<void> {
  if (!transporter) {
    console.log(
      `\n[mailer] SMTP not configured — password reset link for ${toEmail}:\n  ${resetUrl}\n`
    );
    return;
  }

  try {
    await transporter.sendMail({
      from: SMTP_FROM || "no-reply@example.com",
      to: toEmail,
      subject: "Reset your password",
      text: `Reset your password using this link (expires in 1 hour): ${resetUrl}`,
      html: `<p>Reset your password using the link below. This link expires in 1 hour.</p><p><a href="${resetUrl}">${resetUrl}</a></p>`,
    });
  } catch (error) {
    console.error(
      `[mailer] Failed to send password reset email to ${toEmail} — SMTP may be misconfigured or blocked on this network. Falling back to logging the link.`,
      error
    );
    console.log(
      `\n[mailer] Password reset link for ${toEmail} (SMTP send failed):\n  ${resetUrl}\n`
    );
  }
}
