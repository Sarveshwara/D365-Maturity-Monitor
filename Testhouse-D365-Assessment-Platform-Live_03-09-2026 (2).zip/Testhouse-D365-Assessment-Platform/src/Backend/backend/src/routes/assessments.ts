import express from "express";
import { pool } from "../db.js";
import { authenticateToken, AuthRequest } from "../middleware/auth.js";

const router = express.Router();

router.use(authenticateToken);

const CONTEXT_KEY = "__assessment_context";

// ── Context helpers ──────────────────────────────────────────────
// The assessment's context (selectedDomains, implementationType,
// customerInfo) rides inside responses_data under a reserved key,
// so new context fields don't need a schema change later.

function extractContext(responses: Record<string, any> = {}) {
  const context = responses?.[CONTEXT_KEY];
  return context && typeof context === "object" && !Array.isArray(context)
    ? context
    : {};
}

function cleanResponses(responses: Record<string, any> = {}) {
  const { [CONTEXT_KEY]: _omit, ...rest } = responses ?? {};
  return rest;
}

function buildStoredResponses(
  responses: Record<string, any>,
  context?: Record<string, any>
) {
  const cleaned = cleanResponses(responses);
  if (!context || Object.keys(context).length === 0) return cleaned;
  return { ...cleaned, [CONTEXT_KEY]: context };
}

function normalizeRun(row: any) {
  const raw = row.responses_data ?? {};
  return {
    id: row.id,
    assessment_type: row.assessment_type,
    assessment_name: row.assessment_name,
    status: row.status,
    responses_data: cleanResponses(raw),
    notes_data: row.notes_data ?? {},
    assessment_context: extractContext(raw),
    overall_score: row.overall_score ?? null,
    created_by: row.created_by,
    organization_id: row.organization_id,
    run_date: row.run_date,
    completed_at: row.completed_at ?? null,
    created_by_email: row.created_by_email,
    created_by_name: row.created_by_name,
  };
}

// ── GET /api/assessments/admin/all ───────────────────────────────
// Registered before "/:id" so it isn't swallowed by that param route.
router.get("/admin/all", async (req: AuthRequest, res) => {
  const role = req.user?.role;

  if (role !== "super_admin" && role !== "customer_admin") {
    return res.status(403).json({ success: false, message: "Forbidden" });
  }

  try {
    const params: any[] = [];
    let query = `
      SELECT ar.*, u.email AS created_by_email, u.full_name AS created_by_name
      FROM assessment_runs ar
      JOIN app_users u ON u.id = ar.created_by
    `;

    if (role === "customer_admin") {
      params.push(req.user?.organizationId);
      query += ` WHERE ar.organization_id = $${params.length}`;
    }

    query += " ORDER BY ar.run_date DESC LIMIT 200";

    const result = await pool.query(query, params);
    return res.json({ success: true, runs: result.rows.map(normalizeRun) });
  } catch (error) {
    console.error("List all assessments error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── GET /api/assessments/resumable/:type ─────────────────────────
router.get("/resumable/:type", async (req: AuthRequest, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM assessment_runs
       WHERE created_by = $1 AND assessment_type = $2 AND status IN ('draft', 'in_progress')
       ORDER BY run_date DESC LIMIT 1`,
      [req.user?.id, req.params.type]
    );

    return res.json({
      success: true,
      run: result.rows[0] ? normalizeRun(result.rows[0]) : null,
    });
  } catch (error) {
    console.error("Get resumable assessment error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── POST /api/assessments — start a new run ──────────────────────
router.post("/", async (req: AuthRequest, res) => {
  try {
    const { assessmentType, name, context } = req.body;

    if (!assessmentType || !name) {
      return res.status(400).json({
        success: false,
        message: "assessmentType and name are required",
      });
    }

    const responsesData = buildStoredResponses({}, context ?? {});

    const result = await pool.query(
      `INSERT INTO assessment_runs
         (assessment_type, assessment_name, status, responses_data, notes_data, created_by, organization_id, run_date)
       VALUES ($1, $2, 'draft', $3, '{}'::jsonb, $4, $5, now())
       RETURNING id`,
      [assessmentType, name, responsesData, req.user?.id, req.user?.organizationId ?? null]
    );

    return res.status(201).json({ success: true, runId: result.rows[0].id });
  } catch (error) {
    console.error("Start assessment error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── GET /api/assessments — list runs for the current user ────────
router.get("/", async (req: AuthRequest, res) => {
  try {
    const type = req.query.type as string | undefined;
    const limit = Math.min(Number(req.query.limit ?? 5) || 5, 100);

    const params: any[] = [req.user?.id];
    let query = "SELECT * FROM assessment_runs WHERE created_by = $1";

    if (type) {
      params.push(type);
      query += ` AND assessment_type = $${params.length}`;
    }

    params.push(limit);
    query += ` ORDER BY run_date DESC LIMIT $${params.length}`;

    const result = await pool.query(query, params);
    return res.json({ success: true, runs: result.rows.map(normalizeRun) });
  } catch (error) {
    console.error("List assessments error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── GET /api/assessments/:id ──────────────────────────────────────
router.get("/:id", async (req: AuthRequest, res) => {
  try {
    const role = req.user?.role;

    // A regular customer only ever sees their own run. An admin
    // needs to open *anyone's* submission from the Assessment
    // Submissions list — that list endpoint already had this
    // distinction; this single-record fetch (what the "View" button
    // actually calls) never did, which is why every admin "View"
    // click came back empty.
    let result;

    if (role === "super_admin") {
      result = await pool.query(
        "SELECT * FROM assessment_runs WHERE id = $1",
        [req.params.id]
      );
    } else if (role === "customer_admin") {
      result = await pool.query(
        "SELECT * FROM assessment_runs WHERE id = $1 AND organization_id = $2",
        [req.params.id, req.user?.organizationId]
      );
    } else {
      result = await pool.query(
        "SELECT * FROM assessment_runs WHERE id = $1 AND created_by = $2",
        [req.params.id, req.user?.id]
      );
    }

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Assessment run not found" });
    }

    return res.json({ success: true, run: normalizeRun(result.rows[0]) });
  } catch (error) {
    console.error("Get assessment error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── PUT /api/assessments/:id/progress — autosave ─────────────────
router.put("/:id/progress", async (req: AuthRequest, res) => {
  try {
    const { responses, notes, context } = req.body;

    const existing = await pool.query(
      "SELECT responses_data, status FROM assessment_runs WHERE id = $1 AND created_by = $2",
      [req.params.id, req.user?.id]
    );
    if (existing.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Assessment run not found" });
    }

    const existingContext = extractContext(existing.rows[0].responses_data ?? {});
    const finalContext = { ...existingContext, ...(context ?? {}) };
    const storedResponses = buildStoredResponses(responses ?? {}, finalContext);

    // Never move a completed assessment back to in_progress.
    const nextStatus =
      existing.rows[0].status === "completed" ? "completed" : "in_progress";

    await pool.query(
      `UPDATE assessment_runs
       SET responses_data = $1, notes_data = $2, status = $3
       WHERE id = $4 AND created_by = $5`,
      [storedResponses, notes ?? {}, nextStatus, req.params.id, req.user?.id]
    );

    return res.json({ success: true });
  } catch (error) {
    console.error("Save progress error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── PATCH /api/assessments/:id/context — update context only ────
// Deliberately separate from /progress: must never overwrite answers
// already saved, only merge into the context block.
router.patch("/:id/context", async (req: AuthRequest, res) => {
  try {
    const { context, name } = req.body;

    const existing = await pool.query(
      "SELECT responses_data FROM assessment_runs WHERE id = $1 AND created_by = $2",
      [req.params.id, req.user?.id]
    );
    if (existing.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Assessment run not found" });
    }

    const existingResponses = cleanResponses(existing.rows[0].responses_data ?? {});
    const existingContext = extractContext(existing.rows[0].responses_data ?? {});
    const finalContext = { ...existingContext, ...(context ?? {}) };
    const storedResponses = buildStoredResponses(existingResponses, finalContext);

    // "name" is optional — Customer Info sends the latest company
    // name here so the displayed assessment name stays in sync if
    // someone corrects it after the run already exists, rather than
    // freezing at whatever was typed first.
    if (name) {
      await pool.query(
        "UPDATE assessment_runs SET responses_data = $1, assessment_name = $2 WHERE id = $3 AND created_by = $4",
        [storedResponses, name, req.params.id, req.user?.id]
      );
    } else {
      await pool.query(
        "UPDATE assessment_runs SET responses_data = $1 WHERE id = $2 AND created_by = $3",
        [storedResponses, req.params.id, req.user?.id]
      );
    }

    return res.json({ success: true });
  } catch (error) {
    console.error("Update context error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── PUT /api/assessments/:id/complete ─────────────────────────────
router.put("/:id/complete", async (req: AuthRequest, res) => {
  try {
    const { responses, notes, score, context } = req.body;

    const existing = await pool.query(
      "SELECT responses_data FROM assessment_runs WHERE id = $1 AND created_by = $2",
      [req.params.id, req.user?.id]
    );
    if (existing.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Assessment run not found" });
    }

    const existingContext = extractContext(existing.rows[0].responses_data ?? {});
    const finalContext = { ...existingContext, ...(context ?? {}) };
    const storedResponses = buildStoredResponses(responses ?? {}, finalContext);

    await pool.query(
      `UPDATE assessment_runs
       SET responses_data = $1, notes_data = $2, status = 'completed', overall_score = $3, completed_at = now()
       WHERE id = $4 AND created_by = $5`,
      [storedResponses, notes ?? {}, score, req.params.id, req.user?.id]
    );

    return res.json({ success: true });
  } catch (error) {
    console.error("Complete assessment error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// ── DELETE /api/assessments/:id — drafts/in-progress only ────────
router.delete("/:id", async (req: AuthRequest, res) => {
  try {
    await pool.query(
      `DELETE FROM assessment_runs
       WHERE id = $1 AND created_by = $2 AND status IN ('draft', 'in_progress')`,
      [req.params.id, req.user?.id]
    );

    return res.json({ success: true });
  } catch (error) {
    console.error("Delete draft error:", error);
    return res.status(500).json({ success: false, message: "Internal server error" });
  }
});

export default router;
