import express from "express";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { pool } from "../db.js";
import { authenticateToken, AuthRequest } from "../middleware/auth.js";
import { sendPasswordResetEmail } from "../mailer.js";

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "fallback_secret";
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "8h";

function signUserToken(user: {
  id: string;
  email: string;
  role: string;
  organization_id: string | null;
}) {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      role: user.role,
      organizationId: user.organization_id,
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

/**
 * Register User
 *
 * IMPORTANT: role and organizationId are never accepted from the
 * request body. Previously this endpoint trusted whatever the caller
 * sent for `role` (including "super_admin") — anyone could grant
 * themselves admin access. Every self-service signup now lands in
 * the restricted "customer" role with no organization; an admin has
 * to promote them afterwards via PUT /api/admin/users/:id (or
 * directly in the database).
 */
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Name, email and password are required"
      });
    }

    if (String(password).length < 8) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 8 characters"
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();

    const existingUser = await pool.query(
      "SELECT id FROM app_users WHERE lower(email) = $1",
      [normalizedEmail]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({
        success: false,
        message: "User already exists"
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO app_users
        (organization_id, full_name, email, password_hash, role, active)
       VALUES (NULL, $1, $2, $3, 'customer', true)
       RETURNING
        id,
        organization_id,
        full_name,
        email,
        role,
        active,
        created_at`,
      [name, normalizedEmail, passwordHash]
    );

    const user = result.rows[0];

    // Issue a token immediately so a new signup lands straight in the
    // app, the same way login does, instead of having to sign in
    // again right after registering.
    const token = signUserToken({
      id: user.id,
      email: user.email,
      role: user.role,
      organization_id: user.organization_id
    });

    res.status(201).json({
      success: true,
      message: "User registered successfully",
      token,
      user: {
        id: user.id,
        organizationId: user.organization_id,
        name: user.full_name,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {
    console.error("Registration error:", error);

    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});


/**
 * Login User
 */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required"
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();

    const result = await pool.query(
      `SELECT *
       FROM app_users
       WHERE lower(email) = $1
       AND active = true`,
      [normalizedEmail]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password"
      });
    }

    const user = result.rows[0];

    const validPassword = await bcrypt.compare(
      password,
      user.password_hash
    );

    if (!validPassword) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password"
      });
    }

    const token = signUserToken({
      id: user.id,
      email: user.email,
      role: user.role,
      organization_id: user.organization_id
    });

    await pool.query(
      `UPDATE app_users
       SET last_login_at = NOW(),
           updated_at = NOW()
       WHERE id = $1`,
      [user.id]
    );

    res.json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user.id,
        organizationId: user.organization_id,
        name: user.full_name,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {
    console.error("Login error:", error);

    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});

router.get(
  "/me",
  authenticateToken,
  async (req: AuthRequest, res) => {
    try {

      const result = await pool.query(
        `SELECT 
          id,
          organization_id,
          full_name,
          email,
          role,
          active,
          last_login_at,
          created_at
        FROM app_users
        WHERE id = $1`,
        [req.user?.id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      const user = result.rows[0];

      return res.json({
        success: true,
        // Same field names as login/register's `user` object
        // (organizationId/name, not organization_id/full_name) so
        // the frontend can treat every auth response identically.
        user: {
          id: user.id,
          organizationId: user.organization_id,
          name: user.full_name,
          email: user.email,
          role: user.role,
          active: user.active,
          createdAt: user.created_at
        }
      });

    } catch (error) {

      console.error("Get user error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal server error"
      });
    }
  }
);

/**
 * Forgot Password
 *
 * Always responds with success — whether or not the email exists —
 * so this endpoint can't be used to enumerate registered accounts.
 */
router.post("/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required"
      });
    }

    const normalizedEmail = String(email).trim().toLowerCase();

    const result = await pool.query(
      "SELECT id, email FROM app_users WHERE lower(email) = $1 AND active = true",
      [normalizedEmail]
    );

    const user = result.rows[0];

    if (user) {
      const rawToken = crypto.randomBytes(32).toString("hex");
      const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

      await pool.query(
        `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
         VALUES ($1, $2, $3)`,
        [user.id, tokenHash, expiresAt]
      );

      const appUrl = process.env.FRONTEND_URL || "http://localhost:5173";
      const resetUrl = `${appUrl}/reset-password?token=${rawToken}`;

      await sendPasswordResetEmail(user.email, resetUrl);
    }

    return res.json({ success: true, message: "If that email exists, a reset link has been sent." });

  } catch (error) {
    console.error("Forgot password error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});

/**
 * Reset Password
 */
router.post("/reset-password", async (req, res) => {
  try {
    const { token, password } = req.body;

    if (!token || !password) {
      return res.status(400).json({
        success: false,
        message: "Token and new password are required"
      });
    }

    if (String(password).length < 8) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 8 characters"
      });
    }

    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");

    const result = await pool.query(
      `SELECT id, user_id, expires_at, used_at
       FROM password_reset_tokens WHERE token_hash = $1`,
      [tokenHash]
    );

    const record = result.rows[0];

    if (
      !record ||
      record.used_at ||
      new Date(record.expires_at).getTime() < Date.now()
    ) {
      return res.status(400).json({
        success: false,
        message: "This reset link is invalid or has expired."
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    await pool.query(
      "UPDATE app_users SET password_hash = $1, updated_at = now() WHERE id = $2",
      [passwordHash, record.user_id]
    );

    await pool.query(
      "UPDATE password_reset_tokens SET used_at = now() WHERE id = $1",
      [record.id]
    );

    return res.json({ success: true, message: "Password updated successfully." });

  } catch (error) {
    console.error("Reset password error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});

export default router;
