import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { pool } from "../db.js";
import { authenticateToken, AuthRequest } from "../middleware/auth.js";

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "fallback_secret";

/**
 * Register User
 */
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, role, organizationId } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Name, email and password are required"
      });
    }

    const existingUser = await pool.query(
      "SELECT id FROM app_users WHERE email = $1",
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({
        success: false,
        message: "User already exists"
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO app_users
        (organization_id, full_name, email, password_hash, role, active)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING
        id,
        organization_id,
        full_name,
        email,
        role,
        active,
        created_at`,
      [
        organizationId || null,
        name,
        email,
        passwordHash,
        role || "user",
        true
      ]
    );

    res.status(201).json({
      success: true,
      message: "User registered successfully",
      user: result.rows[0]
    });

  } catch (error) {
    console.error("Registration error:", error);

    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});


/**
 * Login User
 */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required"
      });
    }

    const result = await pool.query(
      `SELECT *
       FROM app_users
       WHERE email = $1
       AND active = true`,
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password"
      });
    }

    const user = result.rows[0];

    const validPassword = await bcrypt.compare(
      password,
      user.password_hash
    );

    if (!validPassword) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password"
      });
    }

    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        role: user.role,
        organizationId: user.organization_id
      },
      JWT_SECRET,
      {
        expiresIn: "8h"
      }
    );

    await pool.query(
      `UPDATE app_users
       SET last_login_at = NOW(),
           updated_at = NOW()
       WHERE id = $1`,
      [user.id]
    );

    res.json({
      success: true,
      message: "Login successful",
      token,
      user: {
        id: user.id,
        organizationId: user.organization_id,
        name: user.full_name,
        email: user.email,
        role: user.role
      }
    });

  } catch (error) {
    console.error("Login error:", error);

    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});
router.get(
  "/me",
  authenticateToken,
  async (req: AuthRequest, res) => {
    try {

      const result = await pool.query(
        `SELECT 
          id,
          organization_id,
          full_name,
          email,
          role,
          active,
          last_login_at,
          created_at
        FROM app_users
        WHERE id = $1`,
        [req.user?.id]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "User not found"
        });
      }

      return res.json({
        success: true,
        user: result.rows[0]
      });

    } catch (error) {

      console.error("Get user error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal server error"
      });
    }
  }
);
export default router;