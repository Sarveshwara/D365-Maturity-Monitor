// Sets a real bcrypt password hash for an existing app_users row.
// Needed once for the seed super_admin, and useful any time you need
// to reset someone's password directly against the database.
//
// Usage:
//   npm run set-password -- admin@example.com "YourPassword123!"
import "dotenv/config";
import bcrypt from "bcryptjs";
import pg from "pg";

const [, , email, password] = process.argv;

if (!email || !password) {
  console.error('Usage: npm run set-password -- <email> "<new password>"');
  process.exit(1);
}

if (password.length < 8) {
  console.error("Password must be at least 8 characters.");
  process.exit(1);
}

const { DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD } = process.env;

const client = new pg.Client({
  host: DB_HOST,
  port: Number(DB_PORT) || 5432,
  database: DB_NAME,
  user: DB_USER,
  password: DB_PASSWORD,
});

try {
  await client.connect();
  const hash = await bcrypt.hash(password, 10);

  const result = await client.query(
    "UPDATE app_users SET password_hash = $1, updated_at = now() WHERE lower(email) = lower($2) RETURNING id, email, role",
    [hash, email]
  );

  if (result.rows.length === 0) {
    console.error(`No user found with email ${email}`);
    process.exitCode = 1;
  } else {
    console.log("Password updated for:", result.rows[0]);
  }
} catch (error) {
  console.error("Failed to update password:", error.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
