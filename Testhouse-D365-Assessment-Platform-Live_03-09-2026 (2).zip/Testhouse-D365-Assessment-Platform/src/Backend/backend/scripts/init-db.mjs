// Applies schema.sql using the DB_HOST/DB_PORT/DB_NAME/DB_USER/DB_PASSWORD
// values already in your .env (the same ones db.ts uses).
// Usage:  npm run db:init
import "dotenv/config";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import pg from "pg";

const __dirname = dirname(fileURLToPath(import.meta.url));

const { DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD } = process.env;

if (!DB_HOST || !DB_NAME || !DB_USER) {
  console.error("DB_HOST / DB_NAME / DB_USER are not set. Check your .env.");
  process.exit(1);
}

const sql = readFileSync(join(__dirname, "..", "schema.sql"), "utf8");

const client = new pg.Client({
  host: DB_HOST,
  port: Number(DB_PORT) || 5432,
  database: DB_NAME,
  user: DB_USER,
  password: DB_PASSWORD,
});

try {
  await client.connect();
  console.log(`Connected to ${DB_USER}@${DB_HOST}:${DB_PORT}/${DB_NAME}`);
  await client.query(sql);
  console.log("Schema applied successfully.");
  console.log(
    "\nA seed super_admin row was inserted (admin@example.com) with a placeholder password hash."
  );
  console.log(
    'Set a real password for it now with:\n  npm run set-password -- admin@example.com "YourPassword123!"'
  );
} catch (error) {
  console.error("Failed to apply schema:", error.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
