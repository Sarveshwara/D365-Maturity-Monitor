-- ============================================================
-- Project Orbit backend — PostgreSQL schema
--
-- Matches the columns already assumed by src/routes/auth.ts
-- (app_users: organization_id, full_name, email, password_hash,
-- role, active, last_login_at, created_at, updated_at).
--
-- Run against the "project_orbit" database you created in
-- pgAdmin4:
--   psql "postgresql://postgres:yourpassword@localhost:5432/project_orbit" -f schema.sql
-- or paste into pgAdmin4's Query Tool against that database.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto; -- gives us gen_random_uuid()

-- ── Organizations ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS organizations (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  code        TEXT UNIQUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── App users ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS app_users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  full_name       TEXT,
  email           TEXT NOT NULL,
  password_hash   TEXT NOT NULL,

  -- Matches the roles the frontend already checks for in
  -- RoleGuard/PackageContext, plus "customer" as the safe default
  -- for self-service signups.
  role            TEXT NOT NULL DEFAULT 'customer'
                    CHECK (role IN ('super_admin', 'customer_admin', 'assessor', 'viewer', 'customer')),

  active          BOOLEAN NOT NULL DEFAULT true,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_app_users_email_lower ON app_users (lower(email));
CREATE INDEX IF NOT EXISTS idx_app_users_organization ON app_users (organization_id);

-- ── Password reset tokens ───────────────────────────────────────
-- Only a hash of the token is stored — same principle as
-- password_hash. The raw token only ever exists in the emailed link.
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_password_reset_user ON password_reset_tokens (user_id);

-- ── Assessment runs ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS assessment_runs (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_type  TEXT NOT NULL DEFAULT 'QA_MATURITY'
                     CHECK (assessment_type IN ('QA_MATURITY', 'PERFORMANCE', 'SECURITY')),
  assessment_name  TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft', 'in_progress', 'completed')),

  -- Question answers ({ "Q-001": 3, ... }) plus a reserved
  -- "__assessment_context" key holding selectedDomains /
  -- implementationType / customerInfo.
  responses_data   JSONB NOT NULL DEFAULT '{}'::jsonb,
  notes_data       JSONB NOT NULL DEFAULT '{}'::jsonb,

  overall_score    NUMERIC,
  created_by       UUID NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  organization_id  UUID REFERENCES organizations(id) ON DELETE SET NULL,
  run_date         TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_assessment_runs_created_by ON assessment_runs (created_by);
CREATE INDEX IF NOT EXISTS idx_assessment_runs_org         ON assessment_runs (organization_id);
CREATE INDEX IF NOT EXISTS idx_assessment_runs_type        ON assessment_runs (assessment_type);
CREATE INDEX IF NOT EXISTS idx_assessment_runs_status      ON assessment_runs (status);

-- ============================================================
-- Seed a super_admin so someone can log in on day one.
-- Change the email, then set a real password with:
--   npm run set-password -- admin@example.com "YourPassword123!"
-- ============================================================
INSERT INTO app_users (email, password_hash, full_name, role)
VALUES ('admin@example.com', 'CHANGE_ME_VIA_set-password_SCRIPT', 'Platform Admin', 'super_admin')
ON CONFLICT (lower(email)) DO NOTHING;
