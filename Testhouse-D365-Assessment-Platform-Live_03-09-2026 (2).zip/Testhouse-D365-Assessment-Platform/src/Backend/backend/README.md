# Project Orbit backend

Express + PostgreSQL API for the D365 QA Maturity Assessment app. This is
the backend the frontend was originally wired to call
(`http://localhost:3001/api`) — it just wasn't finished before. This pass
closes a security hole in `/register`, adds password reset, adds the
assessment persistence routes, and adds a schema + setup scripts.

## ⚠️ Rotate your database password first

`.env` in this folder had a real Postgres password committed in plain
text. Treat it as compromised: change it in pgAdmin4 (right-click your
Postgres server → Properties, or `ALTER USER postgres WITH PASSWORD
'...'` in the Query Tool), update `.env` with the new one, and make sure
`.env` is never committed again (a root `.gitignore` now covers this).

## 1. Install dependencies

```bash
cd src/Backend/backend
npm install
```

## 2. Configure

Your `.env` already has `DB_HOST`/`DB_PORT`/`DB_NAME`/`DB_USER`/
`DB_PASSWORD` pointed at the `project_orbit` database you created in
pgAdmin4. Set a real `JWT_SECRET` (`openssl rand -hex 32`) if it's still
the placeholder value.

## 3. Create the schema

```bash
npm run db:init
```

Creates `organizations`, `app_users`, `assessment_runs`, and
`password_reset_tokens` in your `project_orbit` database, and seeds one
`super_admin` row (`admin@example.com`) with a placeholder password.
Set a real one:

```bash
npm run set-password -- admin@example.com "YourPassword123!"
```

## 4. Run it

```bash
npm run dev
```

Listens on `http://localhost:3001` by default, matching what the
frontend already expects (`src/app/components/services/api.ts`).

## What changed in this pass

- **Fixed a privilege-escalation bug**: `/register` used to accept
  `role` and `organizationId` straight from the request body — anyone
  could sign up as `super_admin`. New signups always land in the
  `customer` role with no organization now.
- **`/register` now returns a token**, same as `/login`, so a new
  signup is authenticated immediately instead of having to sign in
  again right after.
- **`/me`'s response now matches `/login`/`/register`'s field names**
  (`organizationId`/`name`, not `organization_id`/`full_name`) — they
  used to disagree, which the frontend had to work around.
- **Added** `/forgot-password` and `/reset-password` (token-based,
  1-hour expiry, emails via SMTP if configured in `.env`, otherwise
  logs the link to the console for local testing).
- **Added** the full assessment persistence API under
  `/api/assessments` (start / autosave / complete / get / list /
  resumable / delete / admin "list all") — this is what makes
  completed assessments actually save, show up under "My
  Assessments," and be retrievable by an admin with the customer info
  attached.
- **Cleaned up `server.ts`**: it previously called `cors()` and
  `express.json()` twice each, with two different (and conflicting)
  CORS origins — consolidated into one.
- Removed the unused native `bcrypt` dependency (the code only ever
  used `bcryptjs`).

## What's NOT covered yet

Several admin screens (Customer Management, User Role Management,
Assessment Marketplace, Notifications, Monitoring, Audit Log, UAT
Dashboard, Go-Live Checklist) still call Supabase directly via
`src/app/lib/supabase-client.ts` rather than this backend. That wasn't
in scope for this pass — the priority was the D365 assessment flow
(signup, login, taking the assessment, PDF export, "My Assessments",
admin submissions view). Migrating the rest of the admin suite is a
follow-up, same pattern: add a route here, point the frontend at it
instead of `supabase.from(...)`.

## Deploying

Right now Postgres and this API both only exist on your local machine.
Before this can run in production, both need to live somewhere
reachable over the network — `DB_HOST=localhost` and a local `npm run
dev` only work when everything is on the same machine. Once you have a
real host for each, update `.env` accordingly.
