# Changes in this pass

Scope: get off Supabase entirely for the D365 QA Maturity Assessment flow,
using the PostgreSQL database created in pgAdmin4, finish the existing
"Project Orbit" Express backend rather than build a new one, add customer
info to the PDF + admin retrieval, add self-service signup, and add a "My
Assessments" profile page. Performance/Security assessments removed from
navigation (not needed for this production deployment) but the code is
left in place.

## ⚠️ Do these two things before anything else

1. **Rotate the database password.** `src/Backend/backend/.env` had a
   real Postgres password committed in plain text
   (`DB_PASSWORD=28June1!`). Change it in pgAdmin4, update `.env` with
   the new value. A `.gitignore` now excludes `.env` going forward, but
   that doesn't undo the old one being committed — if this repo has ever
   been pushed anywhere, treat that password as burned.
2. **Run `npm install` in both `/` and `src/Backend/backend`** —
   `package.json` changed in both places (frontend: nothing new added;
   backend: dropped unused native `bcrypt`, added `nodemailer`, added
   `"type": "module"`), so the lockfiles are stale.

## Backend — `src/Backend/backend/`

This folder had a real, partially-built Express + PostgreSQL backend
already (`app_users` table, working login/register/me). It just wasn't
finished or connected to the frontend yet — the frontend's `Login.tsx`
was calling it, but nothing else was wired up, and `AuthContext.tsx` fell
back to Supabase whenever it wasn't logged in via that backend.

**Fixed:**
- **Privilege escalation in `/register`**: it accepted `role` and
  `organizationId` straight from the request body — anyone could sign up
  as `super_admin`. Now every signup is forced into the `customer` role
  with no organization, regardless of what's sent.
- **`/me`'s response used different field names than `/login`/`/register`**
  (`organization_id`/`full_name` vs `organizationId`/`name`) — now
  consistent across all three.
- **`server.ts` called `cors()` and `express.json()` twice each**, with
  two different, conflicting CORS origins — consolidated into one.
- Removed the unused native `bcrypt` package (only `bcryptjs` was
  actually used).

**Added:**
- `schema.sql` — `organizations`, `app_users` (already assumed by the
  existing code, just never had DDL), `assessment_runs`,
  `password_reset_tokens`.
- `scripts/init-db.mjs`, `scripts/set-password.mjs` — setup helpers.
- `/api/auth/forgot-password`, `/api/auth/reset-password` — token-based,
  1-hour expiry, emails via SMTP if configured, otherwise logs the link
  to the console for local testing.
- `/register` now returns a token immediately (like `/login` does), so a
  new signup is authenticated right away.
- The full assessment persistence API under `/api/assessments` — this is
  the piece that makes a completed assessment actually get saved, show up
  under "My Assessments," and be retrievable by an admin with customer
  info attached. Before this, `assessmentService.start()` was never
  called anywhere in the app, so nothing was ever actually written to a
  database, regardless of which backend was behind it.
- `tsconfig.json`, `.env.example`, `README.md` (setup steps).

## Frontend

- **`src/app/components/services/api.ts`** — extended with `register`,
  `forgotPassword`, `resetPassword` (previously only had `login`); now
  reads `VITE_API_URL` instead of a hardcoded URL.
- **`src/app/contexts/AuthContext.tsx`** — rewritten as the single real
  auth source. Previously it checked a "Project Orbit" JWT first and fell
  back to Supabase — now there's exactly one path, and it actually
  connects to the finished backend. Field names (`profile`, `user`,
  `role`, `isSuperAdmin`, etc.) kept the same so `Layout.tsx`,
  `RoleGuard.tsx`, `PackageContext.tsx`, and `DebugPanel.tsx` all keep
  working unmodified.
- **`src/app/lib/assessment-service.ts`** — rewritten against the new
  `/api/assessments/*` routes, same method signatures as the old
  Supabase-backed version (`start`/`saveProgress`/`complete`/`get`/
  `list`/`getLatestResumable`/`updateContext`/`deleteDraft`), plus a new
  `listAllForAdmin()`. `Questionnaire.tsx` and `AssessmentResults.tsx`
  needed no changes because of this.
- **`Login.tsx`** — now calls real `signIn()`; added a "Create an
  account" link.
- **`Signup.tsx`** (new) — self-service signup page.
- **`ProtectedRoute.tsx`** — checks real auth state instead of a raw
  localStorage flag.
- **`ForgotPassword.tsx` / `ResetPassword.tsx`** — `ResetPassword.tsx`
  now reads a `?token=` from the URL and calls the new reset endpoint,
  instead of relying on a Supabase session.
- **`DomainSelection.tsx`** — now actually calls `assessmentService.start()`
  with the captured customer info attached before navigating to the
  questionnaire. This was the root cause of assessments never being
  saved: the whole persistence layer existed but nothing ever called it.
- **`AssessmentResults.tsx`** — recovers customer info, selected domains,
  and implementation type from the saved run when opened via just a
  `runId` (e.g. from the admin submissions page), not only from
  fresh-navigation state.
- **`export-service.ts`** — PDF and Excel exports now include a
  "Prepared For" block with the customer's name, company, and contact
  details.
- **`MyAssessments.tsx`** (new) — customer-facing "My Assessments" page,
  linked from the profile menu in the top bar.
- **`AssessmentSubmissions.tsx`** (new, admin-only) — lists every
  submission with the captured customer/company info, linked from the
  admin sidebar.
- **`Layout.tsx`** — Performance/Security removed from the sidebar; fixed
  a pre-existing bug where `QAMaturityDashboard.tsx` called
  `assessmentService.list(...).then((runs) => runs.filter(...))` even
  though `list()` returns `{ runs, error }`, not a bare array — this
  would have thrown at runtime the first time it ran.
- **`routes.tsx`** — added `/signup`, `/profile/my-assessments`,
  `/admin/assessment-submissions`; removed the Performance/Security
  routes.

## What's explicitly NOT done

- **Performance & Security assessments**: removed from navigation only —
  the code is untouched and still has the bugs flagged in the original
  review (no answer-completeness validation before scoring, non-functional
  "Save Draft" button). Not a priority for this deployment; still there
  if you want it later.
- **The rest of the admin suite** (Customer Management, User Role
  Management, Assessment Marketplace, Notifications, Monitoring, Audit
  Log, UAT Dashboard, Go-Live Checklist) still calls Supabase directly
  via `src/app/lib/supabase-client.ts`. Migrating those follows the same
  pattern as everything above — add a route to the Express backend,
  point the component at it instead of `supabase.from(...)`.
- **Deployment**: both Postgres and the Express API only exist on your
  local machine right now. Before this goes to production, both need a
  real, network-reachable host — `localhost` only works when everything
  runs on the same machine.

## Backup files

Files that were rewritten during this pass were renamed rather than
deleted (`*.bak.*`), so nothing is lost if you want to compare or revert
something. Safe to delete once you've reviewed the changes:
- `src/app/components/auth/Login.orbit.bak.tsx`
- `src/app/components/services/api.orig.bak.ts`
- `src/app/contexts/AuthContext.supabase.bak.tsx`
- `src/app/contexts/AuthContext.hono-attempt.bak.tsx`
- `src/app/lib/assessment-service.supabase.bak.ts`
- `src/app/lib/assessment-service.hono-attempt.bak.ts`
- `src/Backend/backend/package.json.orig.bak`
- `src/Backend/backend/src/server.orig.bak.ts`
- `src/Backend/backend/src/routes/auth.orig.bak.ts`

(The `hono-attempt` ones are from an earlier pass where a parallel
backend was scaffolded before this existing Express backend was
discovered — superseded, kept only for reference.)

## Follow-up fix — assessment flow gating

Three related gaps found after initial testing:

1. **Sidebar "Questionnaire" link bypassed the whole intake flow.**
   Clicking it went straight to a blank 20-question form with no
   `runId` — meaning no customer info, no domain selection, and
   nothing ever got saved. Fixed: `Questionnaire.tsx` now checks for
   an existing draft on entry via `assessmentService.getLatestResumable()`.
   If found, it resumes it. If not, it redirects to `/assessment` so
   customer info gets captured first, the way `DomainSelection.tsx`
   always intended.
2. **Sidebar "Results" link showed a fake "0.0 / High Risk" report.**
   Same root cause — no `runId`. Fixed: `AssessmentResults.tsx` now
   redirects to `/profile/my-assessments` when there's nothing to
   show, instead of rendering zeros.
3. **Found while fixing #2: `AssessmentResults.tsx` only ever read
   `runId` from router state, never from the `:runId` route param** —
   meaning the "View" links from `MyAssessments.tsx` and
   `AssessmentSubmissions.tsx` (both of which pass it as a route
   param, not state) were silently showing blank reports since they
   were built. Fixed by reading both and preferring whichever is
   present.
4. **Notification bell showed a hardcoded "3" for every user,
   always.** There's no real notifications system behind it, so this
   was just fake data on every account. Removed the badge until a
   real notification count is wired up.

## Follow-up fix — duplicate assessments + pilot sidebar cleanup

1. **"Start Assessment" always created a new run, even with one
   already in progress.** This was the actual cause of "Save & Exit
   sends me back to customer info and I end up with two
   assessments" — `AssessmentWizard.tsx`'s Start button had the same
   gap the sidebar "Questionnaire" link had before (fixed
   previously), just on a different entry point. Now it checks
   `assessmentService.getLatestResumable()` first and resumes an
   existing draft instead of starting fresh. Evidence/notes and
   Save & Exit were kept — the bug was one missing check, not a
   reason to remove either feature.
2. **Every nav item had `alwaysVisible: true`, including all 11
   Administration sub-items** — meaning the role check
   (`super_admin`/`customer_admin` only) a few lines below it never
   actually ran for any of them; every customer saw the full
   Administration menu regardless of role (RoleGuard blocked the
   *page*, but the link itself was always shown). Fixed by removing
   `alwaysVisible` from Administration and its children so the real
   role check applies.
3. **Dashboards, Artifacts, Intelligence, and Reports hidden for
   the pilot** — none of them are wired to real data yet. Commented
   out (not deleted) in `Layout.tsx` so they're a one-line revert
   once each is actually connected.
4. **Administration trimmed to just "Assessment Submissions"** — the
   only sub-item backed by the real database. The rest (Marketplace,
   Customers, Users & Roles, Monitoring, Audit Log, UAT Test Plan,
   Go-Live Checklist, Auth Debug, Platform Settings, Notifications)
   are commented out, same reasoning as #3.

Net effect: a customer's sidebar now shows only "Assessment." An
admin's sidebar shows "Assessment" + "Administration → Assessment
Submissions."

Any assessment runs left over from before fix #1 (a "Completed" and
an orphaned "In Progress" pair for the same person) are just stale
data — safe to delete directly in pgAdmin if you want them gone:
`DELETE FROM assessment_runs WHERE status != 'completed' AND id NOT IN (SELECT id FROM assessment_runs WHERE status = 'completed');`
(review before running — this deletes ALL non-completed runs across
ALL users, fine for pilot test data, not something to run once real
customers are using it.)

## Follow-up fix — landing page + customer info dropping on resumed sessions

1. **New/returning users landed on a broken "Program Dashboard" home
   page** (mock data, visible "apiRequest is not defined" error
   banner). This was the default `"/"` route, and every login,
   signup, and several error-recovery buttons across the app
   navigate to `"/"` after their own action. Rather than patch each
   call site individually, `"/"` itself now redirects to
   `/assessment` — one change covers all of them.
2. **Customer info silently dropped from the PDF/Excel on any
   session that was ever paused and resumed.** Root cause: every
   "resume" entry point (sidebar Questionnaire link, "Start
   Assessment" finding an existing draft, "Continue" from My
   Assessments) only ever passed `{ runId }` forward — not
   `customerInfo`/`selectedDomains`/`implementationType`. Those three
   ride through router state on a fresh, uninterrupted run, but a
   resume silently reset them to nothing from that point on. On
   completion, `AssessmentResults.tsx` skips re-fetching from the
   database whenever answers are already present in state (the fast
   path for a "just completed" view) — which meant it never noticed
   customerInfo was missing and never went and got it, even though
   it was safely sitting in the database the whole time. That's why
   opening the *same* report later from My Assessments (a
   database-backed route, not state-based) showed it correctly.
   Fixed with a small background fetch that backfills just those
   three fields when they're missing, without touching the existing
   fast path for the normal case (no loading spinner, no change to
   answers already shown).

## Follow-up fix — admin couldn't open individual submissions

`GET /api/assessments/:id` (what the "View" button on Assessment
Submissions actually calls) only ever matched `created_by = the
requesting user's own id` — correct for a customer viewing their own
report, but it meant an admin got "No assessment responses were
found" on every single submission, since the admin account is never
the one who created any of them. The separate list endpoint
(`/admin/all`, what populates the submissions table itself) already
had the right role check; this single-record fetch never did.
Fixed: `super_admin` now sees any run, `customer_admin` any run in
their own organization, everyone else unchanged (their own runs
only).

Note: `customer_admin` scoping won't show anything useful yet since
self-signup currently always sets `organization_id = NULL` — there's
no org-assignment flow built. Not a blocker for `super_admin`.

## Follow-up fix — "Rendered fewer hooks than expected" crash on Results

Introduced by my own earlier entry-guard fix, not a pre-existing bug.
`AssessmentResults.tsx` had `if (!runId) { return null; }` placed
*before* several other hooks further down the component (the
score/chart `useMemo` calculations). React requires the exact same
hooks to run in the exact same order on every render of a mounted
instance — this early return skipped those later hooks whenever
`runId` was missing, but not when it was present.

Trigger: viewing a completed report (runId present, full render),
then clicking "Results" in the sidebar *while already on that page*.
Same route path, so React re-renders the existing instance rather
than mounting a new one — but the sidebar link carries no state, so
`runId` disappears on that render. Hook count changes mid-instance
→ React throws and the whole page crashes to its error boundary.
Navigating to a different page first and back "fixed" it only
because that's a genuine fresh mount, not a re-render of the same
instance.

Fixed the same way `Questionnaire.tsx` already correctly handles
this: every hook now runs unconditionally on every render; the
"nothing to show, redirect instead" decision only affects the final
JSX returned, in one place, after all hooks have already executed —
right next to the existing `loadingRun` check, which was already
correctly positioned this way.

## Management review — 5 change requests on Customer Info

1&2. **Name/email locked, pre-filled from signup.** `AssessmentCustomerInfo.tsx`
   now reads `firstName`/`lastName`/`email` from the logged-in
   account (`useAuth()`) and renders them as disabled fields — never
   editable, always the account's own signup details. Job Title stays
   editable. Added **Contact Number** with a **Country Code**
   dropdown (representative list of common codes, not exhaustive).

   **Auto-save**: a draft `assessment_runs` row is now created the
   moment the customer changes *any* field (not on page load — avoids
   a row for someone who just glances at the page), and every change
   after that debounces into a save ~800ms after they stop typing. A
   small "Saving... / Saved / Save failed" indicator shows the actual
   state. Clicking Continue flushes immediately rather than waiting
   for the debounce, so the last few keystrokes are never lost.

   This is a real behavior change worth knowing: **Customer Info now
   creates the assessment run**, not Domain Selection. Domain
   Selection was updated to update that same run via
   `updateContext()` instead of calling `start()` again (which would
   have created a duplicate on top of the auto-saved one).

   Follow-on: since a draft can now exist with customer info but no
   chosen domains yet, all three places that resume an existing draft
   (the "Start Assessment" button, the sidebar Questionnaire link, and
   "Continue" in My Assessments) now check whether
   `assessment_context.selectedDomains` exists — if not, they resume
   at Customer Info (pre-filled) instead of jumping straight into
   questions the person never actually set up.

3&5. **Organisation info + in-progress visibility in Assessment
   Submissions.** The admin table's "View" was disabled for anything
   not completed, and only showed Company/Contact/Email in the table
   itself regardless of status. Added a **Details** button on every
   row (completed or not) opening a dialog with everything captured:
   full contact info (name, email, phone, job title), full
   organisation info (company, industry, country, size), status,
   score, and start/completion timestamps. The "Report" button (full
   scored PDF-equivalent view) stays restricted to completed runs
   only, since a report needs answers that don't exist yet for a
   draft.

4. **Removed "Dynamics 365 Context" entirely** — the whole section
   (D365 Products, Project Stage) is gone from the Customer Info form,
   `AssessmentCustomerInfoData`, the PDF "Prepared For" block, and the
   Excel summary sheet. Phone now appears in both exports where
   Project Stage used to.

Files touched: `AssessmentCustomerInfo.tsx` (near-total rewrite),
`DomainSelection.tsx`, `AssessmentWizard.tsx`, `Questionnaire.tsx`,
`MyAssessments.tsx`, `AssessmentSubmissions.tsx` (near-total rewrite),
`assessment-service.ts`, `export-service.ts`. No backend or database
changes — everything rides through the existing
`__assessment_context` mechanism already in place.

## Follow-up fix — "Level 1 · Level 1" duplicate label

Every option's `label` field in `assessmentQuestions.ts` is just the
literal string `"Level 1"`, `"Level 2"`, etc. (all 20 questions × 5
levels each) — never a distinct descriptive name. The question card
and the "Current selection" indicator both did `Level {level} ·
{label}`, which always rendered as "Level 1 · Level 1" since label
already says "Level 1". Fixed in `Questionnaire.tsx` by dropping the
redundant half — both now just show "Level 1" / "Level 2 selected".

If distinct descriptive names per level are wanted later (e.g.
"Initial", "Managed", "Defined" — a CMMI-style naming, or something
Testhouse-specific), that's a content change to the `label` field in
`src/app/data/assessmentQuestions.ts` for each of the 100 options,
not a code change — the rendering already supports it correctly
once the label field there actually contains something other than
"Level N".

## Docker deployment setup

Added for handing off to the deployment team: `Dockerfile` (frontend,
multi-stage build → nginx), `nginx.conf` (serves the SPA, proxies
`/api` to the backend container internally — no CORS needed in
production), `src/Backend/backend/Dockerfile`, `docker-compose.yml`
(orchestrates db + backend + frontend), `.dockerignore` (both), and
`.env.docker.example`. Full walkthrough — including restoring the DB
backup already shared with the team, and an honest list of what
Docker does and doesn't solve (HTTPS, managed DB, secrets
management) — is in `DEPLOYMENT.md`.

No application code changed in this pass.

## Management review round 2

1. **Forgot Password — "Internal server error".** Root cause: SMTP is
   apparently now configured with real credentials on the VM (unlike
   before, when it was blank and fell back to console-logging), but
   the actual send is failing — likely a blocked outbound port or
   wrong credentials on the VM's network, which is an infrastructure
   question, not a code bug. The code bug was that a failed send
   wasn't handled gracefully: `mailer.ts` let the exception from
   `transporter.sendMail()` propagate all the way up into a 500
   response instead of falling back the same way it already does when
   SMTP isn't configured at all. Fixed: a send failure now logs the
   reset link to the backend's console (same fallback as the
   "not configured" case) and the request still succeeds from the
   user's point of view. The underlying "why is SMTP blocked/failing
   on the VM" is still worth Shivaram/Aswin checking separately (cloud
   providers often block outbound port 25 by default, sometimes 587
   too) — but it no longer breaks the feature while that gets sorted.

2. **"Draft — Completed" confusing name in My Assessments.** Real bug,
   not just a labeling nitpick: the assessment's name was fixed
   permanently at the moment a draft was first auto-saved, and fell
   back to the literal word "Draft" whenever Company Name was still
   empty at that exact moment (e.g. someone filled in Job Title
   first). That name then never updated again, even after the real
   company name was typed in and the assessment was completed — so it
   sat there forever reading like "Draft — Completed." Fixed two ways:
   (a) a run is no longer created at all until Company Name has
   something in it, so the bad fallback can't happen going forward,
   and (b) the saved name is now re-sent on every autosave, so if
   someone changes the company name after the run already exists
   (going back and forth, as you described), the displayed name stays
   in sync instead of freezing at the first value.

   Note: this doesn't retroactively fix already-existing bad-named
   records in the database (like the one in the screenshot) — those
   are just old data. If it's worth cleaning up before the next
   demo: `UPDATE assessment_runs SET assessment_name = 'D365 QA
   Maturity Assessment — <real company name>' WHERE id = '<that
   run's id>';` in pgAdmin.

3. **PDF/Excel report changes:**
   - "Domain Scores" → "Assessment Scores" (table title / Excel sheet
     name)
   - "Domain" column → "Assessment Areas" (only in this specific
     table — left the separate Recommendations table's "Domain"
     column as-is since it wasn't part of what was flagged)
   - Added a timestamp (not just date) to "Generated: ..." in both
     the PDF/Excel and the Results web page
   - Nudged the Status column right-aligned with a fixed width
     instead of centered in whatever space was left over

   The Status column alignment is a best-effort visual read from the
   screenshot — I can't render the actual PDF myself to verify
   pixel-for-pixel, so worth a quick look at the next export to
   confirm it reads the way you wanted.

Files touched: `mailer.ts`, `routes/assessments.ts` (backend),
`assessment-service.ts`, `AssessmentCustomerInfo.tsx`,
`export-service.ts`, `AssessmentResults.tsx`.

## Follow-up fix — Status column alignment + Risk Distribution overlap

1. **PDF Status column still wasn't aligning right.** My previous fix
   set `columnStyles[3].halign: "right"`, which should apply to both
   header and body per jsPDF-autotable's docs — but in practice only
   the body cells respected it; the "Status" header text stayed
   left-aligned. Fixed by setting the alignment directly on the
   header cell object itself (`{ content: "Status", styles: {
   halign: "right" } }`) instead of relying on column-level
   inheritance, which is unambiguous regardless of any style-merge
   quirk in this version of the library.

2. **Risk Distribution donut overlapping when all 3 risk levels are
   present.** There were actually two legends stacked in the same
   small chart area: Recharts' own default `<Legend />` (crammed
   right under the donut, inside the same 200px container) and a
   second, custom-built legend list right below it with colored dots
   and question counts — which was already the one doing the real
   work (it's what's showing "High Risk (L1) — 1 questions" etc.).
   The Recharts one was redundant and is what overlapped when there
   wasn't enough room for all 3 labels side by side. Removed the
   redundant one; the custom list below already covers this cleanly
   with no layout changes needed.

## Customer-restricted view (per Customer_Admin_Changes_V1.docx)

All of the following are gated on `role === "customer"` via `useAuth()`
in each component — every other role (super_admin, customer_admin,
assessor, viewer) sees the exact same experience as before, unchanged.
Scoped to "customer" specifically rather than "customer_admin" too,
since customer_admin has no real users yet (no org-assignment flow
exists) — easy to broaden later if that changes.

1. **My Assessments**: "View Results" no longer renders at all for a
   customer's completed assessments — confirmed as intentionally
   one-time-only (they see the full report once, right after
   submitting; never again after that). The card still shows name,
   status, date, and score inline either way.
2. **Domain Selection**: "20 questions across all assessment areas"
   text removed.
3. **Questionnaire**: Level 1–5 badges removed from each option,
   "Current Selection" box removed, "Supporting evidence or notes"
   field removed. Save & Exit is unchanged — still saves progress and
   returns them to My Assessments as "In Progress," resumable anytime.
4. **Questionnaire, final question**: button now reads "Submit the
   Assessment" instead of "View Results". A confirmation dialog
   ("Assessment submitted successfully") shows first — clicking
   Continue is what actually navigates to results, giving them one
   clear final acknowledgment before finishing.
5. **Results page**: both "Export Excel" buttons removed (there were
   two — one at the top, one in the footer action bar, easy to miss
   the second). "Maturity by Domain" → "Maturity by Assessments",
   "Scores by Domain" → "Scores by Assessments". The entire
   "Prioritised Recommendations" section (including its "all clear,
   no recommendations" alternate state) is removed — the page now
   ends after Scores.
6. **PDF report**: the repeated title in the header's top-right corner
   is gone. Main body heading changed from "QA Maturity Assessment" to
   "D365 QA Maturity Assessment Report". No Prioritised Recommendations
   section — since that section was the only thing that ever added a
   second page to this report, removing it naturally keeps the customer
   PDF to page 1, with no separate truncation logic needed. Excel export
   isn't reached at all since its button is hidden.

Files touched: `DomainSelection.tsx`, `Questionnaire.tsx`,
`MyAssessments.tsx`, `AssessmentResults.tsx`, `export-service.ts`. No
backend changes — this is entirely presentation-layer, driven by the
role already present in the JWT/session.
