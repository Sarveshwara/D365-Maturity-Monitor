# Quick Start Guide - VS Code Installation

## Step 1: Download Files
Download all files from Figma Make and extract them to a folder on your computer.

## Step 2: Open in VS Code
1. Open VS Code
2. Click **File** → **Open Folder**
3. Select the folder where you extracted the files

## Step 3: Open Terminal in VS Code
- Press `` Ctrl + ` `` (backtick) to open the integrated terminal
- Or go to **Terminal** → **New Terminal**

## Step 4: Install Dependencies

In the terminal, type:

```bash
npm install
```

Press **Enter** and wait 3-5 minutes for installation to complete.

**If you see errors about Node.js not found:**
- Install Node.js from https://nodejs.org/ (download the LTS version)
- Restart VS Code after installation
- Try `npm install` again

## Step 5: Start the Application

After installation completes successfully, type:

```bash
npm run dev
```

Press **Enter**. You should see:
```
VITE v6.3.5  ready in 500 ms
➜  Local:   http://localhost:5173/
```

## Step 6: Open in Browser

1. Hold **Ctrl** (or **Cmd** on Mac) and click on `http://localhost:5173/`
2. Or open your browser and go to: `http://localhost:5173/`

You should see the Testhouse login page!

## Step 7: Login

Use any email and password (mock login):
- Email: `admin@testhouse.com`
- Password: `anything`

Click **Sign In**

## ✅ Success!

You should now see the Testhouse D365 QA Maturity Platform with:
- Sidebar navigation on the left
- Testhouse logo in the sidebar
- Program Dashboard displayed

Navigate through all 25 screens using the sidebar menu!

---

## Common Issues

### ❌ "npm is not recognized"
**Solution:** Install Node.js from https://nodejs.org/

### ❌ Installation fails or hangs
**Solution:** 
1. Close VS Code
2. Delete the `node_modules` folder if it exists
3. Reopen VS Code
4. Run `npm install` again

### ❌ "Port 5173 is already in use"
**Solution:** Vite will automatically use port 5174 or 5175

### ❌ White blank screen in browser
**Solution:** 
1. Check VS Code terminal for errors (red text)
2. Press F12 in browser to open console and check for errors
3. Make sure `npm run dev` is still running

---

## Stopping the Application

In VS Code terminal:
- Press **Ctrl + C**
- Type `Y` and press Enter

## Restarting Later

1. Open VS Code
2. Open the project folder
3. Open terminal (`` Ctrl + ` ``)
4. Type `npm run dev`

---

**Need more help?** See `SETUP_GUIDE.md` for detailed troubleshooting.
