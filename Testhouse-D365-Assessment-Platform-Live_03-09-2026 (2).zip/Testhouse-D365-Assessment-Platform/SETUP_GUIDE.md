# Testhouse D365 QA Maturity Platform - Setup Guide

## Prerequisites

Before you begin, ensure you have the following installed on your system:

- **Node.js** (version 18 or higher) - [Download here](https://nodejs.org/)
- **npm** (comes with Node.js) or **pnpm** (recommended)
- **VS Code** (or any code editor)

To check if Node.js is installed, run:
```bash
node --version
npm --version
```

## Step-by-Step Installation Guide

### 1. Download and Extract Project Files

1. Download all the source files from Figma Make
2. Create a new folder on your computer (e.g., `testhouse-qa-platform`)
3. Extract all files maintaining the folder structure

### 2. Verify Project Structure

Your project should have this structure:
```
testhouse-qa-platform/
├── src/
│   ├── app/
│   │   ├── components/
│   │   ├── App.tsx
│   │   └── routes.tsx
│   └── styles/
├── package.json
├── vite.config.ts
├── postcss.config.mjs
└── README.md (or SETUP_GUIDE.md)
```

### 3. Create Missing Configuration Files

**IMPORTANT:** Create these files if they don't exist:

#### Create `index.html` in the root directory:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Testhouse D365 QA Maturity Platform</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

#### Create `src/main.tsx`:

```tsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './app/App'
import './styles/index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
```

#### Create `tsconfig.json` in the root directory:

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

#### Create `tsconfig.node.json`:

```json
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts"]
}
```

### 4. Update package.json

Open `package.json` and ensure it has the correct scripts section:

```json
{
  "name": "testhouse-qa-platform",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0"
  },
  "dependencies": {
    "@emotion/react": "^11.14.0",
    "@emotion/styled": "^11.14.1",
    "@mui/icons-material": "^7.3.5",
    "@mui/material": "^7.3.5",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router": "^7.13.0",
    "recharts": "^2.15.2"
  },
  "devDependencies": {
    "@tailwindcss/vite": "^4.1.12",
    "@types/react": "^18.3.1",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.7.0",
    "tailwindcss": "^4.1.12",
    "typescript": "^5.3.3",
    "vite": "^6.3.5"
  }
}
```

### 5. Handle Figma Assets

Since the project uses `figma:asset` imports for the logo, you need to:

**Option A - Replace with Local Image:**
1. Download the Testhouse logo from https://www.testhouse.net/
2. Save it in `public/logo.png`
3. Update all imports:
   - Change `import testhouseLogo from "figma:asset/..."` 
   - To `import testhouseLogo from "/logo.png"`

**Option B - Use External URL:**
```tsx
// Replace figma:asset imports with:
const testhouseLogo = "https://www.testhouse.net/wp-content/uploads/2021/03/logo.png";
```

Files to update:
- `src/app/components/Layout.tsx`
- `src/app/components/auth/Login.tsx`

### 6. Install Dependencies

Open terminal in the project root directory and run:

```bash
# Using npm (recommended for beginners)
npm install

# OR using pnpm (faster, if you have it installed)
pnpm install

# OR using yarn
yarn install
```

**Note:** The installation may take 3-5 minutes depending on your internet connection.

### 7. Start the Development Server

After installation completes successfully, run:

```bash
npm run dev
```

You should see output like:
```
  VITE v6.3.5  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

### 8. Open in Browser

Open your browser and navigate to `http://localhost:5173/`

You should see the Testhouse D365 QA Maturity Platform login screen!

## Common Installation Issues and Solutions

### Issue 1: "command not found: npm"
**Solution:** Node.js is not installed. Download and install from https://nodejs.org/

### Issue 2: "Cannot find module 'react'"
**Solution:** Dependencies not installed. Run `npm install` again

### Issue 3: Port 5173 already in use
**Solution:** Either:
- Kill the process using that port
- Vite will automatically use the next available port (5174, 5175, etc.)

### Issue 4: TypeScript errors about missing types
**Solution:** Install type definitions:
```bash
npm install --save-dev @types/react @types/react-dom @types/node
```

### Issue 5: "figma:asset" import errors
**Solution:** Replace all figma:asset imports with local images or URLs (see Step 5)

### Issue 6: Module resolution errors
**Solution:** Ensure `tsconfig.json` has the correct paths configuration

### Issue 7: Build fails with "Cannot find module"
**Solution:** 
1. Delete `node_modules` folder
2. Delete `package-lock.json` file
3. Run `npm install` again

### Issue 8: Styles not loading
**Solution:** Ensure all CSS files exist in `src/styles/` directory:
- `index.css`
- `theme.css`
- `tailwind.css`
- `fonts.css`

## Building for Production

To create a production build:

```bash
npm run build
```

This creates an optimized build in the `dist/` folder that you can deploy to any web server.

To preview the production build locally:

```bash
npm run preview
```

## VS Code Recommended Extensions

Install these extensions for the best development experience:

1. **ES7+ React/Redux/React-Native snippets**
2. **Prettier - Code formatter**
3. **ESLint**
4. **Tailwind CSS IntelliSense**
5. **TypeScript Vue Plugin (Volar)**

## Project Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint to check code quality

## Need Help?

If you encounter issues not covered here:

1. Check the browser console for error messages (F12)
2. Check the terminal where you ran `npm run dev` for server errors
3. Ensure all files are in the correct folder structure
4. Make sure all dependencies are installed with `npm install`
5. Try deleting `node_modules` and reinstalling

## Next Steps

After successful installation:

1. Explore the platform by logging in (any credentials work - it's a mock login)
2. Navigate through the 25 different screens using the sidebar
3. Customize the theme in `src/app/App.tsx`
4. Add real API integrations where needed
5. Configure authentication with your identity provider

---

**Developed with Figma Make**  
**Platform:** Testhouse D365 Quality Assurance Maturity Platform  
**Version:** 1.0.0
