# Deployment Guide

## Is Docker the right approach?

Yes, for what you're doing here — handing this off to be deployed on
infrastructure you don't control day-to-day. It solves the problem
you'd otherwise hit immediately: your machine has a specific Node
version, a specific Postgres version, and specific installed
packages, and none of that travels with a plain code handoff. Docker
packages all of it — so whoever runs `docker compose up` on the
target server gets the exact same environment you tested against,
not whatever happens to already be on that machine.

**What Docker does NOT solve on its own** — these still need
deciding, separately from the Docker setup itself:

- **A real server to run it on.** Docker doesn't provide hosting —
  you still need a VM (cloud or on-prem) with Docker installed, and a
  public IP or domain pointed at it.
- **HTTPS.** The app takes real login passwords. Serving it over
  plain HTTP means those passwords travel in cleartext over the
  network — not acceptable for anything beyond a same-machine test.
  This setup doesn't include TLS termination; the standard next step
  is putting this behind a reverse proxy that handles it (Caddy is
  the simplest — it gets free, auto-renewing HTTPS from Let's Encrypt
  with almost no config — or your cloud provider's own load
  balancer/ingress if you're on AWS/Azure/GCP).
- **Database durability.** The `db` service here uses a Docker named
  volume, which survives container restarts and `docker compose
  down` — but not the underlying disk failing. Fine for a pilot;
  for real customer data long-term, a managed Postgres service (AWS
  RDS, Azure Database for PostgreSQL, etc.) handles backups and
  failover for you instead of being one more thing to build
  yourselves.
- **Secrets management.** `.env` still holds real passwords in plain
  text on the server's disk. Fine for a pilot behind a firewall;
  a proper secrets manager (AWS Secrets Manager, Azure Key Vault,
  Doppler, etc.) is the next step up if this becomes permanent
  infrastructure.

None of these block a pilot deployment. They're the honest list of
"what's next" once this moves past pilot.

## What's in this Docker setup

- **`Dockerfile`** (repo root) — builds the React/Vite frontend into
  static files, serves them with nginx.
- **`nginx.conf`** — serves the frontend and proxies `/api/*`
  requests to the backend container internally. This means the
  browser only ever talks to one origin — no CORS configuration
  needed in production, and only one domain/port to expose publicly.
- **`src/Backend/backend/Dockerfile`** — runs the Express API.
- **`docker-compose.yml`** — wires up three services: `db`
  (Postgres), `backend` (the API), `frontend` (nginx). Only
  `frontend` is exposed to the host (port 80) — `backend` and `db`
  are only reachable from inside Docker's internal network, which is
  a real reduction in attack surface (nothing can hit your API or
  database directly from the internet, only through the app).

## First-time setup

### 1. Install Docker

If the target server doesn't have it: https://docs.docker.com/engine/install/
(Docker Compose is bundled with modern Docker installs as `docker compose`.)

### 2. Configure secrets

```bash
cp .env.docker.example .env
```

Edit `.env` and fill in a real `DB_PASSWORD` and `JWT_SECRET`
(`openssl rand -hex 32` for the latter). This `.env` is what
`docker-compose.yml` reads — it's a different file from
`src/Backend/backend/.env`, which is only used when running the
backend directly with `npm run dev` outside Docker.

### 3. Build and start everything

```bash
docker compose up -d --build
```

First run pulls the Postgres and Node/nginx base images and builds
your two application images — takes a few minutes. Subsequent
restarts are fast.

Check everything actually started:

```bash
docker compose ps
```

All three services should show as `running` (or `healthy` for `db`).

### 4. Set up the database — pick ONE of these two

**If you're restoring the DB backup you already shared with the
team** (skip step 4b — the backup already contains the schema):

```bash
# Plain SQL dump (pg_dump without -Fc):
docker compose exec -T db psql -U <DB_USER> -d <DB_NAME> < your-backup.sql

# Custom-format dump (pg_dump -Fc), use pg_restore instead:
docker compose exec -T db pg_restore -U <DB_USER> -d <DB_NAME> --clean --if-exists < your-backup.dump
```

Use the same `DB_USER`/`DB_NAME` you put in `.env`.

**After restoring an older backup, also run:**

```bash
docker compose exec backend npm run db:init
```

Every statement in `schema.sql` is `CREATE TABLE IF NOT EXISTS` /
`CREATE INDEX IF NOT EXISTS`, so this is safe to run against a
database that already has real data — it only adds whatever tables
the schema has gained *since* your backup was taken, without
touching or duplicating anything already there. This matters because
the schema has changed more than once during development (e.g.
`password_reset_tokens` was added partway through) — a backup from
before that point won't have it, and "Forgot Password" will fail with
`relation "password_reset_tokens" does not exist` until you run this.

**If starting completely fresh instead** (no backup to restore):

```bash
docker compose exec backend npm run db:init
docker compose exec backend npm run set-password -- admin@example.com "YourNewPassword123!"
```

### 5. Verify

```bash
curl http://localhost/api/health
```

Should return `{"success":true,"status":"healthy","database":"connected"}`.
Then open `http://<server-address>/` in a browser and confirm login
works.

## Day-to-day operations

**View logs** (add `-f` to follow live):
```bash
docker compose logs backend
docker compose logs frontend
```

**Redeploy after a code change:**
```bash
git pull   # or however new code arrives on the server
docker compose up -d --build
```

**Stop everything** (keeps data):
```bash
docker compose down
```

**Stop and delete all data** (careful — wipes the database):
```bash
docker compose down -v
```

**Back up the database** going forward:
```bash
docker compose exec -T db pg_dump -U <DB_USER> <DB_NAME> > backup-$(date +%Y%m%d).sql
```

## Postgres version note

`docker-compose.yml` uses `postgres:18-alpine` to match the version
you've been developing against (per your pgAdmin screenshots). If
that exact tag isn't available yet when your team builds this, drop
back to `postgres:16-alpine` in `docker-compose.yml` — but check
what version your DB backup was taken from first (`pg_dump --version`
or the header line of the .sql file itself) and try to match it,
since restoring across a big version jump can occasionally hit
compatibility snags.
