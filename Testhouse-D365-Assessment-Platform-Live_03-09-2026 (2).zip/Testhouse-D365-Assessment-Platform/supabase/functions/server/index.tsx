import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";

const app = new Hono();

app.use('*', logger(console.log));
app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
}));

const db = () => createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// ── Health ────────────────────────────────────────────────────
app.get("/make-server-c8ac5349/health", (c) => c.json({ status: "ok" }));

// ── Assessment Domains ────────────────────────────────────────
app.get("/make-server-c8ac5349/domains", async (c) => {
  const { data, error } = await db().from("assessment_domains").select("*").order("domain_name");
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// ── Assessment Packages ───────────────────────────────────────
app.get("/make-server-c8ac5349/packages", async (c) => {
  const { data, error } = await db()
    .from("assessment_packages")
    .select(`*, package_domains(domain_id, domains(domain_code, domain_name, route_prefix, icon))`)
    .order("package_name");
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

app.post("/make-server-c8ac5349/packages", async (c) => {
  const body = await c.req.json();
  const { data, error } = await db().from("assessment_packages").insert(body).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data, 201);
});

app.put("/make-server-c8ac5349/packages/:id/toggle", async (c) => {
  const id = c.req.param("id");
  const { data: pkg } = await db().from("assessment_packages").select("active").eq("id", id).single();
  const { data, error } = await db()
    .from("assessment_packages").update({ active: !pkg?.active }).eq("id", id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// ── Organizations ─────────────────────────────────────────────
app.get("/make-server-c8ac5349/organizations", async (c) => {
  const { data, error } = await db()
    .from("organizations")
    .select(`*, customer_subscriptions(id, active, start_date, end_date, notes, assessment_packages(id, package_code, package_name, color))`)
    .order("name");
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

app.post("/make-server-c8ac5349/organizations", async (c) => {
  const body = await c.req.json();
  const { data, error } = await db().from("organizations").insert(body).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data, 201);
});

app.put("/make-server-c8ac5349/organizations/:id", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const { data, error } = await db().from("organizations").update(body).eq("id", id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// ── Customer Subscriptions ────────────────────────────────────
app.get("/make-server-c8ac5349/subscriptions", async (c) => {
  const orgId = c.req.query("org_id");
  let query = db()
    .from("customer_subscriptions")
    .select(`*, organizations(name, code), assessment_packages(package_code, package_name, color)`);
  if (orgId) query = query.eq("organization_id", orgId);
  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

app.post("/make-server-c8ac5349/subscriptions", async (c) => {
  const body = await c.req.json();
  const { data, error } = await db()
    .from("customer_subscriptions")
    .upsert({ ...body, active: true }, { onConflict: "organization_id,package_id" })
    .select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data, 201);
});

app.put("/make-server-c8ac5349/subscriptions/:id/toggle", async (c) => {
  const id = c.req.param("id");
  const { data: sub } = await db().from("customer_subscriptions").select("active").eq("id", id).single();
  const { data, error } = await db()
    .from("customer_subscriptions").update({ active: !sub?.active }).eq("id", id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

app.delete("/make-server-c8ac5349/subscriptions/:id", async (c) => {
  const id = c.req.param("id");
  const { error } = await db().from("customer_subscriptions").delete().eq("id", id);
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ success: true });
});

// ── Entitlement: accessible routes for an org ─────────────────
// Returns the list of route prefixes the org is entitled to access.
app.get("/make-server-c8ac5349/organizations/:orgId/entitlements", async (c) => {
  const orgId = c.req.param("orgId");
  const { data, error } = await db()
    .from("vw_org_accessible_routes")
    .select("route_prefix")
    .eq("organization_id", orgId);
  if (error) return c.json({ error: error.message }, 500);
  const routes = [...new Set(data?.map((r: any) => r.route_prefix) ?? [])];
  return c.json({ organization_id: orgId, accessible_routes: routes });
});

// ── App Users ─────────────────────────────────────────────────
app.get("/make-server-c8ac5349/users", async (c) => {
  const orgId = c.req.query("org_id");
  let query = db().from("app_users").select(`*, organizations(name, code)`);
  if (orgId) query = query.eq("organization_id", orgId);
  const { data, error } = await query.order("full_name");
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

app.post("/make-server-c8ac5349/users", async (c) => {
  const body = await c.req.json();
  const { data, error } = await db().from("app_users").insert(body).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data, 201);
});

app.put("/make-server-c8ac5349/users/:id", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const { data, error } = await db().from("app_users").update(body).eq("id", id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// ── Profile-based User Management ────────────────────────────
// Lists all users from the profiles table (auth-linked)
app.get("/make-server-c8ac5349/profiles", async (c) => {
  const orgId = c.req.query("org_id");
  let query = db()
    .from("profiles")
    .select(`*, organizations(id, name, code)`);
  if (orgId) query = query.eq("organization_id", orgId);
  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// Update a user's role or organization
app.put("/make-server-c8ac5349/profiles/:id", async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();
  const allowed = ["role", "organization_id", "full_name", "active"];
  const update = Object.fromEntries(Object.entries(body).filter(([k]) => allowed.includes(k)));
  const { data, error } = await db().from("profiles").update(update).eq("id", id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// Invite a new user via Supabase Auth (sends invitation email)
app.post("/make-server-c8ac5349/profiles/invite", async (c) => {
  const { email, role, organization_id, full_name } = await c.req.json();
  const supabase = db();

  // Invite user via Supabase Auth Admin API
  const { data: authData, error: authErr } = await supabase.auth.admin.inviteUserByEmail(email, {
    data: { full_name, role: role ?? "assessor" },
  });
  if (authErr) return c.json({ error: authErr.message }, 500);

  // Set the profile org and role immediately (trigger creates profile row)
  if (authData?.user?.id) {
    await supabase.from("profiles").upsert({
      id: authData.user.id,
      full_name: full_name ?? email,
      role: role ?? "assessor",
      organization_id: organization_id ?? null,
    }, { onConflict: "id" });
  }

  return c.json({ success: true, user_id: authData?.user?.id }, 201);
});

// Deactivate / reactivate a user (toggle active flag)
app.put("/make-server-c8ac5349/profiles/:id/toggle", async (c) => {
  const id = c.req.param("id");
  const { data: current } = await db().from("profiles").select("active").eq("id", id).single();
  const { data, error } = await db()
    .from("profiles").update({ active: !current?.active }).eq("id", id).select().single();
  if (error) return c.json({ error: error.message }, 500);
  return c.json(data);
});

// Send password reset email
app.post("/make-server-c8ac5349/profiles/:id/reset-password", async (c) => {
  const id = c.req.param("id");
  const { data: authUser, error: fetchErr } = await db().auth.admin.getUserById(id);
  if (fetchErr || !authUser?.user?.email) return c.json({ error: "User not found" }, 404);

  const { error } = await db().auth.admin.generateLink({
    type: "recovery",
    email: authUser.user.email,
  });
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ success: true });
});

// ── Audit Logs ────────────────────────────────────────────────
app.get("/make-server-c8ac5349/audit-logs", async (c) => {
  const limit   = parseInt(c.req.query("limit")  ?? "50");
  const offset  = parseInt(c.req.query("offset") ?? "0");
  const orgId   = c.req.query("org_id");
  const type    = c.req.query("event_type");

  let query = db()
    .from("vw_audit_logs")
    .select("*")
    .order("created_at", { ascending: false })
    .range(offset, offset + limit - 1);

  if (orgId) query = query.eq("organization_id", orgId);
  if (type)  query = query.eq("event_type", type);

  const { data, error, count } = await query;
  if (error) return c.json({ error: error.message }, 500);
  return c.json({ data, count });
});

// ── Dashboard Stats (for executive + program dashboards) ─────────
app.get("/make-server-c8ac5349/dashboard-stats", async (c) => {
  const supabase = db();

  // Fetch all completed runs
  const { data: runs } = await supabase
    .from("assessment_runs")
    .select("id, assessment_type, assessment_name, status, overall_score, created_by, organization_id, run_date, completed_at, responses_data")
    .order("run_date", { ascending: false });

  const allRuns   = runs ?? [];
  const completed = allRuns.filter((r: any) => r.status === "completed");
  const draft     = allRuns.filter((r: any) => r.status === "draft");
  const inProgress= allRuns.filter((r: any) => r.status === "in_progress");

  // Average score by type
  const avgByType: Record<string, number> = {};
  const typeGroups: Record<string, number[]> = {};
  for (const r of completed) {
    if (r.overall_score != null) {
      if (!typeGroups[r.assessment_type]) typeGroups[r.assessment_type] = [];
      typeGroups[r.assessment_type].push(r.overall_score);
    }
  }
  for (const [type, scores] of Object.entries(typeGroups)) {
    avgByType[type] = scores.reduce((a: number, b: number) => a + b, 0) / scores.length;
  }

  // Runs by month (last 6 months)
  const now = new Date();
  const monthlyTrend = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const label = d.toLocaleDateString("en-GB", { month: "short", year: "2-digit" });
    const inMonth = completed.filter((r: any) => {
      const rd = new Date(r.run_date);
      return rd.getFullYear() === d.getFullYear() && rd.getMonth() === d.getMonth();
    });
    return {
      month: label,
      total: inMonth.length,
      qa:    inMonth.filter((r: any) => r.assessment_type === "QA_MATURITY").length,
      perf:  inMonth.filter((r: any) => r.assessment_type === "PERFORMANCE").length,
      sec:   inMonth.filter((r: any) => r.assessment_type === "SECURITY").length,
    };
  });

  // Recent runs (last 10)
  const recentRuns = allRuns.slice(0, 10).map((r: any) => ({
    id: r.id,
    name: r.assessment_name ?? r.assessment_type,
    type: r.assessment_type,
    status: r.status,
    score: r.overall_score,
    run_date: r.run_date,
    completed_at: r.completed_at,
  }));

  // Domain breakdown from QA runs (extract category scores from responses_data)
  const qaRuns = completed.filter((r: any) => r.assessment_type === "QA_MATURITY" && r.responses_data);
  const domainTotals: Record<string, { sum: number; count: number }> = {};
  for (const run of qaRuns) {
    const responses = run.responses_data;
    if (typeof responses === "object") {
      for (const [qid, score] of Object.entries(responses)) {
        if (!domainTotals[qid]) domainTotals[qid] = { sum: 0, count: 0 };
        domainTotals[qid].sum += score as number;
        domainTotals[qid].count += 1;
      }
    }
  }

  // Status distribution
  const statusDist = [
    { name: "Completed",   value: completed.length,  color: "#107C10" },
    { name: "In Progress", value: inProgress.length, color: "#0F6CBD" },
    { name: "Draft",       value: draft.length,      color: "#E0E4EC" },
  ].filter((d: any) => d.value > 0);

  return c.json({
    kpis: {
      totalRuns:      allRuns.length,
      completedRuns:  completed.length,
      inProgressRuns: inProgress.length,
      draftRuns:      draft.length,
      completionRate: allRuns.length > 0 ? Math.round((completed.length / allRuns.length) * 100) : 0,
      avgScoreQA:     avgByType["QA_MATURITY"] ?? null,
      avgScorePerf:   avgByType["PERFORMANCE"] ?? null,
      avgScoreSec:    avgByType["SECURITY"] ?? null,
    },
    monthlyTrend,
    recentRuns,
    statusDist,
    byType: {
      QA_MATURITY: completed.filter((r: any) => r.assessment_type === "QA_MATURITY").length,
      PERFORMANCE: completed.filter((r: any) => r.assessment_type === "PERFORMANCE").length,
      SECURITY:    completed.filter((r: any) => r.assessment_type === "SECURITY").length,
    },
  });
});

// ── Platform Stats (for monitoring dashboard) ─────────────────
app.get("/make-server-c8ac5349/stats", async (c) => {
  const supabase = db();
  const [
    { count: userCount },
    { count: orgCount },
    { count: activeOrgCount },
    { count: totalRuns },
    { count: completedRuns },
    { count: drafts },
    { data: recentEvents },
    { data: runsByType },
  ] = await Promise.all([
    supabase.from("profiles")          .select("*", { count: "exact", head: true }),
    supabase.from("organizations")     .select("*", { count: "exact", head: true }),
    supabase.from("organizations")     .select("*", { count: "exact", head: true }).eq("active", true),
    supabase.from("assessment_runs")   .select("*", { count: "exact", head: true }),
    supabase.from("assessment_runs")   .select("*", { count: "exact", head: true }).eq("status", "completed"),
    supabase.from("assessment_runs")   .select("*", { count: "exact", head: true }).eq("status", "draft"),
    supabase.from("vw_audit_logs")     .select("event_type,user_name,org_name,created_at").limit(10),
    supabase.from("assessment_runs")   .select("assessment_type").eq("status", "completed"),
  ]);

  // Count by type
  const byType: Record<string, number> = {};
  for (const r of runsByType ?? []) {
    const t = r.assessment_type ?? "Unknown";
    byType[t] = (byType[t] ?? 0) + 1;
  }

  return c.json({
    users:         userCount ?? 0,
    organizations: orgCount  ?? 0,
    activeOrgs:    activeOrgCount ?? 0,
    totalRuns:     totalRuns ?? 0,
    completedRuns: completedRuns ?? 0,
    draftRuns:     drafts ?? 0,
    completionRate: totalRuns
      ? Math.round(((completedRuns ?? 0) / (totalRuns as number)) * 100)
      : 0,
    byType,
    recentEvents: recentEvents ?? [],
  });
});

Deno.serve(app.fetch);
